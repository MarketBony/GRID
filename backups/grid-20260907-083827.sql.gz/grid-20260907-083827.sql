--
-- PostgreSQL database dump
--

\restrict taNZo5oKaVD4U9RG3XComGMkggzetr13odm3dLhg9lq0mticKDQ8UxsWnPKxLDc

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.11 (Ubuntu 17.11-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: relance; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA relance;


--
-- Name: a_role_global(text); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.a_role_global(p_role text) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
  SELECT EXISTS (
    SELECT 1 FROM relance.role_global rg
    WHERE rg.utilisateur_id = relance.utilisateur_courant()
      AND rg.role = p_role
  )
$$;


--
-- Name: campagne_definir_creneaux(bigint, text[], text[], text, text); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.campagne_definir_creneaux(p_campagne_id bigint, p_codes text[], p_libelles text[], p_mode text DEFAULT NULL::text, p_vers text DEFAULT NULL::text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_administration();
  retires text[];
  ajoutes text[];
  impactes int;
  detail jsonb;
  i int;
BEGIN
  IF p_codes IS NULL OR array_length(p_codes, 1) IS NULL THEN
    RAISE EXCEPTION 'RELANCE: au moins un creneau est requis.';
  END IF;
  IF array_length(p_codes, 1) <> array_length(p_libelles, 1) THEN
    RAISE EXCEPTION 'RELANCE: chaque creneau doit porter un libelle.';
  END IF;
  IF (SELECT count(DISTINCT c) FROM unnest(p_codes) c) <> array_length(p_codes, 1) THEN
    RAISE EXCEPTION 'RELANCE: un creneau est present deux fois.';
  END IF;
  IF NOT relance.campagne_ouverte(p_campagne_id) THEN
    RAISE EXCEPTION 'RELANCE: campagne cloturee, ses creneaux ne sont plus modifiables.';
  END IF;

  SELECT coalesce(array_agg(cc.code ORDER BY cc.ordre), '{}')
    INTO retires
    FROM relance.campagne_creneau cc
   WHERE cc.campagne_id = p_campagne_id AND NOT (cc.code = ANY (p_codes));

  SELECT coalesce(array_agg(c), '{}')
    INTO ajoutes
    FROM unnest(p_codes) c
   WHERE NOT EXISTS (
     SELECT 1 FROM relance.campagne_creneau cc
      WHERE cc.campagne_id = p_campagne_id AND cc.code = c
   );

  SELECT count(*)::int,
         coalesce(jsonb_agg(jsonb_build_object('creneau', s.code, 'actifs', s.actifs, 'archives', s.archives)), '[]'::jsonb)
    INTO impactes, detail
    FROM (
      SELECT r.creneau_code AS code,
             count(*) FILTER (WHERE r.archive_le IS NULL) AS actifs,
             count(*) FILTER (WHERE r.archive_le IS NOT NULL) AS archives
        FROM relance.rdv r
       WHERE r.campagne_id = p_campagne_id AND r.creneau_code = ANY (retires)
       GROUP BY r.creneau_code
    ) s;

  SELECT coalesce(sum((x->>'actifs')::int + (x->>'archives')::int), 0)::int
    INTO impactes FROM jsonb_array_elements(detail) x;

  IF impactes > 0 AND coalesce(p_mode, '') <> 'deplacer' THEN
    RETURN jsonb_build_object(
      'applique', false, 'code', 'RDV_IMPACTES',
      'retires', to_jsonb(retires), 'ajoutes', to_jsonb(ajoutes),
      'impacts', detail, 'creneauxConserves', to_jsonb(p_codes),
      'message', format('Retirer ces creneaux supprimerait le rattachement de %s RDV. Choisir : annuler, ou deplacer ces RDV vers un creneau conserve.', impactes)
    );
  END IF;

  IF impactes > 0 AND (p_vers IS NULL OR NOT (p_vers = ANY (p_codes))) THEN
    RAISE EXCEPTION 'RELANCE: le creneau de destination doit faire partie des creneaux conserves.';
  END IF;

  FOR i IN 1 .. array_length(p_codes, 1) LOOP
    INSERT INTO relance.campagne_creneau (campagne_id, code, libelle, ordre, cree_par)
    VALUES (p_campagne_id, p_codes[i], p_libelles[i], i, moi)
    ON CONFLICT (campagne_id, code) DO UPDATE SET libelle = EXCLUDED.libelle, ordre = EXCLUDED.ordre;
  END LOOP;

  IF impactes > 0 THEN
    UPDATE relance.rdv r
       SET creneau_code = p_vers, modifie_le = now(), modifie_par = moi
     WHERE r.campagne_id = p_campagne_id AND r.creneau_code = ANY (retires);
  END IF;

  IF array_length(retires, 1) IS NOT NULL THEN
    DELETE FROM relance.campagne_creneau cc
     WHERE cc.campagne_id = p_campagne_id AND cc.code = ANY (retires);
  END IF;

  RETURN jsonb_build_object(
    'applique', true, 'retires', to_jsonb(retires), 'ajoutes', to_jsonb(ajoutes),
    'rdvDeplaces', impactes, 'versCreneau', to_jsonb(p_vers),
    'creneaux', (SELECT coalesce(jsonb_agg(jsonb_build_object('code', cc.code, 'libelle', cc.libelle, 'ordre', cc.ordre) ORDER BY cc.ordre), '[]'::jsonb)
                   FROM relance.campagne_creneau cc WHERE cc.campagne_id = p_campagne_id)
  );
END $$;


--
-- Name: campagne_definir_jours(bigint, date[], text, date); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.campagne_definir_jours(p_campagne_id bigint, p_jours date[], p_mode text DEFAULT NULL::text, p_vers date DEFAULT NULL::date) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_administration();
  retires date[];
  ajoutes date[];
  impactes int;
  detail jsonb;
  i int;
BEGIN
  IF p_jours IS NULL OR array_length(p_jours, 1) IS NULL THEN
    RAISE EXCEPTION 'RELANCE: au moins un jour est requis.';
  END IF;
  IF (SELECT count(DISTINCT j) FROM unnest(p_jours) j) <> array_length(p_jours, 1) THEN
    RAISE EXCEPTION 'RELANCE: un jour est present deux fois.';
  END IF;
  IF NOT relance.campagne_ouverte(p_campagne_id) THEN
    RAISE EXCEPTION 'RELANCE: campagne cloturee, ses jours ne sont plus modifiables.';
  END IF;

  SELECT coalesce(array_agg(cj.jour ORDER BY cj.jour), '{}')
    INTO retires
    FROM relance.campagne_jour cj
   WHERE cj.campagne_id = p_campagne_id
     AND NOT (cj.jour = ANY (p_jours));

  SELECT coalesce(array_agg(j ORDER BY j), '{}')
    INTO ajoutes
    FROM unnest(p_jours) j
   WHERE NOT EXISTS (
     SELECT 1 FROM relance.campagne_jour cj
      WHERE cj.campagne_id = p_campagne_id AND cj.jour = j
   );

  -- Les RDV impactes, ARCHIVES COMPRIS : un RDV archive reste rattache a son jour
  -- par la cle etrangere, donc il bloque le retrait exactement comme un actif.
  SELECT count(*)::int,
         coalesce(jsonb_agg(x ORDER BY x->>'jour'), '[]'::jsonb)
    INTO impactes, detail
    FROM (
      SELECT jsonb_build_object(
               'jour', r.jour,
               'actifs', count(*) FILTER (WHERE r.archive_le IS NULL),
               'archives', count(*) FILTER (WHERE r.archive_le IS NOT NULL),
               'vendeurs', coalesce(jsonb_agg(DISTINCT v.nom) FILTER (WHERE r.archive_le IS NULL), '[]'::jsonb)
             ) AS x,
             count(*) AS n
        FROM relance.rdv r
        JOIN relance.vendeur v ON v.id = r.vendeur_id
       WHERE r.campagne_id = p_campagne_id
         AND r.jour = ANY (retires)
       GROUP BY r.jour
    ) s;

  SELECT coalesce(sum((x->>'actifs')::int + (x->>'archives')::int), 0)::int
    INTO impactes
    FROM jsonb_array_elements(detail) x;

  -- SONDAGE : on rend l'impact sans rien modifier. L'interface s'en sert pour
  -- proposer le choix « annuler ou deplacer ».
  IF impactes > 0 AND coalesce(p_mode, '') <> 'deplacer' THEN
    RETURN jsonb_build_object(
      'applique', false,
      'code', 'RDV_IMPACTES',
      'retires', to_jsonb(retires),
      'ajoutes', to_jsonb(ajoutes),
      'impacts', detail,
      'joursConserves', to_jsonb(p_jours),
      'message', format(
        'Retirer %s supprimerait le rattachement de %s RDV. Choisir : annuler la modification, ou deplacer ces RDV vers un jour conserve.',
        CASE WHEN array_length(retires, 1) > 1 THEN 'ces jours' ELSE 'ce jour' END,
        impactes)
    );
  END IF;

  IF impactes > 0 THEN
    IF p_vers IS NULL OR NOT (p_vers = ANY (p_jours)) THEN
      RAISE EXCEPTION 'RELANCE: le jour de destination doit faire partie des jours conserves.';
    END IF;
  END IF;

  -- 1. les jours demandes, crees ou renumerotes
  FOR i IN 1 .. array_length(p_jours, 1) LOOP
    INSERT INTO relance.campagne_jour (campagne_id, jour, ordre, cree_par)
    VALUES (p_campagne_id, p_jours[i], i, moi)
    ON CONFLICT (campagne_id, jour) DO UPDATE SET ordre = EXCLUDED.ordre;
  END LOOP;

  -- 2. les RDV deplaces, APRES la creation des jours de destination
  IF impactes > 0 THEN
    UPDATE relance.rdv r
       SET jour = p_vers, modifie_le = now(), modifie_par = moi
     WHERE r.campagne_id = p_campagne_id
       AND r.jour = ANY (retires);
  END IF;

  -- 3. les jours retires, une fois vides
  IF array_length(retires, 1) IS NOT NULL THEN
    DELETE FROM relance.campagne_jour cj
     WHERE cj.campagne_id = p_campagne_id AND cj.jour = ANY (retires);
  END IF;

  RETURN jsonb_build_object(
    'applique', true,
    'retires', to_jsonb(retires),
    'ajoutes', to_jsonb(ajoutes),
    'rdvDeplaces', impactes,
    'versJour', to_jsonb(p_vers),
    'jours', (SELECT coalesce(jsonb_agg(jsonb_build_object('jour', cj.jour, 'ordre', cj.ordre) ORDER BY cj.ordre), '[]'::jsonb)
                FROM relance.campagne_jour cj WHERE cj.campagne_id = p_campagne_id)
  );
END $$;


--
-- Name: campagne_ouverte(bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.campagne_ouverte(p_campagne_id bigint) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
  SELECT EXISTS (
    SELECT 1 FROM relance.campagne c
    WHERE c.id = p_campagne_id
      AND NOT c.cloturee
      AND c.archive_le IS NULL
  )
$$;


--
-- Name: diffuser_rdv(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.diffuser_rdv() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
BEGIN
  PERFORM realtime.send(
    -- LA CHARGE UTILE NE PORTE NI `client` NI `commentaire`. Meme regle que la vue
    -- `rdv_agrege`, et elle est structurelle : il n'y a pas de champ a oublier de
    -- retirer, il n'y en a jamais eu.
    jsonb_build_object(
      'id', NEW.id::text,
      'vendeurId', NEW.vendeur_id::text,
      'jour', NEW.jour,
      'creneauCode', NEW.creneau_code,
      'marqueId', NEW.marque_id::text,
      'typeVehicule', NEW.type_vehicule,
      'archive', NEW.archive_le IS NOT NULL,
      -- QUI A ECRIT — pour que l'auteur ignore son propre evenement. Il a deja
      -- applique le changement localement (F-C.4) ; le lui rejouer provoquerait un
      -- second rendu, et pendant une saisie au clavier ce scintillement se voit.
      'auteur', coalesce(NEW.modifie_par, NEW.cree_par)::text
    ),
    'rdv',
    'campagne-' || NEW.campagne_id::text,
    true
  );
  RETURN NULL;
END $$;


--
-- Name: exiger_administration(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.exiger_administration() RETURNS bigint
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE moi bigint := relance.utilisateur_courant();
BEGIN
  IF moi IS NULL THEN
    RAISE EXCEPTION 'RELANCE: authentification requise.';
  END IF;
  IF NOT relance.peut_administrer() THEN
    RAISE EXCEPTION 'RELANCE: cette action demande le niveau administrateur ou direction.';
  END IF;
  RETURN moi;
END $$;


--
-- Name: exiger_gestion_comptes(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.exiger_gestion_comptes() RETURNS bigint
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE moi bigint := relance.utilisateur_courant();
BEGIN
  IF moi IS NULL THEN
    RAISE EXCEPTION 'RELANCE: authentification requise.';
  END IF;
  -- `admin` SEUL. C'est la frontiere qui empeche `direction` de se promouvoir,
  -- et elle ne doit jamais etre elargie « pour simplifier ».
  IF NOT relance.peut_gerer_utilisateurs() THEN
    RAISE EXCEPTION 'RELANCE: la gestion des comptes est reservee aux administrateurs.';
  END IF;
  RETURN moi;
END $$;


--
-- Name: exiger_session(bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.exiger_session(p_session_id bigint) RETURNS bigint
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.utilisateur_courant();
  campagne bigint;
BEGIN
  IF moi IS NULL THEN
    RAISE EXCEPTION 'RELANCE: authentification requise.';
  END IF;
  SELECT sp.campagne_id INTO campagne FROM relance.session_plaque sp WHERE sp.id = p_session_id;
  IF campagne IS NULL THEN
    RAISE EXCEPTION 'RELANCE: session introuvable.';
  END IF;
  IF NOT relance.peut_administrer_session(p_session_id) THEN
    RAISE EXCEPTION 'RELANCE: vous n''administrez pas cette plaque sur cette campagne.';
  END IF;
  -- R-C.3. Repete ici parce qu'une session close ne doit pas non plus voir sa
  -- composition changer — le trigger sur `rdv` ne couvre que les RDV.
  IF NOT relance.campagne_ouverte(campagne) THEN
    RAISE EXCEPTION 'RELANCE: cette campagne est cloturee, sa composition n''est plus modifiable.';
  END IF;
  RETURN moi;
END $$;


--
-- Name: interdire_suppression(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.interdire_suppression() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'relance', 'public'
    AS $$
BEGIN
  -- La porte : ouverte pour la duree d'UNE transaction, par la route de purge et
  -- par elle seule. `current_setting(..., true)` rend NULL si le parametre n'a
  -- jamais ete pose — donc le refus est bien le defaut, y compris sur une
  -- connexion neuve.
  IF coalesce(current_setting('relance.purge_autorisee', true), '') = 'oui' THEN
    RETURN NULL; -- trigger STATEMENT : la valeur de retour est ignoree
  END IF;

  RAISE EXCEPTION
    'RELANCE: suppression interdite sur %. Utiliser l''archivage (archive_le ou date_sortie). La purge definitive passe par l''ecran Archivage.',
    TG_TABLE_NAME;
END $$;


--
-- Name: peut_administrer(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.peut_administrer() RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
  SELECT relance.a_role_global('admin') OR relance.a_role_global('direction')
$$;


--
-- Name: peut_administrer_session(bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.peut_administrer_session(p_session_id bigint) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
  SELECT relance.peut_administrer()
      OR EXISTS (
        SELECT 1
        FROM relance.session_plaque sp
        JOIN relance.role_campagne rc
          ON rc.campagne_id = sp.campagne_id
         AND rc.plaque_id = sp.plaque_id
         AND rc.role = 'chef_plaque'
         AND rc.archive_le IS NULL
         AND rc.utilisateur_id = relance.utilisateur_courant()
        WHERE sp.id = p_session_id
      )
$$;


--
-- Name: peut_gerer_utilisateurs(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.peut_gerer_utilisateurs() RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
  SELECT relance.a_role_global('admin')
$$;


--
-- Name: peut_saisir(bigint, bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.peut_saisir(p_vendeur_id bigint, p_campagne_id bigint) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
  SELECT EXISTS (
    SELECT 1 FROM relance.perimetre_saisie ps
    WHERE ps.vendeur_id = p_vendeur_id
      AND ps.campagne_id = p_campagne_id
  )
$$;


--
-- Name: poser_capacites(bigint, bigint[], text, bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.poser_capacites(p_vendeur_id bigint, p_marque_ids bigint[], p_type_vehicule text, p_par bigint) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE m bigint;
BEGIN
  DELETE FROM relance.vendeur_marque WHERE vendeur_id = p_vendeur_id;
  IF p_type_vehicule <> 'VO' AND p_marque_ids IS NOT NULL THEN
    FOREACH m IN ARRAY p_marque_ids LOOP
      INSERT INTO relance.vendeur_marque (vendeur_id, marque_id, cree_par)
      VALUES (p_vendeur_id, m, p_par)
      ON CONFLICT DO NOTHING;
    END LOOP;
  END IF;

  -- PROVENANCE, pas un statut : qui a change les capacites et quand. La notion de
  -- « confirme / placeholder » a ete retiree — un vendeur en base est valide. Ces
  -- deux colonnes servent le jour ou un RDV est refuse sans que personne comprenne.
  UPDATE relance.vendeur
     SET type_vehicule = p_type_vehicule,
         capacites_confirmees_le = now(),
         capacites_confirmees_par = p_par
   WHERE id = p_vendeur_id;
END $$;


--
-- Name: session_appliquer_repartition(bigint, jsonb, boolean); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.session_appliquer_repartition(p_session_id bigint, p_placements jsonb, p_remplacer boolean DEFAULT false) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_session(p_session_id);
  place int := 0;
  p jsonb;
  v jsonb;
  t bigint;
BEGIN
  -- `remplacer` REFAIT la composition entiere : toutes les affectations actives de
  -- la session sont archivees avant de replacer. Derriere une confirmation dans
  -- l'interface, jamais par defaut.
  IF p_remplacer THEN
    UPDATE relance.affectation a SET archive_le = now()
      FROM relance.table_phoning t
     WHERE t.id = a.table_id
       AND t.session_plaque_id = p_session_id
       AND a.archive_le IS NULL;
  END IF;

  FOR p IN SELECT jsonb_array_elements(coalesce(p_placements, '[]'::jsonb)) LOOP
    t := (p->>'tableId')::bigint;

    -- La table doit appartenir A CETTE session : sans ce controle, un appelant
    -- autorise sur sa plaque pourrait ecrire dans les tables d'une autre.
    IF NOT EXISTS (
      SELECT 1 FROM relance.table_phoning tp
       WHERE tp.id = t AND tp.session_plaque_id = p_session_id AND tp.archive_le IS NULL
    ) THEN
      RAISE EXCEPTION 'RELANCE: la table % n''appartient pas a cette session.', t;
    END IF;

    FOR v IN SELECT jsonb_array_elements(coalesce(p->'vendeurIdsAjoutes', '[]'::jsonb)) LOOP
      INSERT INTO relance.affectation (table_id, vendeur_id, origine, cree_par)
      VALUES (t, (v#>>'{}')::bigint, 'auto', moi)
      ON CONFLICT (table_id, vendeur_id) DO UPDATE SET archive_le = NULL, origine = 'auto';
      place := place + 1;
    END LOOP;
  END LOOP;

  RETURN jsonb_build_object('graine', 42, 'remplacer', p_remplacer, 'affectations', place);
END $$;


--
-- Name: session_reprendre(bigint, bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.session_reprendre(p_session_id bigint, p_depuis_campagne_id bigint) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_session(p_session_id);
  plaque bigint;
  campagne bigint;
  source bigint;
  tables_creees int := 0;
  reprises int := 0;
  reportes jsonb := '[]'::jsonb;
  t record;
  a record;
  cible bigint;
  existait boolean;
BEGIN
  SELECT sp.plaque_id, sp.campagne_id INTO plaque, campagne
    FROM relance.session_plaque sp WHERE sp.id = p_session_id;

  IF p_depuis_campagne_id = campagne THEN
    RAISE EXCEPTION 'RELANCE: la campagne source doit etre une AUTRE campagne.';
  END IF;

  SELECT sp.id INTO source
    FROM relance.session_plaque sp
   WHERE sp.campagne_id = p_depuis_campagne_id
     AND sp.plaque_id = plaque
     AND sp.archive_le IS NULL;
  IF source IS NULL THEN
    RAISE EXCEPTION 'RELANCE: cette plaque n''avait aucune session sur la campagne demandee.';
  END IF;

  FOR t IN
    SELECT tp.id, tp.libelle, tp.ordre, tp.chef_utilisateur_id, tp.marque_id
      FROM relance.table_phoning tp
     WHERE tp.session_plaque_id = source AND tp.archive_le IS NULL
     ORDER BY tp.ordre
  LOOP
    SELECT tp.id INTO cible
      FROM relance.table_phoning tp
     WHERE tp.session_plaque_id = p_session_id AND tp.libelle = t.libelle;
    existait := cible IS NOT NULL;

    IF existait THEN
      UPDATE relance.table_phoning
         SET archive_le = NULL, ordre = t.ordre,
             chef_utilisateur_id = t.chef_utilisateur_id, marque_id = t.marque_id
       WHERE id = cible;
    ELSE
      INSERT INTO relance.table_phoning (session_plaque_id, libelle, ordre, chef_utilisateur_id, marque_id, cree_par)
      VALUES (p_session_id, t.libelle, t.ordre, t.chef_utilisateur_id, t.marque_id, moi)
      RETURNING id INTO cible;
      tables_creees := tables_creees + 1;
    END IF;

    FOR a IN
      SELECT v.id, v.nom, v.site_id
        FROM relance.affectation af
        JOIN relance.vendeur v ON v.id = af.vendeur_id
       WHERE af.table_id = t.id AND af.archive_le IS NULL
    LOOP
      -- ELIGIBILITE : present pendant LA NOUVELLE campagne, et toujours de cette
      -- plaque. Les deux conditions sont verifiees ici EN PLUS du trigger, pour
      -- pouvoir NOMMER ceux qu'on laisse de cote plutot que d'echouer en bloc.
      IF NOT EXISTS (
        SELECT 1
          FROM relance.vendeur vv
          JOIN relance.site s ON s.id = vv.site_id
          JOIN relance.campagne c ON c.id = campagne
         WHERE vv.id = a.id
           AND s.plaque_id = plaque
           AND vv.archive_le IS NULL
           AND (vv.date_entree IS NULL OR vv.date_entree <= c.date_fin)
           AND (vv.date_sortie IS NULL OR vv.date_sortie >= c.date_debut)
      ) THEN
        reportes := reportes || jsonb_build_object(
          'nom', a.nom,
          'raison', 'absent de cette campagne, ou rattache a une autre plaque');
        CONTINUE;
      END IF;

      INSERT INTO relance.affectation (table_id, vendeur_id, origine, cree_par)
      VALUES (cible, a.id, 'manuel', moi)
      ON CONFLICT (table_id, vendeur_id) DO UPDATE SET archive_le = NULL;
      reprises := reprises + 1;
    END LOOP;
  END LOOP;

  RETURN jsonb_build_object(
    'tablesCreees', tables_creees,
    'affectationsReprises', reprises,
    'reportes', reportes
  );
END $$;


--
-- Name: table_archiver(bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.table_archiver(p_table_id bigint) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  session_id bigint;
  libelle text;
  n int;
BEGIN
  SELECT t.session_plaque_id, t.libelle INTO session_id, libelle
    FROM relance.table_phoning t WHERE t.id = p_table_id;
  IF session_id IS NULL THEN
    RAISE EXCEPTION 'RELANCE: table introuvable.';
  END IF;
  PERFORM relance.exiger_session(session_id);

  UPDATE relance.table_phoning SET archive_le = now() WHERE id = p_table_id;
  UPDATE relance.affectation SET archive_le = now()
   WHERE table_id = p_table_id AND archive_le IS NULL;
  GET DIAGNOSTICS n = ROW_COUNT;

  RETURN jsonb_build_object(
    'archivee', libelle,
    'affectationsArchivees', n,
    'sessionId', session_id::text,
    'message', format(
      '« %s » est archivee, pas supprimee : sa composition reste consultable. %s vendeur(s) reviennent en reserve et restent saisissables par leur chef de site.',
      libelle, n)
  );
END $$;


--
-- Name: table_definir_vendeurs(bigint, bigint[]); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.table_definir_vendeurs(p_table_id bigint, p_vendeur_ids bigint[]) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint;
  session_id bigint;
  ids bigint[] := coalesce(p_vendeur_ids, '{}');
  retires int;
  v bigint;
BEGIN
  SELECT t.session_plaque_id INTO session_id
    FROM relance.table_phoning t WHERE t.id = p_table_id AND t.archive_le IS NULL;
  IF session_id IS NULL THEN
    RAISE EXCEPTION 'RELANCE: table introuvable ou archivee.';
  END IF;
  moi := relance.exiger_session(session_id);

  UPDATE relance.affectation SET archive_le = now()
   WHERE table_id = p_table_id AND archive_le IS NULL AND NOT (vendeur_id = ANY (ids));
  GET DIAGNOSTICS retires = ROW_COUNT;

  -- Un a un, et non en bloc : les triggers R-B.1 (meme plaque), R-B.4 (une seule
  -- table par campagne) et R-B.5 (marque de la table) sont `FOR EACH ROW`. Leurs
  -- messages, deja ecrits pour un humain, remontent tels quels a l'appelant.
  FOREACH v IN ARRAY ids LOOP
    INSERT INTO relance.affectation (table_id, vendeur_id, origine, cree_par)
    VALUES (p_table_id, v, 'manuel', moi)
    ON CONFLICT (table_id, vendeur_id)
      DO UPDATE SET archive_le = NULL, origine = 'manuel';
  END LOOP;

  RETURN jsonb_build_object(
    'retires', retires,
    'effectif', coalesce(array_length(ids, 1), 0),
    'sessionId', session_id::text
  );
END $$;


--
-- Name: tracer_creation(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.tracer_creation() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.utilisateur_courant();
BEGIN
  IF moi IS NOT NULL THEN
    NEW.cree_par := moi;
  END IF;
  RETURN NEW;
END $$;


--
-- Name: tracer_modification_rdv(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.tracer_modification_rdv() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.utilisateur_courant();
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF moi IS NOT NULL THEN NEW.cree_par := moi; END IF;
    RETURN NEW;
  END IF;

  IF moi IS NOT NULL THEN
    NEW.modifie_par := moi;
    -- L'ARCHIVAGE EST UN UPDATE, c'est la seule facon de retirer un RDV. On veut
    -- donc savoir qui l'a retire, et pas seulement qui l'a modifie en dernier.
    IF NEW.archive_le IS NOT NULL AND OLD.archive_le IS NULL THEN
      NEW.archive_par := moi;
    END IF;
  END IF;
  NEW.modifie_le := now();

  -- `cree_par` et `cree_le` ne se reecrivent jamais. Sans cette ligne, un client
  -- pourrait se declarer auteur d'un RDV saisi par quelqu'un d'autre en le
  -- modifiant — l'attribution serait alors reecrivable a volonte.
  NEW.cree_par := OLD.cree_par;
  NEW.cree_le := OLD.cree_le;
  RETURN NEW;
END $$;


--
-- Name: utilisateur_courant(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.utilisateur_courant() RETURNS bigint
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
  SELECT u.id
  FROM relance.utilisateur u
  WHERE u.auth_uid = auth.uid()
    AND u.actif
    AND u.archive_le IS NULL
$$;


--
-- Name: utilisateur_definir_encadrement(bigint, text, bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.utilisateur_definir_encadrement(p_site_id bigint, p_role text, p_utilisateur_id bigint DEFAULT NULL::bigint) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_gestion_comptes();
BEGIN
  IF p_role NOT IN ('chef_de_site', 'chef_de_vente_vn', 'chef_de_vente_vo') THEN
    RAISE EXCEPTION 'RELANCE: role invalide : chef_de_site, chef_de_vente_vn ou chef_de_vente_vo.';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM relance.site WHERE id = p_site_id AND archive_le IS NULL) THEN
    RAISE EXCEPTION 'RELANCE: site introuvable ou archive.';
  END IF;

  IF p_utilisateur_id IS NULL THEN
    UPDATE relance.encadrement_site SET archive_le = now()
     WHERE site_id = p_site_id AND role = p_role AND archive_le IS NULL;
    RETURN jsonb_build_object('libere', true, 'siteId', p_site_id::text, 'role', p_role);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM relance.utilisateur
     WHERE id = p_utilisateur_id AND actif AND archive_le IS NULL
  ) THEN
    RAISE EXCEPTION 'RELANCE: ce compte est introuvable ou desactive.';
  END IF;

  -- ON LIBERE LE ROLE AVANT DE LE DONNER. L'unique `(site, role)` refuse deux
  -- titulaires : l'ordre inverse echouerait. Meme piege que sur l'ecran des
  -- encadrants, ou deux requetes lancees en parallele se marchaient dessus.
  UPDATE relance.encadrement_site SET archive_le = now()
   WHERE site_id = p_site_id AND role = p_role AND archive_le IS NULL
     AND utilisateur_id <> p_utilisateur_id;

  INSERT INTO relance.encadrement_site (site_id, role, utilisateur_id, cree_par)
  VALUES (p_site_id, p_role, p_utilisateur_id, moi)
  ON CONFLICT (site_id, role) DO UPDATE
    SET utilisateur_id = EXCLUDED.utilisateur_id, archive_le = NULL;

  RETURN jsonb_build_object('siteId', p_site_id::text, 'role', p_role,
                            'utilisateurId', p_utilisateur_id::text);
END $$;


--
-- Name: utilisateur_definir_roles(bigint, text); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.utilisateur_definir_roles(p_utilisateur_id bigint, p_role text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_gestion_comptes();
  etait_admin boolean;
  autres_admins int;
BEGIN
  IF p_role IS NOT NULL AND p_role NOT IN ('admin', 'direction', 'lecteur') THEN
    RAISE EXCEPTION 'RELANCE: role inconnu : admin, direction ou lecteur.';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM relance.utilisateur WHERE id = p_utilisateur_id) THEN
    RAISE EXCEPTION 'RELANCE: compte introuvable.';
  END IF;

  -- LE DERNIER ADMINISTRATEUR NE PEUT PAS ETRE DEGRADE. Sans ce controle,
  -- l'application devient inadministrable et plus personne ne peut creer de compte
  -- — y compris pour se redonner le role.
  SELECT EXISTS (
    SELECT 1 FROM relance.role_global WHERE utilisateur_id = p_utilisateur_id AND role = 'admin'
  ) INTO etait_admin;

  IF etait_admin AND coalesce(p_role, '') <> 'admin' THEN
    SELECT count(*)::int INTO autres_admins
      FROM relance.role_global rg
      JOIN relance.utilisateur u ON u.id = rg.utilisateur_id
     WHERE rg.role = 'admin' AND rg.utilisateur_id <> p_utilisateur_id
       AND u.actif AND u.archive_le IS NULL;
    IF autres_admins = 0 THEN
      RAISE EXCEPTION 'RELANCE: c''est le dernier administrateur actif : le degrader rendrait l''application inadministrable. Nommer un autre administrateur d''abord.';
    END IF;
  END IF;

  DELETE FROM relance.role_global WHERE utilisateur_id = p_utilisateur_id;
  IF p_role IS NOT NULL THEN
    INSERT INTO relance.role_global (utilisateur_id, role, cree_par)
    VALUES (p_utilisateur_id, p_role, moi);
  END IF;

  RETURN jsonb_build_object('utilisateurId', p_utilisateur_id::text, 'role', to_jsonb(p_role));
END $$;


--
-- Name: utilisateur_purger(bigint, text); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.utilisateur_purger(p_utilisateur_id bigint, p_confirmation text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_gestion_comptes();
  nom_exact text;
  attaches text[] := '{}';
BEGIN
  SELECT u.nom INTO nom_exact FROM relance.utilisateur u WHERE u.id = p_utilisateur_id;
  IF nom_exact IS NULL THEN
    RAISE EXCEPTION 'RELANCE: compte introuvable.';
  END IF;
  IF p_utilisateur_id = moi THEN
    RAISE EXCEPTION 'RELANCE: on ne supprime pas son propre compte.';
  END IF;

  -- CE QUI RETIENT UN COMPTE. Un compte qui explique encore quelque chose —
  -- l'auteur d'une saisie, le chef d'une table passee — n'est pas supprimable :
  -- l'historique deviendrait anonyme. Le desactiver conserve la trace sans donner
  -- aucun acces.
  IF EXISTS (SELECT 1 FROM relance.table_phoning WHERE chef_utilisateur_id = p_utilisateur_id) THEN
    attaches := attaches || 'des tables de phoning';
  END IF;
  IF EXISTS (SELECT 1 FROM relance.rdv WHERE cree_par = p_utilisateur_id OR modifie_par = p_utilisateur_id) THEN
    attaches := attaches || 'des RDV saisis';
  END IF;
  IF EXISTS (SELECT 1 FROM relance.vendeur WHERE utilisateur_id = p_utilisateur_id) THEN
    attaches := attaches || 'une fiche vendeur';
  END IF;
  IF array_length(attaches, 1) IS NOT NULL THEN
    RAISE EXCEPTION 'RELANCE: % ne peut pas etre supprime : son compte explique encore %. Le laisser desactive conserve cette trace sans lui donner aucun acces.',
      nom_exact, array_to_string(attaches, ', ');
  END IF;

  IF p_confirmation IS DISTINCT FROM nom_exact THEN
    RAISE EXCEPTION 'RELANCE: pour supprimer definitivement, retaper le nom exact. Attendu : « % ».', nom_exact;
  END IF;

  -- LA PORTE, ouverte pour cette seule transaction. `SET LOCAL` meurt avec elle :
  -- elle ne peut pas rester ouverte par oubli, et aucune autre session n'est
  -- affectee — contrairement a un `ALTER TABLE ... DISABLE TRIGGER`, qui aurait
  -- desarme le garde-fou pour tout le monde, y compris pendant une saisie.
  PERFORM set_config('relance.purge_autorisee', 'oui', true);
  DELETE FROM relance.encadrement_site WHERE utilisateur_id = p_utilisateur_id;
  DELETE FROM relance.role_global WHERE utilisateur_id = p_utilisateur_id;
  DELETE FROM relance.role_campagne WHERE utilisateur_id = p_utilisateur_id;
  DELETE FROM relance.utilisateur WHERE id = p_utilisateur_id;

  RETURN jsonb_build_object('supprime', nom_exact);
END $$;


--
-- Name: vendeur_appliquer_import_marques(jsonb); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.vendeur_appliquer_import_marques(p_lignes jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_administration();
  l jsonb;
  n int := 0;
  marques bigint[];
BEGIN
  FOR l IN SELECT jsonb_array_elements(coalesce(p_lignes, '[]'::jsonb)) LOOP
    SELECT coalesce(array_agg((m#>>'{}')::bigint), '{}')
      INTO marques
      FROM jsonb_array_elements(coalesce(l->'marqueIds', '[]'::jsonb)) m;

    PERFORM relance.poser_capacites(
      (l->>'vendeurId')::bigint, marques, l->>'typeVehicule', moi);
    n := n + 1;
  END LOOP;

  RETURN jsonb_build_object('appliquees', n);
END $$;


--
-- Name: vendeur_creer(text, bigint, text, bigint[], date); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.vendeur_creer(p_nom text, p_site_id bigint, p_type_vehicule text, p_marque_ids bigint[] DEFAULT '{}'::bigint[], p_date_entree date DEFAULT NULL::date) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_administration();
  nouveau bigint;
  nom text := btrim(coalesce(p_nom, ''));
BEGIN
  IF nom = '' THEN
    RAISE EXCEPTION 'RELANCE: le nom du vendeur est requis.';
  END IF;
  IF p_type_vehicule NOT IN ('VN', 'VO') THEN
    RAISE EXCEPTION 'RELANCE: le metier doit etre VN ou VO.';
  END IF;
  IF p_type_vehicule = 'VN' AND coalesce(array_length(p_marque_ids, 1), 0) = 0 THEN
    RAISE EXCEPTION 'RELANCE: un vendeur VN doit porter au moins une marque, sinon sa grille de saisie serait vide.';
  END IF;

  INSERT INTO relance.vendeur (nom, site_id, type_vehicule, date_entree, cree_par)
  VALUES (nom, p_site_id, p_type_vehicule, p_date_entree, moi)
  RETURNING id INTO nouveau;

  PERFORM relance.poser_capacites(nouveau, p_marque_ids, p_type_vehicule, moi);

  RETURN jsonb_build_object('id', nouveau::text, 'nom', nom);
END $$;


--
-- Name: vendeur_modifier(bigint, text, bigint, date, date, boolean, boolean, text, bigint[]); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.vendeur_modifier(p_vendeur_id bigint, p_nom text DEFAULT NULL::text, p_site_id bigint DEFAULT NULL::bigint, p_date_entree date DEFAULT NULL::date, p_date_sortie date DEFAULT NULL::date, p_archiver boolean DEFAULT NULL::boolean, p_changer_capacites boolean DEFAULT false, p_type_vehicule text DEFAULT NULL::text, p_marque_ids bigint[] DEFAULT NULL::bigint[]) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_administration();
BEGIN
  IF NOT EXISTS (SELECT 1 FROM relance.vendeur WHERE id = p_vendeur_id) THEN
    RAISE EXCEPTION 'RELANCE: vendeur introuvable.';
  END IF;

  UPDATE relance.vendeur
     SET nom = coalesce(btrim(p_nom), nom),
         site_id = coalesce(p_site_id, site_id),
         date_entree = CASE WHEN p_date_entree IS NOT NULL THEN p_date_entree ELSE date_entree END,
         date_sortie = CASE WHEN p_date_sortie IS NOT NULL THEN p_date_sortie ELSE date_sortie END,
         archive_le = CASE
                        WHEN p_archiver IS NULL THEN archive_le
                        WHEN p_archiver THEN coalesce(archive_le, now())
                        ELSE NULL
                      END,
         archive_par = CASE
                         WHEN p_archiver IS TRUE THEN moi
                         WHEN p_archiver IS FALSE THEN NULL
                         ELSE archive_par
                       END
   WHERE id = p_vendeur_id;

  IF p_changer_capacites THEN
    IF p_type_vehicule NOT IN ('VN', 'VO') THEN
      RAISE EXCEPTION 'RELANCE: le metier doit etre VN ou VO.';
    END IF;
    IF p_type_vehicule = 'VN' AND coalesce(array_length(p_marque_ids, 1), 0) = 0 THEN
      RAISE EXCEPTION 'RELANCE: un vendeur VN doit porter au moins une marque.';
    END IF;
    PERFORM relance.poser_capacites(p_vendeur_id, p_marque_ids, p_type_vehicule, moi);
  END IF;

  RETURN jsonb_build_object('id', p_vendeur_id::text);
END $$;


--
-- Name: vendeur_purger(bigint, text); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.vendeur_purger(p_vendeur_id bigint, p_confirmation text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_administration();
  nom_exact text;
  archive timestamptz;
  nb_rdv int;
  nb_aff int;
BEGIN
  SELECT v.nom, v.archive_le INTO nom_exact, archive
    FROM relance.vendeur v WHERE v.id = p_vendeur_id;
  IF nom_exact IS NULL THEN
    RAISE EXCEPTION 'RELANCE: vendeur introuvable.';
  END IF;

  -- DEUX VERROUS, ET LES DEUX COMPTENT. L'archivage prealable oblige a passer par
  -- un geste reversible avant l'irreversible ; retaper le nom empeche de purger
  -- une ligne pour une autre depuis une liste.
  IF archive IS NULL THEN
    RAISE EXCEPTION 'RELANCE: ce vendeur doit d''abord etre archive. La purge ne s''applique qu''a une fiche deja retiree.';
  END IF;
  IF p_confirmation IS DISTINCT FROM nom_exact THEN
    RAISE EXCEPTION 'RELANCE: pour purger definitivement, retaper le nom exact du vendeur. Attendu : « % ».', nom_exact;
  END IF;

  SELECT count(*)::int INTO nb_rdv FROM relance.rdv WHERE vendeur_id = p_vendeur_id;
  SELECT count(*)::int INTO nb_aff FROM relance.affectation WHERE vendeur_id = p_vendeur_id;

  PERFORM set_config('relance.purge_autorisee', 'oui', true);
  DELETE FROM relance.rdv WHERE vendeur_id = p_vendeur_id;
  DELETE FROM relance.affectation WHERE vendeur_id = p_vendeur_id;
  DELETE FROM relance.vendeur_marque WHERE vendeur_id = p_vendeur_id;
  DELETE FROM relance.vendeur WHERE id = p_vendeur_id;

  RETURN jsonb_build_object(
    'purge', nom_exact, 'nbRdv', nb_rdv, 'nbAffectations', nb_aff,
    'message', format(
      '%s est definitivement supprime, avec %s RDV et %s affectation(s). Les totaux des campagnes concernees ont change. C''est irreversible.',
      nom_exact, nb_rdv, nb_aff)
  );
END $$;


--
-- Name: verifier_affectation_marque_table(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_affectation_marque_table() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public'
    AS $$
DECLARE
  marque_table   bigint;
  libelle_marque text;
  libelle_table  text;
  type_vendeur   text;
  nom_vendeur    text;
  autorise       boolean;
BEGIN
  -- Une ligne archivee ne rattache plus personne.
  IF NEW.archive_le IS NOT NULL THEN
    RETURN NEW;
  END IF;

  SELECT t.marque_id, t.libelle INTO marque_table, libelle_table
  FROM table_phoning t WHERE t.id = NEW.table_id;

  -- Table mixte : aucune contrainte. Cas normal.
  IF marque_table IS NULL THEN
    RETURN NEW;
  END IF;

  SELECT v.type_vehicule, v.nom INTO type_vendeur, nom_vendeur
  FROM vendeur v WHERE v.id = NEW.vendeur_id;

  IF type_vendeur IS NULL THEN
    -- Vendeur inexistant : la cle etrangere s'en charge, on ne masque pas son
    -- message par le notre.
    RETURN NEW;
  END IF;

  SELECT m.libelle INTO libelle_marque FROM marque m WHERE m.id = marque_table;

  IF type_vendeur = 'VO' THEN
    RAISE EXCEPTION
      'RELANCE: % est un vendeur VO et n''a aucune ventilation par marque : il ne peut pas rejoindre la table "%", specialisee %.',
      nom_vendeur, libelle_table, libelle_marque;
  END IF;

  SELECT EXISTS (
    SELECT 1 FROM vendeur_marque vm
    WHERE vm.vendeur_id = NEW.vendeur_id AND vm.marque_id = marque_table
  ) INTO autorise;

  IF NOT autorise THEN
    RAISE EXCEPTION
      'RELANCE: % n''est pas autorise a vendre % : il ne peut pas rejoindre la table "%", specialisee sur cette marque.',
      nom_vendeur, libelle_marque, libelle_table;
  END IF;

  RETURN NEW;
END $$;


--
-- Name: verifier_affectation_meme_plaque(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_affectation_meme_plaque() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public'
    AS $$
DECLARE
  plaque_table   bigint;
  plaque_vendeur bigint;
  libelle_table  text;
  nom_vendeur    text;
BEGIN
  -- Une ligne archivee ne rattache plus personne : inutile de la contraindre, et
  -- la contraindre empecherait d'archiver une affectation devenue invalide apres
  -- un changement de plaque d'un site.
  IF NEW.archive_le IS NOT NULL THEN
    RETURN NEW;
  END IF;

  SELECT s.plaque_id, t.libelle
    INTO plaque_table, libelle_table
  FROM table_phoning  t
  JOIN session_plaque s ON s.id = t.session_plaque_id
  WHERE t.id = NEW.table_id;

  SELECT si.plaque_id, v.nom
    INTO plaque_vendeur, nom_vendeur
  FROM vendeur v
  JOIN site si ON si.id = v.site_id
  WHERE v.id = NEW.vendeur_id;

  IF plaque_table IS NULL OR plaque_vendeur IS NULL THEN
    -- Table ou vendeur inexistant : les cles etrangeres s'en chargent, on ne
    -- masque pas leur message par le notre.
    RETURN NEW;
  END IF;

  IF plaque_table <> plaque_vendeur THEN
    RAISE EXCEPTION
      'RELANCE: % appartient a une autre plaque que la table "%". Une table ne peut contenir que des vendeurs de sa propre plaque.',
      nom_vendeur, libelle_table;
  END IF;

  RETURN NEW;
END $$;


--
-- Name: verifier_affectation_presence(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_affectation_presence() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  v      record;
  c      record;
BEGIN
  -- ARCHIVER RESTE TOUJOURS POSSIBLE. Sans cette sortie, retirer de sa table un
  -- vendeur qui vient de partir serait refuse par le controle cense l'empecher
  -- d'y etre : on ne pourrait plus corriger la situation qu'on denonce.
  IF NEW.archive_le IS NOT NULL THEN
    RETURN NEW;
  END IF;

  SELECT ve.nom, ve.date_entree, ve.date_sortie, ve.archive_le
    INTO v
    FROM relance.vendeur ve
   WHERE ve.id = NEW.vendeur_id;

  SELECT ca.libelle, ca.date_debut, ca.date_fin
    INTO c
    FROM relance.table_phoning tp
    JOIN relance.session_plaque sp ON sp.id = tp.session_plaque_id
    JOIN relance.campagne ca       ON ca.id = sp.campagne_id
   WHERE tp.id = NEW.table_id;

  IF v IS NULL OR c IS NULL THEN
    RETURN NEW; -- les cles etrangeres s'en chargeront, ce n'est pas notre role
  END IF;

  IF v.archive_le IS NOT NULL THEN
    RAISE EXCEPTION 'RELANCE: % est archive : il ne peut etre affecte a aucune table.', v.nom;
  END IF;

  -- MEME REGLE, MOT POUR MOT, QUE `relance.perimetre_saisie`. Une date nulle
  -- signifie << depuis toujours >> ou << pour toujours >> : le fichier source
  -- n'a pas les dates d'entree des 99 vendeurs importes.
  IF v.date_entree IS NOT NULL AND v.date_entree > c.date_fin THEN
    RAISE EXCEPTION
      'RELANCE: % entre le % : il n''etait pas encore la pendant « % » (% au %).',
      v.nom, to_char(v.date_entree, 'DD/MM/YYYY'), c.libelle,
      to_char(c.date_debut, 'DD/MM/YYYY'), to_char(c.date_fin, 'DD/MM/YYYY');
  END IF;

  IF v.date_sortie IS NOT NULL AND v.date_sortie < c.date_debut THEN
    RAISE EXCEPTION
      'RELANCE: % est sorti le % : il n''etait plus la pendant « % » (% au %).',
      v.nom, to_char(v.date_sortie, 'DD/MM/YYYY'), c.libelle,
      to_char(c.date_debut, 'DD/MM/YYYY'), to_char(c.date_fin, 'DD/MM/YYYY');
  END IF;

  RETURN NEW;
END
$$;


--
-- Name: verifier_affectation_unique(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_affectation_unique() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public'
    AS $$
DECLARE
  autre_table text;
BEGIN
  -- Une ligne archivee ne reserve pas la place du vendeur.
  IF NEW.archive_le IS NOT NULL THEN
    RETURN NEW;
  END IF;

  SELECT t_autre.libelle INTO autre_table
  FROM affectation a
  JOIN table_phoning  t_autre ON t_autre.id = a.table_id
  JOIN session_plaque s_autre ON s_autre.id = t_autre.session_plaque_id
  JOIN table_phoning  t_new   ON t_new.id   = NEW.table_id
  JOIN session_plaque s_new   ON s_new.id   = t_new.session_plaque_id
  WHERE a.vendeur_id = NEW.vendeur_id
    AND a.archive_le IS NULL
    -- Cle METIER, pas identite technique : voir l'explication ci-dessus.
    AND a.table_id <> NEW.table_id
    AND s_autre.campagne_id = s_new.campagne_id
  LIMIT 1;

  IF autre_table IS NOT NULL THEN
    RAISE EXCEPTION 'RELANCE: ce vendeur est deja affecte a la table "%" pour cette campagne.', autre_table;
  END IF;

  RETURN NEW;
END $$;


--
-- Name: verifier_campagne_ouverte(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_campagne_ouverte() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public'
    AS $$
DECLARE
  c record;
BEGIN
  SELECT libelle, cloturee, archive_le INTO c
  FROM campagne
  WHERE id = COALESCE(NEW.campagne_id, OLD.campagne_id);

  IF c.cloturee THEN
    RAISE EXCEPTION 'RELANCE: la campagne "%" est cloturee, plus aucune saisie n''est possible.', c.libelle;
  END IF;

  IF c.archive_le IS NOT NULL THEN
    RAISE EXCEPTION 'RELANCE: la campagne "%" est archivee.', c.libelle;
  END IF;

  RETURN COALESCE(NEW, OLD);
END $$;


--
-- Name: verifier_encadrant_actif(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_encadrant_actif() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public'
    AS $$
DECLARE
  nom_compte text;
  compte_actif boolean;
  compte_archive timestamptz;
BEGIN
  IF NEW.archive_le IS NOT NULL THEN
    RETURN NEW;
  END IF;

  SELECT u.nom, u.actif, u.archive_le
    INTO nom_compte, compte_actif, compte_archive
  FROM utilisateur u WHERE u.id = NEW.utilisateur_id;

  IF nom_compte IS NULL THEN
    RETURN NEW; -- la cle etrangere s'en charge
  END IF;

  IF NOT compte_actif OR compte_archive IS NOT NULL THEN
    RAISE EXCEPTION
      'RELANCE: le compte de % est desactive : il ne peut pas encadrer un site. Le reactiver dans la gestion des comptes.',
      nom_compte;
  END IF;

  RETURN NEW;
END $$;


--
-- Name: verifier_marque_autorisee(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_marque_autorisee() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public'
    AS $$
DECLARE
  nom_vendeur text;
  nom_marque  text;
BEGIN
  IF NEW.marque_id IS NULL THEN
    RETURN NEW;
  END IF;

  IF EXISTS (
    SELECT 1 FROM vendeur_marque vm
    WHERE vm.vendeur_id = NEW.vendeur_id AND vm.marque_id = NEW.marque_id
  ) THEN
    RETURN NEW;
  END IF;

  SELECT v.nom INTO nom_vendeur FROM vendeur v WHERE v.id = NEW.vendeur_id;
  SELECT m.libelle INTO nom_marque FROM marque  m WHERE m.id = NEW.marque_id;

  RAISE EXCEPTION 'RELANCE: % n''est pas autorise a vendre %.',
    COALESCE(nom_vendeur, 'ce vendeur'), COALESCE(nom_marque, 'cette marque');
END $$;


--
-- Name: verifier_marque_selon_metier(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_marque_selon_metier() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public'
    AS $$
DECLARE
  v record;
BEGIN
  SELECT nom, type_vehicule INTO v FROM vendeur WHERE id = NEW.vendeur_id;

  IF v.type_vehicule = 'VO' AND NEW.marque_id IS NOT NULL THEN
    RAISE EXCEPTION 'RELANCE: % est un vendeur VO, ses RDV ne portent pas de marque.', v.nom;
  END IF;

  IF v.type_vehicule = 'VN' AND NEW.marque_id IS NULL THEN
    RAISE EXCEPTION 'RELANCE: % est un vendeur VN, la marque du RDV est obligatoire.', v.nom;
  END IF;

  RETURN NEW;
END $$;


--
-- Name: verifier_type_coherent(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_type_coherent() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public'
    AS $$
DECLARE
  v record;
BEGIN
  SELECT nom, type_vehicule INTO v FROM vendeur WHERE id = NEW.vendeur_id;

  IF v.type_vehicule <> NEW.type_vehicule THEN
    RAISE EXCEPTION 'RELANCE: % est un vendeur %, il ne peut pas recevoir un RDV %.',
      v.nom, v.type_vehicule, NEW.type_vehicule;
  END IF;

  RETURN NEW;
END $$;


--
-- Name: verifier_vendeur_dates_contre_rdv(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_vendeur_dates_contre_rdv() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  conflit record;
BEGIN
  -- Rien a verifier si les deux dates sont inchangees. Un vendeur se modifie
  -- souvent (nom, marques, site) et cette requete n'a pas a tourner pour rien.
  IF TG_OP = 'UPDATE'
     AND NEW.date_entree IS NOT DISTINCT FROM OLD.date_entree
     AND NEW.date_sortie IS NOT DISTINCT FROM OLD.date_sortie THEN
    RETURN NEW;
  END IF;

  IF NEW.date_entree IS NULL AND NEW.date_sortie IS NULL THEN
    RETURN NEW; -- present depuis toujours et pour toujours : rien ne peut clocher
  END IF;

  SELECT c.libelle, c.date_debut, c.date_fin, count(*) AS n
    INTO conflit
    FROM relance.rdv r
    JOIN relance.campagne c ON c.id = r.campagne_id
   WHERE r.vendeur_id = NEW.id
     AND r.archive_le IS NULL
     AND (
       (NEW.date_entree IS NOT NULL AND NEW.date_entree > c.date_fin)
       OR (NEW.date_sortie IS NOT NULL AND NEW.date_sortie < c.date_debut)
     )
   GROUP BY c.id, c.libelle, c.date_debut, c.date_fin
   ORDER BY c.date_debut
   LIMIT 1;

  IF conflit IS NOT NULL THEN
    RAISE EXCEPTION
      'RELANCE: % a % RDV sur « % » (% au %). Ces dates l''en excluraient, et ses RDV disparaitraient des totaux. Archiver ces RDV d''abord si c''est bien voulu.',
      NEW.nom, conflit.n, conflit.libelle,
      to_char(conflit.date_debut, 'DD/MM/YYYY'), to_char(conflit.date_fin, 'DD/MM/YYYY');
  END IF;

  RETURN NEW;
END
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: affectation; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.affectation (
    id bigint NOT NULL,
    table_id bigint NOT NULL,
    vendeur_id bigint NOT NULL,
    origine text DEFAULT 'manuel'::text NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone,
    CONSTRAINT affectation_origine_check CHECK ((origine = ANY (ARRAY['auto'::text, 'manuel'::text])))
);


--
-- Name: affectation_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.affectation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: affectation_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.affectation_id_seq OWNED BY relance.affectation.id;


--
-- Name: campagne; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.campagne (
    id bigint NOT NULL,
    libelle text NOT NULL,
    date_debut date NOT NULL,
    date_fin date NOT NULL,
    cloturee boolean DEFAULT false NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone,
    CONSTRAINT campagne_dates_coherentes_check CHECK ((date_fin >= date_debut))
);


--
-- Name: campagne_creneau; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.campagne_creneau (
    campagne_id bigint NOT NULL,
    code text NOT NULL,
    libelle text NOT NULL,
    ordre integer NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint
);


--
-- Name: campagne_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.campagne_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: campagne_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.campagne_id_seq OWNED BY relance.campagne.id;


--
-- Name: campagne_jour; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.campagne_jour (
    campagne_id bigint NOT NULL,
    jour date NOT NULL,
    ordre integer NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint
);


--
-- Name: encadrement_site; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.encadrement_site (
    id bigint NOT NULL,
    site_id bigint NOT NULL,
    role text NOT NULL,
    utilisateur_id bigint NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT now() NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone,
    CONSTRAINT encadrement_site_role_check CHECK ((role = ANY (ARRAY['chef_de_site'::text, 'chef_de_vente_vn'::text, 'chef_de_vente_vo'::text])))
);


--
-- Name: encadrement_site_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.encadrement_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: encadrement_site_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.encadrement_site_id_seq OWNED BY relance.encadrement_site.id;


--
-- Name: marque; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.marque (
    id bigint NOT NULL,
    code text NOT NULL,
    libelle text NOT NULL,
    ordre integer DEFAULT 0 NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone
);


--
-- Name: marque_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.marque_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: marque_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.marque_id_seq OWNED BY relance.marque.id;


--
-- Name: role_campagne; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.role_campagne (
    id bigint NOT NULL,
    campagne_id bigint NOT NULL,
    utilisateur_id bigint NOT NULL,
    role text NOT NULL,
    plaque_id bigint,
    site_id bigint,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone,
    CONSTRAINT role_campagne_portee_check CHECK ((((role = 'chef_plaque'::text) AND (plaque_id IS NOT NULL) AND (site_id IS NULL)) OR ((role = 'chef_site'::text) AND (site_id IS NOT NULL) AND (plaque_id IS NULL)))),
    CONSTRAINT role_campagne_role_check CHECK ((role = ANY (ARRAY['chef_plaque'::text, 'chef_site'::text])))
);


--
-- Name: session_plaque; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.session_plaque (
    id bigint NOT NULL,
    campagne_id bigint NOT NULL,
    plaque_id bigint NOT NULL,
    mode text DEFAULT 'par_site'::text NOT NULL,
    effectif_cible_table integer,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone,
    CONSTRAINT session_plaque_mode_check CHECK ((mode = ANY (ARRAY['par_site'::text, 'par_table'::text])))
);


--
-- Name: site; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.site (
    id bigint NOT NULL,
    code text NOT NULL,
    libelle text NOT NULL,
    plaque_id bigint NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone
);


--
-- Name: table_phoning; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.table_phoning (
    id bigint NOT NULL,
    session_plaque_id bigint NOT NULL,
    libelle text NOT NULL,
    chef_utilisateur_id bigint,
    ordre integer DEFAULT 0 NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone,
    marque_id bigint
);


--
-- Name: vendeur; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.vendeur (
    id bigint NOT NULL,
    nom text NOT NULL,
    site_id bigint NOT NULL,
    utilisateur_id bigint,
    date_entree date,
    date_sortie date,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    capacites_confirmees_le timestamp(6) with time zone,
    capacites_confirmees_par bigint,
    type_vehicule text NOT NULL,
    archive_le timestamp(6) with time zone,
    archive_par bigint,
    CONSTRAINT vendeur_dates_coherentes_check CHECK (((date_sortie IS NULL) OR (date_entree IS NULL) OR (date_sortie >= date_entree))),
    CONSTRAINT vendeur_type_check CHECK ((type_vehicule = ANY (ARRAY['VN'::text, 'VO'::text])))
);


--
-- Name: perimetre_saisie; Type: VIEW; Schema: relance; Owner: -
--

CREATE VIEW relance.perimetre_saisie AS
 SELECT c.id AS campagne_id,
    v.id AS vendeur_id
   FROM (relance.campagne c
     CROSS JOIN relance.vendeur v)
  WHERE ((relance.utilisateur_courant() IS NOT NULL) AND (v.archive_le IS NULL) AND ((v.date_entree IS NULL) OR (v.date_entree <= c.date_fin)) AND ((v.date_sortie IS NULL) OR (v.date_sortie >= c.date_debut)) AND (relance.peut_administrer() OR (EXISTS ( SELECT 1
           FROM (relance.role_campagne rc
             JOIN relance.site s ON ((s.id = v.site_id)))
          WHERE ((rc.utilisateur_id = relance.utilisateur_courant()) AND (rc.campagne_id = c.id) AND (rc.role = 'chef_plaque'::text) AND (rc.plaque_id = s.plaque_id) AND (rc.archive_le IS NULL)))) OR (EXISTS ( SELECT 1
           FROM relance.role_campagne rc
          WHERE ((rc.utilisateur_id = relance.utilisateur_courant()) AND (rc.campagne_id = c.id) AND (rc.role = 'chef_site'::text) AND (rc.site_id = v.site_id) AND (rc.archive_le IS NULL)))) OR (EXISTS ( SELECT 1
           FROM relance.encadrement_site es
          WHERE ((es.utilisateur_id = relance.utilisateur_courant()) AND (es.site_id = v.site_id) AND (es.archive_le IS NULL)))) OR (EXISTS ( SELECT 1
           FROM ((relance.affectation a
             JOIN relance.table_phoning t ON ((t.id = a.table_id)))
             JOIN relance.session_plaque sp ON ((sp.id = t.session_plaque_id)))
          WHERE ((a.vendeur_id = v.id) AND (a.archive_le IS NULL) AND (t.archive_le IS NULL) AND (t.chef_utilisateur_id = relance.utilisateur_courant()) AND (sp.campagne_id = c.id) AND (sp.archive_le IS NULL))))));


--
-- Name: plaque; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.plaque (
    id bigint NOT NULL,
    libelle text NOT NULL,
    alias text,
    ordre integer DEFAULT 0 NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone
);


--
-- Name: plaque_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.plaque_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: plaque_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.plaque_id_seq OWNED BY relance.plaque.id;


--
-- Name: rdv; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.rdv (
    id bigint NOT NULL,
    campagne_id bigint NOT NULL,
    vendeur_id bigint NOT NULL,
    jour date NOT NULL,
    creneau_code text NOT NULL,
    marque_id bigint,
    type_vehicule text NOT NULL,
    client text NOT NULL,
    commentaire text,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    modifie_le timestamp(6) with time zone,
    modifie_par bigint,
    archive_le timestamp(6) with time zone,
    archive_par bigint,
    CONSTRAINT rdv_client_non_vide_check CHECK ((length(btrim(client)) > 0)),
    CONSTRAINT rdv_type_vehicule_check CHECK ((type_vehicule = ANY (ARRAY['VN'::text, 'VO'::text])))
);


--
-- Name: rdv_agrege; Type: VIEW; Schema: relance; Owner: -
--

CREATE VIEW relance.rdv_agrege AS
 SELECT id,
    campagne_id,
    vendeur_id,
    jour,
    creneau_code,
    marque_id,
    type_vehicule,
    cree_le,
    archive_le
   FROM relance.rdv r
  WHERE (relance.utilisateur_courant() IS NOT NULL);


--
-- Name: rdv_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.rdv_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rdv_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.rdv_id_seq OWNED BY relance.rdv.id;


--
-- Name: role_campagne_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.role_campagne_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: role_campagne_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.role_campagne_id_seq OWNED BY relance.role_campagne.id;


--
-- Name: role_global; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.role_global (
    utilisateur_id bigint NOT NULL,
    role text NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    CONSTRAINT role_global_role_check CHECK ((role = ANY (ARRAY['admin'::text, 'direction'::text, 'lecteur'::text])))
);


--
-- Name: session_plaque_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.session_plaque_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: session_plaque_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.session_plaque_id_seq OWNED BY relance.session_plaque.id;


--
-- Name: site_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: site_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.site_id_seq OWNED BY relance.site.id;


--
-- Name: table_phoning_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.table_phoning_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: table_phoning_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.table_phoning_id_seq OWNED BY relance.table_phoning.id;


--
-- Name: utilisateur; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.utilisateur (
    id bigint NOT NULL,
    login_id text NOT NULL,
    password_hash text NOT NULL,
    nom text NOT NULL,
    actif boolean DEFAULT true NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone,
    auth_uid uuid
);


--
-- Name: COLUMN utilisateur.auth_uid; Type: COMMENT; Schema: relance; Owner: -
--

COMMENT ON COLUMN relance.utilisateur.auth_uid IS 'Identifiant Supabase Auth (auth.users.id). NULL tant que le compte n''a pas ete relie. Aucune FK : voir la migration 20260831200000.';


--
-- Name: utilisateur_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.utilisateur_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: utilisateur_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.utilisateur_id_seq OWNED BY relance.utilisateur.id;


--
-- Name: vendeur_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.vendeur_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vendeur_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.vendeur_id_seq OWNED BY relance.vendeur.id;


--
-- Name: vendeur_marque; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.vendeur_marque (
    vendeur_id bigint NOT NULL,
    marque_id bigint NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint
);


--
-- Name: affectation id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.affectation ALTER COLUMN id SET DEFAULT nextval('relance.affectation_id_seq'::regclass);


--
-- Name: campagne id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.campagne ALTER COLUMN id SET DEFAULT nextval('relance.campagne_id_seq'::regclass);


--
-- Name: encadrement_site id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.encadrement_site ALTER COLUMN id SET DEFAULT nextval('relance.encadrement_site_id_seq'::regclass);


--
-- Name: marque id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.marque ALTER COLUMN id SET DEFAULT nextval('relance.marque_id_seq'::regclass);


--
-- Name: plaque id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.plaque ALTER COLUMN id SET DEFAULT nextval('relance.plaque_id_seq'::regclass);


--
-- Name: rdv id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.rdv ALTER COLUMN id SET DEFAULT nextval('relance.rdv_id_seq'::regclass);


--
-- Name: role_campagne id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.role_campagne ALTER COLUMN id SET DEFAULT nextval('relance.role_campagne_id_seq'::regclass);


--
-- Name: session_plaque id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.session_plaque ALTER COLUMN id SET DEFAULT nextval('relance.session_plaque_id_seq'::regclass);


--
-- Name: site id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.site ALTER COLUMN id SET DEFAULT nextval('relance.site_id_seq'::regclass);


--
-- Name: table_phoning id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.table_phoning ALTER COLUMN id SET DEFAULT nextval('relance.table_phoning_id_seq'::regclass);


--
-- Name: utilisateur id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.utilisateur ALTER COLUMN id SET DEFAULT nextval('relance.utilisateur_id_seq'::regclass);


--
-- Name: vendeur id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.vendeur ALTER COLUMN id SET DEFAULT nextval('relance.vendeur_id_seq'::regclass);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
c3320f35-1cb1-48d3-b154-011a8cfaf156	663bc3222aca5b5f031a3e92f31e1c27d71100c01dd878528b10f6668995fd12	2026-09-01 16:00:01.666769+00	20260901160000_vendeur_dates_contre_rdv	\N	\N	2026-09-01 16:00:01.339588+00	1
034c6337-8f5f-4cc4-bb2c-b0a47266601f	f91fef5197f9ce6f31beb50a6c1cd616ff2e1a0658fcec8952e970f903516ff6	2026-08-31 20:48:17.187601+00	20260828083906_init	\N	\N	2026-08-31 20:48:16.84487+00	1
7e21ca07-0a16-4b73-8f43-e2627375601e	a8435a7dd2f4a6ec9ab7caded693d28463f28a31374df732081b7270e75b5706	2026-08-31 20:48:22.175806+00	20260831201000_rls_portail	\N	\N	2026-08-31 20:48:21.816726+00	1
21ebccf8-3bd5-49c5-a141-e839326a990e	726e168a5281c8963e0ee703fcc9262701c3834d78357c29f95d8147be34a65b	2026-08-31 20:48:17.518104+00	20260828084443_table_phoning_unique	\N	\N	2026-08-31 20:48:17.276477+00	1
f7dd0868-33b8-43e0-a180-6bfa509c20ad	79aafe37634a24daf6351b054e78b9db3cd0d5a7121660e598caedb5aa03240b	2026-08-31 20:48:17.855516+00	20260828084642_marque_code_unique	\N	\N	2026-08-31 20:48:17.608949+00	1
99eae4f4-3ee6-4891-9cfc-18e509016f89	e7873192844e9ad922fdf6d70142b21984b587780f0b30bd7452ea807202651c	2026-08-31 20:48:18.340105+00	20260828090000_invariants	\N	\N	2026-08-31 20:48:17.982293+00	1
d85e8a26-c0b2-465b-be9a-0a0d4cfa03fc	bb7aa8e6c7e08b6ed80c3b0a89ba1a792cc8e9549373777c8e46ce2ddb51f729	2026-08-31 20:48:22.501309+00	20260831202000_triggers_hors_rls	\N	\N	2026-08-31 20:48:22.270654+00	1
a0a1e28b-b64d-4354-ba11-12bef5adf224	48b9288ceed6ca51d370a90c74acda08e77d832ac1014e71eb8bbc6e1f1e6e47	2026-08-31 20:48:18.696869+00	20260828091000_fix_affectation_unique	\N	\N	2026-08-31 20:48:18.452815+00	1
3b5dc4f8-e316-451a-ab05-b74573b23408	08c5fe8ea9d6cb607235f8a64e26fab12d280d0621d17e30d87edd3560417e92	2026-08-31 20:48:19.040117+00	20260828092952_marques_confirmees	\N	\N	2026-08-31 20:48:18.792129+00	1
9a7d8fbc-e799-4c8c-a7f3-29e7633c32ff	4ef1fe153c9bd997429985c5a63f1dae534f2c907fb975cefd10ff2bb9fca77a	2026-08-31 20:48:19.476783+00	20260828121219_vendeur_types_vehicule	\N	\N	2026-08-31 20:48:19.153909+00	1
5eb12b05-cf20-4f66-a0e5-3d9319656d4b	35f523c5ed80dc674eec7bcf015877273434687ab542191724d90c43c3ddaf03	2026-08-31 20:48:22.873781+00	20260831203000_rdv_agrege_compte_actif	\N	\N	2026-08-31 20:48:22.603913+00	1
5b310058-b12b-4151-9848-f467b0bcafbe	906125bc6e4ff14a63a707496d670e8c52ee5eef41be21ee430980b6862d7cfb	2026-08-31 20:48:19.883913+00	20260828140000_vendeur_type_scalaire	\N	\N	2026-08-31 20:48:19.603046+00	1
687baad8-4669-4546-aea8-74e8e6866700	6782c4a8e1c582798e7ab8ef8657cd69725ef1a7e2496aa33025895cdd5a3e05	2026-08-31 20:48:20.230605+00	20260828160000_affectation_meme_plaque	\N	\N	2026-08-31 20:48:19.961444+00	1
7f71923a-d1dd-4f78-a801-5394e5d1f3e2	e2fc62aeae4fdf8ab3f2b3b0ba2d595874fae0203ce025d4c0d3b83dd8e0de50	2026-09-03 08:15:13.054569+00	20260903065812_revoquer_execute_public	\N	\N	2026-09-03 08:15:12.730081+00	1
0b998f60-c78e-47a9-9aea-01e5f0bc24bf	b246a47f533735c55fe3f82fda03bbb0e51ca7e1b2b07d49edd908da7cbbebaa	2026-08-31 20:48:20.594508+00	20260831090000_table_specialisation	\N	\N	2026-08-31 20:48:20.335715+00	1
4fa87ad9-c2fd-4986-8536-7a85f67d65f2	1324cfd0f87dd0599a85c63ba2621853cae0fd29a20500bbc1897ff832abfc1b	2026-08-31 21:08:48.58242+00	20260831210000_rpc_privilegies	\N	\N	2026-08-31 21:08:48.148814+00	1
5ecabbc8-906f-4025-b3d0-51143e3ce56e	b9bc25688197a550d562cefbe3f58cb46e4db8861bbe30070e99ecd933798be0	2026-08-31 20:48:20.995261+00	20260831140000_encadrement_et_purge	\N	\N	2026-08-31 20:48:20.702141+00	1
0b9543be-ee5c-424b-8618-f760e5afb69d	4b915a14c0e99774f99d3cd91e3a544cf77db6fb37b171ace4ff3a2edd22c211	2026-08-31 20:48:21.387548+00	20260831180000_encadrants_comptes	\N	\N	2026-08-31 20:48:21.093345+00	1
a4cbbf19-ca40-438e-98ae-cba138c30915	80d560b4b705f634e6e539b55f834fa8300025c544398a9720839e5fe8a9c530	2026-08-31 20:48:21.71838+00	20260831200000_auth_uid	\N	\N	2026-08-31 20:48:21.486458+00	1
af3ddc2b-6923-4c38-a2d4-2443cae856c0	ed8b975bc704873bf4b3afc146e4176f398a2ead2d3a7c65cf59e167cd9349c6	2026-08-31 21:42:17.980581+00	20260831220000_diffusion_realtime	\N	\N	2026-08-31 21:42:17.649765+00	1
6e95a6cc-d076-49dd-95a6-4e6f2af3e834	cd06454f8dc43f8dac50b3c8220beeb492691d374f495b107fbdffae4758b6fa	2026-08-31 21:59:32.501785+00	20260831230000_canal_sans_deux_points	\N	\N	2026-08-31 21:59:32.192017+00	1
28aa5e09-b1e9-4c3b-a2c5-a56dc0f1e2d8	8d88252bc75fa3bc6ebb0954d538d4d65d23f7f2527b092ac6f89390f533fd2e	2026-08-31 22:35:04.542758+00	20260901090000_droits_service_role	\N	\N	2026-08-31 22:35:04.201542+00	1
2910245a-bde1-452f-bf19-84b49fb01ed6	03ce6c39b993d79520a474350abe48c953e9a2993ecd95c30a44776447bfeb5a	2026-09-01 15:46:46.856505+00	20260901120000_affectation_vendeur_present	\N	\N	2026-09-01 15:46:46.481453+00	1
\.


--
-- Data for Name: affectation; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.affectation (id, table_id, vendeur_id, origine, cree_le, cree_par, archive_le) FROM stdin;
1	1	20	manuel	2026-08-31 20:50:22.754+00	\N	\N
2	1	21	manuel	2026-08-31 20:50:22.841+00	\N	\N
3	1	10	manuel	2026-08-31 20:50:22.891+00	\N	\N
4	1	11	manuel	2026-08-31 20:50:22.931+00	\N	\N
5	1	27	manuel	2026-08-31 20:50:22.966+00	\N	\N
6	1	5	manuel	2026-08-31 20:50:23.066+00	\N	\N
7	2	25	manuel	2026-08-31 20:50:23.103+00	\N	\N
8	2	22	manuel	2026-08-31 20:50:23.146+00	\N	\N
9	2	29	manuel	2026-08-31 20:50:23.182+00	\N	\N
10	2	15	manuel	2026-08-31 20:50:23.224+00	\N	\N
11	2	3	manuel	2026-08-31 20:50:23.27+00	\N	\N
12	2	4	manuel	2026-08-31 20:50:23.32+00	\N	\N
13	3	13	manuel	2026-08-31 20:50:23.362+00	\N	\N
14	3	23	manuel	2026-08-31 20:50:23.421+00	\N	\N
15	3	16	manuel	2026-08-31 20:50:23.47+00	\N	\N
16	3	17	manuel	2026-08-31 20:50:23.523+00	\N	\N
17	3	26	manuel	2026-08-31 20:50:23.602+00	\N	\N
18	3	30	manuel	2026-08-31 20:50:23.671+00	\N	\N
19	4	24	manuel	2026-08-31 20:50:23.725+00	\N	\N
20	4	12	manuel	2026-08-31 20:50:23.775+00	\N	\N
21	4	18	manuel	2026-08-31 20:50:23.824+00	\N	\N
22	4	2	manuel	2026-08-31 20:50:23.881+00	\N	\N
23	4	6	manuel	2026-08-31 20:50:23.92+00	\N	\N
24	4	7	manuel	2026-08-31 20:50:23.98+00	\N	\N
25	5	28	manuel	2026-08-31 20:50:24.017+00	\N	\N
26	5	8	manuel	2026-08-31 20:50:24.061+00	\N	\N
27	5	9	manuel	2026-08-31 20:50:24.102+00	\N	\N
28	5	1	manuel	2026-08-31 20:50:24.162+00	\N	\N
29	5	19	manuel	2026-08-31 20:50:24.295+00	\N	\N
30	5	14	manuel	2026-08-31 20:50:24.34+00	\N	\N
31	6	62	manuel	2026-08-31 20:50:24.383+00	\N	\N
32	6	60	manuel	2026-08-31 20:50:24.444+00	\N	\N
33	6	57	manuel	2026-08-31 20:50:24.5+00	\N	\N
34	6	54	manuel	2026-08-31 20:50:24.54+00	\N	\N
35	6	68	manuel	2026-08-31 20:50:24.583+00	\N	\N
36	6	65	manuel	2026-08-31 20:50:24.628+00	\N	\N
37	7	55	manuel	2026-08-31 20:50:24.674+00	\N	\N
38	7	56	manuel	2026-08-31 20:50:24.723+00	\N	\N
39	7	66	manuel	2026-08-31 20:50:24.782+00	\N	\N
40	7	67	manuel	2026-08-31 20:50:24.84+00	\N	\N
41	7	61	manuel	2026-08-31 20:50:24.885+00	\N	\N
42	7	70	manuel	2026-08-31 20:50:24.943+00	\N	\N
43	8	53	manuel	2026-08-31 20:50:24.99+00	\N	\N
44	8	58	manuel	2026-08-31 20:50:25.031+00	\N	\N
45	8	59	manuel	2026-08-31 20:50:25.089+00	\N	\N
46	8	69	manuel	2026-08-31 20:50:25.127+00	\N	\N
47	8	63	manuel	2026-08-31 20:50:25.168+00	\N	\N
48	8	64	manuel	2026-08-31 20:50:25.247+00	\N	\N
458	11	18	manuel	2026-09-01 16:22:39.942687+00	92	\N
119	11	12	manuel	2026-09-01 15:33:24.773285+00	92	\N
503	9	27	manuel	2026-09-01 16:24:32.369555+00	92	\N
355	11	29	manuel	2026-09-01 16:10:29.873494+00	92	\N
122	9	17	manuel	2026-09-01 15:36:17.114882+00	92	\N
123	9	160	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:28:00.741819+00
514	10	213	manuel	2026-09-01 16:24:34.424935+00	92	\N
542	10	28	manuel	2026-09-01 16:26:10.237926+00	92	\N
527	10	25	manuel	2026-09-01 16:25:56.052063+00	92	2026-09-01 16:26:12.847571+00
120	9	11	auto	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
121	9	16	auto	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
1003	10	212	manuel	2026-09-02 12:33:32.457659+00	92	\N
126	9	25	auto	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
404	9	213	manuel	2026-09-01 16:18:22.397405+00	92	2026-09-01 16:24:34.330589+00
975	146	55	manuel	2026-09-02 09:37:18.5654+00	787	\N
966	146	68	manuel	2026-09-02 09:37:08.756176+00	787	\N
961	146	63	manuel	2026-09-02 09:36:56.215824+00	787	\N
380	10	15	manuel	2026-09-01 16:15:50.843134+00	92	2026-09-01 16:29:39.236415+00
557	12	25	manuel	2026-09-01 16:26:12.935278+00	92	\N
445	12	4	manuel	2026-09-01 16:21:19.493923+00	92	\N
398	13	18	manuel	2026-09-01 16:17:49.152953+00	92	2026-09-01 16:22:39.790055+00
118	12	27	manuel	2026-09-01 15:33:01.648281+00	92	2026-09-01 15:36:17.114882+00
940	145	66	manuel	2026-09-02 09:31:49.297693+00	787	\N
480	12	211	manuel	2026-09-01 16:24:10.226691+00	92	\N
954	145	882	manuel	2026-09-02 09:36:22.618244+00	787	\N
945	145	70	manuel	2026-09-02 09:32:11.551854+00	787	\N
634	10	8	manuel	2026-09-01 16:26:49.055013+00	92	2026-09-02 12:32:25.575309+00
420	12	28	manuel	2026-09-01 16:19:11.844782+00	92	2026-09-01 16:26:10.134249+00
377	13	3	manuel	2026-09-01 16:14:54.37136+00	92	2026-09-01 16:27:58.053286+00
492	9	212	manuel	2026-09-01 16:24:29.121256+00	92	2026-09-02 12:33:32.338735+00
386	10	17	manuel	2026-09-01 16:17:01.059119+00	92	2026-09-01 16:26:47.012437+00
125	9	8	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:26:48.967169+00
918	144	56	manuel	2026-09-01 16:49:47.200314+00	787	2026-09-04 15:10:50.024022+00
921	144	881	manuel	2026-09-02 09:29:26.909987+00	787	\N
933	144	57	manuel	2026-09-02 09:30:07.304445+00	787	\N
295	13	9	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:09:58.492635+00
284	11	8	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:42.573896+00
416	10	160	manuel	2026-09-01 16:19:00.878121+00	92	2026-09-01 16:26:31.851005+00
289	12	17	auto	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:04.929551+00
143	12	21	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:29:36.691409+00
917	144	66	manuel	2026-09-01 16:47:05.541155+00	787	2026-09-01 16:47:07.940102+00
133	11	7	auto	2026-09-01 15:36:17.114882+00	92	2026-09-01 15:54:28.676692+00
278	10	16	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:44.395376+00
271	9	2	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:20.23679+00
132	10	13	auto	2026-09-01 15:36:17.114882+00	92	2026-09-01 15:38:19.167368+00
277	10	23	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:46.005143+00
287	12	5	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:06.932049+00
269	9	12	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:21.546654+00
150	13	20	auto	2026-09-01 15:36:17.114882+00	92	2026-09-01 15:45:32.849189+00
939	144	60	manuel	2026-09-02 09:30:15.856488+00	787	\N
970	146	53	manuel	2026-09-02 09:37:16.501982+00	787	\N
131	10	18	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:10:24.634513+00
290	12	14	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:10.728207+00
924	144	69	manuel	2026-09-02 09:29:36.971986+00	787	\N
286	12	10	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:12.65505+00
282	11	3	auto	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:14.313187+00
139	12	23	auto	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
141	12	22	auto	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
142	12	3	auto	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
144	12	30	auto	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
134	11	6	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
135	11	1	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
130	10	12	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
127	10	5	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
919	144	62	manuel	2026-09-02 09:27:24.480863+00	787	\N
128	10	10	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
149	13	15	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
145	13	4	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
148	13	24	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
136	11	27	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
140	12	19	manuel	2026-09-01 15:36:17.114882+00	92	\N
138	11	9	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
288	12	11	manuel	2026-09-01 16:09:41.773837+00	92	\N
147	13	28	auto	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:52.678846+00
834	12	15	manuel	2026-09-01 16:29:39.331892+00	92	\N
963	146	65	manuel	2026-09-02 09:37:01.762322+00	787	\N
294	13	26	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:09:54.677259+00
981	146	61	manuel	2026-09-02 09:37:22.936546+00	787	\N
292	13	1	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:09:56.738521+00
376	11	214	manuel	2026-09-01 16:14:31.621838+00	92	\N
137	11	26	manuel	2026-09-01 15:36:17.114882+00	92	\N
268	9	15	auto	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:16.655365+00
280	11	24	manuel	2026-09-01 16:09:41.773837+00	92	\N
717	9	3	manuel	2026-09-01 16:27:58.173895+00	92	2026-09-02 12:32:03.585855+00
129	10	29	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:10:29.738855+00
272	9	22	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:17.83428+00
486	13	215	manuel	2026-09-01 16:24:16.765847+00	92	\N
273	9	30	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:18.959226+00
384	13	23	manuel	2026-09-01 16:16:51.960836+00	92	\N
463	13	16	manuel	2026-09-01 16:22:44.394464+00	92	\N
428	13	10	manuel	2026-09-01 16:19:37.585581+00	92	\N
146	13	2	manuel	2026-09-01 15:36:17.114882+00	92	\N
291	13	160	manuel	2026-09-01 16:09:41.773837+00	92	\N
283	11	4	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:32.613245+00
281	11	19	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:35.611782+00
378	9	26	manuel	2026-09-01 16:15:05.564154+00	92	2026-09-01 16:20:50.469134+00
285	11	25	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:38.518255+00
949	145	54	manuel	2026-09-02 09:36:14.095636+00	787	\N
942	145	67	manuel	2026-09-02 09:31:53.883002+00	787	\N
960	145	59	manuel	2026-09-02 09:36:30.814978+00	787	\N
276	10	27	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:24:32.298307+00
270	9	6	manuel	2026-09-01 16:09:41.773837+00	92	\N
449	9	5	manuel	2026-09-01 16:21:31.222739+00	92	\N
124	9	14	manuel	2026-09-01 15:36:17.114882+00	92	\N
279	10	21	manuel	2026-09-01 16:09:41.773837+00	92	\N
520	10	22	manuel	2026-09-01 16:24:40.341832+00	92	\N
393	10	9	manuel	2026-09-01 16:17:30.068762+00	92	\N
\.


--
-- Data for Name: campagne; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.campagne (id, libelle, date_debut, date_fin, cloturee, cree_le, cree_par, archive_le) FROM stdin;
1	Juin 2026	2026-06-11	2026-06-15	f	2026-08-31 20:50:17.444+00	\N	\N
2	Septembre 2026	2026-09-10	2026-09-14	f	2026-08-31 20:50:19.52+00	\N	\N
\.


--
-- Data for Name: campagne_creneau; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.campagne_creneau (campagne_id, code, libelle, ordre, cree_le, cree_par) FROM stdin;
1	08:00-09:00	8h-9h	1	2026-08-31 20:50:17.821+00	\N
1	09:00-10:00	9h-10h	2	2026-08-31 20:50:17.921+00	\N
1	10:00-11:00	10h-11h	3	2026-08-31 20:50:17.96+00	\N
1	11:00-12:00	11h-12h	4	2026-08-31 20:50:18.014+00	\N
1	12:00-13:00	12h-13h	5	2026-08-31 20:50:18.058+00	\N
1	13:00-14:00	13h-14h	6	2026-08-31 20:50:18.099+00	\N
1	14:00-15:00	14h-15h	7	2026-08-31 20:50:18.149+00	\N
1	15:00-16:00	15h-16h	8	2026-08-31 20:50:18.19+00	\N
1	16:00-17:00	16h-17h	9	2026-08-31 20:50:18.23+00	\N
1	17:00-18:00	17h-18h	10	2026-08-31 20:50:18.273+00	\N
1	18:00-19:00	18h-19h	11	2026-08-31 20:50:18.323+00	\N
2	08:00-09:00	8h-9h	1	2026-08-31 20:50:19.849+00	\N
2	09:00-10:00	9h-10h	2	2026-08-31 20:50:19.889+00	\N
2	10:00-11:00	10h-11h	3	2026-08-31 20:50:19.934+00	\N
2	11:00-12:00	11h-12h	4	2026-08-31 20:50:19.987+00	\N
2	12:00-13:00	12h-13h	5	2026-08-31 20:50:20.044+00	\N
2	13:00-14:00	13h-14h	6	2026-08-31 20:50:20.085+00	\N
2	14:00-15:00	14h-15h	7	2026-08-31 20:50:20.161+00	\N
2	15:00-16:00	15h-16h	8	2026-08-31 20:50:20.199+00	\N
2	16:00-17:00	16h-17h	9	2026-08-31 20:50:20.243+00	\N
2	17:00-18:00	17h-18h	10	2026-08-31 20:50:20.284+00	\N
2	18:00-19:00	18h-19h	11	2026-08-31 20:50:20.408+00	\N
\.


--
-- Data for Name: campagne_jour; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.campagne_jour (campagne_id, jour, ordre, cree_le, cree_par) FROM stdin;
1	2026-06-11	1	2026-08-31 20:50:17.546+00	\N
1	2026-06-12	2	2026-08-31 20:50:17.644+00	\N
1	2026-06-13	3	2026-08-31 20:50:17.691+00	\N
1	2026-06-14	4	2026-08-31 20:50:17.737+00	\N
1	2026-06-15	5	2026-08-31 20:50:17.78+00	\N
2	2026-09-10	1	2026-08-31 20:50:19.56+00	\N
2	2026-09-11	2	2026-08-31 20:50:19.607+00	\N
2	2026-09-12	3	2026-08-31 20:50:19.649+00	\N
2	2026-09-13	4	2026-08-31 20:50:19.713+00	\N
2	2026-09-14	5	2026-08-31 20:50:19.779+00	\N
\.


--
-- Data for Name: encadrement_site; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.encadrement_site (id, site_id, role, utilisateur_id, cree_le, cree_par, archive_le) FROM stdin;
544	15	chef_de_site	1777	2026-09-04 09:47:04.446432+00	1	\N
545	14	chef_de_site	1776	2026-09-04 09:47:15.417471+00	1	\N
546	18	chef_de_site	1775	2026-09-04 09:47:25.190832+00	1	\N
547	13	chef_de_site	1778	2026-09-04 09:48:03.668553+00	1	\N
548	19	chef_de_site	1778	2026-09-04 09:48:16.272587+00	1	\N
549	12	chef_de_site	1779	2026-09-04 09:49:33.361849+00	1	\N
550	17	chef_de_site	1780	2026-09-04 09:51:20.89576+00	1	\N
551	16	chef_de_site	1781	2026-09-04 09:51:31.002306+00	1	\N
552	12	chef_de_vente_vn	1778	2026-09-04 09:53:41.284847+00	1	\N
119	7	chef_de_vente_vn	97	2026-09-01 13:03:08.910207+00	92	2026-09-01 16:51:47.090954+00
35	2	chef_de_vente_vn	12	2026-08-31 20:53:18.168+00	\N	2026-09-01 16:28:32.236+00
110	3	chef_de_vente_vn	5	2026-09-01 12:01:04.526057+00	10	\N
111	5	chef_de_site	94	2026-09-01 13:00:01.411095+00	92	\N
34	3	chef_de_site	94	2026-08-31 20:53:17.946+00	\N	\N
113	3	chef_de_vente_vo	6	2026-09-01 13:00:15.179147+00	92	\N
114	1	chef_de_site	2	2026-09-01 13:00:21.513463+00	92	\N
115	2	chef_de_site	4	2026-09-01 13:00:34.781521+00	92	\N
116	4	chef_de_site	3	2026-09-01 13:00:56.770605+00	92	\N
117	7	chef_de_site	96	2026-09-01 13:02:03.428751+00	92	\N
118	8	chef_de_site	96	2026-09-01 13:03:01.351951+00	92	\N
120	6	chef_de_site	96	2026-09-01 13:03:21.300404+00	92	\N
121	6	chef_de_vente_vn	97	2026-09-01 13:03:43.943745+00	92	\N
122	11	chef_de_site	9	2026-09-01 13:04:10.655272+00	92	\N
123	9	chef_de_site	95	2026-09-01 13:04:32.927457+00	92	\N
124	9	chef_de_vente_vn	8	2026-09-01 13:04:38.333952+00	92	\N
125	9	chef_de_vente_vo	8	2026-09-01 13:04:44.588092+00	92	\N
126	10	chef_de_site	7	2026-09-01 13:04:53.644516+00	92	\N
\.


--
-- Data for Name: marque; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.marque (id, code, libelle, ordre, cree_le, cree_par, archive_le) FROM stdin;
1	RENAULT	Renault	1	2026-08-31 20:49:25.026+00	\N	\N
2	DACIA	Dacia	2	2026-08-31 20:49:25.128+00	\N	\N
3	ALPINE	Alpine	3	2026-08-31 20:49:25.174+00	\N	\N
\.


--
-- Data for Name: plaque; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.plaque (id, libelle, alias, ordre, cree_le, cree_par, archive_le) FROM stdin;
1	CENTRE	EAA	1	2026-08-31 20:49:25.236+00	\N	\N
2	NORD	\N	2	2026-08-31 20:49:25.332+00	\N	\N
3	SUD	\N	3	2026-08-31 20:49:25.371+00	\N	\N
4	SUD-OUEST	\N	4	2026-08-31 20:49:25.41+00	\N	\N
\.


--
-- Data for Name: rdv; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.rdv (id, campagne_id, vendeur_id, jour, creneau_code, marque_id, type_vehicule, client, commentaire, cree_le, cree_par, modifie_le, modifie_par, archive_le, archive_par) FROM stdin;
161	2	3	2026-09-10	08:00-09:00	1	VN	CONTROLE NAVIGATEURSAISIE ECRAN	\N	2026-08-31 21:50:44.921383+00	12	2026-08-31 22:00:23.239731+00	12	2026-08-31 22:00:22.212+00	\N
162	2	3	2026-09-10	09:00-10:00	1	VN	CLIENT DEPUIS LA GRILLE	\N	2026-08-31 21:51:54.608775+00	12	2026-08-31 22:00:23.239731+00	\N	2026-08-31 22:00:22.212+00	\N
194	2	1	2026-09-10	18:00-19:00	1	VN	DEPUIS LE TERMINAL	\N	2026-08-31 22:00:00.426+00	\N	2026-08-31 22:00:23.239731+00	\N	2026-08-31 22:00:22.212+00	\N
262	1	10	2026-06-11	09:00-10:00	1	VN	DELATOURAS	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
263	1	10	2026-06-12	09:00-10:00	1	VN	CHARDON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
264	1	10	2026-06-13	09:00-10:00	1	VN	TERON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
265	1	10	2026-06-14	09:00-10:00	1	VN	PERNET	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
266	1	10	2026-06-11	10:00-11:00	1	VN	CREMIEUX	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
267	1	10	2026-06-13	10:00-11:00	1	VN	MARI	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
268	1	10	2026-06-14	10:00-11:00	1	VN	FORMENTI	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
269	1	10	2026-06-11	11:00-12:00	1	VN	PICOT	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
270	1	10	2026-06-14	11:00-12:00	1	VN	CHAMBRE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
271	1	10	2026-06-12	12:00-13:00	1	VN	CHOMEILLE*	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
272	1	10	2026-06-12	14:00-15:00	1	VN	ZAMORA	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
273	1	10	2026-06-13	14:00-15:00	1	VN	VIALTAIX	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
274	1	10	2026-06-14	14:00-15:00	1	VN	ALVES	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
275	1	10	2026-06-11	16:00-17:00	1	VN	MARTIN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
276	1	10	2026-06-13	16:00-17:00	1	VN	BRETTE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
277	1	10	2026-06-14	16:00-17:00	1	VN	RAGOT 208	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
278	1	11	2026-06-12	09:00-10:00	1	VN	JELADE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
279	1	11	2026-06-13	09:00-10:00	1	VN	DEBLOIS	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
280	1	11	2026-06-11	10:00-11:00	1	VN	CHILE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
281	1	11	2026-06-15	10:00-11:00	1	VN	THEVENET	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
282	1	11	2026-06-12	11:00-12:00	1	VN	TARTRY	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
283	1	11	2026-06-15	11:00-12:00	1	VN	MESTRE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
284	1	11	2026-06-11	12:00-13:00	1	VN	VASSET	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
285	1	11	2026-06-12	12:00-13:00	1	VN	DE LA COTARDIERE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
286	1	11	2026-06-15	13:00-14:00	1	VN	ABEL	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
287	1	11	2026-06-12	14:00-15:00	1	VN	GUITTARD	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
288	1	11	2026-06-15	14:00-15:00	1	VN	BONNET	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
289	1	11	2026-06-15	16:00-17:00	1	VN	DELODDE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
290	1	11	2026-06-11	14:00-15:00	2	VN	CABANAC	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
291	1	11	2026-06-12	15:00-16:00	2	VN	MONNERON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
292	1	11	2026-06-11	16:00-17:00	2	VN	GOUTAIN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
293	1	11	2026-06-12	16:00-17:00	2	VN	POSSON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
294	1	11	2026-06-11	18:00-19:00	2	VN	GOUTEFANGEAT	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
295	1	12	2026-06-11	08:00-09:00	2	VN	RICCARDELLI (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
296	1	12	2026-06-12	09:00-10:00	2	VN	DELORME (BIGSTER)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
297	1	12	2026-06-13	09:00-10:00	2	VN	SCHAMPERS (JOGGER)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
298	1	12	2026-06-14	09:00-10:00	2	VN	DUREL (DUSTER)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
299	1	12	2026-06-11	10:00-11:00	2	VN	BERNIGAUD (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
300	1	12	2026-06-12	10:00-11:00	2	VN	DAMIANI (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
301	1	12	2026-06-13	10:00-11:00	2	VN	TROUCAS (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
302	1	12	2026-06-14	10:00-11:00	2	VN	PAILHE (SANDERO STEPWAY)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
303	1	12	2026-06-15	10:00-11:00	2	VN	VAGNE (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
304	1	12	2026-06-11	11:00-12:00	2	VN	CHAVAROCHE  (DUSTER)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
305	1	12	2026-06-12	11:00-12:00	2	VN	AMBLARD (BIGSTER)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
306	1	12	2026-06-11	14:00-15:00	2	VN	LEMONIER (STEPWAY)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
307	1	12	2026-06-12	14:00-15:00	2	VN	LEMOINE (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
308	1	12	2026-06-14	14:00-15:00	2	VN	FRANCES (DUSTER)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
309	1	12	2026-06-15	15:00-16:00	2	VN	BEAL (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
310	1	12	2026-06-14	16:00-17:00	2	VN	DUMAS (JOGGER)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
311	1	12	2026-06-11	17:00-18:00	2	VN	QUERART (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
312	1	12	2026-06-12	17:00-18:00	2	VN	MAILLET (BIGSTER)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
313	1	12	2026-06-13	17:00-18:00	2	VN	NUGER (JOGGER)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
314	1	12	2026-06-11	18:00-19:00	2	VN	JACQUIER (sandero)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
315	1	13	2026-06-11	09:00-10:00	1	VN	ARTAUD	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
316	1	13	2026-06-14	09:00-10:00	1	VN	BERKOUN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
317	1	13	2026-06-12	09:00-10:00	2	VN	NORE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
318	1	13	2026-06-13	09:00-10:00	2	VN	ALBERT	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
319	1	13	2026-06-11	10:00-11:00	2	VN	COUESNON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
320	1	13	2026-06-13	10:00-11:00	2	VN	OUDARD	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
321	1	13	2026-06-14	10:00-11:00	2	VN	VERNIERE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
322	1	13	2026-06-11	11:00-12:00	2	VN	CLAVELOU	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
323	1	13	2026-06-12	11:00-12:00	2	VN	DEGRANGE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
324	1	13	2026-06-11	13:00-14:00	2	VN	SAINTE ARROMAN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
325	1	13	2026-06-14	14:00-15:00	2	VN	DREUX	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
326	1	13	2026-06-14	15:00-16:00	2	VN	GORALSKI	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
327	1	13	2026-06-15	15:00-16:00	2	VN	GUIENNE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
328	1	14	2026-06-11	16:00-17:00	1	VN	LECHARPENTIER (Twingo ou Spring)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
329	1	14	2026-06-11	08:00-09:00	2	VN	GUERINO (Sandero)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
330	1	14	2026-06-12	09:00-10:00	2	VN	MUCIENTES (Sandero)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
331	1	14	2026-06-14	09:00-10:00	2	VN	CHANTELAUZE (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
332	1	14	2026-06-13	10:00-11:00	2	VN	RADINI (Duster 4x4 diesel reprise)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
333	1	14	2026-06-13	13:00-14:00	2	VN	GENINO (Sandero)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
334	1	14	2026-06-11	14:00-15:00	2	VN	LEMAIRE (DUster)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
335	1	14	2026-06-14	14:00-15:00	2	VN	FAURIOL (Bigster)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
336	1	14	2026-06-13	15:00-16:00	2	VN	GULF (jogger 7 places)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
337	1	14	2026-06-14	16:00-17:00	2	VN	ESCURE (Duster, reprise DUstuer diesel 4x4)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
338	1	14	2026-06-11	17:00-18:00	2	VN	ASTARI (Sandero)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
339	1	14	2026-06-12	18:00-19:00	2	VN	COL (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
340	1	15	2026-06-13	09:00-10:00	1	VN	SARDIER	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
341	1	15	2026-06-14	09:00-10:00	1	VN	JUNG	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
342	1	15	2026-06-15	09:00-10:00	1	VN	TISON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
343	1	15	2026-06-13	10:00-11:00	1	VN	JAMOT	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
344	1	15	2026-06-15	10:00-11:00	1	VN	GODARD	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
345	1	15	2026-06-11	14:00-15:00	1	VN	FAYARD	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
346	1	15	2026-06-15	14:00-15:00	1	VN	MARCHAND	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
347	1	15	2026-06-11	09:00-10:00	2	VN	NEGRONIE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
348	1	15	2026-06-12	09:00-10:00	2	VN	NAULT	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
349	1	15	2026-06-11	11:00-12:00	2	VN	MIAUX	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
350	1	15	2026-06-12	11:00-12:00	2	VN	FAURE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
351	1	15	2026-06-12	14:00-15:00	2	VN	DARTOIS	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
352	1	15	2026-06-13	14:00-15:00	2	VN	DUBOIS	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
353	1	15	2026-06-12	16:00-17:00	2	VN	MONTOLOY	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
354	1	15	2026-06-12	17:00-18:00	2	VN	EYDIEUX	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
355	1	16	2026-06-11	09:00-10:00	1	VN	JALAN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
356	1	16	2026-06-15	09:00-10:00	1	VN	RAMBEAU	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
357	1	16	2026-06-12	10:00-11:00	1	VN	STRADY	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
358	1	16	2026-06-14	10:00-11:00	1	VN	RAMBAUD	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
359	1	16	2026-06-15	10:00-11:00	1	VN	BAYDE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
360	1	16	2026-06-11	11:00-12:00	1	VN	MEUNIER	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
361	1	16	2026-06-12	11:00-12:00	1	VN	VOLDOIRE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
362	1	16	2026-06-12	12:00-13:00	1	VN	LAGACHE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
363	1	16	2026-06-13	12:00-13:00	1	VN	MONTOUTON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
364	1	16	2026-06-12	14:00-15:00	1	VN	ROUX	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
365	1	16	2026-06-13	14:00-15:00	1	VN	COUDERT	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
366	1	16	2026-06-14	14:00-15:00	1	VN	JOURNIAC	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
367	1	16	2026-06-12	16:00-17:00	1	VN	CHEVALIER	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
368	1	16	2026-06-11	17:00-18:00	1	VN	ZAKARIA	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
369	1	16	2026-06-15	17:00-18:00	1	VN	BARRA	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
370	1	17	2026-06-11	09:00-10:00	1	VN	SIGURET	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
371	1	17	2026-06-13	09:00-10:00	1	VN	CEYRAS	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
372	1	17	2026-06-14	09:00-10:00	1	VN	HABRIAL	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
373	1	17	2026-06-15	09:00-10:00	1	VN	LECOIN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
374	1	17	2026-06-11	10:00-11:00	1	VN	GAUDICHON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
375	1	17	2026-06-14	10:00-11:00	1	VN	SAUSSAC	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
376	1	17	2026-06-15	11:00-12:00	1	VN	DEKEYSER	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
377	1	17	2026-06-11	13:00-14:00	1	VN	KANIT	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
378	1	17	2026-06-12	13:00-14:00	1	VN	CORDIESE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
379	1	17	2026-06-11	14:00-15:00	1	VN	MAILHOT	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
380	1	17	2026-06-12	14:00-15:00	1	VN	BONNIN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
381	1	17	2026-06-13	14:00-15:00	1	VN	BERTIN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
382	1	17	2026-06-14	14:00-15:00	1	VN	VAYSSADE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
383	1	17	2026-06-13	15:00-16:00	1	VN	MONTBOISSE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
384	1	17	2026-06-15	15:00-16:00	1	VN	CURADO	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
385	1	17	2026-06-11	16:00-17:00	1	VN	FOZEN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
386	1	17	2026-06-13	17:00-18:00	1	VN	CHALLET	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
387	1	17	2026-06-15	17:00-18:00	1	VN	FLORES	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
388	1	18	2026-06-12	09:00-10:00	1	VN	LAON (R4)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
389	1	18	2026-06-13	09:00-10:00	1	VN	MR BAYARD	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
390	1	18	2026-06-11	10:00-11:00	1	VN	ABRANTES (TWINGO ETECH)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
391	1	18	2026-06-12	10:00-11:00	1	VN	HOUZEAU (AUSTRAl)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
392	1	18	2026-06-15	10:00-11:00	1	VN	GLAIZE (R4 E TECH)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
393	1	18	2026-06-11	14:00-15:00	1	VN	MARTINEZ (CLIO 6)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
394	1	18	2026-06-12	14:00-15:00	1	VN	MARQUES (CAPTUR)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
395	1	18	2026-06-13	14:00-15:00	1	VN	GAILLER (CLIO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
396	1	18	2026-06-14	14:00-15:00	1	VN	CHANUDET (R5)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
397	1	18	2026-06-15	14:00-15:00	1	VN	MEAUGER (TWINGO ETECH)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
398	1	18	2026-06-12	15:00-16:00	1	VN	ROUGIER (CLIO 6 ECO G)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
399	1	18	2026-06-13	15:00-16:00	1	VN	CHAPER (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
400	1	18	2026-06-11	16:00-17:00	1	VN	DUMONT (R5 ETECH)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
401	1	18	2026-06-11	17:00-18:00	1	VN	DAGUNA (TWINGO etech)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
402	1	18	2026-06-15	18:00-19:00	1	VN	DAULAT	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
403	1	19	2026-06-11	08:00-09:00	1	VN	MIGLIAVACCA (Clio)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
404	1	19	2026-06-12	08:00-09:00	1	VN	BELOT (R5)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
405	1	19	2026-06-11	09:00-10:00	1	VN	TARDIVAT (Captur)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
406	1	19	2026-06-13	09:00-10:00	1	VN	PENOT (Twingo electrique)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
407	1	19	2026-06-14	09:00-10:00	1	VN	MISSONIER (R5)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
408	1	19	2026-06-15	09:00-10:00	1	VN	RODIER (Clio)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
409	1	19	2026-06-11	10:00-11:00	1	VN	GROSSE (Twingo)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
410	1	19	2026-06-12	10:00-11:00	1	VN	LOUIS Isabelle (R5)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
411	1	19	2026-06-13	10:00-11:00	1	VN	SAHUC (reprise Twingo)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
412	1	19	2026-06-14	10:00-11:00	1	VN	HEALY (fin solde)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
413	1	19	2026-06-13	11:00-12:00	1	VN	PIRONNET (Captur)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
414	1	19	2026-06-11	14:00-15:00	1	VN	SALGADO (Twingo)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
415	1	19	2026-06-14	14:00-15:00	1	VN	DALLOUBEIX (reprise Captur)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
416	1	19	2026-06-12	15:00-16:00	1	VN	SEVAILLE (R5 Megane elec)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
417	1	19	2026-06-11	16:00-17:00	1	VN	DEBONNO (Captur)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
418	1	19	2026-06-12	16:00-17:00	1	VN	DEPRESLE (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
419	1	19	2026-06-13	16:00-17:00	1	VN	LAPORTE (reprise Captur)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
420	1	19	2026-06-12	17:00-18:00	1	VN	CLAVEL (Clio)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
421	1	19	2026-06-13	17:00-18:00	1	VN	GUILLON COTARD (Captur)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
422	1	19	2026-06-15	17:00-18:00	1	VN	PETIT (CLio)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
423	1	20	2026-06-12	11:00-12:00	2	VN	ROUX	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
424	1	20	2026-06-13	11:00-12:00	2	VN	NICODEME	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
425	1	20	2026-06-15	11:00-12:00	2	VN	BARDOTTI	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
426	1	20	2026-06-12	14:00-15:00	2	VN	MOULY	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
427	1	20	2026-06-15	14:00-15:00	2	VN	PLANE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
428	1	20	2026-06-13	16:00-17:00	2	VN	SERRE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
429	1	20	2026-06-14	16:00-17:00	2	VN	GOGEOUR	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
430	1	20	2026-06-15	16:00-17:00	2	VN	BRUSTEL	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
431	1	20	2026-06-12	17:00-18:00	2	VN	JARNIAL	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
432	1	20	2026-06-15	18:00-19:00	2	VN	PEDRINI	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
433	1	21	2026-06-15	09:00-10:00	\N	VO	ESPOSITO	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
434	1	21	2026-06-13	10:00-11:00	\N	VO	PERETON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
435	1	21	2026-06-15	10:00-11:00	\N	VO	FERREIRA	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
436	1	21	2026-06-15	11:00-12:00	\N	VO	COURAGEOT	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
437	1	21	2026-06-13	14:00-15:00	\N	VO	JAFFEUX	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
438	1	21	2026-06-14	14:00-15:00	\N	VO	SOUCHER	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
439	1	21	2026-06-14	16:00-17:00	\N	VO	LARVOL	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
440	1	21	2026-06-12	17:00-18:00	\N	VO	VANDEVILLE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
441	1	21	2026-06-14	17:00-18:00	\N	VO	PLANCHER	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
442	1	21	2026-06-15	18:00-19:00	\N	VO	PETIT	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
443	1	22	2026-06-11	10:00-11:00	\N	VO	SEBASTIEN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
444	1	22	2026-06-13	10:00-11:00	\N	VO	BONIN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
445	1	22	2026-06-13	11:00-12:00	\N	VO	TERKIHADJ	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
446	1	22	2026-06-14	14:00-15:00	\N	VO	FRANCK	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
447	1	22	2026-06-11	15:00-16:00	\N	VO	MARTIN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
448	1	22	2026-06-13	15:00-16:00	\N	VO	MARET	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
449	1	22	2026-06-14	16:00-17:00	\N	VO	FAURE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
450	1	22	2026-06-15	16:00-17:00	\N	VO	BOULANGER	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
451	1	22	2026-06-11	17:00-18:00	\N	VO	PERREIRA	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
452	1	23	2026-06-11	09:00-10:00	\N	VO	SOYDARI	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
453	1	23	2026-06-14	09:00-10:00	\N	VO	COLON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
454	1	23	2026-06-12	10:00-11:00	\N	VO	HANNARD	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
455	1	23	2026-06-11	11:00-12:00	\N	VO	DAMON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
456	1	23	2026-06-11	13:00-14:00	\N	VO	GENESTIER	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
457	1	23	2026-06-12	14:00-15:00	\N	VO	LANDILLON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
458	1	23	2026-06-11	17:00-18:00	\N	VO	PAYET	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
459	1	24	2026-06-12	09:00-10:00	\N	VO	LAMBAIN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
460	1	24	2026-06-14	09:00-10:00	\N	VO	ROUFFET	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
461	1	24	2026-06-14	10:00-11:00	\N	VO	BENIER (CAPTUR)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
462	1	24	2026-06-13	11:00-12:00	\N	VO	RICHARD	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
463	1	24	2026-06-12	14:00-15:00	\N	VO	ROUDIER (CLIO DIESEL)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
464	1	24	2026-06-13	14:00-15:00	\N	VO	CHEREL (CLIO 5 hev)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
465	1	24	2026-06-14	16:00-17:00	\N	VO	FRUQUIERE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
466	1	24	2026-06-15	16:00-17:00	\N	VO	MALLET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
467	1	24	2026-06-12	17:00-18:00	\N	VO	ADDEO (CLIO)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
468	1	24	2026-06-15	17:00-18:00	\N	VO	GATIGNOL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
469	1	25	2026-06-13	09:00-10:00	\N	VO	EHMIG	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
470	1	25	2026-06-14	09:00-10:00	\N	VO	ROUFFET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
471	1	25	2026-06-11	14:00-15:00	\N	VO	ROUVET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
472	1	25	2026-06-13	14:00-15:00	\N	VO	GORY	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
473	1	25	2026-06-15	14:00-15:00	\N	VO	DEVERNOIS	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
474	1	25	2026-06-14	16:00-17:00	\N	VO	FRUQUIERE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
475	1	25	2026-06-11	17:00-18:00	\N	VO	GHIAB	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
476	1	25	2026-06-12	17:00-18:00	\N	VO	MAUME	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
477	1	25	2026-06-13	17:00-18:00	\N	VO	BONNET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
478	1	25	2026-06-15	17:00-18:00	\N	VO	ANADON LUIS	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
479	1	25	2026-06-15	14:00-15:00	\N	VO	DE SOUSA	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
480	1	3	2026-06-12	09:00-10:00	1	VN	GIAMPRETIE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
481	1	3	2026-06-13	09:00-10:00	1	VN	ALLENDE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
482	1	3	2026-06-14	10:00-11:00	1	VN	BELKADI	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
483	1	3	2026-06-13	11:00-12:00	1	VN	SEMA	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
484	1	3	2026-06-13	14:00-15:00	1	VN	GUYONNET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
485	1	3	2026-06-14	14:00-15:00	1	VN	BERTRAND	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
486	1	3	2026-06-12	15:00-16:00	1	VN	FUZET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
487	1	3	2026-06-15	15:00-16:00	1	VN	LASTIQUE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
488	1	3	2026-06-13	16:00-17:00	1	VN	MUNOZ	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
489	1	3	2026-06-15	16:00-17:00	1	VN	CLEMENT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
490	1	3	2026-06-12	17:00-18:00	1	VN	BRONGNIART	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
491	1	3	2026-06-13	17:00-18:00	1	VN	VERGNE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
492	1	3	2026-06-14	17:00-18:00	1	VN	CHONAL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
493	1	3	2026-06-15	10:00-11:00	2	VN	CHELLES	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
494	1	3	2026-06-12	14:00-15:00	2	VN	PINET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
495	1	3	2026-06-14	14:00-15:00	2	VN	GIUSIANO	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
496	1	3	2026-06-12	16:00-17:00	2	VN	MORIOL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
497	1	4	2026-06-12	08:00-09:00	1	VN	THOMAS	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
498	1	4	2026-06-11	09:00-10:00	1	VN	KUNTZ	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
499	1	4	2026-06-12	09:00-10:00	1	VN	FRADETAL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
500	1	4	2026-06-11	10:00-11:00	1	VN	SEGUIN	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
501	1	4	2026-06-14	10:00-11:00	1	VN	MARTINET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
502	1	4	2026-06-13	11:00-12:00	1	VN	PERONNET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
503	1	4	2026-06-12	14:00-15:00	1	VN	GRAVIL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
504	1	4	2026-06-13	14:00-15:00	1	VN	ARNAUD	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
505	1	4	2026-06-14	14:00-15:00	1	VN	GRENIER	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
506	1	4	2026-06-12	15:00-16:00	1	VN	IMBERT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
507	1	4	2026-06-13	15:00-16:00	1	VN	DECLOUX	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
508	1	4	2026-06-11	17:00-18:00	1	VN	PETITCOLLIN	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
509	1	4	2026-06-13	10:00-11:00	2	VN	ARDAILLON	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
510	1	4	2026-06-11	11:00-12:00	2	VN	COUDERT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
511	1	4	2026-06-11	14:00-15:00	2	VN	BONNOT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
512	1	4	2026-06-13	14:00-15:00	2	VN	ARCHAMBEAU	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
513	1	4	2026-06-11	16:00-17:00	2	VN	CHARVEL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
514	1	4	2026-06-12	17:00-18:00	2	VN	MENUGE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
515	1	5	2026-06-11	09:00-10:00	1	VN	GUERIOT ANNA	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
516	1	5	2026-06-12	09:00-10:00	1	VN	GONZALEZ	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
517	1	5	2026-06-14	09:00-10:00	1	VN	PEROL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
518	1	5	2026-06-14	10:00-11:00	1	VN	TINEL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
519	1	5	2026-06-11	11:00-12:00	1	VN	DUMAS	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
520	1	5	2026-06-11	14:00-15:00	1	VN	PREVOT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
521	1	5	2026-06-12	14:00-15:00	1	VN	PETIT CLEMENT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
522	1	5	2026-06-15	14:00-15:00	1	VN	DEGUIS	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
523	1	5	2026-06-11	15:00-16:00	1	VN	SCHANK	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
524	1	5	2026-06-13	17:00-18:00	1	VN	MARION GILLES	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
525	1	5	2026-06-13	18:00-19:00	1	VN	SCANDELLA	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
526	1	5	2026-06-12	09:00-10:00	2	VN	MORLIN	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
527	1	5	2026-06-11	10:00-11:00	2	VN	SAUVADET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
528	1	5	2026-06-13	11:00-12:00	2	VN	GOUT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
529	1	5	2026-06-11	17:00-18:00	2	VN	GILON	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
530	1	6	2026-06-12	09:00-10:00	1	VN	ROULLEAU (CLIO)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
531	1	6	2026-06-14	09:00-10:00	1	VN	GIRAUD (CAPTUR)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
532	1	6	2026-06-13	10:00-11:00	1	VN	THEUIL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
533	1	6	2026-06-14	10:00-11:00	1	VN	AMBLARD (ESPACE)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
534	1	6	2026-06-15	10:00-11:00	1	VN	DIOGON (AUSTRAL OU RAFALE)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
535	1	6	2026-06-14	11:00-12:00	1	VN	VACHER ( CAPTUR)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
536	1	6	2026-06-13	14:00-15:00	1	VN	DEVILLARD (R5 E TECH)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
537	1	6	2026-06-14	14:00-15:00	1	VN	ESSARD (R5 E TYECH)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
538	1	6	2026-06-14	15:00-16:00	1	VN	CHARMETON (AUSTRAL)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
539	1	6	2026-06-11	16:00-17:00	1	VN	ROAESTER (CLIO)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
540	1	6	2026-06-13	16:00-17:00	1	VN	BOUSSEARE (R5)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
541	1	6	2026-06-11	17:00-18:00	1	VN	BASQUE (R5)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
542	1	6	2026-06-12	18:00-19:00	1	VN	CALDEIRA (CLIO 5 OU 6)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
543	1	6	2026-06-12	08:00-09:00	2	VN	HEMAR (JOGGER)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
544	1	6	2026-06-11	09:00-10:00	2	VN	Thors (Stepway)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
545	1	6	2026-06-11	10:00-11:00	2	VN	FOUCAUD (STEPWAY)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
546	1	6	2026-06-13	11:00-12:00	2	VN	MALARD (SPRING)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
547	1	6	2026-06-11	15:00-16:00	2	VN	PELLET (DUSTER)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
548	1	6	2026-06-11	18:00-19:00	2	VN	FRESCENAUNAI (JOGGER)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
549	1	7	2026-06-13	09:00-10:00	1	VN	MONIER (SCENIC E TECH)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
550	1	7	2026-06-11	10:00-11:00	1	VN	DEBAIN (R5)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
551	1	7	2026-06-12	10:00-11:00	1	VN	BOLLATON (R5)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
552	1	7	2026-06-11	14:00-15:00	1	VN	BRASSIER (CAPTUR)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
553	1	7	2026-06-12	14:00-15:00	1	VN	RASTERO (scenic etech)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
554	1	7	2026-06-13	14:00-15:00	1	VN	PIROIRE MEGANE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
555	1	7	2026-06-15	14:00-15:00	1	VN	RM	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
556	1	7	2026-06-13	15:00-16:00	1	VN	MAGUIGNOU (CLIO 6)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
557	1	7	2026-06-12	16:00-17:00	1	VN	BELLET (R5 ETECH)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
558	1	7	2026-06-13	16:00-17:00	1	VN	FAURE (R4 ETECH)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
559	1	7	2026-06-11	17:00-18:00	1	VN	COURTIAL CLIO 6	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
560	1	7	2026-06-13	10:00-11:00	2	VN	DEBEZ(sandero)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
561	1	7	2026-06-11	11:00-12:00	2	VN	MARTINS (jOGGER)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
562	1	7	2026-06-13	11:00-12:00	2	VN	BELLE SANDERO OU DUSTER	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
563	1	7	2026-06-15	15:00-16:00	2	VN	PONNA SANDERO	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
564	1	7	2026-06-14	17:00-18:00	2	VN	POUILLY (SCENIC)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
565	1	8	2026-06-11	08:00-09:00	\N	VO	THIALLET (Espace 6)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
566	1	8	2026-06-12	08:00-09:00	\N	VO	BIDET (DUSTER)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
567	1	8	2026-06-11	09:00-10:00	\N	VO	PLANCHAT (CLio 5)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
568	1	8	2026-06-13	09:00-10:00	\N	VO	MALESTROIT (DUster)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
569	1	8	2026-06-11	10:00-11:00	\N	VO	SUGERE (ARKANA)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
570	1	8	2026-06-13	10:00-11:00	\N	VO	MORGAN (Clio)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
571	1	8	2026-06-14	10:00-11:00	\N	VO	ABDALAH (reprise clio)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
572	1	8	2026-06-11	11:00-12:00	\N	VO	BOUAJAY (Sandero)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
573	1	8	2026-06-13	11:00-12:00	\N	VO	FIGUERIDO (Megane)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
574	1	8	2026-06-14	11:00-12:00	\N	VO	LIGIER (DOkker)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
575	1	8	2026-06-11	14:00-15:00	\N	VO	ROLLIN (Captur)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
576	1	8	2026-06-13	14:00-15:00	\N	VO	BAUDOIN (Austral)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
577	1	8	2026-06-14	14:00-15:00	\N	VO	DA SILVA (CLio)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
578	1	8	2026-06-15	14:00-15:00	\N	VO	CLEMENT (Captur)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
579	1	8	2026-06-14	15:00-16:00	\N	VO	TESSANDIER (CAPTUR)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
580	1	8	2026-06-13	16:00-17:00	\N	VO	MAZZOLINI (reprise Zoé)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
581	1	8	2026-06-12	17:00-18:00	\N	VO	FOURNIER (Arkana)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
582	1	8	2026-06-15	18:00-19:00	\N	VO	LANDRO (Sandero)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
583	1	9	2026-06-12	08:00-09:00	\N	VO	CORNOT (Austral?)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
584	1	9	2026-06-14	10:00-11:00	\N	VO	PERTIN (CLio)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
585	1	9	2026-06-11	11:00-12:00	\N	VO	AVRIL (Jogger)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
586	1	9	2026-06-13	11:00-12:00	\N	VO	Mairie de BORNES les MIMOSA (Master benne)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
587	1	9	2026-06-14	11:00-12:00	\N	VO	PERTIN (Captur)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
588	1	9	2026-06-11	14:00-15:00	\N	VO	PRADA (Sandero)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
589	1	9	2026-06-12	14:00-15:00	\N	VO	GARDON (Renouvellement elec)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
590	1	9	2026-06-13	14:00-15:00	\N	VO	LAMBERT (Clio hybride 145)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
591	1	9	2026-06-14	14:00-15:00	\N	VO	BAFOURD (Clio)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
592	1	9	2026-06-11	15:00-16:00	\N	VO	VAURE - DENIS (LOA elec)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
593	1	9	2026-06-14	15:00-16:00	\N	VO	MAZE (CLio)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
594	1	9	2026-06-11	16:00-17:00	\N	VO	DEVEAUX (Sandero)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
595	1	9	2026-06-11	17:00-18:00	\N	VO	BOURJIS (Zoé ?)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
596	1	26	2026-06-11	11:00-12:00	1	VN	SIMMONOT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
597	1	26	2026-06-12	14:00-15:00	1	VN	REDONDY	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
598	1	26	2026-06-13	14:00-15:00	1	VN	SULTAN	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
599	1	26	2026-06-13	16:00-17:00	1	VN	CHABOT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
600	1	26	2026-06-11	10:00-11:00	2	VN	BELLEGUEULE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
601	1	26	2026-06-14	11:00-12:00	2	VN	MALAQUI	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
602	1	26	2026-06-12	16:00-17:00	2	VN	JACOB	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
603	1	27	2026-06-11	08:00-09:00	1	VN	¨GOIFFON	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
604	1	27	2026-06-13	10:00-11:00	1	VN	PAREL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
605	1	27	2026-06-14	10:00-11:00	1	VN	FAUGERAS	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
606	1	27	2026-06-13	11:00-12:00	1	VN	SCHOENMAKERS	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
607	1	27	2026-06-12	14:00-15:00	1	VN	NIN	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
608	1	27	2026-06-13	14:00-15:00	1	VN	ARNOULT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
609	1	27	2026-06-11	16:00-17:00	1	VN	GOUYO	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
610	1	27	2026-06-12	11:00-12:00	2	VN	TREUIL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
611	1	27	2026-06-12	15:00-16:00	2	VN	SABOURIN	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
612	1	27	2026-06-13	16:00-17:00	2	VN	JAKSIK	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
613	1	28	2026-06-13	08:00-09:00	\N	VO	GUGGER (DUSTER)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
614	1	28	2026-06-13	09:00-10:00	\N	VO	NOEL (Arkana)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
615	1	28	2026-06-14	10:00-11:00	\N	VO	PRELAT (Spring)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
616	1	28	2026-06-12	14:00-15:00	\N	VO	COSTERO (DUSTER)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
617	1	28	2026-06-13	15:00-16:00	\N	VO	CELERIER (Captur)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
618	1	28	2026-06-14	15:00-16:00	\N	VO	DUPONT (VO)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
619	1	28	2026-06-12	17:00-18:00	\N	VO	BARRAGE (Duster)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
620	1	29	2026-06-13	09:00-10:00	3	VN	MATHE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
621	1	29	2026-06-13	10:00-11:00	3	VN	DUMAZET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
622	1	29	2026-06-14	10:00-11:00	3	VN	DELENCLOS	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
623	1	29	2026-06-12	11:00-12:00	3	VN	BERGOGNE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
624	1	29	2026-06-13	11:00-12:00	3	VN	LEHMAN	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
625	1	29	2026-06-14	11:00-12:00	3	VN	BATISSON	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
626	1	29	2026-06-12	14:00-15:00	3	VN	MOREL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
627	1	29	2026-06-13	14:00-15:00	3	VN	ZHAO	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
628	1	29	2026-06-14	14:00-15:00	3	VN	IERA	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
629	1	29	2026-06-13	15:00-16:00	3	VN	VALETTE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
630	1	29	2026-06-14	15:00-16:00	3	VN	MINET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
631	1	29	2026-06-12	16:00-17:00	3	VN	MEZIN	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
632	1	29	2026-06-13	16:00-17:00	3	VN	BILLEBAULT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
633	1	29	2026-06-13	17:00-18:00	3	VN	BILLEBAULT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
634	1	30	2026-06-12	09:00-10:00	3	VN	lacroix  (l,nore)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
635	1	30	2026-06-11	10:00-11:00	3	VN	THEVENET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
636	1	30	2026-06-12	10:00-11:00	3	VN	IZARD	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
637	1	30	2026-06-13	10:00-11:00	3	VN	CABANO	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
638	1	30	2026-06-14	10:00-11:00	3	VN	chevasson (l,nore)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
639	1	30	2026-06-12	11:00-12:00	3	VN	ramon (l,nore)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
640	1	30	2026-06-13	13:00-14:00	3	VN	garret (l,nore)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
641	1	30	2026-06-11	14:00-15:00	3	VN	PESTANA	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
642	1	30	2026-06-12	14:00-15:00	3	VN	DUCROT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
643	1	30	2026-06-13	14:00-15:00	3	VN	COMBETTES	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
644	1	30	2026-06-14	14:00-15:00	3	VN	gieze (l,nore)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
645	1	30	2026-06-13	15:00-16:00	3	VN	POUZET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
646	1	30	2026-06-11	16:00-17:00	3	VN	SEVESTRE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
647	1	30	2026-06-12	16:00-17:00	3	VN	LAVERGNE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
648	1	30	2026-06-12	17:00-18:00	3	VN	BERNAT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
649	1	1	2026-06-11	09:00-10:00	1	VN	MOUSTEY (Megane VO)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
650	1	1	2026-06-13	09:00-10:00	1	VN	MOURTON (Scenic)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
651	1	1	2026-06-15	09:00-10:00	1	VN	CHEVALIER (CLio 6)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
652	1	1	2026-06-14	10:00-11:00	1	VN	BOUANET (R5)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
653	1	1	2026-06-13	11:00-12:00	1	VN	VIAL (Duster 4x4)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
654	1	1	2026-06-14	11:00-12:00	1	VN	PECOL (R4)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
655	1	1	2026-06-13	15:00-16:00	1	VN	PUERTAS (SANDERO)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
656	1	1	2026-06-12	12:00-13:00	2	VN	ENSMINGER (Spring ou Sandero)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
657	1	1	2026-06-12	15:00-16:00	2	VN	BRIGO (Sandero bleu)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
658	1	2	2026-06-11	09:00-10:00	1	VN	MERCIER (CLIO EVO)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
659	1	2	2026-06-14	09:00-10:00	1	VN	SOULE (GAMME EV)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
660	1	2	2026-06-15	09:00-10:00	1	VN	BOUCHERIE TAVES /VERNY	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
661	1	2	2026-06-12	10:00-11:00	1	VN	Esperaing (Twingo)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
662	1	2	2026-06-11	11:00-12:00	1	VN	DOME SANCY ARTENSE( KANGOO)	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
663	1	2	2026-06-13	11:00-12:00	1	VN	TERPENEAU (R5)	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
664	1	2	2026-06-11	14:00-15:00	1	VN	PETIT (R5 ETECH)	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
862	1	49	2026-06-12	15:00-16:00	1	VN	Derbias	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
665	1	2	2026-06-13	14:00-15:00	1	VN	MONIER (TWINGO OU R5)	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
666	1	2	2026-06-12	17:00-18:00	1	VN	DARPHIN (TWINGO)	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
667	1	2	2026-06-13	09:00-10:00	2	VN	BERGER SANDERO	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
668	1	2	2026-06-11	16:00-17:00	2	VN	Guillon Duster	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
669	1	42	2026-06-12	09:00-10:00	2	VN	Laustriat Jogger	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
670	1	42	2026-06-13	09:00-10:00	2	VN	Laborde Duster	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
671	1	42	2026-06-11	10:00-11:00	2	VN	Gaillard Sandero	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
672	1	42	2026-06-14	10:00-11:00	2	VN	Molle Sandero	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
673	1	42	2026-06-13	11:00-12:00	2	VN	Fardeau Sandero	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
674	1	42	2026-06-11	14:00-15:00	2	VN	Schmalzle Sandero	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
675	1	42	2026-06-13	14:00-15:00	2	VN	Hissler Sandero	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
676	1	42	2026-06-11	15:00-16:00	2	VN	Mousse Sandero	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
677	1	42	2026-06-12	15:00-16:00	2	VN	Caillavet	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
678	1	42	2026-06-14	15:00-16:00	2	VN	Ferret Sandero	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
679	1	42	2026-06-13	16:00-17:00	2	VN	Gauthier Bigster	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
680	1	42	2026-06-11	17:00-18:00	2	VN	Jonier Duster	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
681	1	42	2026-06-12	17:00-18:00	2	VN	Plet Sandero	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
682	1	43	2026-06-11	08:00-09:00	1	VN	Tourreau Symbioz	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
683	1	43	2026-06-12	08:00-09:00	1	VN	Coudrot Twingo/R5	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
684	1	43	2026-06-13	08:00-09:00	1	VN	Rouyer Clio 6	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
685	1	43	2026-06-14	08:00-09:00	1	VN	Bechonnet R5	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
686	1	43	2026-06-15	08:00-09:00	1	VN	Michon Twingo	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
687	1	43	2026-06-11	09:00-10:00	1	VN	Pontonier Rafale	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
688	1	43	2026-06-13	09:00-10:00	1	VN	Michon R4	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
689	1	43	2026-06-12	10:00-11:00	1	VN	Novac LC R5	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
690	1	43	2026-06-13	10:00-11:00	1	VN	Charpit R4	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
691	1	43	2026-06-13	11:00-12:00	1	VN	Raymond LC R5	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
692	1	43	2026-06-13	14:00-15:00	1	VN	Gammet Austral	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
693	1	43	2026-06-13	15:00-16:00	1	VN	Dumont LC Twingo	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
694	1	43	2026-06-12	16:00-17:00	1	VN	Gibert Symbioz	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
695	1	43	2026-06-15	17:00-18:00	1	VN	Pozzi LC Austral	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
696	1	43	2026-06-12	14:00-15:00	2	VN	Roux LC Duster	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
697	1	43	2026-06-14	14:00-15:00	2	VN	Chouchkaiev Duster	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
698	1	43	2026-06-13	15:00-16:00	2	VN	Gauthier duster	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
699	1	44	2026-06-11	08:00-09:00	1	VN	Bernard Megane E Tech	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
700	1	44	2026-06-11	09:00-10:00	1	VN	Fosse R5	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
701	1	44	2026-06-12	09:00-10:00	1	VN	Guilloux Symbioz	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
702	1	44	2026-06-11	10:00-11:00	1	VN	Danodier	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
703	1	44	2026-06-13	10:00-11:00	1	VN	Laborde R5	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
704	1	44	2026-06-15	10:00-11:00	1	VN	Berrat R5	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
705	1	44	2026-06-12	11:00-12:00	1	VN	Belland Master benne	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
706	1	44	2026-06-13	11:00-12:00	1	VN	Prudhomme R5	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
707	1	44	2026-06-14	11:00-12:00	1	VN	Normand R5	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
708	1	44	2026-06-12	14:00-15:00	1	VN	Singery Clio	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
709	1	44	2026-06-13	14:00-15:00	1	VN	Bertrand Twingo	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
710	1	44	2026-06-14	14:00-15:00	1	VN	Bostivois R5	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
711	1	44	2026-06-12	15:00-16:00	1	VN	Petitjean Twingo	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
712	1	44	2026-06-15	15:00-16:00	1	VN	Riollet Scenic	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
713	1	44	2026-06-12	16:00-17:00	1	VN	Sennepin Austral	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
714	1	44	2026-06-12	18:00-19:00	1	VN	Esnard Baillon clio 6	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
715	1	44	2026-06-11	15:00-16:00	2	VN	Moroy	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
716	1	45	2026-06-14	08:00-09:00	\N	VO	Repos	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
717	1	45	2026-06-13	11:00-12:00	\N	VO	Froliche Clio	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
718	1	45	2026-06-13	15:00-16:00	\N	VO	Lamouche	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
719	1	45	2026-06-11	16:00-17:00	\N	VO	Techer	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
720	1	46	2026-06-13	09:00-10:00	\N	VO	Maire André	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
721	1	46	2026-06-14	09:00-10:00	\N	VO	Da costa	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
722	1	46	2026-06-12	11:00-12:00	\N	VO	Delaye Gladys	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
723	1	46	2026-06-12	17:00-18:00	\N	VO	chapelet Romain	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
724	1	47	2026-06-14	10:00-11:00	\N	VO	El Asheb	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
725	1	47	2026-06-13	14:00-15:00	\N	VO	Auclair	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
726	1	47	2026-06-14	14:00-15:00	\N	VO	Peyrin	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
727	1	47	2026-06-14	15:00-16:00	\N	VO	Bordes	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
728	1	47	2026-06-12	15:00-16:00	\N	VO	Lopez-lage Sandero	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
729	1	31	2026-06-11	09:00-10:00	2	VN	DEPLACE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
730	1	31	2026-06-12	09:00-10:00	2	VN	OCTAVE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
731	1	31	2026-06-13	09:00-10:00	2	VN	MACE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
732	1	31	2026-06-14	09:00-10:00	2	VN	DIOT	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
733	1	31	2026-06-11	10:00-11:00	2	VN	NAJEAN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
734	1	31	2026-06-12	10:00-11:00	2	VN	PERROUX	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
735	1	31	2026-06-11	11:00-12:00	2	VN	RACAT	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
736	1	31	2026-06-11	14:00-15:00	2	VN	MECHIN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
737	1	31	2026-06-12	14:00-15:00	2	VN	M LORQUIN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
738	1	31	2026-06-13	14:00-15:00	2	VN	M BEAUDRON	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
739	1	31	2026-06-14	17:00-18:00	2	VN	MERCIER	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
740	1	32	2026-06-11	09:00-10:00	2	VN	BIGOT	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
741	1	32	2026-06-12	09:00-10:00	2	VN	BUTLER	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
742	1	32	2026-06-13	09:00-10:00	2	VN	RIBES PAPA	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
743	1	32	2026-06-14	09:00-10:00	2	VN	LECLERC	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
744	1	32	2026-06-15	09:00-10:00	2	VN	DESCHAMPS	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
745	1	32	2026-06-12	10:00-11:00	2	VN	STANITTA	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
746	1	32	2026-06-13	10:00-11:00	2	VN	RIBES MAMAN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
747	1	32	2026-06-11	11:00-12:00	2	VN	FERBOS	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
748	1	32	2026-06-13	11:00-12:00	2	VN	RIBES FILLE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
749	1	32	2026-06-11	14:00-15:00	2	VN	COULPIER	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
750	1	32	2026-06-12	14:00-15:00	2	VN	DUBUSSET	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
751	1	32	2026-06-13	14:00-15:00	2	VN	FERREIRA	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
752	1	32	2026-06-14	14:00-15:00	2	VN	MAYER	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
753	1	32	2026-06-11	16:00-17:00	2	VN	GUILLOT	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
754	1	32	2026-06-12	16:00-17:00	2	VN	VASSAL	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
755	1	32	2026-06-11	17:00-18:00	2	VN	LECOIN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
756	1	32	2026-06-12	17:00-18:00	2	VN	LAFONT GAGNIERE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
757	1	32	2026-06-12	18:00-19:00	2	VN	SIMONET	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
758	1	33	2026-06-11	09:00-10:00	1	VN	M ODIN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
759	1	33	2026-06-12	09:00-10:00	1	VN	M VILLE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
760	1	33	2026-06-13	09:00-10:00	1	VN	GARDETTE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
761	1	33	2026-06-14	09:00-10:00	1	VN	TRAFARSKI	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
762	1	33	2026-06-11	10:00-11:00	1	VN	MUYARD	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
763	1	33	2026-06-12	10:00-11:00	1	VN	RIGAUDIAS	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
764	1	33	2026-06-13	10:00-11:00	1	VN	THOUVENET	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
765	1	33	2026-06-14	10:00-11:00	1	VN	BAL	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
766	1	33	2026-06-15	10:00-11:00	1	VN	COURTOIS	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
767	1	33	2026-06-11	11:00-12:00	1	VN	PUCCPCCI	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
768	1	33	2026-06-12	11:00-12:00	1	VN	M TROTIN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
769	1	33	2026-06-13	11:00-12:00	1	VN	BUVAT	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
770	1	33	2026-06-14	11:00-12:00	1	VN	STONS	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
771	1	33	2026-06-11	12:00-13:00	1	VN	M GENESTE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
772	1	33	2026-06-11	14:00-15:00	1	VN	LOMBARD	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
773	1	33	2026-06-12	14:00-15:00	1	VN	GONCALVES	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
774	1	33	2026-06-13	14:00-15:00	1	VN	PAGES	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
775	1	33	2026-06-11	15:00-16:00	1	VN	DAVID	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
776	1	33	2026-06-13	15:00-16:00	1	VN	FARRET	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
777	1	33	2026-06-11	16:00-17:00	1	VN	DECORAY	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
778	1	33	2026-06-12	16:00-17:00	1	VN	M RIESEN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
779	1	33	2026-06-13	16:00-17:00	1	VN	JEUDI	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
780	1	33	2026-06-14	16:00-17:00	1	VN	M RIGAUDIAS	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
781	1	33	2026-06-11	17:00-18:00	1	VN	M HENRIOT	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
782	1	33	2026-06-12	17:00-18:00	1	VN	LE VAN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
783	1	33	2026-06-13	17:00-18:00	1	VN	BOUILLERAND	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
784	1	33	2026-06-15	17:00-18:00	1	VN	MAITRIAS	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
785	1	33	2026-06-11	18:00-19:00	1	VN	CHARLIEU	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
786	1	33	2026-06-12	18:00-19:00	1	VN	ALLIGIER	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
787	1	33	2026-06-13	18:00-19:00	1	VN	M ROUSSEL	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
788	1	34	2026-06-11	09:00-10:00	1	VN	DUJARDIN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
789	1	34	2026-06-13	09:00-10:00	1	VN	LEDOUX	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
790	1	34	2026-06-15	09:00-10:00	1	VN	BELVEDERE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
791	1	34	2026-06-11	10:00-11:00	1	VN	MOREL	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
792	1	34	2026-06-12	10:00-11:00	1	VN	WEIDELICH	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
793	1	34	2026-06-14	10:00-11:00	1	VN	BRANCHI	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
794	1	34	2026-06-11	11:00-12:00	1	VN	BERNARD ALPINE 290	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
795	1	34	2026-06-12	11:00-12:00	1	VN	DEBUSSY	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
796	1	34	2026-06-13	11:00-12:00	1	VN	TETU	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
797	1	34	2026-06-11	15:00-16:00	1	VN	LETIZIA	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
798	1	34	2026-06-12	15:00-16:00	1	VN	JOUFFRE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
799	1	34	2026-06-13	15:00-16:00	1	VN	EVEILLAU	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
800	1	34	2026-06-14	15:00-16:00	1	VN	BEAUDEAN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
801	1	34	2026-06-14	16:00-17:00	1	VN	KOUDOUGOU	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
802	1	34	2026-06-11	17:00-18:00	1	VN	BEAUMET	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
803	1	34	2026-06-12	17:00-18:00	1	VN	DUPRE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
804	1	34	2026-06-13	17:00-18:00	1	VN	MECHIN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
805	1	34	2026-06-15	17:00-18:00	1	VN	GUILLON	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
806	1	34	2026-06-12	18:00-19:00	1	VN	IMBERDIS PAPA	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
807	1	34	2026-06-12	08:00-09:00	2	VN	IMBERDI FILLE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
808	1	35	2026-06-11	08:00-09:00	1	VN	REGNY	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
809	1	35	2026-06-12	08:00-09:00	1	VN	DURANTET	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
810	1	35	2026-06-11	09:00-10:00	1	VN	AMIGO	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
811	1	35	2026-06-12	10:00-11:00	1	VN	GLADINE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
812	1	35	2026-06-13	10:00-11:00	1	VN	TALABARD	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
813	1	35	2026-06-14	10:00-11:00	1	VN	CARRICO	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
814	1	35	2026-06-11	11:00-12:00	1	VN	BUTEY	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
815	1	35	2026-06-11	14:00-15:00	1	VN	DOCHEZ	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
816	1	35	2026-06-13	14:00-15:00	1	VN	MARTIN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
817	1	35	2026-06-14	14:00-15:00	1	VN	SOPHIE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
818	1	35	2026-06-12	16:00-17:00	1	VN	GOUGAT	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
819	1	35	2026-06-11	17:00-18:00	1	VN	GUERET	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
820	1	35	2026-06-14	17:00-18:00	1	VN	REVENU	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
821	1	36	2026-06-11	09:00-10:00	1	VN	BERTHAULT	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
822	1	36	2026-06-11	10:00-11:00	1	VN	MEGE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
823	1	36	2026-06-13	10:00-11:00	1	VN	DURANTET	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
824	1	36	2026-06-12	11:00-12:00	1	VN	JANIQUE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
825	1	36	2026-06-13	15:00-16:00	1	VN	LEMAITRE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
826	1	36	2026-06-14	15:00-16:00	1	VN	PORTTIN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
827	1	36	2026-06-11	16:00-17:00	1	VN	VLACH	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
828	1	36	2026-06-12	16:00-17:00	1	VN	SOCOL	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
829	1	36	2026-06-13	17:00-18:00	1	VN	ROTTAT	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
830	1	39	2026-06-11	09:00-10:00	\N	VO	DAPZOL	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
831	1	39	2026-06-12	09:00-10:00	\N	VO	LABUSSIERE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
832	1	39	2026-06-14	09:00-10:00	\N	VO	DAMPURE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
833	1	39	2026-06-12	14:00-15:00	\N	VO	CASILE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
834	1	39	2026-06-15	14:00-15:00	\N	VO	PROVOST	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
835	1	39	2026-06-13	16:00-17:00	\N	VO	ALIGIER	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
836	1	39	2026-06-11	17:00-18:00	\N	VO	CHANTELOUP	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
837	1	39	2026-06-12	18:00-19:00	\N	VO	MILLER	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
838	1	40	2026-06-11	10:00-11:00	\N	VO	HEDOO	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
839	1	40	2026-06-13	10:00-11:00	\N	VO	LAGACHE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
840	1	40	2026-06-14	11:00-12:00	\N	VO	BONJEAN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
841	1	40	2026-06-11	15:00-16:00	\N	VO	LEDENTU	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
842	1	40	2026-06-14	15:00-16:00	\N	VO	ETIENNE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
843	1	41	2026-06-13	09:00-10:00	\N	VO	GABARD	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
844	1	41	2026-06-14	10:00-11:00	\N	VO	DENNE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
845	1	41	2026-06-13	11:00-12:00	\N	VO	VEYNE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
846	1	41	2026-06-13	14:00-15:00	\N	VO	EYMARD	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
847	1	41	2026-06-14	15:00-16:00	\N	VO	HUSSAR	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
848	1	41	2026-06-12	16:00-17:00	\N	VO	TOUREAU	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
849	1	41	2026-06-13	16:00-17:00	\N	VO	BELOT	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
850	1	41	2026-06-15	16:00-17:00	\N	VO	NAVARRE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
851	1	41	2026-06-11	17:00-18:00	\N	VO	PATON	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
852	1	48	2026-06-13	08:00-09:00	1	VN	Absent	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
853	1	48	2026-06-11	09:00-10:00	1	VN	M Languedoc	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
854	1	48	2026-06-12	11:00-12:00	1	VN	M Crohas	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
855	1	48	2026-06-11	18:00-19:00	1	VN	M Massimino	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
856	1	48	2026-06-12	09:00-10:00	2	VN	M Legay	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
857	1	49	2026-06-11	09:00-10:00	1	VN	M Gardes	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
858	1	49	2026-06-13	09:00-10:00	1	VN	Thiers	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
859	1	49	2026-06-15	09:00-10:00	1	VN	M Pasquet	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
860	1	49	2026-06-11	10:00-11:00	1	VN	M Fayolle	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
861	1	49	2026-06-12	11:00-12:00	1	VN	Fouillot	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
863	1	49	2026-06-13	16:00-17:00	1	VN	Chouvel	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
864	1	49	2026-06-14	10:00-11:00	2	VN	Buvat	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
865	1	49	2026-06-12	11:00-12:00	2	VN	Chefdeville	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
866	1	49	2026-06-11	14:00-15:00	2	VN	M Gouttetoque	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
867	1	49	2026-06-13	14:00-15:00	2	VN	Culpo	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
868	1	50	2026-06-13	09:00-10:00	1	VN	M Roccetto	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
869	1	50	2026-06-14	09:00-10:00	1	VN	M Dartois	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
870	1	50	2026-06-11	10:00-11:00	1	VN	M Gentil	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
871	1	50	2026-06-12	10:00-11:00	1	VN	M Haverland	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
872	1	50	2026-06-13	10:00-11:00	1	VN	M Goutefangheas	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
873	1	50	2026-06-14	10:00-11:00	1	VN	M Mathe	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
874	1	50	2026-06-11	14:00-15:00	1	VN	M Arnaud	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
875	1	50	2026-06-12	14:00-15:00	1	VN	Mme Bonnal	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
876	1	50	2026-06-14	14:00-15:00	1	VN	M Raymond	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
877	1	50	2026-06-15	14:00-15:00	1	VN	M Privat	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
878	1	50	2026-06-11	15:00-16:00	1	VN	M Escailler	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
879	1	50	2026-06-12	15:00-16:00	1	VN	M Couturier	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
880	1	50	2026-06-14	15:00-16:00	1	VN	M Roche	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
881	1	50	2026-06-11	17:00-18:00	1	VN	M Ferrier	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
882	1	50	2026-06-12	18:00-19:00	1	VN	Mme Mazellier	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
883	1	51	2026-06-14	09:00-10:00	\N	VO	M Perrin	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
884	1	51	2026-06-11	10:00-11:00	\N	VO	M Monteilhet	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
885	1	51	2026-06-14	15:00-16:00	\N	VO	M Pousset	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
886	1	51	2026-06-11	18:00-19:00	\N	VO	M Gomez	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
887	1	52	2026-06-14	08:00-09:00	\N	VO	absent	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
888	1	52	2026-06-13	09:00-10:00	\N	VO	M Roussillon	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
889	1	52	2026-06-11	10:00-11:00	\N	VO	M Montpetroux	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
890	1	52	2026-06-12	10:00-11:00	\N	VO	M Delbege	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
891	1	52	2026-06-13	10:00-11:00	\N	VO	M Plazenet	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
892	1	52	2026-06-13	11:00-12:00	\N	VO	M Montereal	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
893	1	52	2026-06-11	14:00-15:00	\N	VO	M Leudir	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
894	1	52	2026-06-11	15:00-16:00	\N	VO	M Borel	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
895	1	52	2026-06-12	15:00-16:00	\N	VO	M Brugas	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
896	1	52	2026-06-11	16:00-17:00	\N	VO	M Nicolas	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
897	1	52	2026-06-11	17:00-18:00	\N	VO	M Barge	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
898	1	52	2026-06-12	17:00-18:00	\N	VO	M Poquet	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
899	1	62	2026-06-13	09:00-10:00	1	VN	Mr DOUIX	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
900	1	62	2026-06-14	10:00-11:00	1	VN	Mme DEGOUDE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
901	1	62	2026-06-13	11:00-12:00	1	VN	Mme PALKHIVALA	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
902	1	62	2026-06-13	14:00-15:00	1	VN	JEANNNOT	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
903	1	62	2026-06-14	14:00-15:00	1	VN	MmeTAMAGNI	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
904	1	62	2026-06-11	15:00-16:00	1	VN	Mme APTEL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
905	1	62	2026-06-13	15:00-16:00	1	VN	GROLIERE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
906	1	62	2026-06-14	16:00-17:00	1	VN	Mme MORVAN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
907	1	62	2026-06-11	17:00-18:00	1	VN	Mme VALENTE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
908	1	62	2026-06-14	15:00-16:00	2	VN	Mme RODIER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
909	1	63	2026-06-13	10:00-11:00	1	VN	ROBILLON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
910	1	63	2026-06-12	11:00-12:00	1	VN	PINET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
911	1	63	2026-06-12	15:00-16:00	1	VN	DUMAS	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
912	1	63	2026-06-13	15:00-16:00	1	VN	ABOU SAMRA	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
913	1	63	2026-06-14	15:00-16:00	1	VN	DELORME	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
914	1	63	2026-06-13	17:00-18:00	1	VN	GARTILLON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
915	1	63	2026-06-14	10:00-11:00	2	VN	DELBOS	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
916	1	63	2026-06-13	11:00-12:00	2	VN	SAUVESTRE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
917	1	63	2026-06-13	14:00-15:00	2	VN	FIORENTINO	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
918	1	63	2026-06-11	15:00-16:00	2	VN	HALLIROL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
919	1	63	2026-06-11	16:00-17:00	2	VN	COMPTE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
920	1	63	2026-06-12	16:00-17:00	2	VN	DALBE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
921	1	63	2026-06-13	16:00-17:00	2	VN	CONTOUX	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
922	1	63	2026-06-11	17:00-18:00	2	VN	BELLY	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
923	1	65	2026-06-11	08:00-09:00	1	VN	Mme BERTRAND	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
924	1	65	2026-06-11	09:00-10:00	1	VN	Mr MORAND	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
925	1	65	2026-06-14	11:00-12:00	1	VN	Mr FOURNIER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
926	1	65	2026-06-14	14:00-15:00	1	VN	BESSON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
927	1	65	2026-06-12	15:00-16:00	1	VN	DEAN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
928	1	65	2026-06-13	18:00-19:00	1	VN	Mr SELLIN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
929	1	65	2026-06-11	09:00-10:00	2	VN	DEMANGE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
930	1	65	2026-06-14	09:00-10:00	2	VN	M VIGANOTTI	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
931	1	65	2026-06-11	11:00-12:00	2	VN	M MOLLE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
932	1	65	2026-06-11	14:00-15:00	2	VN	Mme  CROS	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
933	1	66	2026-06-11	09:00-10:00	1	VN	MAHAUT	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
934	1	66	2026-06-11	11:00-12:00	1	VN	CAUTAL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
935	1	66	2026-06-13	11:00-12:00	1	VN	JEANNOT	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
936	1	66	2026-06-11	14:00-15:00	1	VN	LECOCALI	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
937	1	66	2026-06-12	14:00-15:00	1	VN	RAMEL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
938	1	66	2026-06-12	15:00-16:00	1	VN	BRAS	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
939	1	66	2026-06-12	16:00-17:00	1	VN	PILLON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
940	1	66	2026-06-11	10:00-11:00	2	VN	GIOAN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
941	1	66	2026-06-12	10:00-11:00	2	VN	DUPART	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
942	1	66	2026-06-13	10:00-11:00	2	VN	MEURIE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
943	1	66	2026-06-15	10:00-11:00	2	VN	BRUCIAMACCHIE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
944	1	66	2026-06-13	12:00-13:00	2	VN	GROLIERES	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
945	1	66	2026-06-13	13:00-14:00	2	VN	BACHAYTER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
946	1	66	2026-06-14	14:00-15:00	2	VN	BEABIN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
947	1	66	2026-06-14	15:00-16:00	2	VN	ESTRADE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
948	1	66	2026-06-11	16:00-17:00	2	VN	ZYMAN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
949	1	66	2026-06-11	17:00-18:00	2	VN	NARCE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
950	1	66	2026-06-11	18:00-19:00	2	VN	NARCE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
951	1	67	2026-06-15	09:00-10:00	1	VN	I	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
952	1	67	2026-06-11	10:00-11:00	1	VN	CROS	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
953	1	67	2026-06-14	10:00-11:00	1	VN	OUDOUL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
954	1	67	2026-06-14	11:00-12:00	1	VN	DUFEUTEULE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
955	1	67	2026-06-12	14:00-15:00	1	VN	CARBASSE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
956	1	67	2026-06-14	15:00-16:00	1	VN	ROCHES	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
957	1	67	2026-06-12	17:00-18:00	1	VN	BOUQUET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
958	1	67	2026-06-13	18:00-19:00	1	VN	BOURDON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
959	1	67	2026-06-11	09:00-10:00	2	VN	MEUNIER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
960	1	67	2026-06-12	09:00-10:00	2	VN	HERITIER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
961	1	67	2026-06-13	09:00-10:00	2	VN	ROBILLON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
962	1	67	2026-06-13	10:00-11:00	2	VN	PEDRONETTO	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
963	1	67	2026-06-13	11:00-12:00	2	VN	MAISONNEUVE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
964	1	67	2026-06-11	14:00-15:00	2	VN	TISSERAND	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
965	1	67	2026-06-12	16:00-17:00	2	VN	ROFFET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
966	1	67	2026-06-14	16:00-17:00	2	VN	ANSELLEME	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
967	1	68	2026-06-11	08:00-09:00	\N	VO	DAUBARD	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
968	1	68	2026-06-12	08:00-09:00	\N	VO	TRASSOUDAINE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
969	1	68	2026-06-11	09:00-10:00	\N	VO	Mme DELPAGNE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
970	1	68	2026-06-11	10:00-11:00	\N	VO	I	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
971	1	68	2026-06-13	10:00-11:00	\N	VO	Mme BICHERAY	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
972	1	68	2026-06-11	14:00-15:00	\N	VO	Mme SEMBEL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
973	1	68	2026-06-11	08:00-09:00	\N	VO	COSTON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
974	1	68	2026-06-12	10:00-11:00	\N	VO	MAZET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
975	1	68	2026-06-13	14:00-15:00	\N	VO	MMe PARDANAUD	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
976	1	68	2026-06-12	16:00-17:00	\N	VO	Mme GARINOT	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
977	1	69	2026-06-13	10:00-11:00	\N	VO	TALLOBRE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
978	1	69	2026-06-13	14:00-15:00	\N	VO	PORTEIX	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
979	1	69	2026-06-11	18:00-19:00	\N	VO	MONDILLON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
980	1	70	2026-06-11	09:00-10:00	\N	VO	NOUGUIER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
981	1	70	2026-06-13	09:00-10:00	\N	VO	PLANTIN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
982	1	70	2026-06-13	10:00-11:00	\N	VO	DIAS	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
983	1	70	2026-06-11	11:00-12:00	\N	VO	DUCHER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
984	1	70	2026-06-11	14:00-15:00	\N	VO	PERRIN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
985	1	70	2026-06-13	14:00-15:00	\N	VO	BENKEMOUN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
986	1	70	2026-06-11	15:00-16:00	\N	VO	PRANYES	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
987	1	70	2026-06-11	16:00-17:00	\N	VO	BREJAUD	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
988	1	70	2026-06-11	08:00-09:00	\N	VO	ANGLADE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
989	1	70	2026-06-11	10:00-11:00	\N	VO	LAPELEGERIE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
990	1	70	2026-06-12	10:00-11:00	\N	VO	BARD	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
991	1	70	2026-06-12	11:00-12:00	\N	VO	VANDERSUISSE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
992	1	53	2026-06-11	08:00-09:00	1	VN	DELALANDE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
993	1	53	2026-06-11	09:00-10:00	1	VN	CHABERT	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
994	1	53	2026-06-11	10:00-11:00	1	VN	VIGOUROUX	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
995	1	53	2026-06-13	10:00-11:00	1	VN	LYOTARD	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
996	1	53	2026-06-14	10:00-11:00	1	VN	VILLESECHE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
997	1	53	2026-06-13	11:00-12:00	1	VN	FAURE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
998	1	53	2026-06-11	14:00-15:00	1	VN	SAGNARD	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
999	1	53	2026-06-12	14:00-15:00	1	VN	BEGEY	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1000	1	53	2026-06-13	14:00-15:00	1	VN	CHARBONNEL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1001	1	53	2026-06-12	15:00-16:00	1	VN	CHABERT	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1002	1	53	2026-06-13	15:00-16:00	1	VN	OUILON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1003	1	53	2026-06-14	15:00-16:00	1	VN	ORFEUBRE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1004	1	53	2026-06-12	16:00-17:00	1	VN	DELUBAC	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1005	1	53	2026-06-13	16:00-17:00	1	VN	AURELLE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1006	1	53	2026-06-14	16:00-17:00	1	VN	MAUACI	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1007	1	53	2026-06-12	17:00-18:00	1	VN	SOUCHON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1008	1	53	2026-06-12	18:00-19:00	1	VN	MAGNE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1009	1	53	2026-06-12	13:00-14:00	2	VN	VALLET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1010	1	53	2026-06-11	15:00-16:00	2	VN	RAFFARD DE BRIENNE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1011	1	54	2026-06-11	09:00-10:00	1	VN	M GUILLON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1012	1	54	2026-06-12	10:00-11:00	1	VN	Mr PILlOT	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1013	1	54	2026-06-14	10:00-11:00	1	VN	Mr COURTIAL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1014	1	54	2026-06-11	11:00-12:00	1	VN	ART FLORAL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1015	1	54	2026-06-12	11:00-12:00	1	VN	MR LAUBUGE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1016	1	54	2026-06-12	14:00-15:00	1	VN	Mme TEYSSIER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1017	1	54	2026-06-12	17:00-18:00	1	VN	Mme VAUZELLE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1018	1	54	2026-06-13	09:00-10:00	2	VN	Mme ROCHETTE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1019	1	54	2026-06-11	13:00-14:00	2	VN	Mme PAQUIN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1020	1	55	2026-06-11	09:00-10:00	1	VN	DAVID / LANGEAC	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1021	1	55	2026-06-13	09:00-10:00	1	VN	DREYFUS	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1022	1	55	2026-06-11	10:00-11:00	1	VN	BESSON / LANGEAC	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1023	1	55	2026-06-15	14:00-15:00	1	VN	GERANTON / VOREY	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1024	1	55	2026-06-11	09:00-10:00	2	VN	GOBELET / LANGEAC	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1025	1	55	2026-06-11	14:00-15:00	2	VN	GIRARD / SERVEL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1026	1	55	2026-06-12	14:00-15:00	2	VN	BESSON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1027	1	55	2026-06-11	17:00-18:00	2	VN	MARIN / BIGSTER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1028	1	56	2026-06-12	10:00-11:00	1	VN	DUPUIS	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1029	1	56	2026-06-13	10:00-11:00	1	VN	JOUANNY	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1030	1	56	2026-06-14	10:00-11:00	1	VN	PONTVIANNE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1031	1	56	2026-06-15	10:00-11:00	1	VN	BOUCHET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1032	1	56	2026-06-11	11:00-12:00	1	VN	BONNET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1033	1	56	2026-06-13	13:00-14:00	1	VN	BATTONET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1034	1	56	2026-06-15	14:00-15:00	1	VN	CROS	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1035	1	56	2026-06-13	15:00-16:00	1	VN	NOUVET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1036	1	56	2026-06-14	16:00-17:00	1	VN	AVOUAC	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1037	1	56	2026-06-15	16:00-17:00	1	VN	MAZET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1038	1	56	2026-06-11	10:00-11:00	2	VN	MULLER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1039	1	57	2026-06-13	09:00-10:00	\N	VO	M COURJAUD	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1040	1	57	2026-06-14	09:00-10:00	\N	VO	9h30 Berger	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1041	1	57	2026-06-13	11:00-12:00	\N	VO	Mr MEZIN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1042	1	57	2026-06-12	14:00-15:00	\N	VO	MMe BOSSAERT	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1043	1	58	2026-06-11	10:00-11:00	\N	VO	ROUSSET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1044	1	58	2026-06-14	10:00-11:00	\N	VO	TORRESAN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1045	1	58	2026-06-13	11:00-12:00	\N	VO	VIALVIELLE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1046	1	58	2026-06-13	13:00-14:00	\N	VO	DARBOUSSET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1047	1	58	2026-06-11	14:00-15:00	\N	VO	DAMIEN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1048	1	58	2026-06-12	14:00-15:00	\N	VO	CIODOIU	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1049	1	58	2026-06-11	15:00-16:00	\N	VO	JEANNIN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1050	1	58	2026-06-11	16:00-17:00	\N	VO	CLUZEL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1051	1	58	2026-06-14	16:00-17:00	\N	VO	DUMOND	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1052	1	58	2026-06-12	17:00-18:00	\N	VO	RODRIGUES	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1053	1	58	2026-06-11	18:00-19:00	\N	VO	LIOGIER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1054	1	59	2026-06-12	09:00-10:00	1	VN	TAULAMESSE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1055	1	59	2026-06-13	09:00-10:00	1	VN	BADUEL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1056	1	59	2026-06-11	10:00-11:00	1	VN	MARCU	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1057	1	59	2026-06-13	10:00-11:00	1	VN	BERNIER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1058	1	59	2026-06-14	10:00-11:00	1	VN	HERME	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1059	1	59	2026-06-14	11:00-12:00	1	VN	CALANDRE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1060	1	59	2026-06-13	14:00-15:00	1	VN	PEPIN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1061	1	59	2026-06-11	16:00-17:00	1	VN	LEITAO	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1062	1	59	2026-06-15	16:00-17:00	1	VN	COLLET	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1063	1	59	2026-06-13	17:00-18:00	1	VN	BRUNET	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1064	1	59	2026-06-11	18:00-19:00	1	VN	OZIOL	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1065	1	59	2026-06-12	10:00-11:00	2	VN	PELOTHIER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1066	1	59	2026-06-12	14:00-15:00	2	VN	SEGOLA	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1067	1	59	2026-06-14	14:00-15:00	2	VN	POUDEVIGNE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1068	1	59	2026-06-12	15:00-16:00	2	VN	BROJAN	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1069	1	59	2026-06-12	16:00-17:00	2	VN	FOURNIER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1070	1	59	2026-06-12	17:00-18:00	2	VN	GAUGAIN	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1071	1	61	2026-06-12	10:00-11:00	\N	VO	REMISE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1072	1	61	2026-06-15	10:00-11:00	\N	VO	SOANE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1073	1	61	2026-06-11	14:00-15:00	\N	VO	JIMENEZ	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1074	1	61	2026-06-13	14:00-15:00	\N	VO	DELRIEU	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1075	1	61	2026-06-14	14:00-15:00	\N	VO	PORTAL	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1076	1	61	2026-06-12	09:00-10:00	\N	VO	DELON	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1077	1	61	2026-06-14	10:00-11:00	\N	VO	MONIEZ	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1078	1	61	2026-06-12	14:00-15:00	\N	VO	MONTESANI	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1079	1	61	2026-06-13	16:00-17:00	\N	VO	REMIZE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1080	1	61	2026-06-12	17:00-18:00	\N	VO	ASTIER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1081	1	61	2026-06-12	18:00-19:00	\N	VO	TROCELLIER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1082	1	79	2026-06-13	09:00-10:00	1	VN	BONAMI DUSTER CAPTUR	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1083	1	79	2026-06-11	10:00-11:00	1	VN	LEGRAND TWINGO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1084	1	79	2026-06-12	11:00-12:00	1	VN	BELLIERE R4	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1085	1	79	2026-06-13	15:00-16:00	1	VN	GARIN TW3 OU R5	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1086	1	79	2026-06-12	16:00-17:00	2	VN	DELOUS SANDERO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1087	1	79	2026-06-13	16:00-17:00	2	VN	DOMERGUES SPRING OU SANDERO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1088	1	79	2026-06-11	17:00-18:00	2	VN	BARBIER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1089	1	79	2026-06-13	17:00-18:00	2	VN	GARCIA CLIO 6	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1090	1	80	2026-06-11	08:00-09:00	1	VN	OLIVIER TWINGO VD	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1091	1	80	2026-06-11	09:00-10:00	1	VN	GUTFREND CLIO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1092	1	80	2026-06-12	09:00-10:00	1	VN	AURIOL TWINGO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1093	1	80	2026-06-13	09:00-10:00	1	VN	ESPINASSE RENOUV ZOE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1094	1	80	2026-06-11	10:00-11:00	1	VN	VASILIC TWINGO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1095	1	80	2026-06-12	10:00-11:00	1	VN	CROS CLIO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1096	1	80	2026-06-13	10:00-11:00	1	VN	CARRIERE RENOUV MEGANE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1097	1	80	2026-06-15	10:00-11:00	1	VN	BLANC	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1098	1	80	2026-06-11	11:00-12:00	1	VN	DUBAR CAPTUR	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1099	1	80	2026-06-15	11:00-12:00	1	VN	LACLEDE RENOUV MEGANE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1100	1	80	2026-06-11	12:00-13:00	1	VN	MOULY RENOUV ZOE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1101	1	80	2026-06-11	13:00-14:00	1	VN	MOLINIER CAPTUR	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1102	1	80	2026-06-11	14:00-15:00	1	VN	MAZARS	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1103	1	80	2026-06-12	14:00-15:00	1	VN	FLEURY SCENIC	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1104	1	80	2026-06-12	15:00-16:00	1	VN	DELOUS CLIO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1105	1	80	2026-06-11	16:00-17:00	1	VN	JOULIA	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1106	1	80	2026-06-11	17:00-18:00	1	VN	MERCIER A VOIR	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1107	1	80	2026-06-11	18:00-19:00	1	VN	ROUSSELLE RENOUV ZOE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1108	1	81	2026-06-14	14:00-15:00	1	VN	GRIBBAL TWINGO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1109	1	81	2026-06-11	18:00-19:00	1	VN	CHENE CHRISTOPHE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1110	1	81	2026-06-12	09:00-10:00	2	VN	BARRETTE SANDERO VD	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1111	1	81	2026-06-11	10:00-11:00	2	VN	QUENHE JOGGER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1112	1	81	2026-06-12	11:00-12:00	2	VN	GATIMEL DUSTER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1113	1	81	2026-06-14	12:00-13:00	2	VN	FOUCAT SANDERO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1114	1	81	2026-06-11	16:00-17:00	2	VN	FABIE SANDERO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1115	1	82	2026-06-11	09:00-10:00	1	VN	CARLES	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1116	1	82	2026-06-13	09:00-10:00	1	VN	ROGUET MEGANE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1117	1	82	2026-06-11	10:00-11:00	1	VN	FAGES	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1118	1	82	2026-06-12	10:00-11:00	1	VN	VERNES CLIO 6	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1119	1	82	2026-06-13	10:00-11:00	1	VN	MURAT SCENIC	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1120	1	82	2026-06-15	10:00-11:00	1	VN	PHOUMAN CLIO 5	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1121	1	82	2026-06-13	11:00-12:00	1	VN	DELMAS TWINGO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1122	1	82	2026-06-13	12:00-13:00	1	VN	NOWFOL R4	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1123	1	82	2026-06-13	14:00-15:00	1	VN	ALONZO CLIO 6	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1124	1	82	2026-06-13	16:00-17:00	1	VN	FRUNEAU TWINGO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1125	1	82	2026-06-11	17:00-18:00	1	VN	GEMARIN	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1126	1	82	2026-06-12	17:00-18:00	1	VN	ALBERT SCENIC	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1127	1	82	2026-06-12	09:00-10:00	2	VN	LERIDENT BIGSTER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1128	1	82	2026-06-11	14:00-15:00	2	VN	DEGUIRARD DUSTER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1129	1	82	2026-06-13	15:00-16:00	2	VN	DOMERGUES JOGGER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1130	1	82	2026-06-11	17:00-18:00	2	VN	BLANQUET SANDERO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1131	1	83	2026-06-13	10:00-11:00	\N	VO	HYGONET	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1132	1	83	2026-06-12	11:00-12:00	\N	VO	MER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1133	1	83	2026-06-14	11:00-12:00	\N	VO	REDOULES	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1134	1	83	2026-06-13	15:00-16:00	\N	VO	LADET TWINGO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1135	1	83	2026-06-14	15:00-16:00	\N	VO	MOUNIRAT	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1136	1	83	2026-06-11	16:00-17:00	\N	VO	COMBRET SPRING	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1137	1	83	2026-06-13	16:00-17:00	\N	VO	ALFONSO JOGGER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1138	1	83	2026-06-14	16:00-17:00	\N	VO	BEN DAOUD	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1139	1	84	2026-06-13	09:00-10:00	\N	VO	LEONNARD CLIO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1140	1	84	2026-06-12	15:00-16:00	\N	VO	THERON CLIO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1141	1	84	2026-06-11	17:00-18:00	\N	VO	MAUME ZOE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1142	1	84	2026-06-12	17:00-18:00	\N	VO	LACAN MELANIE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1143	1	84	2026-06-13	17:00-18:00	\N	VO	ESTELLE CAVALERIE ZE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1144	1	85	2026-06-12	10:00-11:00	\N	VO	AGUERA AUDI A1	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1145	1	85	2026-06-15	11:00-12:00	\N	VO	PANOT	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1146	1	85	2026-06-12	14:00-15:00	\N	VO	BLANC CAPTUR	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1147	1	85	2026-06-12	15:00-16:00	\N	VO	RAYNAL CAPTUR	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1148	1	92	2026-06-11	10:00-11:00	1	VN	TOVAR	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1149	1	92	2026-06-12	10:00-11:00	1	VN	MERDRIGNAC	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1150	1	92	2026-06-11	11:00-12:00	1	VN	NOZIERES	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1151	1	92	2026-06-12	11:00-12:00	1	VN	GARD	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1152	1	92	2026-06-12	14:00-15:00	1	VN	OGLAZA	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1153	1	92	2026-06-13	14:00-15:00	1	VN	CONSTENSOU	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1154	1	92	2026-06-12	15:00-16:00	1	VN	SOULIER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1155	1	92	2026-06-13	15:00-16:00	1	VN	MEZGHANI	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1156	1	92	2026-06-11	16:00-17:00	1	VN	LUSSIER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1157	1	92	2026-06-12	16:00-17:00	1	VN	PICARONNY	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1158	1	92	2026-06-11	17:00-18:00	1	VN	MESTRIES	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1159	1	92	2026-06-12	17:00-18:00	1	VN	THEATE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1160	1	92	2026-06-15	17:00-18:00	1	VN	DEGUIRARD	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1161	1	92	2026-06-11	18:00-19:00	1	VN	HEBRARD	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1162	1	92	2026-06-12	18:00-19:00	1	VN	BEDOUSSAC	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1163	1	92	2026-06-11	09:00-10:00	2	VN	GUILLERON	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1164	1	92	2026-06-13	09:00-10:00	2	VN	KAIQUE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1165	1	92	2026-06-13	17:00-18:00	2	VN	CHAILLOU	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1166	1	93	2026-06-11	09:00-10:00	1	VN	MOISSINAC	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1167	1	93	2026-06-13	09:00-10:00	1	VN	FALIES	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1168	1	93	2026-06-13	10:00-11:00	1	VN	BESSE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1169	1	93	2026-06-11	11:00-12:00	1	VN	LACROZE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1170	1	93	2026-06-11	14:00-15:00	1	VN	LIMBERTIE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1171	1	93	2026-06-12	14:00-15:00	1	VN	KIALA	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1172	1	93	2026-06-15	14:00-15:00	1	VN	LASFAUX	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1173	1	93	2026-06-12	15:00-16:00	1	VN	TRIN	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1174	1	93	2026-06-13	15:00-16:00	1	VN	LALOIS	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1175	1	93	2026-06-15	17:00-18:00	1	VN	NEY	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1176	1	93	2026-06-11	10:00-11:00	2	VN	PUECH	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1177	1	93	2026-06-13	17:00-18:00	2	VN	REUR	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1178	1	94	2026-06-13	09:00-10:00	1	VN	VEYRIERES	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1179	1	94	2026-06-15	09:00-10:00	1	VN	CHARMES	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1180	1	94	2026-06-12	10:00-11:00	1	VN	LORCY	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1181	1	94	2026-06-11	11:00-12:00	1	VN	PRUNIERES	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1182	1	94	2026-06-12	14:00-15:00	1	VN	LAJARRIGE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1183	1	94	2026-06-13	14:00-15:00	1	VN	COUET	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1184	1	94	2026-06-15	15:00-16:00	1	VN	ESPALIEU	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1185	1	94	2026-06-15	17:00-18:00	1	VN	VEILLY	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1186	1	94	2026-06-15	18:00-19:00	1	VN	RODDE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1187	1	94	2026-06-13	10:00-11:00	2	VN	ROCHE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1188	1	94	2026-06-15	10:00-11:00	2	VN	CONSTANT	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1189	1	94	2026-06-13	11:00-12:00	2	VN	DANIS	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1190	1	94	2026-06-12	17:00-18:00	2	VN	FREYTET	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1191	1	86	2026-06-15	09:00-10:00	1	VN	GINESTET (Clio GPL)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1192	1	86	2026-06-11	10:00-11:00	1	VN	GUILLEMIN (Espace VD)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1193	1	86	2026-06-12	10:00-11:00	1	VN	BERNADMONT (Twingo)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1194	1	86	2026-06-13	10:00-11:00	1	VN	BLANC (Clio)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1195	1	86	2026-06-14	11:00-12:00	1	VN	GUIBBERT (Clio VI)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1196	1	86	2026-06-12	14:00-15:00	1	VN	MALLAT (Twingo)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1197	1	86	2026-06-13	14:00-15:00	1	VN	PERSEGOL (Captur)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1198	1	86	2026-06-14	14:00-15:00	1	VN	HURGON (Captur)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1199	1	86	2026-06-15	14:00-15:00	1	VN	BELMOTKAR  (Captur)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1200	1	86	2026-06-11	15:00-16:00	1	VN	GAVALDA (Clio)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1201	1	86	2026-06-13	16:00-17:00	1	VN	GALZIN (Rafale)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1202	1	86	2026-06-11	17:00-18:00	1	VN	CHEVALIER (Clio ou Captur)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1203	1	86	2026-06-12	18:00-19:00	1	VN	RAVELEAU (Clio)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1204	1	87	2026-06-11	09:00-10:00	2	VN	MAURY (Duster)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1205	1	87	2026-06-13	09:00-10:00	2	VN	RICHARD (Master VO)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1206	1	87	2026-06-12	10:00-11:00	2	VN	BOONEFOUS (duster)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1207	1	87	2026-06-11	11:00-12:00	2	VN	WILLERMACK (Duster LOA)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1208	1	87	2026-06-12	11:00-12:00	2	VN	GINESTE (Sandero)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1209	1	87	2026-06-13	11:00-12:00	2	VN	DANILL (Duster LOA)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1210	1	87	2026-06-15	11:00-12:00	2	VN	ROCHER (Sandero)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1211	1	87	2026-06-11	14:00-15:00	2	VN	VIALE (Jogger en LOA)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1212	1	87	2026-06-12	14:00-15:00	2	VN	LAMOTTE (Sandero)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1213	1	87	2026-06-13	14:00-15:00	2	VN	BOURDAIS (etech)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1214	1	87	2026-06-11	15:00-16:00	2	VN	GAL (Sandero LOA)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1215	1	87	2026-06-13	15:00-16:00	2	VN	AMDRAUD (Sandero)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1216	1	87	2026-06-13	16:00-17:00	2	VN	Carriere (Bigster)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1217	1	71	2026-06-11	09:00-10:00	1	VN	JANIN Rafale	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1218	1	71	2026-06-12	09:00-10:00	1	VN	POMPIER Scenic	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1219	1	71	2026-06-13	10:00-11:00	1	VN	CARRE R5	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1220	1	71	2026-06-11	11:00-12:00	1	VN	RAFRE Scenic	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1221	1	71	2026-06-12	11:00-12:00	1	VN	DURIF R5	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1222	1	71	2026-06-11	14:00-15:00	1	VN	RICARDOU Twingo	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1223	1	71	2026-06-11	15:00-16:00	1	VN	CHEVILLER R5	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1224	1	71	2026-06-12	15:00-16:00	1	VN	PAILLASSA R5	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1225	1	71	2026-06-13	15:00-16:00	1	VN	DABLANC Kangoo	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1226	1	71	2026-06-11	17:00-18:00	1	VN	AUZAN R5	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1227	1	72	2026-06-11	09:00-10:00	1	VN	VARLET Megane	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1228	1	72	2026-06-12	09:00-10:00	1	VN	PATAQUI R5	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1229	1	72	2026-06-11	10:00-11:00	1	VN	LEVY Captur	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1230	1	72	2026-06-12	10:00-11:00	1	VN	CHAPLIN Clio	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1231	1	72	2026-06-11	11:00-12:00	1	VN	PEREZ Captur	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1232	1	72	2026-06-11	14:00-15:00	1	VN	PANADERO Twingo	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1233	1	72	2026-06-12	14:00-15:00	1	VN	MOSTARDI Twingo	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1234	1	72	2026-06-11	15:00-16:00	1	VN	MARIE Megane	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1235	1	72	2026-06-13	15:00-16:00	1	VN	PORTAL Clio	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1236	1	72	2026-06-11	16:00-17:00	1	VN	DEMEURE Espace	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1237	1	72	2026-06-12	16:00-17:00	1	VN	NAVARRO Twingo	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1238	1	72	2026-06-13	16:00-17:00	1	VN	FILLION E Tech	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1239	1	72	2026-06-11	17:00-18:00	1	VN	SALANDIN Austral	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1240	1	72	2026-06-13	17:00-18:00	1	VN	GOMEZ Twingo	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1241	1	72	2026-06-11	18:00-19:00	1	VN	LEFEVRE Scenic	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1242	1	73	2026-06-11	09:00-10:00	1	VN	BARRE Megane	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1243	1	73	2026-06-13	09:00-10:00	1	VN	BARTHE R5	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1244	1	73	2026-06-13	10:00-11:00	1	VN	BIBAL Clio	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1245	1	73	2026-06-12	11:00-12:00	1	VN	BELIERE Clio	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1246	1	73	2026-06-12	14:00-15:00	1	VN	FIGUIERE R5	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1247	1	73	2026-06-11	15:00-16:00	1	VN	BALKE Captur	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1248	1	73	2026-06-12	15:00-16:00	1	VN	PIBERNAT Twingo	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1249	1	73	2026-06-11	16:00-17:00	1	VN	BONNET Kangoo	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1250	1	73	2026-06-11	17:00-18:00	1	VN	SOULIE Twingo	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1251	1	73	2026-06-11	10:00-11:00	2	VN	DELMAS Sandero	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1252	1	73	2026-06-12	16:00-17:00	2	VN	MILLET Spring	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1253	1	74	2026-06-11	10:00-11:00	1	VN	GRANGE Twingo	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1254	1	74	2026-06-13	10:00-11:00	1	VN	DUBUY Clio	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1255	1	74	2026-06-13	11:00-12:00	1	VN	ANTERIEUR Kex	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1256	1	74	2026-06-11	14:00-15:00	1	VN	TRAPAS Twingo	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1257	1	74	2026-06-13	14:00-15:00	1	VN	BERNARDIN Clio	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1258	1	74	2026-06-12	16:00-17:00	1	VN	TAILLEFER Clio	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1259	1	74	2026-06-11	17:00-18:00	1	VN	SOULA Megane	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1260	1	74	2026-06-12	17:00-18:00	1	VN	ROBIN Clio	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1261	1	74	2026-06-12	18:00-19:00	1	VN	NAVARRO R5	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1262	1	74	2026-06-12	10:00-11:00	2	VN	RAHAL Jogger	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1263	1	75	2026-06-11	09:00-10:00	1	VN	DELEBECQUE Scenic	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1264	1	75	2026-06-11	11:00-12:00	1	VN	SAUVAGE Captur	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1265	1	75	2026-06-12	15:00-16:00	1	VN	CHALIEZ Clio	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1266	1	75	2026-06-11	17:00-18:00	1	VN	LIMOUZY Rafale	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1267	1	75	2026-06-11	10:00-11:00	2	VN	FORMAGE Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1268	1	75	2026-06-13	10:00-11:00	2	VN	TISSIER Spring	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1269	1	75	2026-06-12	11:00-12:00	2	VN	ABBES Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1270	1	75	2026-06-13	11:00-12:00	2	VN	MONCHAMP Spring	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1271	1	75	2026-06-15	12:00-13:00	2	VN	DELAIRE Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1272	1	75	2026-06-11	14:00-15:00	2	VN	MASSA Spring	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1273	1	75	2026-06-11	15:00-16:00	2	VN	LAUNAY Twingo	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1274	1	75	2026-06-11	16:00-17:00	2	VN	DRAGUTIN R5	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1275	1	76	2026-06-11	10:00-11:00	1	VN	PERRINE Kangoo	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1276	1	76	2026-06-13	10:00-11:00	1	VN	COUDOURNAC R4	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1277	1	76	2026-06-12	11:00-12:00	1	VN	DEFAUS Megane	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1278	1	76	2026-06-15	17:00-18:00	1	VN	MERCIER R5	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1279	1	76	2026-06-13	14:00-15:00	2	VN	ALBOUY Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1280	1	78	2026-06-11	08:00-09:00	1	VN	DELRIEU Arkana	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1281	1	78	2026-06-11	10:00-11:00	1	VN	DA SILVA Scenic	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1282	1	78	2026-06-12	10:00-11:00	1	VN	LAURENT Captur	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1283	1	78	2026-06-11	11:00-12:00	1	VN	CAUGUEZ R5	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1284	1	78	2026-06-12	11:00-12:00	1	VN	LEVIGUELOUX R5	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1285	1	78	2026-06-14	11:00-12:00	1	VN	TASSEL R5	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1286	1	78	2026-06-11	12:00-13:00	1	VN	GAVALDA TWINGO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1287	1	78	2026-06-11	14:00-15:00	1	VN	ORTHE Captur	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1288	1	78	2026-06-12	14:00-15:00	1	VN	SOUNGOULA Austral	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1289	1	78	2026-06-13	14:00-15:00	1	VN	THOUNANA Captur	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1290	1	78	2026-06-14	14:00-15:00	1	VN	VILLEDIEU CLIO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1291	1	78	2026-06-11	15:00-16:00	1	VN	MARTINAUD Twingo	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1292	1	78	2026-06-13	15:00-16:00	1	VN	CHARTROU Austral	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1293	1	78	2026-06-12	16:00-17:00	1	VN	CAZELLE Captur	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1294	1	78	2026-06-15	16:00-17:00	1	VN	DUCROS Twingo	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1295	1	78	2026-06-11	17:00-18:00	1	VN	RUDELLE Clio	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1296	1	78	2026-06-12	17:00-18:00	1	VN	BIAU Clio	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1297	1	78	2026-06-13	17:00-18:00	1	VN	BOURDON Clio	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1298	1	99	2026-06-12	10:00-11:00	1	VN	ROUSSILHES Clio	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1299	1	99	2026-06-13	10:00-11:00	1	VN	ASSIE Captur	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1300	1	99	2026-06-14	10:00-11:00	1	VN	DASTE Captur	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1301	1	99	2026-06-12	15:00-16:00	1	VN	BEAUGENDRE R4	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1302	1	99	2026-06-12	16:00-17:00	1	VN	RAYSSAC Megane	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1303	1	99	2026-06-13	16:00-17:00	1	VN	HERAIL Megane	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1304	1	99	2026-06-12	09:00-10:00	2	VN	CANTAGREL Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1305	1	99	2026-06-15	09:00-10:00	2	VN	BACHELERI Bigster	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1306	1	99	2026-06-11	10:00-11:00	2	VN	PICARD Duster	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1307	1	99	2026-06-15	10:00-11:00	2	VN	ISSALLI Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1308	1	99	2026-06-12	11:00-12:00	2	VN	GANGLOF Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1309	1	99	2026-06-11	14:00-15:00	2	VN	ALLEGRE Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1310	1	99	2026-06-13	14:00-15:00	2	VN	GEMAIN Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1311	1	99	2026-06-14	14:00-15:00	2	VN	PUTEAU Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1312	1	99	2026-06-15	14:00-15:00	2	VN	KOSTIL Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1313	1	99	2026-06-11	16:00-17:00	2	VN	MAURAISIN Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1314	1	99	2026-06-15	16:00-17:00	2	VN	VERDIS Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1315	1	99	2026-06-12	18:00-19:00	2	VN	VERDIN Duster	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1316	1	99	2026-06-15	18:00-19:00	2	VN	MUNOZ Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1317	1	96	2026-06-11	09:00-10:00	1	VN	BESSIERE TWINGO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1318	1	96	2026-06-12	09:00-10:00	1	VN	BONSANG CLIO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1319	1	96	2026-06-13	10:00-11:00	1	VN	ARTIGUES TWINGO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1320	1	96	2026-06-11	14:00-15:00	1	VN	LALOEUF TWINGO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1321	1	96	2026-06-12	14:00-15:00	1	VN	ROUZIES CAPTUR	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1322	1	96	2026-06-15	14:00-15:00	1	VN	LAGARRIGUE TWINGO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1323	1	96	2026-06-13	15:00-16:00	1	VN	CIPRIANO R5	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1324	1	96	2026-06-15	15:00-16:00	1	VN	AUDOUY R5	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1325	1	96	2026-06-11	16:00-17:00	1	VN	CAPABIDY TWINGO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1326	1	96	2026-06-12	17:00-18:00	1	VN	ESTIVAL CAPTUR	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1327	1	96	2026-06-13	17:00-18:00	1	VN	MARUEJOULS CLIO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1328	1	96	2026-06-15	17:00-18:00	1	VN	PACHIN CLIO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1329	1	96	2026-06-13	09:00-10:00	2	VN	TOUPENSE DUSTER	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1330	1	96	2026-06-11	10:00-11:00	2	VN	LATAPIE DUSTER	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1331	1	96	2026-06-12	10:00-11:00	2	VN	CHAMEROYS DUSTER	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1332	1	96	2026-06-15	10:00-11:00	2	VN	GINESTE SANDERO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1333	1	96	2026-06-13	14:00-15:00	2	VN	MOGADOR SPRING	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1334	1	97	2026-06-11	09:00-10:00	1	VN	DAENILKIT TRAFIC	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1335	1	97	2026-06-13	10:00-11:00	1	VN	BERT R5	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1336	1	97	2026-06-15	10:00-11:00	1	VN	POIGNANT MEGANE	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1337	1	97	2026-06-11	16:00-17:00	1	VN	CONTE CLIO 6	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1338	1	97	2026-06-11	10:00-11:00	2	VN	DEFOIS DUSTER BIGSTER	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1339	1	97	2026-06-12	10:00-11:00	2	VN	LEGRUE DUSTER	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1340	1	97	2026-06-11	14:00-15:00	2	VN	GILBERT	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1341	1	97	2026-06-13	14:00-15:00	2	VN	JORIS DUSTER	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1342	1	97	2026-06-12	15:00-16:00	2	VN	ROQUES SPRING	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1343	1	89	2026-06-13	09:00-10:00	1	VN	bagreo twingo	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1344	1	89	2026-06-14	09:00-10:00	1	VN	BOMBAISI CLIO 6	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1345	1	89	2026-06-12	11:00-12:00	1	VN	COSSARD CLIO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1346	1	89	2026-06-11	14:00-15:00	1	VN	calmels clio	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1347	1	89	2026-06-13	14:00-15:00	1	VN	ERVIE TWINGO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1348	1	89	2026-06-12	15:00-16:00	1	VN	chambon austral	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1349	1	89	2026-06-11	17:00-18:00	1	VN	CHANDELIER AUSTRAL	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1350	1	89	2026-06-12	10:00-11:00	2	VN	ARIES SANDERO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1351	1	89	2026-06-13	11:00-12:00	2	VN	SALLES SPRING	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1352	1	89	2026-06-13	16:00-17:00	2	VN	CIPIERE SPRING	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1353	1	89	2026-06-15	16:00-17:00	2	VN	mazard spring	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1354	1	89	2026-06-12	17:00-18:00	2	VN	LABRE SANDERO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1355	1	90	2026-06-12	09:00-10:00	1	VN	PEGOURIE R5	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1356	1	90	2026-06-13	09:00-10:00	1	VN	TEYSSEDOU CLIO6	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1357	1	90	2026-06-12	11:00-12:00	1	VN	GOACHET AUSTRAL	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1358	1	90	2026-06-13	11:00-12:00	1	VN	hotzalari clio 6	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1359	1	90	2026-06-11	14:00-15:00	1	VN	BERTHIN SCENIC	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1360	1	90	2026-06-12	14:00-15:00	1	VN	GUILIVERT CLIO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1361	1	90	2026-06-13	16:00-17:00	1	VN	AMIEL CLIO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1362	1	90	2026-06-11	17:00-18:00	1	VN	MARTY R5	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1363	1	90	2026-06-12	10:00-11:00	2	VN	BRUN SANDERO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1364	1	91	2026-06-11	10:00-11:00	1	VN	GALTHIER CAPTUR	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1365	1	91	2026-06-12	11:00-12:00	1	VN	COSTE SANDERO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1366	1	91	2026-06-15	11:00-12:00	1	VN	FAURE CAPTUR	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1367	1	91	2026-06-12	18:00-19:00	1	VN	DEBORD SCENIC	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1368	1	91	2026-06-11	18:00-19:00	2	VN	SENTIS BIGSTER SPRING	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1541	2	66	2026-09-10	15:00-16:00	1	VN	TEST	\N	2026-09-02 09:40:26.168786+00	787	2026-09-02 09:41:06.325855+00	787	2026-09-02 09:41:06.94+00	787
1542	2	66	2026-09-11	10:00-11:00	2	VN	TEST 2	\N	2026-09-02 09:40:30.034751+00	787	2026-09-02 09:41:08.434615+00	787	2026-09-02 09:41:08.993+00	787
1562	2	25	2026-09-10	08:00-09:00	\N	VO	ESSAI PREMIER	\N	2026-09-03 07:13:11.195526+00	92	2026-09-03 07:14:31.272781+00	92	2026-09-03 07:14:30.928+00	92
1563	2	25	2026-09-10	08:00-09:00	\N	VO	ESSAI SECOND	\N	2026-09-03 07:14:18.986022+00	92	2026-09-03 07:14:49.003273+00	92	2026-09-03 07:14:48.684+00	92
\.


--
-- Data for Name: role_campagne; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.role_campagne (id, campagne_id, utilisateur_id, role, plaque_id, site_id, cree_le, cree_par, archive_le) FROM stdin;
4	2	13	chef_plaque	1	\N	2026-08-31 20:53:19.106+00	\N	\N
5	2	14	chef_site	\N	3	2026-08-31 20:53:19.987+00	\N	\N
\.


--
-- Data for Name: role_global; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.role_global (utilisateur_id, role, cree_le, cree_par) FROM stdin;
1	admin	2026-08-31 20:50:15.137+00	\N
10	admin	2026-08-31 20:53:15.78+00	\N
11	direction	2026-08-31 20:53:17.147+00	\N
787	admin	2026-09-01 16:43:20.447858+00	\N
92	admin	2026-09-01 12:45:20.746852+00	\N
93	admin	2026-09-01 12:58:40.915832+00	\N
94	direction	2026-09-01 12:59:44.615288+00	\N
95	direction	2026-09-01 13:01:37.569948+00	\N
96	direction	2026-09-01 13:01:52.884959+00	\N
98	admin	2026-09-01 15:11:18.605526+00	\N
1779	direction	2026-09-04 09:48:52.997933+00	\N
\.


--
-- Data for Name: session_plaque; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.session_plaque (id, campagne_id, plaque_id, mode, effectif_cible_table, cree_le, cree_par, archive_le) FROM stdin;
1	1	1	par_table	6	2026-08-31 20:50:18.397+00	\N	\N
2	1	2	par_site	\N	2026-08-31 20:50:18.808+00	\N	\N
3	1	3	par_table	6	2026-08-31 20:50:19.045+00	\N	\N
4	1	4	par_site	\N	2026-08-31 20:50:19.279+00	\N	\N
5	2	1	par_table	6	2026-08-31 20:50:20.458+00	\N	\N
6	2	2	par_site	\N	2026-08-31 20:50:20.716+00	\N	\N
7	2	3	par_table	6	2026-08-31 20:50:21.29+00	\N	\N
8	2	4	par_site	\N	2026-08-31 20:50:21.539+00	\N	\N
\.


--
-- Data for Name: site; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.site (id, code, libelle, plaque_id, cree_le, cree_par, archive_le) FROM stdin;
1	MASS	Massagettes	1	2026-08-31 20:49:25.453+00	\N	\N
2	MOZ	Mozac	1	2026-08-31 20:49:25.569+00	\N	\N
3	CLF	Clermont-Ferrand	1	2026-08-31 20:49:25.61+00	\N	\N
4	USS	Ussel	1	2026-08-31 20:49:25.658+00	\N	\N
5	ALPINE	Alpine	1	2026-08-31 20:49:25.702+00	\N	\N
6	VI	Vichy	2	2026-08-31 20:49:25.745+00	\N	\N
7	MOU	Moulins	2	2026-08-31 20:49:25.793+00	\N	\N
8	TH	Thiers	2	2026-08-31 20:49:25.83+00	\N	\N
9	PUY	Le Puy	3	2026-08-31 20:49:25.871+00	\N	\N
10	MEN	Mende	3	2026-08-31 20:49:25.942+00	\N	\N
11	ISS	Issoire	3	2026-08-31 20:49:25.992+00	\N	\N
12	GAILL	Gaillac	4	2026-08-31 20:49:26.025+00	\N	\N
13	ALBI	Albi	4	2026-08-31 20:49:26.066+00	\N	\N
14	RDZ	Rodez	4	2026-08-31 20:49:26.11+00	\N	\N
15	MILL	Millau	4	2026-08-31 20:49:26.149+00	\N	\N
16	FIGEAC	Figeac	4	2026-08-31 20:49:26.19+00	\N	\N
17	AUR	Aurillac	4	2026-08-31 20:49:26.232+00	\N	\N
18	VDR	Villefranche	4	2026-08-31 20:49:26.28+00	\N	\N
19	CARM	Carmaux	4	2026-08-31 20:49:26.33+00	\N	\N
710	LAV	Lavaur	4	2026-09-04 13:11:11.762874+00	\N	\N
\.


--
-- Data for Name: table_phoning; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.table_phoning (id, session_plaque_id, libelle, chef_utilisateur_id, ordre, cree_le, cree_par, archive_le, marque_id) FROM stdin;
1	1	Table 1	2	1	2026-08-31 20:50:21.882+00	\N	\N	\N
2	1	Table 2	3	2	2026-08-31 20:50:22.039+00	\N	\N	\N
3	1	Table 3	4	3	2026-08-31 20:50:22.124+00	\N	\N	\N
4	1	Table 4	5	4	2026-08-31 20:50:22.226+00	\N	\N	\N
5	1	Table 5	6	5	2026-08-31 20:50:22.346+00	\N	\N	\N
6	3	Table 1	7	1	2026-08-31 20:50:22.461+00	\N	\N	\N
7	3	Table 2	8	2	2026-08-31 20:50:22.59+00	\N	\N	\N
8	3	Table 3	9	3	2026-08-31 20:50:22.709+00	\N	\N	\N
145	7	PLAQUE SUD - 2	8	2	2026-09-02 09:30:35.062701+00	787	\N	\N
9	5	TABLE 1 - EAA	5	1	2026-09-01 15:28:59.817474+00	92	\N	\N
10	5	TABLE 2 - EAA	6	2	2026-09-01 15:29:31.677519+00	92	\N	\N
11	5	TABLE 3 - EAA	4	3	2026-09-01 15:29:37.085727+00	92	\N	\N
12	5	TABLE 4 - EAA	2	4	2026-09-01 15:29:42.158952+00	92	\N	\N
13	5	TABLE 5 - EAA	3	5	2026-09-01 15:29:49.251706+00	92	\N	\N
144	7	Plaque SUD -1	7	1	2026-09-01 16:46:55.487315+00	787	\N	\N
146	7	PLAQUE SUD - 3	9	3	2026-09-02 09:36:45.359915+00	787	\N	\N
\.


--
-- Data for Name: utilisateur; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.utilisateur (id, login_id, password_hash, nom, actif, cree_le, cree_par, archive_le, auth_uid) FROM stdin;
10	admin.test	$2b$10$jf1LfAOZSMgiQLYsVflYL.q0dRv8ocSlzR9ZpBjoTQNojIXHN9CJa	ADMIN — test	f	2026-08-31 20:53:15.597+00	\N	\N	37d1c8d1-6efb-41d9-84ad-1f5978acc0ce
1	admin	$2b$10$jf1LfAOZSMgiQLYsVflYL.q0dRv8ocSlzR9ZpBjoTQNojIXHN9CJa	Administrateur	t	2026-08-31 20:50:14.806+00	\N	\N	2e6f4109-a9ae-4975-9077-757592869249
13	chef.plaque.test	$2b$10$jf1LfAOZSMgiQLYsVflYL.q0dRv8ocSlzR9ZpBjoTQNojIXHN9CJa	CHEF DE PLAQUE — test	f	2026-08-31 20:53:18.693+00	\N	\N	\N
14	chef.site.test	$2b$10$jf1LfAOZSMgiQLYsVflYL.q0dRv8ocSlzR9ZpBjoTQNojIXHN9CJa	CHEF DE SITE — test	f	2026-08-31 20:53:19.683+00	\N	\N	\N
11	direction.test	$2b$10$jf1LfAOZSMgiQLYsVflYL.q0dRv8ocSlzR9ZpBjoTQNojIXHN9CJa	DIRECTION — test	f	2026-08-31 20:53:16.85+00	\N	\N	986a6c38-99b3-4ad6-8d71-501a04ca0c23
12	encadrant.test	$2b$10$jf1LfAOZSMgiQLYsVflYL.q0dRv8ocSlzR9ZpBjoTQNojIXHN9CJa	ENCADRANT — test	f	2026-08-31 20:53:17.728+00	\N	\N	d39e1b71-0b03-4d78-902f-02d50d3fa1ab
1775	cfabre	(supabase-auth)	Caroline FABRE	t	2026-09-04 09:45:14.793567+00	\N	\N	7fcb205f-7f0d-4136-baec-a7a34f9d1b8e
787	lroux	(supabase-auth)	LUDIVINE ROUX	t	2026-09-01 16:43:20.353208+00	\N	\N	303b0dd3-4ada-4f53-958b-29825fef98f3
92	tlabonne	(supabase-auth)	THEO LABONNE	t	2026-09-01 12:45:20.618531+00	\N	\N	9467b496-2b42-4663-9254-76454c9ae544
3	tcoignac	$2b$10$gYMOmKic9qsqxHud2dyZ0.RjSMQpPXWKzzZpZJj7CBvkSggU6bevK	THIERRY COIGNAC	t	2026-08-31 20:50:15.729+00	\N	\N	c4f2a711-917f-4158-adab-74a71c34527e
4	lmarchetti	$2b$10$gYMOmKic9qsqxHud2dyZ0.RjSMQpPXWKzzZpZJj7CBvkSggU6bevK	LUCIEN MARCHETTI	t	2026-08-31 20:50:15.98+00	\N	\N	6d61ac3b-1cad-42ce-ae94-963421dd4fb1
5	jlarget	$2b$10$gYMOmKic9qsqxHud2dyZ0.RjSMQpPXWKzzZpZJj7CBvkSggU6bevK	JF LARGET	t	2026-08-31 20:50:16.198+00	\N	\N	5a637024-b12e-47b9-b3f1-25631c049fdd
1776	smarty	(supabase-auth)	Stéphanie MARTY	t	2026-09-04 09:46:25.290645+00	\N	\N	0d437d07-4ce1-4368-8c7e-bb9dc0017c1a
6	mmasson	$2b$10$gYMOmKic9qsqxHud2dyZ0.RjSMQpPXWKzzZpZJj7CBvkSggU6bevK	MICKAEL MASSON	t	2026-08-31 20:50:16.394+00	\N	\N	bfc0adb8-889d-482e-a45c-17ca5ac56805
2	sbesson	$2b$10$jf1LfAOZSMgiQLYsVflYL.q0dRv8ocSlzR9ZpBjoTQNojIXHN9CJa	SÉVERINE BESSON	t	2026-08-31 20:50:15.467+00	\N	\N	323bc1ec-515e-4676-913a-50b39e43d18c
7	fnogues	$2b$10$gYMOmKic9qsqxHud2dyZ0.RjSMQpPXWKzzZpZJj7CBvkSggU6bevK	FRANCK NOGUES	t	2026-08-31 20:50:16.599+00	\N	\N	79958d14-63ab-4f93-bbc6-f57e3bb5082d
8	jhebert	$2b$10$gYMOmKic9qsqxHud2dyZ0.RjSMQpPXWKzzZpZJj7CBvkSggU6bevK	JÉRÔME HÉBERT	t	2026-08-31 20:50:16.808+00	\N	\N	c0eb4ed3-3b70-4af4-98f1-9fbb01f55f97
9	gparrain	$2b$10$gYMOmKic9qsqxHud2dyZ0.RjSMQpPXWKzzZpZJj7CBvkSggU6bevK	GILLES PARRAIN	t	2026-08-31 20:50:17.083+00	\N	\N	104bb84c-e5c5-4201-85aa-bf8cbdad1fb9
1777	lbressan	(supabase-auth)	Laurent BRESSAN	t	2026-09-04 09:46:42.435072+00	\N	\N	42985b02-8b3b-4dd6-9163-a7e443132448
1778	rbouzat	(supabase-auth)	Renaud BOUZAT	t	2026-09-04 09:47:53.826403+00	\N	\N	734f38ca-fe79-417e-9e7b-9a287336436c
1779	dsarotti	(supabase-auth)	Didier SAROTTI	t	2026-09-04 09:48:52.932794+00	\N	\N	5a1145e6-a11b-43df-825f-ce23b5620782
1780	cdelpuech	(supabase-auth)	Cédric DELPUECH	t	2026-09-04 09:49:59.218837+00	\N	\N	e988aca4-d096-462e-ba0f-3f23fae0f037
1781	jcazes	(supabase-auth)	Jean-Philippe CAZES	t	2026-09-04 09:50:49.297013+00	\N	\N	2de97c97-7eda-4f79-8d07-ff68abaf4f21
93	rfuziol	(supabase-auth)	RAPHAÊL FUZIOL	t	2026-09-01 12:58:40.811244+00	\N	\N	28e3e42b-0162-49f0-a62c-c0b827534777
94	ftixier	(supabase-auth)	FRANCK TIXIER	t	2026-09-01 12:59:44.528474+00	\N	\N	5c3f5664-b44a-44ef-8683-79041d50ac78
95	bbourron	(supabase-auth)	BENJAMIN BOURRON	t	2026-09-01 13:01:37.432109+00	\N	\N	11da046f-dfd2-4216-890f-f97c3782fea8
96	sgaudon	(supabase-auth)	STÉPHANE GAUDON	t	2026-09-01 13:01:52.818469+00	\N	\N	da923fe6-593f-4f5a-9423-36ff8b088d03
97	pduverger	(supabase-auth)	PIERRE DUVERGER	t	2026-09-01 13:02:41.790628+00	\N	\N	d6837ce3-decd-41a9-b616-77c9b16791e2
98	perard	(supabase-auth)	PIERRE-MICHEL ERARD	t	2026-09-01 15:11:18.506033+00	\N	\N	14b3b621-42d9-4463-9baa-57b036c50a27
\.


--
-- Data for Name: vendeur; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.vendeur (id, nom, site_id, utilisateur_id, date_entree, date_sortie, cree_le, cree_par, capacites_confirmees_le, capacites_confirmees_par, type_vehicule, archive_le, archive_par) FROM stdin;
2	VIRGINIE CUMINAL	1	\N	\N	\N	2026-08-31 20:49:27.54+00	\N	\N	\N	VN	\N	\N
3	ANTHONY DONAS	2	\N	\N	\N	2026-08-31 20:49:28.084+00	\N	\N	\N	VN	\N	\N
4	JORDAN CALDEIRA	2	\N	\N	\N	2026-08-31 20:49:28.795+00	\N	\N	\N	VN	\N	\N
5	ROBIN RABOISSON	2	\N	\N	\N	2026-08-31 20:49:29.355+00	\N	\N	\N	VN	\N	\N
6	KEVIN DIJOUX	2	\N	\N	\N	2026-08-31 20:49:30.148+00	\N	\N	\N	VN	\N	\N
13	BLANDINE CLÉMENT	3	\N	\N	2026-07-31	2026-08-31 20:49:33.679+00	\N	2026-09-01 15:38:04.770842+00	92	VN	\N	\N
8	YANN DE OLIVEIRA	2	\N	\N	\N	2026-08-31 20:49:31.298+00	\N	\N	\N	VO	\N	\N
9	MATTHIAS VALLE	2	\N	\N	\N	2026-08-31 20:49:31.515+00	\N	\N	\N	VO	\N	\N
10	VALENTIN PARPINELLI	3	\N	\N	\N	2026-08-31 20:49:31.644+00	\N	\N	\N	VN	\N	\N
11	THIERRY DUBERNAT	3	\N	\N	\N	2026-08-31 20:49:32.17+00	\N	\N	\N	VN	\N	\N
12	OCEANE ESPINASSE	3	\N	\N	\N	2026-08-31 20:49:33.088+00	\N	\N	\N	VN	\N	\N
14	THOMAS SOULIER	3	\N	\N	\N	2026-08-31 20:49:34.277+00	\N	\N	\N	VN	\N	\N
15	CHRISTOPHE BROSSEAU	3	\N	\N	\N	2026-08-31 20:49:34.82+00	\N	\N	\N	VN	\N	\N
16	THÉO ROUSSET	3	\N	\N	\N	2026-08-31 20:49:35.392+00	\N	\N	\N	VN	\N	\N
17	QUENTIN BELLAIGUES	3	\N	\N	\N	2026-08-31 20:49:35.914+00	\N	\N	\N	VN	\N	\N
18	JEAN-PIERRE FERRIER	3	\N	\N	\N	2026-08-31 20:49:36.449+00	\N	\N	\N	VN	\N	\N
19	JULIEN BIASUTTI	3	\N	\N	\N	2026-08-31 20:49:37.08+00	\N	\N	\N	VN	\N	\N
21	ANTOINE BASTIEN	3	\N	\N	\N	2026-08-31 20:49:38.351+00	\N	\N	\N	VO	\N	\N
22	DYLAN GUERRET	3	\N	\N	\N	2026-08-31 20:49:38.482+00	\N	\N	\N	VO	\N	\N
23	JOAO TEIXEIRA	3	\N	\N	\N	2026-08-31 20:49:38.604+00	\N	\N	\N	VO	\N	\N
24	THIERRY MARTINEZ	3	\N	\N	\N	2026-08-31 20:49:38.777+00	\N	\N	\N	VO	\N	\N
25	JEROME SABIN	3	\N	\N	\N	2026-08-31 20:49:38.909+00	\N	\N	\N	VO	\N	\N
26	ROBIN GUERY	4	\N	\N	\N	2026-08-31 20:49:39.039+00	\N	\N	\N	VN	\N	\N
27	JULIEN SPADAT	4	\N	\N	\N	2026-08-31 20:49:39.636+00	\N	\N	\N	VN	\N	\N
28	STÉPHANE VANDAMME	4	\N	\N	\N	2026-08-31 20:49:40.281+00	\N	\N	\N	VO	\N	\N
29	SÉBASTIEN MIRA	5	\N	\N	\N	2026-08-31 20:49:40.399+00	\N	\N	\N	VN	\N	\N
30	EMILIEN SOLEILHAVOUP	5	\N	\N	\N	2026-08-31 20:49:40.727+00	\N	\N	\N	VN	\N	\N
31	ALEXANDRE CHAVIGNON	6	\N	\N	\N	2026-08-31 20:49:41.278+00	\N	\N	\N	VN	\N	\N
32	MICHEL GUILLERM	6	\N	\N	\N	2026-08-31 20:49:41.815+00	\N	\N	\N	VN	\N	\N
33	ALEXANDRE DIOT	6	\N	\N	\N	2026-08-31 20:49:42.493+00	\N	\N	\N	VN	\N	\N
34	DYLAN MEYRIAL	6	\N	\N	\N	2026-08-31 20:49:43.05+00	\N	\N	\N	VN	\N	\N
35	YOANN TRIBOULET	6	\N	\N	\N	2026-08-31 20:49:43.564+00	\N	\N	\N	VN	\N	\N
36	MATTIS BONNAMOUR	6	\N	\N	\N	2026-08-31 20:49:44.169+00	\N	\N	\N	VN	\N	\N
37	VIKTORIIA BONDARENKO	6	\N	\N	\N	2026-08-31 20:49:44.723+00	\N	\N	\N	VN	\N	\N
38	NICOLAS BOUCHET	6	\N	\N	\N	2026-08-31 20:49:45.35+00	\N	\N	\N	VO	\N	\N
39	CLÉMENT JACQUET	6	\N	\N	\N	2026-08-31 20:49:45.484+00	\N	\N	\N	VO	\N	\N
40	ROMARIC RAMBERT	6	\N	\N	\N	2026-08-31 20:49:45.643+00	\N	\N	\N	VO	\N	\N
41	CLÉMENT RAYA	6	\N	\N	\N	2026-08-31 20:49:45.839+00	\N	\N	\N	VO	\N	\N
42	SYLVETTE ROGUE	7	\N	\N	\N	2026-08-31 20:49:45.97+00	\N	\N	\N	VN	\N	\N
43	SEBASTIEN DUBOST	7	\N	\N	\N	2026-08-31 20:49:46.529+00	\N	\N	\N	VN	\N	\N
44	MARC PALUMBO	7	\N	\N	\N	2026-08-31 20:49:47.037+00	\N	\N	\N	VN	\N	\N
45	PAULINE COIGNET	7	\N	\N	\N	2026-08-31 20:49:47.57+00	\N	\N	\N	VO	\N	\N
46	JULIEN LE QUELLEC	7	\N	\N	\N	2026-08-31 20:49:47.699+00	\N	\N	\N	VO	\N	\N
47	ROMAIN DENIS	7	\N	\N	\N	2026-08-31 20:49:47.82+00	\N	\N	\N	VO	\N	\N
48	LOUIS DUBOST	8	\N	\N	\N	2026-08-31 20:49:47.952+00	\N	\N	\N	VN	\N	\N
49	CYNTHIA VALLIN	8	\N	\N	\N	2026-08-31 20:49:48.57+00	\N	\N	\N	VN	\N	\N
50	AXEL DUMONT	8	\N	\N	\N	2026-08-31 20:49:49.219+00	\N	\N	\N	VN	\N	\N
51	DAMIEN DAGOSTINO	8	\N	\N	\N	2026-08-31 20:49:49.754+00	\N	\N	\N	VO	\N	\N
52	ALEXANDRE PINOT	8	\N	\N	\N	2026-08-31 20:49:49.924+00	\N	\N	\N	VO	\N	\N
53	ARNAUD GALLAND	9	\N	\N	\N	2026-08-31 20:49:50.054+00	\N	\N	\N	VN	\N	\N
54	GUILLAUME SAVINEL	9	\N	\N	\N	2026-08-31 20:49:50.598+00	\N	\N	\N	VN	\N	\N
55	JEAN-PAUL RANVOISE	9	\N	\N	\N	2026-08-31 20:49:51.171+00	\N	\N	\N	VN	\N	\N
56	ARTHUR DURANTON	9	\N	\N	\N	2026-08-31 20:49:51.736+00	\N	\N	\N	VN	\N	\N
57	VALENTIN MOLINES	9	\N	\N	\N	2026-08-31 20:49:52.381+00	\N	\N	\N	VO	\N	\N
58	RICHARD WEISSELDINGER	9	\N	\N	\N	2026-08-31 20:49:52.544+00	\N	\N	\N	VO	\N	\N
59	JÉRÉMY DA COSTA	10	\N	\N	\N	2026-08-31 20:49:52.699+00	\N	\N	\N	VN	\N	\N
60	DYLAN NOGUEIRA	10	\N	\N	\N	2026-08-31 20:49:53.289+00	\N	\N	\N	VN	\N	\N
61	WILLIAM PASCAL	10	\N	\N	\N	2026-08-31 20:49:53.893+00	\N	\N	\N	VO	\N	\N
62	YOANN PICARD	11	\N	\N	\N	2026-08-31 20:49:54.046+00	\N	\N	\N	VN	\N	\N
63	STANISLAS RODAMEL	11	\N	\N	\N	2026-08-31 20:49:54.607+00	\N	\N	\N	VN	\N	\N
65	MAGALI MICHEL	11	\N	\N	\N	2026-08-31 20:49:55.883+00	\N	\N	\N	VN	\N	\N
66	AMÉLIE HERVÉ	11	\N	\N	\N	2026-08-31 20:49:56.498+00	\N	\N	\N	VN	\N	\N
67	SÉBASTIEN DUMONT	11	\N	\N	\N	2026-08-31 20:49:57.277+00	\N	\N	\N	VN	\N	\N
68	REDWANE TOULOUSE	11	\N	\N	\N	2026-08-31 20:49:57.884+00	\N	\N	\N	VO	\N	\N
69	STÉPHANE DALLO-BELLESSA	11	\N	\N	\N	2026-08-31 20:49:58.037+00	\N	\N	\N	VO	\N	\N
72	JULIEN SEBE	12	\N	\N	\N	2026-08-31 20:49:59.003+00	\N	\N	\N	VN	\N	\N
73	GUILLAUME SEGUI	12	\N	\N	\N	2026-08-31 20:49:59.657+00	\N	\N	\N	VN	\N	\N
74	FLAVIEN MILLON	12	\N	\N	\N	2026-08-31 20:50:00.271+00	\N	\N	\N	VN	\N	\N
75	DANIEL DIAS FERNANDES	13	\N	\N	\N	2026-08-31 20:50:00.978+00	\N	\N	\N	VN	\N	\N
76	AURÉLIE BOMPART	13	\N	\N	\N	2026-08-31 20:50:01.551+00	\N	\N	\N	VN	\N	\N
71	CHRISTIAN CAUQUIL	710	\N	\N	\N	2026-08-31 20:49:58.351+00	\N	2026-09-04 13:55:35.191838+00	92	VN	\N	\N
78	FLORENT THOMASSIN	13	\N	\N	\N	2026-08-31 20:50:02.833+00	\N	\N	\N	VN	\N	\N
79	ROMAIN BOISSONNADE	14	\N	\N	\N	2026-08-31 20:50:03.448+00	\N	\N	\N	VN	\N	\N
81	ALEXIS COMPANS	14	\N	\N	\N	2026-08-31 20:50:04.58+00	\N	\N	\N	VN	\N	\N
82	RÉMI DEGAND	14	\N	\N	\N	2026-08-31 20:50:05.428+00	\N	\N	\N	VN	\N	\N
83	ARNAUD LOPEZ	14	\N	\N	\N	2026-08-31 20:50:05.981+00	\N	\N	\N	VO	\N	\N
84	DORIAN FRANCE	14	\N	\N	\N	2026-08-31 20:50:06.106+00	\N	\N	\N	VO	\N	\N
85	DAMIEN RULHE	14	\N	\N	\N	2026-08-31 20:50:06.263+00	\N	\N	\N	VO	\N	\N
89	DORIAN ALLEGRE	16	\N	\N	\N	2026-08-31 20:50:08.199+00	\N	\N	\N	VN	\N	\N
90	MATIS BRUNO	16	\N	\N	\N	2026-08-31 20:50:08.719+00	\N	\N	\N	VN	\N	\N
92	YOHAN BANYIK	17	\N	\N	\N	2026-08-31 20:50:09.915+00	\N	\N	\N	VN	\N	\N
93	ROMAIN COMBOURIEU	17	\N	\N	\N	2026-08-31 20:50:10.608+00	\N	\N	\N	VN	\N	\N
1	QUENTIN VANINI	1	\N	\N	2026-08-01	2026-08-31 20:49:26.552+00	\N	2026-09-01 16:15:23.629754+00	92	VN	\N	\N
64	JULIEN MONATTE	11	\N	\N	2026-07-01	2026-08-31 20:49:55.371+00	\N	2026-09-02 09:28:21.242777+00	787	VN	\N	\N
882	JULIEN RAYNAL	9	\N	2026-08-17	\N	2026-09-02 09:29:00.167354+00	787	2026-09-02 09:29:00.167354+00	787	VO	\N	\N
88	ELSA AGRINIER	15	\N	\N	2026-09-01	2026-08-31 20:50:07.65+00	\N	2026-09-04 09:40:02.976243+00	1	VN	\N	\N
86	NICOLAS CAYRON	15	\N	\N	2026-09-01	2026-08-31 20:50:06.406+00	\N	2026-09-04 09:40:10.368376+00	1	VN	\N	\N
87	MATHIS FRANCOIS	15	\N	\N	\N	2026-08-31 20:50:06.987+00	\N	2026-09-04 09:40:53.277466+00	1	VN	\N	\N
94	STÉPHANE SUC	17	\N	\N	\N	2026-08-31 20:50:11.145+00	\N	\N	\N	VN	\N	\N
95	ANTONIN LUC	17	\N	\N	\N	2026-08-31 20:50:11.84+00	\N	\N	\N	VN	\N	\N
96	MAGALI BRUGIER	18	\N	\N	\N	2026-08-31 20:50:12.458+00	\N	\N	\N	VN	\N	\N
97	THOMAS BERT	18	\N	\N	\N	2026-08-31 20:50:13.438+00	\N	\N	\N	VN	\N	\N
99	GEOFFREY SALGUES	19	\N	\N	\N	2026-08-31 20:50:14.173+00	\N	\N	\N	VN	\N	\N
7	UGO FERVEL	2	\N	\N	2026-08-31	2026-08-31 20:49:30.651+00	\N	2026-09-01 15:39:00.971629+00	92	VN	\N	\N
881	ADRIEN BRISSARD	11	\N	2026-09-01	\N	2026-09-02 09:28:07.716215+00	787	2026-09-02 09:28:07.716215+00	787	VN	\N	\N
70	LENAIC FRANCOIS	11	\N	\N	\N	2026-08-31 20:49:58.198+00	\N	2026-09-02 09:32:30.62226+00	787	VO	\N	\N
1886	Florian HELOIRE	14	\N	2026-09-01	\N	2026-09-04 09:41:48.853076+00	1	2026-09-04 09:41:48.853076+00	1	VN	\N	\N
80	MARINE FLAUJAGUET	14	\N	\N	\N	2026-08-31 20:50:03.969+00	\N	2026-09-04 09:41:57.153009+00	1	VN	\N	\N
98	AZIZ CHOUAY	18	\N	\N	\N	2026-08-31 20:50:14.021+00	\N	\N	\N	VO	2026-09-04 09:42:32.67308+00	1
211	PASCAL TABOULOT	3	\N	\N	\N	2026-09-01 16:12:42.508485+00	92	2026-09-01 16:12:42.508485+00	92	VO	\N	\N
212	DAMIEN TERRASSE	3	\N	\N	\N	2026-09-01 16:13:00.762443+00	92	2026-09-01 16:13:00.762443+00	92	VO	\N	\N
213	PIERRE PASSARELLI	3	\N	\N	\N	2026-09-01 16:13:19.46982+00	92	2026-09-01 16:13:19.46982+00	92	VO	\N	\N
214	QUENTIN OLIVO	3	\N	\N	\N	2026-09-01 16:13:43.970975+00	92	2026-09-01 16:13:43.970975+00	92	VO	\N	\N
215	FABIEN DELPUECH	3	\N	\N	\N	2026-09-01 16:14:02.900871+00	92	2026-09-01 16:14:02.900871+00	92	VO	\N	\N
159	EMMA GUENGEN	13	\N	\N	2026-09-01	2026-09-01 08:36:23.102009+00	10	2026-09-04 09:30:54.305402+00	1	VN	\N	\N
160	BAPTISTE DUBOIS	2	\N	2026-09-01	\N	2026-09-01 15:35:17.590064+00	92	2026-09-01 15:35:17.590064+00	92	VN	\N	\N
91	CLÉMENT MALGOUZOU	16	\N	\N	2026-09-01	2026-08-31 20:50:09.313+00	\N	2026-09-04 09:34:40.704556+00	1	VN	\N	\N
77	EMMA GUEGUEN	13	\N	\N	\N	2026-08-31 20:50:02.201+00	\N	\N	\N	VN	2026-09-01 08:35:38.146573+00	10
20	PIERRE-EDOUARD LAROCHE	3	\N	\N	2026-07-31	2026-08-31 20:49:37.667+00	\N	2026-09-01 15:33:51.776264+00	92	VN	\N	\N
1885	Clément CALVI	15	\N	2026-09-01	\N	2026-09-04 09:40:42.733882+00	1	2026-09-04 09:40:42.733882+00	1	VN	\N	\N
\.


--
-- Data for Name: vendeur_marque; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.vendeur_marque (vendeur_id, marque_id, cree_le, cree_par) FROM stdin;
2	1	2026-08-31 20:49:27.576+00	\N
2	2	2026-08-31 20:49:27.817+00	\N
3	1	2026-08-31 20:49:28.212+00	\N
3	2	2026-08-31 20:49:28.479+00	\N
4	1	2026-08-31 20:49:28.848+00	\N
4	2	2026-08-31 20:49:29.057+00	\N
5	1	2026-08-31 20:49:29.425+00	\N
5	2	2026-08-31 20:49:29.849+00	\N
6	1	2026-08-31 20:49:30.181+00	\N
6	2	2026-08-31 20:49:30.406+00	\N
10	1	2026-08-31 20:49:31.686+00	\N
10	2	2026-08-31 20:49:31.899+00	\N
11	1	2026-08-31 20:49:32.21+00	\N
11	2	2026-08-31 20:49:32.555+00	\N
12	1	2026-08-31 20:49:33.14+00	\N
12	2	2026-08-31 20:49:33.353+00	\N
14	1	2026-08-31 20:49:34.32+00	\N
14	2	2026-08-31 20:49:34.514+00	\N
15	1	2026-08-31 20:49:34.897+00	\N
15	2	2026-08-31 20:49:35.147+00	\N
16	1	2026-08-31 20:49:35.436+00	\N
16	2	2026-08-31 20:49:35.67+00	\N
17	1	2026-08-31 20:49:35.95+00	\N
17	2	2026-08-31 20:49:36.162+00	\N
18	1	2026-08-31 20:49:36.514+00	\N
18	2	2026-08-31 20:49:36.777+00	\N
19	1	2026-08-31 20:49:37.136+00	\N
19	2	2026-08-31 20:49:37.39+00	\N
26	1	2026-08-31 20:49:39.08+00	\N
26	2	2026-08-31 20:49:39.323+00	\N
27	1	2026-08-31 20:49:39.68+00	\N
27	2	2026-08-31 20:49:39.91+00	\N
29	3	2026-08-31 20:49:40.443+00	\N
30	3	2026-08-31 20:49:40.765+00	\N
31	1	2026-08-31 20:49:41.325+00	\N
31	2	2026-08-31 20:49:41.57+00	\N
32	1	2026-08-31 20:49:41.856+00	\N
32	2	2026-08-31 20:49:42.145+00	\N
33	1	2026-08-31 20:49:42.557+00	\N
33	2	2026-08-31 20:49:42.766+00	\N
34	1	2026-08-31 20:49:43.091+00	\N
34	2	2026-08-31 20:49:43.328+00	\N
35	1	2026-08-31 20:49:43.609+00	\N
35	2	2026-08-31 20:49:43.877+00	\N
36	1	2026-08-31 20:49:44.219+00	\N
36	2	2026-08-31 20:49:44.449+00	\N
37	1	2026-08-31 20:49:44.77+00	\N
37	2	2026-08-31 20:49:45.04+00	\N
42	1	2026-08-31 20:49:46.019+00	\N
42	2	2026-08-31 20:49:46.226+00	\N
43	1	2026-08-31 20:49:46.569+00	\N
43	2	2026-08-31 20:49:46.786+00	\N
44	1	2026-08-31 20:49:47.082+00	\N
44	2	2026-08-31 20:49:47.3+00	\N
48	1	2026-08-31 20:49:47.996+00	\N
48	2	2026-08-31 20:49:48.275+00	\N
49	1	2026-08-31 20:49:48.614+00	\N
49	2	2026-08-31 20:49:48.847+00	\N
50	1	2026-08-31 20:49:49.267+00	\N
50	2	2026-08-31 20:49:49.475+00	\N
53	1	2026-08-31 20:49:50.105+00	\N
53	2	2026-08-31 20:49:50.328+00	\N
54	1	2026-08-31 20:49:50.641+00	\N
54	2	2026-08-31 20:49:50.868+00	\N
55	1	2026-08-31 20:49:51.205+00	\N
55	2	2026-08-31 20:49:51.425+00	\N
56	1	2026-08-31 20:49:51.796+00	\N
56	2	2026-08-31 20:49:52.039+00	\N
59	1	2026-08-31 20:49:52.737+00	\N
59	2	2026-08-31 20:49:52.962+00	\N
60	1	2026-08-31 20:49:53.33+00	\N
60	2	2026-08-31 20:49:53.602+00	\N
62	1	2026-08-31 20:49:54.098+00	\N
62	2	2026-08-31 20:49:54.313+00	\N
63	1	2026-08-31 20:49:54.649+00	\N
63	2	2026-08-31 20:49:54.961+00	\N
65	1	2026-08-31 20:49:55.931+00	\N
65	2	2026-08-31 20:49:56.154+00	\N
66	1	2026-08-31 20:49:56.546+00	\N
66	2	2026-08-31 20:49:56.803+00	\N
67	1	2026-08-31 20:49:57.336+00	\N
67	2	2026-08-31 20:49:57.574+00	\N
72	1	2026-08-31 20:49:59.067+00	\N
72	2	2026-08-31 20:49:59.385+00	\N
73	1	2026-08-31 20:49:59.724+00	\N
73	2	2026-08-31 20:49:59.974+00	\N
74	1	2026-08-31 20:50:00.315+00	\N
74	2	2026-08-31 20:50:00.598+00	\N
75	1	2026-08-31 20:50:01.028+00	\N
75	2	2026-08-31 20:50:01.244+00	\N
76	1	2026-08-31 20:50:01.606+00	\N
76	2	2026-08-31 20:50:01.846+00	\N
77	1	2026-08-31 20:50:02.246+00	\N
77	2	2026-08-31 20:50:02.52+00	\N
78	1	2026-08-31 20:50:02.879+00	\N
78	2	2026-08-31 20:50:03.174+00	\N
79	1	2026-08-31 20:50:03.49+00	\N
79	2	2026-08-31 20:50:03.714+00	\N
81	1	2026-08-31 20:50:04.644+00	\N
81	2	2026-08-31 20:50:05.177+00	\N
82	1	2026-08-31 20:50:05.473+00	\N
82	2	2026-08-31 20:50:05.709+00	\N
89	1	2026-08-31 20:50:08.248+00	\N
89	2	2026-08-31 20:50:08.454+00	\N
90	1	2026-08-31 20:50:08.761+00	\N
90	2	2026-08-31 20:50:08.973+00	\N
92	1	2026-08-31 20:50:09.99+00	\N
92	2	2026-08-31 20:50:10.24+00	\N
93	1	2026-08-31 20:50:10.656+00	\N
93	2	2026-08-31 20:50:10.896+00	\N
94	1	2026-08-31 20:50:11.207+00	\N
94	2	2026-08-31 20:50:11.464+00	\N
95	1	2026-08-31 20:50:11.899+00	\N
95	2	2026-08-31 20:50:12.155+00	\N
96	1	2026-08-31 20:50:12.494+00	\N
96	2	2026-08-31 20:50:12.721+00	\N
97	1	2026-08-31 20:50:13.51+00	\N
97	2	2026-08-31 20:50:13.721+00	\N
99	1	2026-08-31 20:50:14.218+00	\N
99	2	2026-08-31 20:50:14.52+00	\N
20	1	2026-09-01 15:33:51.776264+00	92
20	2	2026-09-01 15:33:51.776264+00	92
160	1	2026-09-01 15:35:17.590064+00	92
160	2	2026-09-01 15:35:17.590064+00	92
13	1	2026-09-01 15:38:04.770842+00	92
13	2	2026-09-01 15:38:04.770842+00	92
7	1	2026-09-01 15:39:00.971629+00	92
7	2	2026-09-01 15:39:00.971629+00	92
1	1	2026-09-01 16:15:23.629754+00	92
1	2	2026-09-01 16:15:23.629754+00	92
881	1	2026-09-02 09:28:07.716215+00	787
881	2	2026-09-02 09:28:07.716215+00	787
64	1	2026-09-02 09:28:21.242777+00	787
64	2	2026-09-02 09:28:21.242777+00	787
159	1	2026-09-04 09:30:54.305402+00	1
159	2	2026-09-04 09:30:54.305402+00	1
91	1	2026-09-04 09:34:40.704556+00	1
91	2	2026-09-04 09:34:40.704556+00	1
88	1	2026-09-04 09:40:02.976243+00	1
88	2	2026-09-04 09:40:02.976243+00	1
86	1	2026-09-04 09:40:10.368376+00	1
86	2	2026-09-04 09:40:10.368376+00	1
1885	1	2026-09-04 09:40:42.733882+00	1
87	2	2026-09-04 09:40:53.277466+00	1
1886	2	2026-09-04 09:41:48.853076+00	1
80	1	2026-09-04 09:41:57.153009+00	1
71	1	2026-09-04 13:55:35.191838+00	92
71	2	2026-09-04 13:55:35.191838+00	92
\.


--
-- Name: affectation_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.affectation_id_seq', 1424, true);


--
-- Name: campagne_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.campagne_id_seq', 652, true);


--
-- Name: encadrement_site_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.encadrement_site_id_seq', 552, true);


--
-- Name: marque_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.marque_id_seq', 51, true);


--
-- Name: plaque_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.plaque_id_seq', 329, true);


--
-- Name: rdv_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.rdv_id_seq', 1629, true);


--
-- Name: role_campagne_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.role_campagne_id_seq', 20, true);


--
-- Name: session_plaque_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.session_plaque_id_seq', 333, true);


--
-- Name: site_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.site_id_seq', 710, true);


--
-- Name: table_phoning_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.table_phoning_id_seq', 341, true);


--
-- Name: utilisateur_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.utilisateur_id_seq', 1781, true);


--
-- Name: vendeur_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.vendeur_id_seq', 1886, true);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: affectation affectation_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.affectation
    ADD CONSTRAINT affectation_pkey PRIMARY KEY (id);


--
-- Name: campagne_creneau campagne_creneau_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.campagne_creneau
    ADD CONSTRAINT campagne_creneau_pkey PRIMARY KEY (campagne_id, code);


--
-- Name: campagne_jour campagne_jour_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.campagne_jour
    ADD CONSTRAINT campagne_jour_pkey PRIMARY KEY (campagne_id, jour);


--
-- Name: campagne campagne_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.campagne
    ADD CONSTRAINT campagne_pkey PRIMARY KEY (id);


--
-- Name: encadrement_site encadrement_site_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.encadrement_site
    ADD CONSTRAINT encadrement_site_pkey PRIMARY KEY (id);


--
-- Name: marque marque_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.marque
    ADD CONSTRAINT marque_pkey PRIMARY KEY (id);


--
-- Name: plaque plaque_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.plaque
    ADD CONSTRAINT plaque_pkey PRIMARY KEY (id);


--
-- Name: rdv rdv_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.rdv
    ADD CONSTRAINT rdv_pkey PRIMARY KEY (id);


--
-- Name: role_campagne role_campagne_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.role_campagne
    ADD CONSTRAINT role_campagne_pkey PRIMARY KEY (id);


--
-- Name: role_global role_global_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.role_global
    ADD CONSTRAINT role_global_pkey PRIMARY KEY (utilisateur_id, role);


--
-- Name: session_plaque session_plaque_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.session_plaque
    ADD CONSTRAINT session_plaque_pkey PRIMARY KEY (id);


--
-- Name: site site_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.site
    ADD CONSTRAINT site_pkey PRIMARY KEY (id);


--
-- Name: table_phoning table_phoning_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.table_phoning
    ADD CONSTRAINT table_phoning_pkey PRIMARY KEY (id);


--
-- Name: utilisateur utilisateur_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.utilisateur
    ADD CONSTRAINT utilisateur_pkey PRIMARY KEY (id);


--
-- Name: vendeur_marque vendeur_marque_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.vendeur_marque
    ADD CONSTRAINT vendeur_marque_pkey PRIMARY KEY (vendeur_id, marque_id);


--
-- Name: vendeur vendeur_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.vendeur
    ADD CONSTRAINT vendeur_pkey PRIMARY KEY (id);


--
-- Name: affectation_table_id_vendeur_id_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX affectation_table_id_vendeur_id_key ON relance.affectation USING btree (table_id, vendeur_id);


--
-- Name: affectation_vendeur_id_idx; Type: INDEX; Schema: relance; Owner: -
--

CREATE INDEX affectation_vendeur_id_idx ON relance.affectation USING btree (vendeur_id);


--
-- Name: campagne_libelle_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX campagne_libelle_key ON relance.campagne USING btree (libelle);


--
-- Name: encadrement_site_site_role_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX encadrement_site_site_role_key ON relance.encadrement_site USING btree (site_id, role);


--
-- Name: encadrement_site_utilisateur_id_idx; Type: INDEX; Schema: relance; Owner: -
--

CREATE INDEX encadrement_site_utilisateur_id_idx ON relance.encadrement_site USING btree (utilisateur_id);


--
-- Name: marque_code_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX marque_code_key ON relance.marque USING btree (code);


--
-- Name: plaque_libelle_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX plaque_libelle_key ON relance.plaque USING btree (libelle);


--
-- Name: rdv_campagne_id_jour_creneau_code_idx; Type: INDEX; Schema: relance; Owner: -
--

CREATE INDEX rdv_campagne_id_jour_creneau_code_idx ON relance.rdv USING btree (campagne_id, jour, creneau_code);


--
-- Name: rdv_campagne_id_vendeur_id_idx; Type: INDEX; Schema: relance; Owner: -
--

CREATE INDEX rdv_campagne_id_vendeur_id_idx ON relance.rdv USING btree (campagne_id, vendeur_id);


--
-- Name: role_campagne_campagne_id_utilisateur_id_idx; Type: INDEX; Schema: relance; Owner: -
--

CREATE INDEX role_campagne_campagne_id_utilisateur_id_idx ON relance.role_campagne USING btree (campagne_id, utilisateur_id);


--
-- Name: session_plaque_campagne_id_plaque_id_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX session_plaque_campagne_id_plaque_id_key ON relance.session_plaque USING btree (campagne_id, plaque_id);


--
-- Name: site_code_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX site_code_key ON relance.site USING btree (code);


--
-- Name: table_phoning_marque_id_idx; Type: INDEX; Schema: relance; Owner: -
--

CREATE INDEX table_phoning_marque_id_idx ON relance.table_phoning USING btree (marque_id);


--
-- Name: table_phoning_session_plaque_id_libelle_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX table_phoning_session_plaque_id_libelle_key ON relance.table_phoning USING btree (session_plaque_id, libelle);


--
-- Name: utilisateur_auth_uid_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX utilisateur_auth_uid_key ON relance.utilisateur USING btree (auth_uid);


--
-- Name: utilisateur_login_id_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX utilisateur_login_id_key ON relance.utilisateur USING btree (login_id);


--
-- Name: vendeur_site_id_idx; Type: INDEX; Schema: relance; Owner: -
--

CREATE INDEX vendeur_site_id_idx ON relance.vendeur USING btree (site_id);


--
-- Name: vendeur_utilisateur_id_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX vendeur_utilisateur_id_key ON relance.vendeur USING btree (utilisateur_id);


--
-- Name: affectation affectation_marque_table; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER affectation_marque_table BEFORE INSERT OR UPDATE ON relance.affectation FOR EACH ROW EXECUTE FUNCTION relance.verifier_affectation_marque_table();


--
-- Name: affectation affectation_meme_plaque; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER affectation_meme_plaque BEFORE INSERT OR UPDATE ON relance.affectation FOR EACH ROW EXECUTE FUNCTION relance.verifier_affectation_meme_plaque();


--
-- Name: affectation affectation_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER affectation_pas_de_delete BEFORE DELETE ON relance.affectation FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: affectation affectation_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER affectation_tracabilite BEFORE INSERT ON relance.affectation FOR EACH ROW EXECUTE FUNCTION relance.tracer_creation();


--
-- Name: affectation affectation_unique_par_campagne; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER affectation_unique_par_campagne BEFORE INSERT OR UPDATE ON relance.affectation FOR EACH ROW EXECUTE FUNCTION relance.verifier_affectation_unique();


--
-- Name: affectation affectation_vendeur_present; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER affectation_vendeur_present BEFORE INSERT OR UPDATE ON relance.affectation FOR EACH ROW EXECUTE FUNCTION relance.verifier_affectation_presence();


--
-- Name: campagne campagne_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER campagne_pas_de_delete BEFORE DELETE ON relance.campagne FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: campagne campagne_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER campagne_tracabilite BEFORE INSERT ON relance.campagne FOR EACH ROW EXECUTE FUNCTION relance.tracer_creation();


--
-- Name: encadrement_site encadrement_site_compte_actif; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER encadrement_site_compte_actif BEFORE INSERT OR UPDATE ON relance.encadrement_site FOR EACH ROW EXECUTE FUNCTION relance.verifier_encadrant_actif();


--
-- Name: encadrement_site encadrement_site_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER encadrement_site_pas_de_delete BEFORE DELETE ON relance.encadrement_site FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: encadrement_site encadrement_site_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER encadrement_site_tracabilite BEFORE INSERT ON relance.encadrement_site FOR EACH ROW EXECUTE FUNCTION relance.tracer_creation();


--
-- Name: marque marque_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER marque_pas_de_delete BEFORE DELETE ON relance.marque FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: plaque plaque_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER plaque_pas_de_delete BEFORE DELETE ON relance.plaque FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: rdv rdv_campagne_ouverte; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER rdv_campagne_ouverte BEFORE INSERT OR DELETE OR UPDATE ON relance.rdv FOR EACH ROW EXECUTE FUNCTION relance.verifier_campagne_ouverte();


--
-- Name: rdv rdv_diffusion; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER rdv_diffusion AFTER INSERT OR UPDATE ON relance.rdv FOR EACH ROW EXECUTE FUNCTION relance.diffuser_rdv();


--
-- Name: rdv rdv_marque_autorisee; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER rdv_marque_autorisee BEFORE INSERT OR UPDATE OF vendeur_id, marque_id ON relance.rdv FOR EACH ROW EXECUTE FUNCTION relance.verifier_marque_autorisee();


--
-- Name: rdv rdv_marque_selon_metier; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER rdv_marque_selon_metier BEFORE INSERT OR UPDATE OF vendeur_id, marque_id ON relance.rdv FOR EACH ROW EXECUTE FUNCTION relance.verifier_marque_selon_metier();


--
-- Name: rdv rdv_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER rdv_pas_de_delete BEFORE DELETE ON relance.rdv FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: rdv rdv_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER rdv_tracabilite BEFORE INSERT OR UPDATE ON relance.rdv FOR EACH ROW EXECUTE FUNCTION relance.tracer_modification_rdv();


--
-- Name: rdv rdv_type_coherent; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER rdv_type_coherent BEFORE INSERT OR UPDATE OF vendeur_id, type_vehicule ON relance.rdv FOR EACH ROW EXECUTE FUNCTION relance.verifier_type_coherent();


--
-- Name: role_campagne role_campagne_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER role_campagne_tracabilite BEFORE INSERT ON relance.role_campagne FOR EACH ROW EXECUTE FUNCTION relance.tracer_creation();


--
-- Name: role_global role_global_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER role_global_tracabilite BEFORE INSERT ON relance.role_global FOR EACH ROW EXECUTE FUNCTION relance.tracer_creation();


--
-- Name: session_plaque session_plaque_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER session_plaque_pas_de_delete BEFORE DELETE ON relance.session_plaque FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: session_plaque session_plaque_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER session_plaque_tracabilite BEFORE INSERT ON relance.session_plaque FOR EACH ROW EXECUTE FUNCTION relance.tracer_creation();


--
-- Name: site site_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER site_pas_de_delete BEFORE DELETE ON relance.site FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: table_phoning table_phoning_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER table_phoning_pas_de_delete BEFORE DELETE ON relance.table_phoning FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: table_phoning table_phoning_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER table_phoning_tracabilite BEFORE INSERT ON relance.table_phoning FOR EACH ROW EXECUTE FUNCTION relance.tracer_creation();


--
-- Name: utilisateur utilisateur_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER utilisateur_pas_de_delete BEFORE DELETE ON relance.utilisateur FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: vendeur vendeur_dates_contre_rdv; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER vendeur_dates_contre_rdv BEFORE INSERT OR UPDATE ON relance.vendeur FOR EACH ROW EXECUTE FUNCTION relance.verifier_vendeur_dates_contre_rdv();


--
-- Name: vendeur vendeur_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER vendeur_pas_de_delete BEFORE DELETE ON relance.vendeur FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: vendeur vendeur_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER vendeur_tracabilite BEFORE INSERT ON relance.vendeur FOR EACH ROW EXECUTE FUNCTION relance.tracer_creation();


--
-- Name: affectation affectation_table_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.affectation
    ADD CONSTRAINT affectation_table_id_fkey FOREIGN KEY (table_id) REFERENCES relance.table_phoning(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: affectation affectation_vendeur_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.affectation
    ADD CONSTRAINT affectation_vendeur_id_fkey FOREIGN KEY (vendeur_id) REFERENCES relance.vendeur(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: campagne_creneau campagne_creneau_campagne_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.campagne_creneau
    ADD CONSTRAINT campagne_creneau_campagne_id_fkey FOREIGN KEY (campagne_id) REFERENCES relance.campagne(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: campagne_jour campagne_jour_campagne_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.campagne_jour
    ADD CONSTRAINT campagne_jour_campagne_id_fkey FOREIGN KEY (campagne_id) REFERENCES relance.campagne(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: encadrement_site encadrement_site_site_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.encadrement_site
    ADD CONSTRAINT encadrement_site_site_id_fkey FOREIGN KEY (site_id) REFERENCES relance.site(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: encadrement_site encadrement_site_utilisateur_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.encadrement_site
    ADD CONSTRAINT encadrement_site_utilisateur_id_fkey FOREIGN KEY (utilisateur_id) REFERENCES relance.utilisateur(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: rdv rdv_campagne_id_creneau_code_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.rdv
    ADD CONSTRAINT rdv_campagne_id_creneau_code_fkey FOREIGN KEY (campagne_id, creneau_code) REFERENCES relance.campagne_creneau(campagne_id, code) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: rdv rdv_campagne_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.rdv
    ADD CONSTRAINT rdv_campagne_id_fkey FOREIGN KEY (campagne_id) REFERENCES relance.campagne(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: rdv rdv_campagne_id_jour_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.rdv
    ADD CONSTRAINT rdv_campagne_id_jour_fkey FOREIGN KEY (campagne_id, jour) REFERENCES relance.campagne_jour(campagne_id, jour) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: rdv rdv_marque_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.rdv
    ADD CONSTRAINT rdv_marque_id_fkey FOREIGN KEY (marque_id) REFERENCES relance.marque(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: rdv rdv_vendeur_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.rdv
    ADD CONSTRAINT rdv_vendeur_id_fkey FOREIGN KEY (vendeur_id) REFERENCES relance.vendeur(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: role_campagne role_campagne_campagne_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.role_campagne
    ADD CONSTRAINT role_campagne_campagne_id_fkey FOREIGN KEY (campagne_id) REFERENCES relance.campagne(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: role_campagne role_campagne_plaque_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.role_campagne
    ADD CONSTRAINT role_campagne_plaque_id_fkey FOREIGN KEY (plaque_id) REFERENCES relance.plaque(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: role_campagne role_campagne_site_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.role_campagne
    ADD CONSTRAINT role_campagne_site_id_fkey FOREIGN KEY (site_id) REFERENCES relance.site(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: role_campagne role_campagne_utilisateur_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.role_campagne
    ADD CONSTRAINT role_campagne_utilisateur_id_fkey FOREIGN KEY (utilisateur_id) REFERENCES relance.utilisateur(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: role_global role_global_utilisateur_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.role_global
    ADD CONSTRAINT role_global_utilisateur_id_fkey FOREIGN KEY (utilisateur_id) REFERENCES relance.utilisateur(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: session_plaque session_plaque_campagne_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.session_plaque
    ADD CONSTRAINT session_plaque_campagne_id_fkey FOREIGN KEY (campagne_id) REFERENCES relance.campagne(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: session_plaque session_plaque_plaque_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.session_plaque
    ADD CONSTRAINT session_plaque_plaque_id_fkey FOREIGN KEY (plaque_id) REFERENCES relance.plaque(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: site site_plaque_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.site
    ADD CONSTRAINT site_plaque_id_fkey FOREIGN KEY (plaque_id) REFERENCES relance.plaque(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: table_phoning table_phoning_chef_utilisateur_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.table_phoning
    ADD CONSTRAINT table_phoning_chef_utilisateur_id_fkey FOREIGN KEY (chef_utilisateur_id) REFERENCES relance.utilisateur(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: table_phoning table_phoning_marque_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.table_phoning
    ADD CONSTRAINT table_phoning_marque_id_fkey FOREIGN KEY (marque_id) REFERENCES relance.marque(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: table_phoning table_phoning_session_plaque_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.table_phoning
    ADD CONSTRAINT table_phoning_session_plaque_id_fkey FOREIGN KEY (session_plaque_id) REFERENCES relance.session_plaque(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vendeur_marque vendeur_marque_marque_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.vendeur_marque
    ADD CONSTRAINT vendeur_marque_marque_id_fkey FOREIGN KEY (marque_id) REFERENCES relance.marque(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: vendeur_marque vendeur_marque_vendeur_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.vendeur_marque
    ADD CONSTRAINT vendeur_marque_vendeur_id_fkey FOREIGN KEY (vendeur_id) REFERENCES relance.vendeur(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: vendeur vendeur_site_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.vendeur
    ADD CONSTRAINT vendeur_site_id_fkey FOREIGN KEY (site_id) REFERENCES relance.site(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: vendeur vendeur_utilisateur_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.vendeur
    ADD CONSTRAINT vendeur_utilisateur_id_fkey FOREIGN KEY (utilisateur_id) REFERENCES relance.utilisateur(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: _prisma_migrations; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance._prisma_migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: affectation; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.affectation ENABLE ROW LEVEL SECURITY;

--
-- Name: affectation affectation_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY affectation_creation ON relance.affectation FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: affectation affectation_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY affectation_lecture ON relance.affectation FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: affectation affectation_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY affectation_modification ON relance.affectation FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: campagne; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.campagne ENABLE ROW LEVEL SECURITY;

--
-- Name: campagne campagne_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_creation ON relance.campagne FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: campagne_creneau; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.campagne_creneau ENABLE ROW LEVEL SECURITY;

--
-- Name: campagne_creneau campagne_creneau_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_creneau_creation ON relance.campagne_creneau FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: campagne_creneau campagne_creneau_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_creneau_lecture ON relance.campagne_creneau FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: campagne_creneau campagne_creneau_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_creneau_modification ON relance.campagne_creneau FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: campagne_jour; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.campagne_jour ENABLE ROW LEVEL SECURITY;

--
-- Name: campagne_jour campagne_jour_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_jour_creation ON relance.campagne_jour FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: campagne_jour campagne_jour_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_jour_lecture ON relance.campagne_jour FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: campagne_jour campagne_jour_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_jour_modification ON relance.campagne_jour FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: campagne campagne_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_lecture ON relance.campagne FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: campagne campagne_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_modification ON relance.campagne FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: encadrement_site; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.encadrement_site ENABLE ROW LEVEL SECURITY;

--
-- Name: encadrement_site encadrement_site_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY encadrement_site_creation ON relance.encadrement_site FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs));


--
-- Name: encadrement_site encadrement_site_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY encadrement_site_lecture ON relance.encadrement_site FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: encadrement_site encadrement_site_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY encadrement_site_modification ON relance.encadrement_site FOR UPDATE TO authenticated USING (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs)) WITH CHECK (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs));


--
-- Name: marque; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.marque ENABLE ROW LEVEL SECURITY;

--
-- Name: marque marque_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY marque_creation ON relance.marque FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: marque marque_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY marque_lecture ON relance.marque FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: marque marque_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY marque_modification ON relance.marque FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: plaque; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.plaque ENABLE ROW LEVEL SECURITY;

--
-- Name: plaque plaque_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY plaque_creation ON relance.plaque FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: plaque plaque_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY plaque_lecture ON relance.plaque FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: plaque plaque_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY plaque_modification ON relance.plaque FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: rdv; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.rdv ENABLE ROW LEVEL SECURITY;

--
-- Name: rdv rdv_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY rdv_creation ON relance.rdv FOR INSERT TO authenticated WITH CHECK ((( SELECT relance.peut_saisir(rdv.vendeur_id, rdv.campagne_id) AS peut_saisir) AND ( SELECT relance.campagne_ouverte(rdv.campagne_id) AS campagne_ouverte)));


--
-- Name: rdv rdv_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY rdv_lecture ON relance.rdv FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM relance.perimetre_saisie ps
  WHERE ((ps.campagne_id = rdv.campagne_id) AND (ps.vendeur_id = rdv.vendeur_id)))));


--
-- Name: rdv rdv_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY rdv_modification ON relance.rdv FOR UPDATE TO authenticated USING ((( SELECT relance.peut_saisir(rdv.vendeur_id, rdv.campagne_id) AS peut_saisir) AND ( SELECT relance.campagne_ouverte(rdv.campagne_id) AS campagne_ouverte))) WITH CHECK ((( SELECT relance.peut_saisir(rdv.vendeur_id, rdv.campagne_id) AS peut_saisir) AND ( SELECT relance.campagne_ouverte(rdv.campagne_id) AS campagne_ouverte)));


--
-- Name: role_campagne; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.role_campagne ENABLE ROW LEVEL SECURITY;

--
-- Name: role_campagne role_campagne_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY role_campagne_creation ON relance.role_campagne FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs));


--
-- Name: role_campagne role_campagne_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY role_campagne_lecture ON relance.role_campagne FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: role_campagne role_campagne_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY role_campagne_modification ON relance.role_campagne FOR UPDATE TO authenticated USING (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs)) WITH CHECK (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs));


--
-- Name: role_global; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.role_global ENABLE ROW LEVEL SECURITY;

--
-- Name: role_global role_global_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY role_global_creation ON relance.role_global FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs));


--
-- Name: role_global role_global_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY role_global_lecture ON relance.role_global FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: role_global role_global_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY role_global_modification ON relance.role_global FOR UPDATE TO authenticated USING (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs)) WITH CHECK (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs));


--
-- Name: session_plaque; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.session_plaque ENABLE ROW LEVEL SECURITY;

--
-- Name: session_plaque session_plaque_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY session_plaque_creation ON relance.session_plaque FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: session_plaque session_plaque_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY session_plaque_lecture ON relance.session_plaque FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: session_plaque session_plaque_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY session_plaque_modification ON relance.session_plaque FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: site; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.site ENABLE ROW LEVEL SECURITY;

--
-- Name: site site_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY site_creation ON relance.site FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: site site_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY site_lecture ON relance.site FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: site site_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY site_modification ON relance.site FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: table_phoning; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.table_phoning ENABLE ROW LEVEL SECURITY;

--
-- Name: table_phoning table_phoning_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY table_phoning_creation ON relance.table_phoning FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: table_phoning table_phoning_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY table_phoning_lecture ON relance.table_phoning FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: table_phoning table_phoning_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY table_phoning_modification ON relance.table_phoning FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: utilisateur; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.utilisateur ENABLE ROW LEVEL SECURITY;

--
-- Name: utilisateur utilisateur_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY utilisateur_creation ON relance.utilisateur FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs));


--
-- Name: utilisateur utilisateur_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY utilisateur_lecture ON relance.utilisateur FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: utilisateur utilisateur_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY utilisateur_modification ON relance.utilisateur FOR UPDATE TO authenticated USING (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs)) WITH CHECK (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs));


--
-- Name: vendeur; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.vendeur ENABLE ROW LEVEL SECURITY;

--
-- Name: vendeur vendeur_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY vendeur_creation ON relance.vendeur FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: vendeur vendeur_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY vendeur_lecture ON relance.vendeur FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: vendeur_marque; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.vendeur_marque ENABLE ROW LEVEL SECURITY;

--
-- Name: vendeur_marque vendeur_marque_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY vendeur_marque_creation ON relance.vendeur_marque FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: vendeur_marque vendeur_marque_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY vendeur_marque_lecture ON relance.vendeur_marque FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: vendeur_marque vendeur_marque_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY vendeur_marque_modification ON relance.vendeur_marque FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: vendeur vendeur_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY vendeur_modification ON relance.vendeur FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- PostgreSQL database dump complete
--

\unrestrict taNZo5oKaVD4U9RG3XComGMkggzetr13odm3dLhg9lq0mticKDQ8UxsWnPKxLDc

