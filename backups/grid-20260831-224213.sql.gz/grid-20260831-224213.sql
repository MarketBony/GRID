--
-- PostgreSQL database dump
--

\restrict 9h6UxezZwrNqEo4JDMWwizvNqVFXkaO2tbKnNG8nKByFiZhIMGR3uSn9wPhpVza

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.11 (Ubuntu 17.11-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: relance; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA relance;


--
-- Name: a_role_global(text); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.a_role_global(p_role text) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
  SELECT EXISTS (
    SELECT 1 FROM relance.role_global rg
    WHERE rg.utilisateur_id = relance.utilisateur_courant()
      AND rg.role = p_role
  )
$$;


--
-- Name: campagne_definir_creneaux(bigint, text[], text[], text, text); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.campagne_definir_creneaux(p_campagne_id bigint, p_codes text[], p_libelles text[], p_mode text DEFAULT NULL::text, p_vers text DEFAULT NULL::text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_administration();
  retires text[];
  ajoutes text[];
  impactes int;
  detail jsonb;
  i int;
BEGIN
  IF p_codes IS NULL OR array_length(p_codes, 1) IS NULL THEN
    RAISE EXCEPTION 'RELANCE: au moins un creneau est requis.';
  END IF;
  IF array_length(p_codes, 1) <> array_length(p_libelles, 1) THEN
    RAISE EXCEPTION 'RELANCE: chaque creneau doit porter un libelle.';
  END IF;
  IF (SELECT count(DISTINCT c) FROM unnest(p_codes) c) <> array_length(p_codes, 1) THEN
    RAISE EXCEPTION 'RELANCE: un creneau est present deux fois.';
  END IF;
  IF NOT relance.campagne_ouverte(p_campagne_id) THEN
    RAISE EXCEPTION 'RELANCE: campagne cloturee, ses creneaux ne sont plus modifiables.';
  END IF;

  SELECT coalesce(array_agg(cc.code ORDER BY cc.ordre), '{}')
    INTO retires
    FROM relance.campagne_creneau cc
   WHERE cc.campagne_id = p_campagne_id AND NOT (cc.code = ANY (p_codes));

  SELECT coalesce(array_agg(c), '{}')
    INTO ajoutes
    FROM unnest(p_codes) c
   WHERE NOT EXISTS (
     SELECT 1 FROM relance.campagne_creneau cc
      WHERE cc.campagne_id = p_campagne_id AND cc.code = c
   );

  SELECT count(*)::int,
         coalesce(jsonb_agg(jsonb_build_object('creneau', s.code, 'actifs', s.actifs, 'archives', s.archives)), '[]'::jsonb)
    INTO impactes, detail
    FROM (
      SELECT r.creneau_code AS code,
             count(*) FILTER (WHERE r.archive_le IS NULL) AS actifs,
             count(*) FILTER (WHERE r.archive_le IS NOT NULL) AS archives
        FROM relance.rdv r
       WHERE r.campagne_id = p_campagne_id AND r.creneau_code = ANY (retires)
       GROUP BY r.creneau_code
    ) s;

  SELECT coalesce(sum((x->>'actifs')::int + (x->>'archives')::int), 0)::int
    INTO impactes FROM jsonb_array_elements(detail) x;

  IF impactes > 0 AND coalesce(p_mode, '') <> 'deplacer' THEN
    RETURN jsonb_build_object(
      'applique', false, 'code', 'RDV_IMPACTES',
      'retires', to_jsonb(retires), 'ajoutes', to_jsonb(ajoutes),
      'impacts', detail, 'creneauxConserves', to_jsonb(p_codes),
      'message', format('Retirer ces creneaux supprimerait le rattachement de %s RDV. Choisir : annuler, ou deplacer ces RDV vers un creneau conserve.', impactes)
    );
  END IF;

  IF impactes > 0 AND (p_vers IS NULL OR NOT (p_vers = ANY (p_codes))) THEN
    RAISE EXCEPTION 'RELANCE: le creneau de destination doit faire partie des creneaux conserves.';
  END IF;

  FOR i IN 1 .. array_length(p_codes, 1) LOOP
    INSERT INTO relance.campagne_creneau (campagne_id, code, libelle, ordre, cree_par)
    VALUES (p_campagne_id, p_codes[i], p_libelles[i], i, moi)
    ON CONFLICT (campagne_id, code) DO UPDATE SET libelle = EXCLUDED.libelle, ordre = EXCLUDED.ordre;
  END LOOP;

  IF impactes > 0 THEN
    UPDATE relance.rdv r
       SET creneau_code = p_vers, modifie_le = now(), modifie_par = moi
     WHERE r.campagne_id = p_campagne_id AND r.creneau_code = ANY (retires);
  END IF;

  IF array_length(retires, 1) IS NOT NULL THEN
    DELETE FROM relance.campagne_creneau cc
     WHERE cc.campagne_id = p_campagne_id AND cc.code = ANY (retires);
  END IF;

  RETURN jsonb_build_object(
    'applique', true, 'retires', to_jsonb(retires), 'ajoutes', to_jsonb(ajoutes),
    'rdvDeplaces', impactes, 'versCreneau', to_jsonb(p_vers),
    'creneaux', (SELECT coalesce(jsonb_agg(jsonb_build_object('code', cc.code, 'libelle', cc.libelle, 'ordre', cc.ordre) ORDER BY cc.ordre), '[]'::jsonb)
                   FROM relance.campagne_creneau cc WHERE cc.campagne_id = p_campagne_id)
  );
END $$;


--
-- Name: campagne_definir_jours(bigint, date[], text, date); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.campagne_definir_jours(p_campagne_id bigint, p_jours date[], p_mode text DEFAULT NULL::text, p_vers date DEFAULT NULL::date) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_administration();
  retires date[];
  ajoutes date[];
  impactes int;
  detail jsonb;
  i int;
BEGIN
  IF p_jours IS NULL OR array_length(p_jours, 1) IS NULL THEN
    RAISE EXCEPTION 'RELANCE: au moins un jour est requis.';
  END IF;
  IF (SELECT count(DISTINCT j) FROM unnest(p_jours) j) <> array_length(p_jours, 1) THEN
    RAISE EXCEPTION 'RELANCE: un jour est present deux fois.';
  END IF;
  IF NOT relance.campagne_ouverte(p_campagne_id) THEN
    RAISE EXCEPTION 'RELANCE: campagne cloturee, ses jours ne sont plus modifiables.';
  END IF;

  SELECT coalesce(array_agg(cj.jour ORDER BY cj.jour), '{}')
    INTO retires
    FROM relance.campagne_jour cj
   WHERE cj.campagne_id = p_campagne_id
     AND NOT (cj.jour = ANY (p_jours));

  SELECT coalesce(array_agg(j ORDER BY j), '{}')
    INTO ajoutes
    FROM unnest(p_jours) j
   WHERE NOT EXISTS (
     SELECT 1 FROM relance.campagne_jour cj
      WHERE cj.campagne_id = p_campagne_id AND cj.jour = j
   );

  -- Les RDV impactes, ARCHIVES COMPRIS : un RDV archive reste rattache a son jour
  -- par la cle etrangere, donc il bloque le retrait exactement comme un actif.
  SELECT count(*)::int,
         coalesce(jsonb_agg(x ORDER BY x->>'jour'), '[]'::jsonb)
    INTO impactes, detail
    FROM (
      SELECT jsonb_build_object(
               'jour', r.jour,
               'actifs', count(*) FILTER (WHERE r.archive_le IS NULL),
               'archives', count(*) FILTER (WHERE r.archive_le IS NOT NULL),
               'vendeurs', coalesce(jsonb_agg(DISTINCT v.nom) FILTER (WHERE r.archive_le IS NULL), '[]'::jsonb)
             ) AS x,
             count(*) AS n
        FROM relance.rdv r
        JOIN relance.vendeur v ON v.id = r.vendeur_id
       WHERE r.campagne_id = p_campagne_id
         AND r.jour = ANY (retires)
       GROUP BY r.jour
    ) s;

  SELECT coalesce(sum((x->>'actifs')::int + (x->>'archives')::int), 0)::int
    INTO impactes
    FROM jsonb_array_elements(detail) x;

  -- SONDAGE : on rend l'impact sans rien modifier. L'interface s'en sert pour
  -- proposer le choix « annuler ou deplacer ».
  IF impactes > 0 AND coalesce(p_mode, '') <> 'deplacer' THEN
    RETURN jsonb_build_object(
      'applique', false,
      'code', 'RDV_IMPACTES',
      'retires', to_jsonb(retires),
      'ajoutes', to_jsonb(ajoutes),
      'impacts', detail,
      'joursConserves', to_jsonb(p_jours),
      'message', format(
        'Retirer %s supprimerait le rattachement de %s RDV. Choisir : annuler la modification, ou deplacer ces RDV vers un jour conserve.',
        CASE WHEN array_length(retires, 1) > 1 THEN 'ces jours' ELSE 'ce jour' END,
        impactes)
    );
  END IF;

  IF impactes > 0 THEN
    IF p_vers IS NULL OR NOT (p_vers = ANY (p_jours)) THEN
      RAISE EXCEPTION 'RELANCE: le jour de destination doit faire partie des jours conserves.';
    END IF;
  END IF;

  -- 1. les jours demandes, crees ou renumerotes
  FOR i IN 1 .. array_length(p_jours, 1) LOOP
    INSERT INTO relance.campagne_jour (campagne_id, jour, ordre, cree_par)
    VALUES (p_campagne_id, p_jours[i], i, moi)
    ON CONFLICT (campagne_id, jour) DO UPDATE SET ordre = EXCLUDED.ordre;
  END LOOP;

  -- 2. les RDV deplaces, APRES la creation des jours de destination
  IF impactes > 0 THEN
    UPDATE relance.rdv r
       SET jour = p_vers, modifie_le = now(), modifie_par = moi
     WHERE r.campagne_id = p_campagne_id
       AND r.jour = ANY (retires);
  END IF;

  -- 3. les jours retires, une fois vides
  IF array_length(retires, 1) IS NOT NULL THEN
    DELETE FROM relance.campagne_jour cj
     WHERE cj.campagne_id = p_campagne_id AND cj.jour = ANY (retires);
  END IF;

  RETURN jsonb_build_object(
    'applique', true,
    'retires', to_jsonb(retires),
    'ajoutes', to_jsonb(ajoutes),
    'rdvDeplaces', impactes,
    'versJour', to_jsonb(p_vers),
    'jours', (SELECT coalesce(jsonb_agg(jsonb_build_object('jour', cj.jour, 'ordre', cj.ordre) ORDER BY cj.ordre), '[]'::jsonb)
                FROM relance.campagne_jour cj WHERE cj.campagne_id = p_campagne_id)
  );
END $$;


--
-- Name: campagne_ouverte(bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.campagne_ouverte(p_campagne_id bigint) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
  SELECT EXISTS (
    SELECT 1 FROM relance.campagne c
    WHERE c.id = p_campagne_id
      AND NOT c.cloturee
      AND c.archive_le IS NULL
  )
$$;


--
-- Name: diffuser_rdv(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.diffuser_rdv() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
BEGIN
  PERFORM realtime.send(
    -- LA CHARGE UTILE NE PORTE NI `client` NI `commentaire`. Meme regle que la vue
    -- `rdv_agrege`, et elle est structurelle : il n'y a pas de champ a oublier de
    -- retirer, il n'y en a jamais eu.
    jsonb_build_object(
      'id', NEW.id::text,
      'vendeurId', NEW.vendeur_id::text,
      'jour', NEW.jour,
      'creneauCode', NEW.creneau_code,
      'marqueId', NEW.marque_id::text,
      'typeVehicule', NEW.type_vehicule,
      'archive', NEW.archive_le IS NOT NULL,
      -- QUI A ECRIT — pour que l'auteur ignore son propre evenement. Il a deja
      -- applique le changement localement (F-C.4) ; le lui rejouer provoquerait un
      -- second rendu, et pendant une saisie au clavier ce scintillement se voit.
      'auteur', coalesce(NEW.modifie_par, NEW.cree_par)::text
    ),
    'rdv',
    'campagne-' || NEW.campagne_id::text,
    true
  );
  RETURN NULL;
END $$;


--
-- Name: exiger_administration(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.exiger_administration() RETURNS bigint
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE moi bigint := relance.utilisateur_courant();
BEGIN
  IF moi IS NULL THEN
    RAISE EXCEPTION 'RELANCE: authentification requise.';
  END IF;
  IF NOT relance.peut_administrer() THEN
    RAISE EXCEPTION 'RELANCE: cette action demande le niveau administrateur ou direction.';
  END IF;
  RETURN moi;
END $$;


--
-- Name: exiger_gestion_comptes(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.exiger_gestion_comptes() RETURNS bigint
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE moi bigint := relance.utilisateur_courant();
BEGIN
  IF moi IS NULL THEN
    RAISE EXCEPTION 'RELANCE: authentification requise.';
  END IF;
  -- `admin` SEUL. C'est la frontiere qui empeche `direction` de se promouvoir,
  -- et elle ne doit jamais etre elargie « pour simplifier ».
  IF NOT relance.peut_gerer_utilisateurs() THEN
    RAISE EXCEPTION 'RELANCE: la gestion des comptes est reservee aux administrateurs.';
  END IF;
  RETURN moi;
END $$;


--
-- Name: exiger_session(bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.exiger_session(p_session_id bigint) RETURNS bigint
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.utilisateur_courant();
  campagne bigint;
BEGIN
  IF moi IS NULL THEN
    RAISE EXCEPTION 'RELANCE: authentification requise.';
  END IF;
  SELECT sp.campagne_id INTO campagne FROM relance.session_plaque sp WHERE sp.id = p_session_id;
  IF campagne IS NULL THEN
    RAISE EXCEPTION 'RELANCE: session introuvable.';
  END IF;
  IF NOT relance.peut_administrer_session(p_session_id) THEN
    RAISE EXCEPTION 'RELANCE: vous n''administrez pas cette plaque sur cette campagne.';
  END IF;
  -- R-C.3. Repete ici parce qu'une session close ne doit pas non plus voir sa
  -- composition changer — le trigger sur `rdv` ne couvre que les RDV.
  IF NOT relance.campagne_ouverte(campagne) THEN
    RAISE EXCEPTION 'RELANCE: cette campagne est cloturee, sa composition n''est plus modifiable.';
  END IF;
  RETURN moi;
END $$;


--
-- Name: interdire_suppression(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.interdire_suppression() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'relance', 'public'
    AS $$
BEGIN
  -- La porte : ouverte pour la duree d'UNE transaction, par la route de purge et
  -- par elle seule. `current_setting(..., true)` rend NULL si le parametre n'a
  -- jamais ete pose — donc le refus est bien le defaut, y compris sur une
  -- connexion neuve.
  IF coalesce(current_setting('relance.purge_autorisee', true), '') = 'oui' THEN
    RETURN NULL; -- trigger STATEMENT : la valeur de retour est ignoree
  END IF;

  RAISE EXCEPTION
    'RELANCE: suppression interdite sur %. Utiliser l''archivage (archive_le ou date_sortie). La purge definitive passe par l''ecran Archivage.',
    TG_TABLE_NAME;
END $$;


--
-- Name: peut_administrer(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.peut_administrer() RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
  SELECT relance.a_role_global('admin') OR relance.a_role_global('direction')
$$;


--
-- Name: peut_administrer_session(bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.peut_administrer_session(p_session_id bigint) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
  SELECT relance.peut_administrer()
      OR EXISTS (
        SELECT 1
        FROM relance.session_plaque sp
        JOIN relance.role_campagne rc
          ON rc.campagne_id = sp.campagne_id
         AND rc.plaque_id = sp.plaque_id
         AND rc.role = 'chef_plaque'
         AND rc.archive_le IS NULL
         AND rc.utilisateur_id = relance.utilisateur_courant()
        WHERE sp.id = p_session_id
      )
$$;


--
-- Name: peut_gerer_utilisateurs(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.peut_gerer_utilisateurs() RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
  SELECT relance.a_role_global('admin')
$$;


--
-- Name: peut_saisir(bigint, bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.peut_saisir(p_vendeur_id bigint, p_campagne_id bigint) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
  SELECT EXISTS (
    SELECT 1 FROM relance.perimetre_saisie ps
    WHERE ps.vendeur_id = p_vendeur_id
      AND ps.campagne_id = p_campagne_id
  )
$$;


--
-- Name: poser_capacites(bigint, bigint[], text, bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.poser_capacites(p_vendeur_id bigint, p_marque_ids bigint[], p_type_vehicule text, p_par bigint) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE m bigint;
BEGIN
  DELETE FROM relance.vendeur_marque WHERE vendeur_id = p_vendeur_id;
  IF p_type_vehicule <> 'VO' AND p_marque_ids IS NOT NULL THEN
    FOREACH m IN ARRAY p_marque_ids LOOP
      INSERT INTO relance.vendeur_marque (vendeur_id, marque_id, cree_par)
      VALUES (p_vendeur_id, m, p_par)
      ON CONFLICT DO NOTHING;
    END LOOP;
  END IF;

  -- PROVENANCE, pas un statut : qui a change les capacites et quand. La notion de
  -- « confirme / placeholder » a ete retiree — un vendeur en base est valide. Ces
  -- deux colonnes servent le jour ou un RDV est refuse sans que personne comprenne.
  UPDATE relance.vendeur
     SET type_vehicule = p_type_vehicule,
         capacites_confirmees_le = now(),
         capacites_confirmees_par = p_par
   WHERE id = p_vendeur_id;
END $$;


--
-- Name: session_appliquer_repartition(bigint, jsonb, boolean); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.session_appliquer_repartition(p_session_id bigint, p_placements jsonb, p_remplacer boolean DEFAULT false) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_session(p_session_id);
  place int := 0;
  p jsonb;
  v jsonb;
  t bigint;
BEGIN
  -- `remplacer` REFAIT la composition entiere : toutes les affectations actives de
  -- la session sont archivees avant de replacer. Derriere une confirmation dans
  -- l'interface, jamais par defaut.
  IF p_remplacer THEN
    UPDATE relance.affectation a SET archive_le = now()
      FROM relance.table_phoning t
     WHERE t.id = a.table_id
       AND t.session_plaque_id = p_session_id
       AND a.archive_le IS NULL;
  END IF;

  FOR p IN SELECT jsonb_array_elements(coalesce(p_placements, '[]'::jsonb)) LOOP
    t := (p->>'tableId')::bigint;

    -- La table doit appartenir A CETTE session : sans ce controle, un appelant
    -- autorise sur sa plaque pourrait ecrire dans les tables d'une autre.
    IF NOT EXISTS (
      SELECT 1 FROM relance.table_phoning tp
       WHERE tp.id = t AND tp.session_plaque_id = p_session_id AND tp.archive_le IS NULL
    ) THEN
      RAISE EXCEPTION 'RELANCE: la table % n''appartient pas a cette session.', t;
    END IF;

    FOR v IN SELECT jsonb_array_elements(coalesce(p->'vendeurIdsAjoutes', '[]'::jsonb)) LOOP
      INSERT INTO relance.affectation (table_id, vendeur_id, origine, cree_par)
      VALUES (t, (v#>>'{}')::bigint, 'auto', moi)
      ON CONFLICT (table_id, vendeur_id) DO UPDATE SET archive_le = NULL, origine = 'auto';
      place := place + 1;
    END LOOP;
  END LOOP;

  RETURN jsonb_build_object('graine', 42, 'remplacer', p_remplacer, 'affectations', place);
END $$;


--
-- Name: session_reprendre(bigint, bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.session_reprendre(p_session_id bigint, p_depuis_campagne_id bigint) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_session(p_session_id);
  plaque bigint;
  campagne bigint;
  source bigint;
  tables_creees int := 0;
  reprises int := 0;
  reportes jsonb := '[]'::jsonb;
  t record;
  a record;
  cible bigint;
  existait boolean;
BEGIN
  SELECT sp.plaque_id, sp.campagne_id INTO plaque, campagne
    FROM relance.session_plaque sp WHERE sp.id = p_session_id;

  IF p_depuis_campagne_id = campagne THEN
    RAISE EXCEPTION 'RELANCE: la campagne source doit etre une AUTRE campagne.';
  END IF;

  SELECT sp.id INTO source
    FROM relance.session_plaque sp
   WHERE sp.campagne_id = p_depuis_campagne_id
     AND sp.plaque_id = plaque
     AND sp.archive_le IS NULL;
  IF source IS NULL THEN
    RAISE EXCEPTION 'RELANCE: cette plaque n''avait aucune session sur la campagne demandee.';
  END IF;

  FOR t IN
    SELECT tp.id, tp.libelle, tp.ordre, tp.chef_utilisateur_id, tp.marque_id
      FROM relance.table_phoning tp
     WHERE tp.session_plaque_id = source AND tp.archive_le IS NULL
     ORDER BY tp.ordre
  LOOP
    SELECT tp.id INTO cible
      FROM relance.table_phoning tp
     WHERE tp.session_plaque_id = p_session_id AND tp.libelle = t.libelle;
    existait := cible IS NOT NULL;

    IF existait THEN
      UPDATE relance.table_phoning
         SET archive_le = NULL, ordre = t.ordre,
             chef_utilisateur_id = t.chef_utilisateur_id, marque_id = t.marque_id
       WHERE id = cible;
    ELSE
      INSERT INTO relance.table_phoning (session_plaque_id, libelle, ordre, chef_utilisateur_id, marque_id, cree_par)
      VALUES (p_session_id, t.libelle, t.ordre, t.chef_utilisateur_id, t.marque_id, moi)
      RETURNING id INTO cible;
      tables_creees := tables_creees + 1;
    END IF;

    FOR a IN
      SELECT v.id, v.nom, v.site_id
        FROM relance.affectation af
        JOIN relance.vendeur v ON v.id = af.vendeur_id
       WHERE af.table_id = t.id AND af.archive_le IS NULL
    LOOP
      -- ELIGIBILITE : present pendant LA NOUVELLE campagne, et toujours de cette
      -- plaque. Les deux conditions sont verifiees ici EN PLUS du trigger, pour
      -- pouvoir NOMMER ceux qu'on laisse de cote plutot que d'echouer en bloc.
      IF NOT EXISTS (
        SELECT 1
          FROM relance.vendeur vv
          JOIN relance.site s ON s.id = vv.site_id
          JOIN relance.campagne c ON c.id = campagne
         WHERE vv.id = a.id
           AND s.plaque_id = plaque
           AND vv.archive_le IS NULL
           AND (vv.date_entree IS NULL OR vv.date_entree <= c.date_fin)
           AND (vv.date_sortie IS NULL OR vv.date_sortie >= c.date_debut)
      ) THEN
        reportes := reportes || jsonb_build_object(
          'nom', a.nom,
          'raison', 'absent de cette campagne, ou rattache a une autre plaque');
        CONTINUE;
      END IF;

      INSERT INTO relance.affectation (table_id, vendeur_id, origine, cree_par)
      VALUES (cible, a.id, 'manuel', moi)
      ON CONFLICT (table_id, vendeur_id) DO UPDATE SET archive_le = NULL;
      reprises := reprises + 1;
    END LOOP;
  END LOOP;

  RETURN jsonb_build_object(
    'tablesCreees', tables_creees,
    'affectationsReprises', reprises,
    'reportes', reportes
  );
END $$;


--
-- Name: table_archiver(bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.table_archiver(p_table_id bigint) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  session_id bigint;
  libelle text;
  n int;
BEGIN
  SELECT t.session_plaque_id, t.libelle INTO session_id, libelle
    FROM relance.table_phoning t WHERE t.id = p_table_id;
  IF session_id IS NULL THEN
    RAISE EXCEPTION 'RELANCE: table introuvable.';
  END IF;
  PERFORM relance.exiger_session(session_id);

  UPDATE relance.table_phoning SET archive_le = now() WHERE id = p_table_id;
  UPDATE relance.affectation SET archive_le = now()
   WHERE table_id = p_table_id AND archive_le IS NULL;
  GET DIAGNOSTICS n = ROW_COUNT;

  RETURN jsonb_build_object(
    'archivee', libelle,
    'affectationsArchivees', n,
    'sessionId', session_id::text,
    'message', format(
      '« %s » est archivee, pas supprimee : sa composition reste consultable. %s vendeur(s) reviennent en reserve et restent saisissables par leur chef de site.',
      libelle, n)
  );
END $$;


--
-- Name: table_definir_vendeurs(bigint, bigint[]); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.table_definir_vendeurs(p_table_id bigint, p_vendeur_ids bigint[]) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint;
  session_id bigint;
  ids bigint[] := coalesce(p_vendeur_ids, '{}');
  retires int;
  v bigint;
BEGIN
  SELECT t.session_plaque_id INTO session_id
    FROM relance.table_phoning t WHERE t.id = p_table_id AND t.archive_le IS NULL;
  IF session_id IS NULL THEN
    RAISE EXCEPTION 'RELANCE: table introuvable ou archivee.';
  END IF;
  moi := relance.exiger_session(session_id);

  UPDATE relance.affectation SET archive_le = now()
   WHERE table_id = p_table_id AND archive_le IS NULL AND NOT (vendeur_id = ANY (ids));
  GET DIAGNOSTICS retires = ROW_COUNT;

  -- Un a un, et non en bloc : les triggers R-B.1 (meme plaque), R-B.4 (une seule
  -- table par campagne) et R-B.5 (marque de la table) sont `FOR EACH ROW`. Leurs
  -- messages, deja ecrits pour un humain, remontent tels quels a l'appelant.
  FOREACH v IN ARRAY ids LOOP
    INSERT INTO relance.affectation (table_id, vendeur_id, origine, cree_par)
    VALUES (p_table_id, v, 'manuel', moi)
    ON CONFLICT (table_id, vendeur_id)
      DO UPDATE SET archive_le = NULL, origine = 'manuel';
  END LOOP;

  RETURN jsonb_build_object(
    'retires', retires,
    'effectif', coalesce(array_length(ids, 1), 0),
    'sessionId', session_id::text
  );
END $$;


--
-- Name: tracer_creation(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.tracer_creation() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.utilisateur_courant();
BEGIN
  IF moi IS NOT NULL THEN
    NEW.cree_par := moi;
  END IF;
  RETURN NEW;
END $$;


--
-- Name: tracer_modification_rdv(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.tracer_modification_rdv() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.utilisateur_courant();
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF moi IS NOT NULL THEN NEW.cree_par := moi; END IF;
    RETURN NEW;
  END IF;

  IF moi IS NOT NULL THEN
    NEW.modifie_par := moi;
    -- L'ARCHIVAGE EST UN UPDATE, c'est la seule facon de retirer un RDV. On veut
    -- donc savoir qui l'a retire, et pas seulement qui l'a modifie en dernier.
    IF NEW.archive_le IS NOT NULL AND OLD.archive_le IS NULL THEN
      NEW.archive_par := moi;
    END IF;
  END IF;
  NEW.modifie_le := now();

  -- `cree_par` et `cree_le` ne se reecrivent jamais. Sans cette ligne, un client
  -- pourrait se declarer auteur d'un RDV saisi par quelqu'un d'autre en le
  -- modifiant — l'attribution serait alors reecrivable a volonte.
  NEW.cree_par := OLD.cree_par;
  NEW.cree_le := OLD.cree_le;
  RETURN NEW;
END $$;


--
-- Name: utilisateur_courant(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.utilisateur_courant() RETURNS bigint
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
  SELECT u.id
  FROM relance.utilisateur u
  WHERE u.auth_uid = auth.uid()
    AND u.actif
    AND u.archive_le IS NULL
$$;


--
-- Name: utilisateur_definir_encadrement(bigint, text, bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.utilisateur_definir_encadrement(p_site_id bigint, p_role text, p_utilisateur_id bigint DEFAULT NULL::bigint) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_gestion_comptes();
BEGIN
  IF p_role NOT IN ('chef_de_site', 'chef_de_vente_vn', 'chef_de_vente_vo') THEN
    RAISE EXCEPTION 'RELANCE: role invalide : chef_de_site, chef_de_vente_vn ou chef_de_vente_vo.';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM relance.site WHERE id = p_site_id AND archive_le IS NULL) THEN
    RAISE EXCEPTION 'RELANCE: site introuvable ou archive.';
  END IF;

  IF p_utilisateur_id IS NULL THEN
    UPDATE relance.encadrement_site SET archive_le = now()
     WHERE site_id = p_site_id AND role = p_role AND archive_le IS NULL;
    RETURN jsonb_build_object('libere', true, 'siteId', p_site_id::text, 'role', p_role);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM relance.utilisateur
     WHERE id = p_utilisateur_id AND actif AND archive_le IS NULL
  ) THEN
    RAISE EXCEPTION 'RELANCE: ce compte est introuvable ou desactive.';
  END IF;

  -- ON LIBERE LE ROLE AVANT DE LE DONNER. L'unique `(site, role)` refuse deux
  -- titulaires : l'ordre inverse echouerait. Meme piege que sur l'ecran des
  -- encadrants, ou deux requetes lancees en parallele se marchaient dessus.
  UPDATE relance.encadrement_site SET archive_le = now()
   WHERE site_id = p_site_id AND role = p_role AND archive_le IS NULL
     AND utilisateur_id <> p_utilisateur_id;

  INSERT INTO relance.encadrement_site (site_id, role, utilisateur_id, cree_par)
  VALUES (p_site_id, p_role, p_utilisateur_id, moi)
  ON CONFLICT (site_id, role) DO UPDATE
    SET utilisateur_id = EXCLUDED.utilisateur_id, archive_le = NULL;

  RETURN jsonb_build_object('siteId', p_site_id::text, 'role', p_role,
                            'utilisateurId', p_utilisateur_id::text);
END $$;


--
-- Name: utilisateur_definir_roles(bigint, text); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.utilisateur_definir_roles(p_utilisateur_id bigint, p_role text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_gestion_comptes();
  etait_admin boolean;
  autres_admins int;
BEGIN
  IF p_role IS NOT NULL AND p_role NOT IN ('admin', 'direction', 'lecteur') THEN
    RAISE EXCEPTION 'RELANCE: role inconnu : admin, direction ou lecteur.';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM relance.utilisateur WHERE id = p_utilisateur_id) THEN
    RAISE EXCEPTION 'RELANCE: compte introuvable.';
  END IF;

  -- LE DERNIER ADMINISTRATEUR NE PEUT PAS ETRE DEGRADE. Sans ce controle,
  -- l'application devient inadministrable et plus personne ne peut creer de compte
  -- — y compris pour se redonner le role.
  SELECT EXISTS (
    SELECT 1 FROM relance.role_global WHERE utilisateur_id = p_utilisateur_id AND role = 'admin'
  ) INTO etait_admin;

  IF etait_admin AND coalesce(p_role, '') <> 'admin' THEN
    SELECT count(*)::int INTO autres_admins
      FROM relance.role_global rg
      JOIN relance.utilisateur u ON u.id = rg.utilisateur_id
     WHERE rg.role = 'admin' AND rg.utilisateur_id <> p_utilisateur_id
       AND u.actif AND u.archive_le IS NULL;
    IF autres_admins = 0 THEN
      RAISE EXCEPTION 'RELANCE: c''est le dernier administrateur actif : le degrader rendrait l''application inadministrable. Nommer un autre administrateur d''abord.';
    END IF;
  END IF;

  DELETE FROM relance.role_global WHERE utilisateur_id = p_utilisateur_id;
  IF p_role IS NOT NULL THEN
    INSERT INTO relance.role_global (utilisateur_id, role, cree_par)
    VALUES (p_utilisateur_id, p_role, moi);
  END IF;

  RETURN jsonb_build_object('utilisateurId', p_utilisateur_id::text, 'role', to_jsonb(p_role));
END $$;


--
-- Name: utilisateur_purger(bigint, text); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.utilisateur_purger(p_utilisateur_id bigint, p_confirmation text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_gestion_comptes();
  nom_exact text;
  attaches text[] := '{}';
BEGIN
  SELECT u.nom INTO nom_exact FROM relance.utilisateur u WHERE u.id = p_utilisateur_id;
  IF nom_exact IS NULL THEN
    RAISE EXCEPTION 'RELANCE: compte introuvable.';
  END IF;
  IF p_utilisateur_id = moi THEN
    RAISE EXCEPTION 'RELANCE: on ne supprime pas son propre compte.';
  END IF;

  -- CE QUI RETIENT UN COMPTE. Un compte qui explique encore quelque chose —
  -- l'auteur d'une saisie, le chef d'une table passee — n'est pas supprimable :
  -- l'historique deviendrait anonyme. Le desactiver conserve la trace sans donner
  -- aucun acces.
  IF EXISTS (SELECT 1 FROM relance.table_phoning WHERE chef_utilisateur_id = p_utilisateur_id) THEN
    attaches := attaches || 'des tables de phoning';
  END IF;
  IF EXISTS (SELECT 1 FROM relance.rdv WHERE cree_par = p_utilisateur_id OR modifie_par = p_utilisateur_id) THEN
    attaches := attaches || 'des RDV saisis';
  END IF;
  IF EXISTS (SELECT 1 FROM relance.vendeur WHERE utilisateur_id = p_utilisateur_id) THEN
    attaches := attaches || 'une fiche vendeur';
  END IF;
  IF array_length(attaches, 1) IS NOT NULL THEN
    RAISE EXCEPTION 'RELANCE: % ne peut pas etre supprime : son compte explique encore %. Le laisser desactive conserve cette trace sans lui donner aucun acces.',
      nom_exact, array_to_string(attaches, ', ');
  END IF;

  IF p_confirmation IS DISTINCT FROM nom_exact THEN
    RAISE EXCEPTION 'RELANCE: pour supprimer definitivement, retaper le nom exact. Attendu : « % ».', nom_exact;
  END IF;

  -- LA PORTE, ouverte pour cette seule transaction. `SET LOCAL` meurt avec elle :
  -- elle ne peut pas rester ouverte par oubli, et aucune autre session n'est
  -- affectee — contrairement a un `ALTER TABLE ... DISABLE TRIGGER`, qui aurait
  -- desarme le garde-fou pour tout le monde, y compris pendant une saisie.
  PERFORM set_config('relance.purge_autorisee', 'oui', true);
  DELETE FROM relance.encadrement_site WHERE utilisateur_id = p_utilisateur_id;
  DELETE FROM relance.role_global WHERE utilisateur_id = p_utilisateur_id;
  DELETE FROM relance.role_campagne WHERE utilisateur_id = p_utilisateur_id;
  DELETE FROM relance.utilisateur WHERE id = p_utilisateur_id;

  RETURN jsonb_build_object('supprime', nom_exact);
END $$;


--
-- Name: vendeur_appliquer_import_marques(jsonb); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.vendeur_appliquer_import_marques(p_lignes jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_administration();
  l jsonb;
  n int := 0;
  marques bigint[];
BEGIN
  FOR l IN SELECT jsonb_array_elements(coalesce(p_lignes, '[]'::jsonb)) LOOP
    SELECT coalesce(array_agg((m#>>'{}')::bigint), '{}')
      INTO marques
      FROM jsonb_array_elements(coalesce(l->'marqueIds', '[]'::jsonb)) m;

    PERFORM relance.poser_capacites(
      (l->>'vendeurId')::bigint, marques, l->>'typeVehicule', moi);
    n := n + 1;
  END LOOP;

  RETURN jsonb_build_object('appliquees', n);
END $$;


--
-- Name: vendeur_creer(text, bigint, text, bigint[], date); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.vendeur_creer(p_nom text, p_site_id bigint, p_type_vehicule text, p_marque_ids bigint[] DEFAULT '{}'::bigint[], p_date_entree date DEFAULT NULL::date) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_administration();
  nouveau bigint;
  nom text := btrim(coalesce(p_nom, ''));
BEGIN
  IF nom = '' THEN
    RAISE EXCEPTION 'RELANCE: le nom du vendeur est requis.';
  END IF;
  IF p_type_vehicule NOT IN ('VN', 'VO') THEN
    RAISE EXCEPTION 'RELANCE: le metier doit etre VN ou VO.';
  END IF;
  IF p_type_vehicule = 'VN' AND coalesce(array_length(p_marque_ids, 1), 0) = 0 THEN
    RAISE EXCEPTION 'RELANCE: un vendeur VN doit porter au moins une marque, sinon sa grille de saisie serait vide.';
  END IF;

  INSERT INTO relance.vendeur (nom, site_id, type_vehicule, date_entree, cree_par)
  VALUES (nom, p_site_id, p_type_vehicule, p_date_entree, moi)
  RETURNING id INTO nouveau;

  PERFORM relance.poser_capacites(nouveau, p_marque_ids, p_type_vehicule, moi);

  RETURN jsonb_build_object('id', nouveau::text, 'nom', nom);
END $$;


--
-- Name: vendeur_modifier(bigint, text, bigint, date, date, boolean, boolean, text, bigint[]); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.vendeur_modifier(p_vendeur_id bigint, p_nom text DEFAULT NULL::text, p_site_id bigint DEFAULT NULL::bigint, p_date_entree date DEFAULT NULL::date, p_date_sortie date DEFAULT NULL::date, p_archiver boolean DEFAULT NULL::boolean, p_changer_capacites boolean DEFAULT false, p_type_vehicule text DEFAULT NULL::text, p_marque_ids bigint[] DEFAULT NULL::bigint[]) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_administration();
BEGIN
  IF NOT EXISTS (SELECT 1 FROM relance.vendeur WHERE id = p_vendeur_id) THEN
    RAISE EXCEPTION 'RELANCE: vendeur introuvable.';
  END IF;

  UPDATE relance.vendeur
     SET nom = coalesce(btrim(p_nom), nom),
         site_id = coalesce(p_site_id, site_id),
         date_entree = CASE WHEN p_date_entree IS NOT NULL THEN p_date_entree ELSE date_entree END,
         date_sortie = CASE WHEN p_date_sortie IS NOT NULL THEN p_date_sortie ELSE date_sortie END,
         archive_le = CASE
                        WHEN p_archiver IS NULL THEN archive_le
                        WHEN p_archiver THEN coalesce(archive_le, now())
                        ELSE NULL
                      END,
         archive_par = CASE
                         WHEN p_archiver IS TRUE THEN moi
                         WHEN p_archiver IS FALSE THEN NULL
                         ELSE archive_par
                       END
   WHERE id = p_vendeur_id;

  IF p_changer_capacites THEN
    IF p_type_vehicule NOT IN ('VN', 'VO') THEN
      RAISE EXCEPTION 'RELANCE: le metier doit etre VN ou VO.';
    END IF;
    IF p_type_vehicule = 'VN' AND coalesce(array_length(p_marque_ids, 1), 0) = 0 THEN
      RAISE EXCEPTION 'RELANCE: un vendeur VN doit porter au moins une marque.';
    END IF;
    PERFORM relance.poser_capacites(p_vendeur_id, p_marque_ids, p_type_vehicule, moi);
  END IF;

  RETURN jsonb_build_object('id', p_vendeur_id::text);
END $$;


--
-- Name: vendeur_purger(bigint, text); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.vendeur_purger(p_vendeur_id bigint, p_confirmation text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_administration();
  nom_exact text;
  archive timestamptz;
  nb_rdv int;
  nb_aff int;
BEGIN
  SELECT v.nom, v.archive_le INTO nom_exact, archive
    FROM relance.vendeur v WHERE v.id = p_vendeur_id;
  IF nom_exact IS NULL THEN
    RAISE EXCEPTION 'RELANCE: vendeur introuvable.';
  END IF;

  -- DEUX VERROUS, ET LES DEUX COMPTENT. L'archivage prealable oblige a passer par
  -- un geste reversible avant l'irreversible ; retaper le nom empeche de purger
  -- une ligne pour une autre depuis une liste.
  IF archive IS NULL THEN
    RAISE EXCEPTION 'RELANCE: ce vendeur doit d''abord etre archive. La purge ne s''applique qu''a une fiche deja retiree.';
  END IF;
  IF p_confirmation IS DISTINCT FROM nom_exact THEN
    RAISE EXCEPTION 'RELANCE: pour purger definitivement, retaper le nom exact du vendeur. Attendu : « % ».', nom_exact;
  END IF;

  SELECT count(*)::int INTO nb_rdv FROM relance.rdv WHERE vendeur_id = p_vendeur_id;
  SELECT count(*)::int INTO nb_aff FROM relance.affectation WHERE vendeur_id = p_vendeur_id;

  PERFORM set_config('relance.purge_autorisee', 'oui', true);
  DELETE FROM relance.rdv WHERE vendeur_id = p_vendeur_id;
  DELETE FROM relance.affectation WHERE vendeur_id = p_vendeur_id;
  DELETE FROM relance.vendeur_marque WHERE vendeur_id = p_vendeur_id;
  DELETE FROM relance.vendeur WHERE id = p_vendeur_id;

  RETURN jsonb_build_object(
    'purge', nom_exact, 'nbRdv', nb_rdv, 'nbAffectations', nb_aff,
    'message', format(
      '%s est definitivement supprime, avec %s RDV et %s affectation(s). Les totaux des campagnes concernees ont change. C''est irreversible.',
      nom_exact, nb_rdv, nb_aff)
  );
END $$;


--
-- Name: verifier_affectation_marque_table(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_affectation_marque_table() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public'
    AS $$
DECLARE
  marque_table   bigint;
  libelle_marque text;
  libelle_table  text;
  type_vendeur   text;
  nom_vendeur    text;
  autorise       boolean;
BEGIN
  -- Une ligne archivee ne rattache plus personne.
  IF NEW.archive_le IS NOT NULL THEN
    RETURN NEW;
  END IF;

  SELECT t.marque_id, t.libelle INTO marque_table, libelle_table
  FROM table_phoning t WHERE t.id = NEW.table_id;

  -- Table mixte : aucune contrainte. Cas normal.
  IF marque_table IS NULL THEN
    RETURN NEW;
  END IF;

  SELECT v.type_vehicule, v.nom INTO type_vendeur, nom_vendeur
  FROM vendeur v WHERE v.id = NEW.vendeur_id;

  IF type_vendeur IS NULL THEN
    -- Vendeur inexistant : la cle etrangere s'en charge, on ne masque pas son
    -- message par le notre.
    RETURN NEW;
  END IF;

  SELECT m.libelle INTO libelle_marque FROM marque m WHERE m.id = marque_table;

  IF type_vendeur = 'VO' THEN
    RAISE EXCEPTION
      'RELANCE: % est un vendeur VO et n''a aucune ventilation par marque : il ne peut pas rejoindre la table "%", specialisee %.',
      nom_vendeur, libelle_table, libelle_marque;
  END IF;

  SELECT EXISTS (
    SELECT 1 FROM vendeur_marque vm
    WHERE vm.vendeur_id = NEW.vendeur_id AND vm.marque_id = marque_table
  ) INTO autorise;

  IF NOT autorise THEN
    RAISE EXCEPTION
      'RELANCE: % n''est pas autorise a vendre % : il ne peut pas rejoindre la table "%", specialisee sur cette marque.',
      nom_vendeur, libelle_marque, libelle_table;
  END IF;

  RETURN NEW;
END $$;


--
-- Name: verifier_affectation_meme_plaque(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_affectation_meme_plaque() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public'
    AS $$
DECLARE
  plaque_table   bigint;
  plaque_vendeur bigint;
  libelle_table  text;
  nom_vendeur    text;
BEGIN
  -- Une ligne archivee ne rattache plus personne : inutile de la contraindre, et
  -- la contraindre empecherait d'archiver une affectation devenue invalide apres
  -- un changement de plaque d'un site.
  IF NEW.archive_le IS NOT NULL THEN
    RETURN NEW;
  END IF;

  SELECT s.plaque_id, t.libelle
    INTO plaque_table, libelle_table
  FROM table_phoning  t
  JOIN session_plaque s ON s.id = t.session_plaque_id
  WHERE t.id = NEW.table_id;

  SELECT si.plaque_id, v.nom
    INTO plaque_vendeur, nom_vendeur
  FROM vendeur v
  JOIN site si ON si.id = v.site_id
  WHERE v.id = NEW.vendeur_id;

  IF plaque_table IS NULL OR plaque_vendeur IS NULL THEN
    -- Table ou vendeur inexistant : les cles etrangeres s'en chargent, on ne
    -- masque pas leur message par le notre.
    RETURN NEW;
  END IF;

  IF plaque_table <> plaque_vendeur THEN
    RAISE EXCEPTION
      'RELANCE: % appartient a une autre plaque que la table "%". Une table ne peut contenir que des vendeurs de sa propre plaque.',
      nom_vendeur, libelle_table;
  END IF;

  RETURN NEW;
END $$;


--
-- Name: verifier_affectation_unique(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_affectation_unique() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public'
    AS $$
DECLARE
  autre_table text;
BEGIN
  -- Une ligne archivee ne reserve pas la place du vendeur.
  IF NEW.archive_le IS NOT NULL THEN
    RETURN NEW;
  END IF;

  SELECT t_autre.libelle INTO autre_table
  FROM affectation a
  JOIN table_phoning  t_autre ON t_autre.id = a.table_id
  JOIN session_plaque s_autre ON s_autre.id = t_autre.session_plaque_id
  JOIN table_phoning  t_new   ON t_new.id   = NEW.table_id
  JOIN session_plaque s_new   ON s_new.id   = t_new.session_plaque_id
  WHERE a.vendeur_id = NEW.vendeur_id
    AND a.archive_le IS NULL
    -- Cle METIER, pas identite technique : voir l'explication ci-dessus.
    AND a.table_id <> NEW.table_id
    AND s_autre.campagne_id = s_new.campagne_id
  LIMIT 1;

  IF autre_table IS NOT NULL THEN
    RAISE EXCEPTION 'RELANCE: ce vendeur est deja affecte a la table "%" pour cette campagne.', autre_table;
  END IF;

  RETURN NEW;
END $$;


--
-- Name: verifier_campagne_ouverte(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_campagne_ouverte() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public'
    AS $$
DECLARE
  c record;
BEGIN
  SELECT libelle, cloturee, archive_le INTO c
  FROM campagne
  WHERE id = COALESCE(NEW.campagne_id, OLD.campagne_id);

  IF c.cloturee THEN
    RAISE EXCEPTION 'RELANCE: la campagne "%" est cloturee, plus aucune saisie n''est possible.', c.libelle;
  END IF;

  IF c.archive_le IS NOT NULL THEN
    RAISE EXCEPTION 'RELANCE: la campagne "%" est archivee.', c.libelle;
  END IF;

  RETURN COALESCE(NEW, OLD);
END $$;


--
-- Name: verifier_encadrant_actif(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_encadrant_actif() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public'
    AS $$
DECLARE
  nom_compte text;
  compte_actif boolean;
  compte_archive timestamptz;
BEGIN
  IF NEW.archive_le IS NOT NULL THEN
    RETURN NEW;
  END IF;

  SELECT u.nom, u.actif, u.archive_le
    INTO nom_compte, compte_actif, compte_archive
  FROM utilisateur u WHERE u.id = NEW.utilisateur_id;

  IF nom_compte IS NULL THEN
    RETURN NEW; -- la cle etrangere s'en charge
  END IF;

  IF NOT compte_actif OR compte_archive IS NOT NULL THEN
    RAISE EXCEPTION
      'RELANCE: le compte de % est desactive : il ne peut pas encadrer un site. Le reactiver dans la gestion des comptes.',
      nom_compte;
  END IF;

  RETURN NEW;
END $$;


--
-- Name: verifier_marque_autorisee(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_marque_autorisee() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public'
    AS $$
DECLARE
  nom_vendeur text;
  nom_marque  text;
BEGIN
  IF NEW.marque_id IS NULL THEN
    RETURN NEW;
  END IF;

  IF EXISTS (
    SELECT 1 FROM vendeur_marque vm
    WHERE vm.vendeur_id = NEW.vendeur_id AND vm.marque_id = NEW.marque_id
  ) THEN
    RETURN NEW;
  END IF;

  SELECT v.nom INTO nom_vendeur FROM vendeur v WHERE v.id = NEW.vendeur_id;
  SELECT m.libelle INTO nom_marque FROM marque  m WHERE m.id = NEW.marque_id;

  RAISE EXCEPTION 'RELANCE: % n''est pas autorise a vendre %.',
    COALESCE(nom_vendeur, 'ce vendeur'), COALESCE(nom_marque, 'cette marque');
END $$;


--
-- Name: verifier_marque_selon_metier(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_marque_selon_metier() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public'
    AS $$
DECLARE
  v record;
BEGIN
  SELECT nom, type_vehicule INTO v FROM vendeur WHERE id = NEW.vendeur_id;

  IF v.type_vehicule = 'VO' AND NEW.marque_id IS NOT NULL THEN
    RAISE EXCEPTION 'RELANCE: % est un vendeur VO, ses RDV ne portent pas de marque.', v.nom;
  END IF;

  IF v.type_vehicule = 'VN' AND NEW.marque_id IS NULL THEN
    RAISE EXCEPTION 'RELANCE: % est un vendeur VN, la marque du RDV est obligatoire.', v.nom;
  END IF;

  RETURN NEW;
END $$;


--
-- Name: verifier_type_coherent(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_type_coherent() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public'
    AS $$
DECLARE
  v record;
BEGIN
  SELECT nom, type_vehicule INTO v FROM vendeur WHERE id = NEW.vendeur_id;

  IF v.type_vehicule <> NEW.type_vehicule THEN
    RAISE EXCEPTION 'RELANCE: % est un vendeur %, il ne peut pas recevoir un RDV %.',
      v.nom, v.type_vehicule, NEW.type_vehicule;
  END IF;

  RETURN NEW;
END $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: affectation; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.affectation (
    id bigint NOT NULL,
    table_id bigint NOT NULL,
    vendeur_id bigint NOT NULL,
    origine text DEFAULT 'manuel'::text NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone,
    CONSTRAINT affectation_origine_check CHECK ((origine = ANY (ARRAY['auto'::text, 'manuel'::text])))
);


--
-- Name: affectation_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.affectation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: affectation_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.affectation_id_seq OWNED BY relance.affectation.id;


--
-- Name: campagne; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.campagne (
    id bigint NOT NULL,
    libelle text NOT NULL,
    date_debut date NOT NULL,
    date_fin date NOT NULL,
    cloturee boolean DEFAULT false NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone,
    CONSTRAINT campagne_dates_coherentes_check CHECK ((date_fin >= date_debut))
);


--
-- Name: campagne_creneau; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.campagne_creneau (
    campagne_id bigint NOT NULL,
    code text NOT NULL,
    libelle text NOT NULL,
    ordre integer NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint
);


--
-- Name: campagne_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.campagne_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: campagne_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.campagne_id_seq OWNED BY relance.campagne.id;


--
-- Name: campagne_jour; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.campagne_jour (
    campagne_id bigint NOT NULL,
    jour date NOT NULL,
    ordre integer NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint
);


--
-- Name: encadrement_site; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.encadrement_site (
    id bigint NOT NULL,
    site_id bigint NOT NULL,
    role text NOT NULL,
    utilisateur_id bigint NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT now() NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone,
    CONSTRAINT encadrement_site_role_check CHECK ((role = ANY (ARRAY['chef_de_site'::text, 'chef_de_vente_vn'::text, 'chef_de_vente_vo'::text])))
);


--
-- Name: encadrement_site_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.encadrement_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: encadrement_site_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.encadrement_site_id_seq OWNED BY relance.encadrement_site.id;


--
-- Name: marque; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.marque (
    id bigint NOT NULL,
    code text NOT NULL,
    libelle text NOT NULL,
    ordre integer DEFAULT 0 NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone
);


--
-- Name: marque_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.marque_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: marque_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.marque_id_seq OWNED BY relance.marque.id;


--
-- Name: role_campagne; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.role_campagne (
    id bigint NOT NULL,
    campagne_id bigint NOT NULL,
    utilisateur_id bigint NOT NULL,
    role text NOT NULL,
    plaque_id bigint,
    site_id bigint,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone,
    CONSTRAINT role_campagne_portee_check CHECK ((((role = 'chef_plaque'::text) AND (plaque_id IS NOT NULL) AND (site_id IS NULL)) OR ((role = 'chef_site'::text) AND (site_id IS NOT NULL) AND (plaque_id IS NULL)))),
    CONSTRAINT role_campagne_role_check CHECK ((role = ANY (ARRAY['chef_plaque'::text, 'chef_site'::text])))
);


--
-- Name: session_plaque; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.session_plaque (
    id bigint NOT NULL,
    campagne_id bigint NOT NULL,
    plaque_id bigint NOT NULL,
    mode text DEFAULT 'par_site'::text NOT NULL,
    effectif_cible_table integer,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone,
    CONSTRAINT session_plaque_mode_check CHECK ((mode = ANY (ARRAY['par_site'::text, 'par_table'::text])))
);


--
-- Name: site; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.site (
    id bigint NOT NULL,
    code text NOT NULL,
    libelle text NOT NULL,
    plaque_id bigint NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone
);


--
-- Name: table_phoning; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.table_phoning (
    id bigint NOT NULL,
    session_plaque_id bigint NOT NULL,
    libelle text NOT NULL,
    chef_utilisateur_id bigint,
    ordre integer DEFAULT 0 NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone,
    marque_id bigint
);


--
-- Name: vendeur; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.vendeur (
    id bigint NOT NULL,
    nom text NOT NULL,
    site_id bigint NOT NULL,
    utilisateur_id bigint,
    date_entree date,
    date_sortie date,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    capacites_confirmees_le timestamp(6) with time zone,
    capacites_confirmees_par bigint,
    type_vehicule text NOT NULL,
    archive_le timestamp(6) with time zone,
    archive_par bigint,
    CONSTRAINT vendeur_dates_coherentes_check CHECK (((date_sortie IS NULL) OR (date_entree IS NULL) OR (date_sortie >= date_entree))),
    CONSTRAINT vendeur_type_check CHECK ((type_vehicule = ANY (ARRAY['VN'::text, 'VO'::text])))
);


--
-- Name: perimetre_saisie; Type: VIEW; Schema: relance; Owner: -
--

CREATE VIEW relance.perimetre_saisie AS
 SELECT c.id AS campagne_id,
    v.id AS vendeur_id
   FROM (relance.campagne c
     CROSS JOIN relance.vendeur v)
  WHERE ((relance.utilisateur_courant() IS NOT NULL) AND (v.archive_le IS NULL) AND ((v.date_entree IS NULL) OR (v.date_entree <= c.date_fin)) AND ((v.date_sortie IS NULL) OR (v.date_sortie >= c.date_debut)) AND (relance.peut_administrer() OR (EXISTS ( SELECT 1
           FROM (relance.role_campagne rc
             JOIN relance.site s ON ((s.id = v.site_id)))
          WHERE ((rc.utilisateur_id = relance.utilisateur_courant()) AND (rc.campagne_id = c.id) AND (rc.role = 'chef_plaque'::text) AND (rc.plaque_id = s.plaque_id) AND (rc.archive_le IS NULL)))) OR (EXISTS ( SELECT 1
           FROM relance.role_campagne rc
          WHERE ((rc.utilisateur_id = relance.utilisateur_courant()) AND (rc.campagne_id = c.id) AND (rc.role = 'chef_site'::text) AND (rc.site_id = v.site_id) AND (rc.archive_le IS NULL)))) OR (EXISTS ( SELECT 1
           FROM relance.encadrement_site es
          WHERE ((es.utilisateur_id = relance.utilisateur_courant()) AND (es.site_id = v.site_id) AND (es.archive_le IS NULL)))) OR (EXISTS ( SELECT 1
           FROM ((relance.affectation a
             JOIN relance.table_phoning t ON ((t.id = a.table_id)))
             JOIN relance.session_plaque sp ON ((sp.id = t.session_plaque_id)))
          WHERE ((a.vendeur_id = v.id) AND (a.archive_le IS NULL) AND (t.archive_le IS NULL) AND (t.chef_utilisateur_id = relance.utilisateur_courant()) AND (sp.campagne_id = c.id) AND (sp.archive_le IS NULL))))));


--
-- Name: plaque; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.plaque (
    id bigint NOT NULL,
    libelle text NOT NULL,
    alias text,
    ordre integer DEFAULT 0 NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone
);


--
-- Name: plaque_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.plaque_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: plaque_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.plaque_id_seq OWNED BY relance.plaque.id;


--
-- Name: rdv; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.rdv (
    id bigint NOT NULL,
    campagne_id bigint NOT NULL,
    vendeur_id bigint NOT NULL,
    jour date NOT NULL,
    creneau_code text NOT NULL,
    marque_id bigint,
    type_vehicule text NOT NULL,
    client text NOT NULL,
    commentaire text,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    modifie_le timestamp(6) with time zone,
    modifie_par bigint,
    archive_le timestamp(6) with time zone,
    archive_par bigint,
    CONSTRAINT rdv_client_non_vide_check CHECK ((length(btrim(client)) > 0)),
    CONSTRAINT rdv_type_vehicule_check CHECK ((type_vehicule = ANY (ARRAY['VN'::text, 'VO'::text])))
);


--
-- Name: rdv_agrege; Type: VIEW; Schema: relance; Owner: -
--

CREATE VIEW relance.rdv_agrege AS
 SELECT id,
    campagne_id,
    vendeur_id,
    jour,
    creneau_code,
    marque_id,
    type_vehicule,
    cree_le,
    archive_le
   FROM relance.rdv r
  WHERE (relance.utilisateur_courant() IS NOT NULL);


--
-- Name: rdv_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.rdv_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rdv_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.rdv_id_seq OWNED BY relance.rdv.id;


--
-- Name: role_campagne_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.role_campagne_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: role_campagne_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.role_campagne_id_seq OWNED BY relance.role_campagne.id;


--
-- Name: role_global; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.role_global (
    utilisateur_id bigint NOT NULL,
    role text NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    CONSTRAINT role_global_role_check CHECK ((role = ANY (ARRAY['admin'::text, 'direction'::text, 'lecteur'::text])))
);


--
-- Name: session_plaque_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.session_plaque_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: session_plaque_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.session_plaque_id_seq OWNED BY relance.session_plaque.id;


--
-- Name: site_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: site_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.site_id_seq OWNED BY relance.site.id;


--
-- Name: table_phoning_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.table_phoning_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: table_phoning_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.table_phoning_id_seq OWNED BY relance.table_phoning.id;


--
-- Name: utilisateur; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.utilisateur (
    id bigint NOT NULL,
    login_id text NOT NULL,
    password_hash text NOT NULL,
    nom text NOT NULL,
    actif boolean DEFAULT true NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone,
    auth_uid uuid
);


--
-- Name: COLUMN utilisateur.auth_uid; Type: COMMENT; Schema: relance; Owner: -
--

COMMENT ON COLUMN relance.utilisateur.auth_uid IS 'Identifiant Supabase Auth (auth.users.id). NULL tant que le compte n''a pas ete relie. Aucune FK : voir la migration 20260831200000.';


--
-- Name: utilisateur_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.utilisateur_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: utilisateur_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.utilisateur_id_seq OWNED BY relance.utilisateur.id;


--
-- Name: vendeur_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.vendeur_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vendeur_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.vendeur_id_seq OWNED BY relance.vendeur.id;


--
-- Name: vendeur_marque; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.vendeur_marque (
    vendeur_id bigint NOT NULL,
    marque_id bigint NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint
);


--
-- Name: affectation id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.affectation ALTER COLUMN id SET DEFAULT nextval('relance.affectation_id_seq'::regclass);


--
-- Name: campagne id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.campagne ALTER COLUMN id SET DEFAULT nextval('relance.campagne_id_seq'::regclass);


--
-- Name: encadrement_site id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.encadrement_site ALTER COLUMN id SET DEFAULT nextval('relance.encadrement_site_id_seq'::regclass);


--
-- Name: marque id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.marque ALTER COLUMN id SET DEFAULT nextval('relance.marque_id_seq'::regclass);


--
-- Name: plaque id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.plaque ALTER COLUMN id SET DEFAULT nextval('relance.plaque_id_seq'::regclass);


--
-- Name: rdv id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.rdv ALTER COLUMN id SET DEFAULT nextval('relance.rdv_id_seq'::regclass);


--
-- Name: role_campagne id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.role_campagne ALTER COLUMN id SET DEFAULT nextval('relance.role_campagne_id_seq'::regclass);


--
-- Name: session_plaque id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.session_plaque ALTER COLUMN id SET DEFAULT nextval('relance.session_plaque_id_seq'::regclass);


--
-- Name: site id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.site ALTER COLUMN id SET DEFAULT nextval('relance.site_id_seq'::regclass);


--
-- Name: table_phoning id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.table_phoning ALTER COLUMN id SET DEFAULT nextval('relance.table_phoning_id_seq'::regclass);


--
-- Name: utilisateur id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.utilisateur ALTER COLUMN id SET DEFAULT nextval('relance.utilisateur_id_seq'::regclass);


--
-- Name: vendeur id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.vendeur ALTER COLUMN id SET DEFAULT nextval('relance.vendeur_id_seq'::regclass);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
034c6337-8f5f-4cc4-bb2c-b0a47266601f	f91fef5197f9ce6f31beb50a6c1cd616ff2e1a0658fcec8952e970f903516ff6	2026-08-31 20:48:17.187601+00	20260828083906_init	\N	\N	2026-08-31 20:48:16.84487+00	1
7e21ca07-0a16-4b73-8f43-e2627375601e	a8435a7dd2f4a6ec9ab7caded693d28463f28a31374df732081b7270e75b5706	2026-08-31 20:48:22.175806+00	20260831201000_rls_portail	\N	\N	2026-08-31 20:48:21.816726+00	1
21ebccf8-3bd5-49c5-a141-e839326a990e	726e168a5281c8963e0ee703fcc9262701c3834d78357c29f95d8147be34a65b	2026-08-31 20:48:17.518104+00	20260828084443_table_phoning_unique	\N	\N	2026-08-31 20:48:17.276477+00	1
f7dd0868-33b8-43e0-a180-6bfa509c20ad	79aafe37634a24daf6351b054e78b9db3cd0d5a7121660e598caedb5aa03240b	2026-08-31 20:48:17.855516+00	20260828084642_marque_code_unique	\N	\N	2026-08-31 20:48:17.608949+00	1
99eae4f4-3ee6-4891-9cfc-18e509016f89	e7873192844e9ad922fdf6d70142b21984b587780f0b30bd7452ea807202651c	2026-08-31 20:48:18.340105+00	20260828090000_invariants	\N	\N	2026-08-31 20:48:17.982293+00	1
d85e8a26-c0b2-465b-be9a-0a0d4cfa03fc	bb7aa8e6c7e08b6ed80c3b0a89ba1a792cc8e9549373777c8e46ce2ddb51f729	2026-08-31 20:48:22.501309+00	20260831202000_triggers_hors_rls	\N	\N	2026-08-31 20:48:22.270654+00	1
a0a1e28b-b64d-4354-ba11-12bef5adf224	48b9288ceed6ca51d370a90c74acda08e77d832ac1014e71eb8bbc6e1f1e6e47	2026-08-31 20:48:18.696869+00	20260828091000_fix_affectation_unique	\N	\N	2026-08-31 20:48:18.452815+00	1
3b5dc4f8-e316-451a-ab05-b74573b23408	08c5fe8ea9d6cb607235f8a64e26fab12d280d0621d17e30d87edd3560417e92	2026-08-31 20:48:19.040117+00	20260828092952_marques_confirmees	\N	\N	2026-08-31 20:48:18.792129+00	1
9a7d8fbc-e799-4c8c-a7f3-29e7633c32ff	4ef1fe153c9bd997429985c5a63f1dae534f2c907fb975cefd10ff2bb9fca77a	2026-08-31 20:48:19.476783+00	20260828121219_vendeur_types_vehicule	\N	\N	2026-08-31 20:48:19.153909+00	1
5eb12b05-cf20-4f66-a0e5-3d9319656d4b	35f523c5ed80dc674eec7bcf015877273434687ab542191724d90c43c3ddaf03	2026-08-31 20:48:22.873781+00	20260831203000_rdv_agrege_compte_actif	\N	\N	2026-08-31 20:48:22.603913+00	1
5b310058-b12b-4151-9848-f467b0bcafbe	906125bc6e4ff14a63a707496d670e8c52ee5eef41be21ee430980b6862d7cfb	2026-08-31 20:48:19.883913+00	20260828140000_vendeur_type_scalaire	\N	\N	2026-08-31 20:48:19.603046+00	1
687baad8-4669-4546-aea8-74e8e6866700	6782c4a8e1c582798e7ab8ef8657cd69725ef1a7e2496aa33025895cdd5a3e05	2026-08-31 20:48:20.230605+00	20260828160000_affectation_meme_plaque	\N	\N	2026-08-31 20:48:19.961444+00	1
0b998f60-c78e-47a9-9aea-01e5f0bc24bf	b246a47f533735c55fe3f82fda03bbb0e51ca7e1b2b07d49edd908da7cbbebaa	2026-08-31 20:48:20.594508+00	20260831090000_table_specialisation	\N	\N	2026-08-31 20:48:20.335715+00	1
4fa87ad9-c2fd-4986-8536-7a85f67d65f2	1324cfd0f87dd0599a85c63ba2621853cae0fd29a20500bbc1897ff832abfc1b	2026-08-31 21:08:48.58242+00	20260831210000_rpc_privilegies	\N	\N	2026-08-31 21:08:48.148814+00	1
5ecabbc8-906f-4025-b3d0-51143e3ce56e	b9bc25688197a550d562cefbe3f58cb46e4db8861bbe30070e99ecd933798be0	2026-08-31 20:48:20.995261+00	20260831140000_encadrement_et_purge	\N	\N	2026-08-31 20:48:20.702141+00	1
0b9543be-ee5c-424b-8618-f760e5afb69d	4b915a14c0e99774f99d3cd91e3a544cf77db6fb37b171ace4ff3a2edd22c211	2026-08-31 20:48:21.387548+00	20260831180000_encadrants_comptes	\N	\N	2026-08-31 20:48:21.093345+00	1
a4cbbf19-ca40-438e-98ae-cba138c30915	80d560b4b705f634e6e539b55f834fa8300025c544398a9720839e5fe8a9c530	2026-08-31 20:48:21.71838+00	20260831200000_auth_uid	\N	\N	2026-08-31 20:48:21.486458+00	1
af3ddc2b-6923-4c38-a2d4-2443cae856c0	ed8b975bc704873bf4b3afc146e4176f398a2ead2d3a7c65cf59e167cd9349c6	2026-08-31 21:42:17.980581+00	20260831220000_diffusion_realtime	\N	\N	2026-08-31 21:42:17.649765+00	1
6e95a6cc-d076-49dd-95a6-4e6f2af3e834	cd06454f8dc43f8dac50b3c8220beeb492691d374f495b107fbdffae4758b6fa	2026-08-31 21:59:32.501785+00	20260831230000_canal_sans_deux_points	\N	\N	2026-08-31 21:59:32.192017+00	1
28aa5e09-b1e9-4c3b-a2c5-a56dc0f1e2d8	8d88252bc75fa3bc6ebb0954d538d4d65d23f7f2527b092ac6f89390f533fd2e	2026-08-31 22:35:04.542758+00	20260901090000_droits_service_role	\N	\N	2026-08-31 22:35:04.201542+00	1
\.


--
-- Data for Name: affectation; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.affectation (id, table_id, vendeur_id, origine, cree_le, cree_par, archive_le) FROM stdin;
1	1	20	manuel	2026-08-31 20:50:22.754+00	\N	\N
2	1	21	manuel	2026-08-31 20:50:22.841+00	\N	\N
3	1	10	manuel	2026-08-31 20:50:22.891+00	\N	\N
4	1	11	manuel	2026-08-31 20:50:22.931+00	\N	\N
5	1	27	manuel	2026-08-31 20:50:22.966+00	\N	\N
6	1	5	manuel	2026-08-31 20:50:23.066+00	\N	\N
7	2	25	manuel	2026-08-31 20:50:23.103+00	\N	\N
8	2	22	manuel	2026-08-31 20:50:23.146+00	\N	\N
9	2	29	manuel	2026-08-31 20:50:23.182+00	\N	\N
10	2	15	manuel	2026-08-31 20:50:23.224+00	\N	\N
11	2	3	manuel	2026-08-31 20:50:23.27+00	\N	\N
12	2	4	manuel	2026-08-31 20:50:23.32+00	\N	\N
13	3	13	manuel	2026-08-31 20:50:23.362+00	\N	\N
14	3	23	manuel	2026-08-31 20:50:23.421+00	\N	\N
15	3	16	manuel	2026-08-31 20:50:23.47+00	\N	\N
16	3	17	manuel	2026-08-31 20:50:23.523+00	\N	\N
17	3	26	manuel	2026-08-31 20:50:23.602+00	\N	\N
18	3	30	manuel	2026-08-31 20:50:23.671+00	\N	\N
19	4	24	manuel	2026-08-31 20:50:23.725+00	\N	\N
20	4	12	manuel	2026-08-31 20:50:23.775+00	\N	\N
21	4	18	manuel	2026-08-31 20:50:23.824+00	\N	\N
22	4	2	manuel	2026-08-31 20:50:23.881+00	\N	\N
23	4	6	manuel	2026-08-31 20:50:23.92+00	\N	\N
24	4	7	manuel	2026-08-31 20:50:23.98+00	\N	\N
25	5	28	manuel	2026-08-31 20:50:24.017+00	\N	\N
26	5	8	manuel	2026-08-31 20:50:24.061+00	\N	\N
27	5	9	manuel	2026-08-31 20:50:24.102+00	\N	\N
28	5	1	manuel	2026-08-31 20:50:24.162+00	\N	\N
29	5	19	manuel	2026-08-31 20:50:24.295+00	\N	\N
30	5	14	manuel	2026-08-31 20:50:24.34+00	\N	\N
31	6	62	manuel	2026-08-31 20:50:24.383+00	\N	\N
32	6	60	manuel	2026-08-31 20:50:24.444+00	\N	\N
33	6	57	manuel	2026-08-31 20:50:24.5+00	\N	\N
34	6	54	manuel	2026-08-31 20:50:24.54+00	\N	\N
35	6	68	manuel	2026-08-31 20:50:24.583+00	\N	\N
36	6	65	manuel	2026-08-31 20:50:24.628+00	\N	\N
37	7	55	manuel	2026-08-31 20:50:24.674+00	\N	\N
38	7	56	manuel	2026-08-31 20:50:24.723+00	\N	\N
39	7	66	manuel	2026-08-31 20:50:24.782+00	\N	\N
40	7	67	manuel	2026-08-31 20:50:24.84+00	\N	\N
41	7	61	manuel	2026-08-31 20:50:24.885+00	\N	\N
42	7	70	manuel	2026-08-31 20:50:24.943+00	\N	\N
43	8	53	manuel	2026-08-31 20:50:24.99+00	\N	\N
44	8	58	manuel	2026-08-31 20:50:25.031+00	\N	\N
45	8	59	manuel	2026-08-31 20:50:25.089+00	\N	\N
46	8	69	manuel	2026-08-31 20:50:25.127+00	\N	\N
47	8	63	manuel	2026-08-31 20:50:25.168+00	\N	\N
48	8	64	manuel	2026-08-31 20:50:25.247+00	\N	\N
\.


--
-- Data for Name: campagne; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.campagne (id, libelle, date_debut, date_fin, cloturee, cree_le, cree_par, archive_le) FROM stdin;
1	Juin 2026	2026-06-11	2026-06-15	f	2026-08-31 20:50:17.444+00	\N	\N
2	Septembre 2026	2026-09-10	2026-09-14	f	2026-08-31 20:50:19.52+00	\N	\N
\.


--
-- Data for Name: campagne_creneau; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.campagne_creneau (campagne_id, code, libelle, ordre, cree_le, cree_par) FROM stdin;
1	08:00-09:00	8h-9h	1	2026-08-31 20:50:17.821+00	\N
1	09:00-10:00	9h-10h	2	2026-08-31 20:50:17.921+00	\N
1	10:00-11:00	10h-11h	3	2026-08-31 20:50:17.96+00	\N
1	11:00-12:00	11h-12h	4	2026-08-31 20:50:18.014+00	\N
1	12:00-13:00	12h-13h	5	2026-08-31 20:50:18.058+00	\N
1	13:00-14:00	13h-14h	6	2026-08-31 20:50:18.099+00	\N
1	14:00-15:00	14h-15h	7	2026-08-31 20:50:18.149+00	\N
1	15:00-16:00	15h-16h	8	2026-08-31 20:50:18.19+00	\N
1	16:00-17:00	16h-17h	9	2026-08-31 20:50:18.23+00	\N
1	17:00-18:00	17h-18h	10	2026-08-31 20:50:18.273+00	\N
1	18:00-19:00	18h-19h	11	2026-08-31 20:50:18.323+00	\N
2	08:00-09:00	8h-9h	1	2026-08-31 20:50:19.849+00	\N
2	09:00-10:00	9h-10h	2	2026-08-31 20:50:19.889+00	\N
2	10:00-11:00	10h-11h	3	2026-08-31 20:50:19.934+00	\N
2	11:00-12:00	11h-12h	4	2026-08-31 20:50:19.987+00	\N
2	12:00-13:00	12h-13h	5	2026-08-31 20:50:20.044+00	\N
2	13:00-14:00	13h-14h	6	2026-08-31 20:50:20.085+00	\N
2	14:00-15:00	14h-15h	7	2026-08-31 20:50:20.161+00	\N
2	15:00-16:00	15h-16h	8	2026-08-31 20:50:20.199+00	\N
2	16:00-17:00	16h-17h	9	2026-08-31 20:50:20.243+00	\N
2	17:00-18:00	17h-18h	10	2026-08-31 20:50:20.284+00	\N
2	18:00-19:00	18h-19h	11	2026-08-31 20:50:20.408+00	\N
\.


--
-- Data for Name: campagne_jour; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.campagne_jour (campagne_id, jour, ordre, cree_le, cree_par) FROM stdin;
1	2026-06-11	1	2026-08-31 20:50:17.546+00	\N
1	2026-06-12	2	2026-08-31 20:50:17.644+00	\N
1	2026-06-13	3	2026-08-31 20:50:17.691+00	\N
1	2026-06-14	4	2026-08-31 20:50:17.737+00	\N
1	2026-06-15	5	2026-08-31 20:50:17.78+00	\N
2	2026-09-10	1	2026-08-31 20:50:19.56+00	\N
2	2026-09-11	2	2026-08-31 20:50:19.607+00	\N
2	2026-09-12	3	2026-08-31 20:50:19.649+00	\N
2	2026-09-13	4	2026-08-31 20:50:19.713+00	\N
2	2026-09-14	5	2026-08-31 20:50:19.779+00	\N
\.


--
-- Data for Name: encadrement_site; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.encadrement_site (id, site_id, role, utilisateur_id, cree_le, cree_par, archive_le) FROM stdin;
34	3	chef_de_site	12	2026-08-31 20:53:17.946+00	\N	\N
35	2	chef_de_vente_vn	12	2026-08-31 20:53:18.168+00	\N	\N
\.


--
-- Data for Name: marque; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.marque (id, code, libelle, ordre, cree_le, cree_par, archive_le) FROM stdin;
1	RENAULT	Renault	1	2026-08-31 20:49:25.026+00	\N	\N
2	DACIA	Dacia	2	2026-08-31 20:49:25.128+00	\N	\N
3	ALPINE	Alpine	3	2026-08-31 20:49:25.174+00	\N	\N
\.


--
-- Data for Name: plaque; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.plaque (id, libelle, alias, ordre, cree_le, cree_par, archive_le) FROM stdin;
1	CENTRE	EAA	1	2026-08-31 20:49:25.236+00	\N	\N
2	NORD	\N	2	2026-08-31 20:49:25.332+00	\N	\N
3	SUD	\N	3	2026-08-31 20:49:25.371+00	\N	\N
4	SUD-OUEST	\N	4	2026-08-31 20:49:25.41+00	\N	\N
\.


--
-- Data for Name: rdv; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.rdv (id, campagne_id, vendeur_id, jour, creneau_code, marque_id, type_vehicule, client, commentaire, cree_le, cree_par, modifie_le, modifie_par, archive_le, archive_par) FROM stdin;
161	2	3	2026-09-10	08:00-09:00	1	VN	CONTROLE NAVIGATEURSAISIE ECRAN	\N	2026-08-31 21:50:44.921383+00	12	2026-08-31 22:00:23.239731+00	12	2026-08-31 22:00:22.212+00	\N
162	2	3	2026-09-10	09:00-10:00	1	VN	CLIENT DEPUIS LA GRILLE	\N	2026-08-31 21:51:54.608775+00	12	2026-08-31 22:00:23.239731+00	\N	2026-08-31 22:00:22.212+00	\N
194	2	1	2026-09-10	18:00-19:00	1	VN	DEPUIS LE TERMINAL	\N	2026-08-31 22:00:00.426+00	\N	2026-08-31 22:00:23.239731+00	\N	2026-08-31 22:00:22.212+00	\N
\.


--
-- Data for Name: role_campagne; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.role_campagne (id, campagne_id, utilisateur_id, role, plaque_id, site_id, cree_le, cree_par, archive_le) FROM stdin;
4	2	13	chef_plaque	1	\N	2026-08-31 20:53:19.106+00	\N	\N
5	2	14	chef_site	\N	3	2026-08-31 20:53:19.987+00	\N	\N
\.


--
-- Data for Name: role_global; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.role_global (utilisateur_id, role, cree_le, cree_par) FROM stdin;
1	admin	2026-08-31 20:50:15.137+00	\N
10	admin	2026-08-31 20:53:15.78+00	\N
11	direction	2026-08-31 20:53:17.147+00	\N
\.


--
-- Data for Name: session_plaque; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.session_plaque (id, campagne_id, plaque_id, mode, effectif_cible_table, cree_le, cree_par, archive_le) FROM stdin;
1	1	1	par_table	6	2026-08-31 20:50:18.397+00	\N	\N
2	1	2	par_site	\N	2026-08-31 20:50:18.808+00	\N	\N
3	1	3	par_table	6	2026-08-31 20:50:19.045+00	\N	\N
4	1	4	par_site	\N	2026-08-31 20:50:19.279+00	\N	\N
5	2	1	par_table	6	2026-08-31 20:50:20.458+00	\N	\N
6	2	2	par_site	\N	2026-08-31 20:50:20.716+00	\N	\N
7	2	3	par_table	6	2026-08-31 20:50:21.29+00	\N	\N
8	2	4	par_site	\N	2026-08-31 20:50:21.539+00	\N	\N
\.


--
-- Data for Name: site; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.site (id, code, libelle, plaque_id, cree_le, cree_par, archive_le) FROM stdin;
1	MASS	Massagettes	1	2026-08-31 20:49:25.453+00	\N	\N
2	MOZ	Mozac	1	2026-08-31 20:49:25.569+00	\N	\N
3	CLF	Clermont-Ferrand	1	2026-08-31 20:49:25.61+00	\N	\N
4	USS	Ussel	1	2026-08-31 20:49:25.658+00	\N	\N
5	ALPINE	Alpine	1	2026-08-31 20:49:25.702+00	\N	\N
6	VI	Vichy	2	2026-08-31 20:49:25.745+00	\N	\N
7	MOU	Moulins	2	2026-08-31 20:49:25.793+00	\N	\N
8	TH	Thiers	2	2026-08-31 20:49:25.83+00	\N	\N
9	PUY	Le Puy	3	2026-08-31 20:49:25.871+00	\N	\N
10	MEN	Mende	3	2026-08-31 20:49:25.942+00	\N	\N
11	ISS	Issoire	3	2026-08-31 20:49:25.992+00	\N	\N
12	GAILL	Gaillac	4	2026-08-31 20:49:26.025+00	\N	\N
13	ALBI	Albi	4	2026-08-31 20:49:26.066+00	\N	\N
14	RDZ	Rodez	4	2026-08-31 20:49:26.11+00	\N	\N
15	MILL	Millau	4	2026-08-31 20:49:26.149+00	\N	\N
16	FIGEAC	Figeac	4	2026-08-31 20:49:26.19+00	\N	\N
17	AUR	Aurillac	4	2026-08-31 20:49:26.232+00	\N	\N
18	VDR	Villefranche	4	2026-08-31 20:49:26.28+00	\N	\N
19	CARM	Carmaux	4	2026-08-31 20:49:26.33+00	\N	\N
\.


--
-- Data for Name: table_phoning; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.table_phoning (id, session_plaque_id, libelle, chef_utilisateur_id, ordre, cree_le, cree_par, archive_le, marque_id) FROM stdin;
1	1	Table 1	2	1	2026-08-31 20:50:21.882+00	\N	\N	\N
2	1	Table 2	3	2	2026-08-31 20:50:22.039+00	\N	\N	\N
3	1	Table 3	4	3	2026-08-31 20:50:22.124+00	\N	\N	\N
4	1	Table 4	5	4	2026-08-31 20:50:22.226+00	\N	\N	\N
5	1	Table 5	6	5	2026-08-31 20:50:22.346+00	\N	\N	\N
6	3	Table 1	7	1	2026-08-31 20:50:22.461+00	\N	\N	\N
7	3	Table 2	8	2	2026-08-31 20:50:22.59+00	\N	\N	\N
8	3	Table 3	9	3	2026-08-31 20:50:22.709+00	\N	\N	\N
\.


--
-- Data for Name: utilisateur; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.utilisateur (id, login_id, password_hash, nom, actif, cree_le, cree_par, archive_le, auth_uid) FROM stdin;
1	admin	$2b$10$jf1LfAOZSMgiQLYsVflYL.q0dRv8ocSlzR9ZpBjoTQNojIXHN9CJa	Administrateur	t	2026-08-31 20:50:14.806+00	\N	\N	2e6f4109-a9ae-4975-9077-757592869249
10	admin.test	$2b$10$jf1LfAOZSMgiQLYsVflYL.q0dRv8ocSlzR9ZpBjoTQNojIXHN9CJa	ADMIN — test	t	2026-08-31 20:53:15.597+00	\N	\N	37d1c8d1-6efb-41d9-84ad-1f5978acc0ce
11	direction.test	$2b$10$jf1LfAOZSMgiQLYsVflYL.q0dRv8ocSlzR9ZpBjoTQNojIXHN9CJa	DIRECTION — test	t	2026-08-31 20:53:16.85+00	\N	\N	986a6c38-99b3-4ad6-8d71-501a04ca0c23
12	encadrant.test	$2b$10$jf1LfAOZSMgiQLYsVflYL.q0dRv8ocSlzR9ZpBjoTQNojIXHN9CJa	ENCADRANT — test	t	2026-08-31 20:53:17.728+00	\N	\N	d39e1b71-0b03-4d78-902f-02d50d3fa1ab
3	tcoignac	$2b$10$gYMOmKic9qsqxHud2dyZ0.RjSMQpPXWKzzZpZJj7CBvkSggU6bevK	THIERRY COIGNAC	t	2026-08-31 20:50:15.729+00	\N	\N	c4f2a711-917f-4158-adab-74a71c34527e
4	lmarchetti	$2b$10$gYMOmKic9qsqxHud2dyZ0.RjSMQpPXWKzzZpZJj7CBvkSggU6bevK	LUCIEN MARCHETTI	t	2026-08-31 20:50:15.98+00	\N	\N	6d61ac3b-1cad-42ce-ae94-963421dd4fb1
5	jlarget	$2b$10$gYMOmKic9qsqxHud2dyZ0.RjSMQpPXWKzzZpZJj7CBvkSggU6bevK	JF LARGET	t	2026-08-31 20:50:16.198+00	\N	\N	5a637024-b12e-47b9-b3f1-25631c049fdd
13	chef.plaque.test	$2b$10$jf1LfAOZSMgiQLYsVflYL.q0dRv8ocSlzR9ZpBjoTQNojIXHN9CJa	CHEF DE PLAQUE — test	t	2026-08-31 20:53:18.693+00	\N	\N	\N
14	chef.site.test	$2b$10$jf1LfAOZSMgiQLYsVflYL.q0dRv8ocSlzR9ZpBjoTQNojIXHN9CJa	CHEF DE SITE — test	t	2026-08-31 20:53:19.683+00	\N	\N	\N
6	mmasson	$2b$10$gYMOmKic9qsqxHud2dyZ0.RjSMQpPXWKzzZpZJj7CBvkSggU6bevK	MICKAEL MASSON	t	2026-08-31 20:50:16.394+00	\N	\N	bfc0adb8-889d-482e-a45c-17ca5ac56805
2	sbesson	$2b$10$jf1LfAOZSMgiQLYsVflYL.q0dRv8ocSlzR9ZpBjoTQNojIXHN9CJa	SÉVERINE BESSON	t	2026-08-31 20:50:15.467+00	\N	\N	323bc1ec-515e-4676-913a-50b39e43d18c
7	fnogues	$2b$10$gYMOmKic9qsqxHud2dyZ0.RjSMQpPXWKzzZpZJj7CBvkSggU6bevK	FRANCK NOGUES	t	2026-08-31 20:50:16.599+00	\N	\N	79958d14-63ab-4f93-bbc6-f57e3bb5082d
8	jhebert	$2b$10$gYMOmKic9qsqxHud2dyZ0.RjSMQpPXWKzzZpZJj7CBvkSggU6bevK	JÉRÔME HÉBERT	t	2026-08-31 20:50:16.808+00	\N	\N	c0eb4ed3-3b70-4af4-98f1-9fbb01f55f97
9	gparrain	$2b$10$gYMOmKic9qsqxHud2dyZ0.RjSMQpPXWKzzZpZJj7CBvkSggU6bevK	GILLES PARRAIN	t	2026-08-31 20:50:17.083+00	\N	\N	104bb84c-e5c5-4201-85aa-bf8cbdad1fb9
\.


--
-- Data for Name: vendeur; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.vendeur (id, nom, site_id, utilisateur_id, date_entree, date_sortie, cree_le, cree_par, capacites_confirmees_le, capacites_confirmees_par, type_vehicule, archive_le, archive_par) FROM stdin;
1	QUENTIN VANINI	1	\N	\N	\N	2026-08-31 20:49:26.552+00	\N	\N	\N	VN	\N	\N
2	VIRGINIE CUMINAL	1	\N	\N	\N	2026-08-31 20:49:27.54+00	\N	\N	\N	VN	\N	\N
3	ANTHONY DONAS	2	\N	\N	\N	2026-08-31 20:49:28.084+00	\N	\N	\N	VN	\N	\N
4	JORDAN CALDEIRA	2	\N	\N	\N	2026-08-31 20:49:28.795+00	\N	\N	\N	VN	\N	\N
5	ROBIN RABOISSON	2	\N	\N	\N	2026-08-31 20:49:29.355+00	\N	\N	\N	VN	\N	\N
6	KEVIN DIJOUX	2	\N	\N	\N	2026-08-31 20:49:30.148+00	\N	\N	\N	VN	\N	\N
7	UGO FERVEL	2	\N	\N	\N	2026-08-31 20:49:30.651+00	\N	\N	\N	VN	\N	\N
8	YANN DE OLIVEIRA	2	\N	\N	\N	2026-08-31 20:49:31.298+00	\N	\N	\N	VO	\N	\N
9	MATTHIAS VALLE	2	\N	\N	\N	2026-08-31 20:49:31.515+00	\N	\N	\N	VO	\N	\N
10	VALENTIN PARPINELLI	3	\N	\N	\N	2026-08-31 20:49:31.644+00	\N	\N	\N	VN	\N	\N
11	THIERRY DUBERNAT	3	\N	\N	\N	2026-08-31 20:49:32.17+00	\N	\N	\N	VN	\N	\N
12	OCEANE ESPINASSE	3	\N	\N	\N	2026-08-31 20:49:33.088+00	\N	\N	\N	VN	\N	\N
13	BLANDINE CLÉMENT	3	\N	\N	\N	2026-08-31 20:49:33.679+00	\N	\N	\N	VN	\N	\N
14	THOMAS SOULIER	3	\N	\N	\N	2026-08-31 20:49:34.277+00	\N	\N	\N	VN	\N	\N
15	CHRISTOPHE BROSSEAU	3	\N	\N	\N	2026-08-31 20:49:34.82+00	\N	\N	\N	VN	\N	\N
16	THÉO ROUSSET	3	\N	\N	\N	2026-08-31 20:49:35.392+00	\N	\N	\N	VN	\N	\N
17	QUENTIN BELLAIGUES	3	\N	\N	\N	2026-08-31 20:49:35.914+00	\N	\N	\N	VN	\N	\N
18	JEAN-PIERRE FERRIER	3	\N	\N	\N	2026-08-31 20:49:36.449+00	\N	\N	\N	VN	\N	\N
19	JULIEN BIASUTTI	3	\N	\N	\N	2026-08-31 20:49:37.08+00	\N	\N	\N	VN	\N	\N
20	PIERRE-EDOUARD LAROCHE	3	\N	\N	\N	2026-08-31 20:49:37.667+00	\N	\N	\N	VN	\N	\N
21	ANTOINE BASTIEN	3	\N	\N	\N	2026-08-31 20:49:38.351+00	\N	\N	\N	VO	\N	\N
22	DYLAN GUERRET	3	\N	\N	\N	2026-08-31 20:49:38.482+00	\N	\N	\N	VO	\N	\N
23	JOAO TEIXEIRA	3	\N	\N	\N	2026-08-31 20:49:38.604+00	\N	\N	\N	VO	\N	\N
24	THIERRY MARTINEZ	3	\N	\N	\N	2026-08-31 20:49:38.777+00	\N	\N	\N	VO	\N	\N
25	JEROME SABIN	3	\N	\N	\N	2026-08-31 20:49:38.909+00	\N	\N	\N	VO	\N	\N
26	ROBIN GUERY	4	\N	\N	\N	2026-08-31 20:49:39.039+00	\N	\N	\N	VN	\N	\N
27	JULIEN SPADAT	4	\N	\N	\N	2026-08-31 20:49:39.636+00	\N	\N	\N	VN	\N	\N
28	STÉPHANE VANDAMME	4	\N	\N	\N	2026-08-31 20:49:40.281+00	\N	\N	\N	VO	\N	\N
29	SÉBASTIEN MIRA	5	\N	\N	\N	2026-08-31 20:49:40.399+00	\N	\N	\N	VN	\N	\N
30	EMILIEN SOLEILHAVOUP	5	\N	\N	\N	2026-08-31 20:49:40.727+00	\N	\N	\N	VN	\N	\N
31	ALEXANDRE CHAVIGNON	6	\N	\N	\N	2026-08-31 20:49:41.278+00	\N	\N	\N	VN	\N	\N
32	MICHEL GUILLERM	6	\N	\N	\N	2026-08-31 20:49:41.815+00	\N	\N	\N	VN	\N	\N
33	ALEXANDRE DIOT	6	\N	\N	\N	2026-08-31 20:49:42.493+00	\N	\N	\N	VN	\N	\N
34	DYLAN MEYRIAL	6	\N	\N	\N	2026-08-31 20:49:43.05+00	\N	\N	\N	VN	\N	\N
35	YOANN TRIBOULET	6	\N	\N	\N	2026-08-31 20:49:43.564+00	\N	\N	\N	VN	\N	\N
36	MATTIS BONNAMOUR	6	\N	\N	\N	2026-08-31 20:49:44.169+00	\N	\N	\N	VN	\N	\N
37	VIKTORIIA BONDARENKO	6	\N	\N	\N	2026-08-31 20:49:44.723+00	\N	\N	\N	VN	\N	\N
38	NICOLAS BOUCHET	6	\N	\N	\N	2026-08-31 20:49:45.35+00	\N	\N	\N	VO	\N	\N
39	CLÉMENT JACQUET	6	\N	\N	\N	2026-08-31 20:49:45.484+00	\N	\N	\N	VO	\N	\N
40	ROMARIC RAMBERT	6	\N	\N	\N	2026-08-31 20:49:45.643+00	\N	\N	\N	VO	\N	\N
41	CLÉMENT RAYA	6	\N	\N	\N	2026-08-31 20:49:45.839+00	\N	\N	\N	VO	\N	\N
42	SYLVETTE ROGUE	7	\N	\N	\N	2026-08-31 20:49:45.97+00	\N	\N	\N	VN	\N	\N
43	SEBASTIEN DUBOST	7	\N	\N	\N	2026-08-31 20:49:46.529+00	\N	\N	\N	VN	\N	\N
44	MARC PALUMBO	7	\N	\N	\N	2026-08-31 20:49:47.037+00	\N	\N	\N	VN	\N	\N
45	PAULINE COIGNET	7	\N	\N	\N	2026-08-31 20:49:47.57+00	\N	\N	\N	VO	\N	\N
46	JULIEN LE QUELLEC	7	\N	\N	\N	2026-08-31 20:49:47.699+00	\N	\N	\N	VO	\N	\N
47	ROMAIN DENIS	7	\N	\N	\N	2026-08-31 20:49:47.82+00	\N	\N	\N	VO	\N	\N
48	LOUIS DUBOST	8	\N	\N	\N	2026-08-31 20:49:47.952+00	\N	\N	\N	VN	\N	\N
49	CYNTHIA VALLIN	8	\N	\N	\N	2026-08-31 20:49:48.57+00	\N	\N	\N	VN	\N	\N
50	AXEL DUMONT	8	\N	\N	\N	2026-08-31 20:49:49.219+00	\N	\N	\N	VN	\N	\N
51	DAMIEN DAGOSTINO	8	\N	\N	\N	2026-08-31 20:49:49.754+00	\N	\N	\N	VO	\N	\N
52	ALEXANDRE PINOT	8	\N	\N	\N	2026-08-31 20:49:49.924+00	\N	\N	\N	VO	\N	\N
53	ARNAUD GALLAND	9	\N	\N	\N	2026-08-31 20:49:50.054+00	\N	\N	\N	VN	\N	\N
54	GUILLAUME SAVINEL	9	\N	\N	\N	2026-08-31 20:49:50.598+00	\N	\N	\N	VN	\N	\N
55	JEAN-PAUL RANVOISE	9	\N	\N	\N	2026-08-31 20:49:51.171+00	\N	\N	\N	VN	\N	\N
56	ARTHUR DURANTON	9	\N	\N	\N	2026-08-31 20:49:51.736+00	\N	\N	\N	VN	\N	\N
57	VALENTIN MOLINES	9	\N	\N	\N	2026-08-31 20:49:52.381+00	\N	\N	\N	VO	\N	\N
58	RICHARD WEISSELDINGER	9	\N	\N	\N	2026-08-31 20:49:52.544+00	\N	\N	\N	VO	\N	\N
59	JÉRÉMY DA COSTA	10	\N	\N	\N	2026-08-31 20:49:52.699+00	\N	\N	\N	VN	\N	\N
60	DYLAN NOGUEIRA	10	\N	\N	\N	2026-08-31 20:49:53.289+00	\N	\N	\N	VN	\N	\N
61	WILLIAM PASCAL	10	\N	\N	\N	2026-08-31 20:49:53.893+00	\N	\N	\N	VO	\N	\N
62	YOANN PICARD	11	\N	\N	\N	2026-08-31 20:49:54.046+00	\N	\N	\N	VN	\N	\N
63	STANISLAS RODAMEL	11	\N	\N	\N	2026-08-31 20:49:54.607+00	\N	\N	\N	VN	\N	\N
64	JULIEN MONATTE	11	\N	\N	\N	2026-08-31 20:49:55.371+00	\N	\N	\N	VN	\N	\N
65	MAGALI MICHEL	11	\N	\N	\N	2026-08-31 20:49:55.883+00	\N	\N	\N	VN	\N	\N
66	AMÉLIE HERVÉ	11	\N	\N	\N	2026-08-31 20:49:56.498+00	\N	\N	\N	VN	\N	\N
67	SÉBASTIEN DUMONT	11	\N	\N	\N	2026-08-31 20:49:57.277+00	\N	\N	\N	VN	\N	\N
68	REDWANE TOULOUSE	11	\N	\N	\N	2026-08-31 20:49:57.884+00	\N	\N	\N	VO	\N	\N
69	STÉPHANE DALLO-BELLESSA	11	\N	\N	\N	2026-08-31 20:49:58.037+00	\N	\N	\N	VO	\N	\N
70	FRANCOIS LENAIC	11	\N	\N	\N	2026-08-31 20:49:58.198+00	\N	\N	\N	VO	\N	\N
71	CHRISTIAN CAUQUIL	12	\N	\N	\N	2026-08-31 20:49:58.351+00	\N	\N	\N	VN	\N	\N
72	JULIEN SEBE	12	\N	\N	\N	2026-08-31 20:49:59.003+00	\N	\N	\N	VN	\N	\N
73	GUILLAUME SEGUI	12	\N	\N	\N	2026-08-31 20:49:59.657+00	\N	\N	\N	VN	\N	\N
74	FLAVIEN MILLON	12	\N	\N	\N	2026-08-31 20:50:00.271+00	\N	\N	\N	VN	\N	\N
75	DANIEL DIAS FERNANDES	13	\N	\N	\N	2026-08-31 20:50:00.978+00	\N	\N	\N	VN	\N	\N
76	AURÉLIE BOMPART	13	\N	\N	\N	2026-08-31 20:50:01.551+00	\N	\N	\N	VN	\N	\N
77	EMMA GUEGUEN	13	\N	\N	\N	2026-08-31 20:50:02.201+00	\N	\N	\N	VN	\N	\N
78	FLORENT THOMASSIN	13	\N	\N	\N	2026-08-31 20:50:02.833+00	\N	\N	\N	VN	\N	\N
79	ROMAIN BOISSONNADE	14	\N	\N	\N	2026-08-31 20:50:03.448+00	\N	\N	\N	VN	\N	\N
80	MARINE FLAUJAGUET	14	\N	\N	\N	2026-08-31 20:50:03.969+00	\N	\N	\N	VN	\N	\N
81	ALEXIS COMPANS	14	\N	\N	\N	2026-08-31 20:50:04.58+00	\N	\N	\N	VN	\N	\N
82	RÉMI DEGAND	14	\N	\N	\N	2026-08-31 20:50:05.428+00	\N	\N	\N	VN	\N	\N
83	ARNAUD LOPEZ	14	\N	\N	\N	2026-08-31 20:50:05.981+00	\N	\N	\N	VO	\N	\N
84	DORIAN FRANCE	14	\N	\N	\N	2026-08-31 20:50:06.106+00	\N	\N	\N	VO	\N	\N
85	DAMIEN RULHE	14	\N	\N	\N	2026-08-31 20:50:06.263+00	\N	\N	\N	VO	\N	\N
86	NICOLAS CAYRON	15	\N	\N	\N	2026-08-31 20:50:06.406+00	\N	\N	\N	VN	\N	\N
87	MATHIS FRANCOIS	15	\N	\N	\N	2026-08-31 20:50:06.987+00	\N	\N	\N	VN	\N	\N
88	ELSA AGRINIER	15	\N	\N	\N	2026-08-31 20:50:07.65+00	\N	\N	\N	VN	\N	\N
89	DORIAN ALLEGRE	16	\N	\N	\N	2026-08-31 20:50:08.199+00	\N	\N	\N	VN	\N	\N
90	MATIS BRUNO	16	\N	\N	\N	2026-08-31 20:50:08.719+00	\N	\N	\N	VN	\N	\N
91	CLÉMENT MALGOUZOU	16	\N	\N	\N	2026-08-31 20:50:09.313+00	\N	\N	\N	VN	\N	\N
92	YOHAN BANYIK	17	\N	\N	\N	2026-08-31 20:50:09.915+00	\N	\N	\N	VN	\N	\N
93	ROMAIN COMBOURIEU	17	\N	\N	\N	2026-08-31 20:50:10.608+00	\N	\N	\N	VN	\N	\N
94	STÉPHANE SUC	17	\N	\N	\N	2026-08-31 20:50:11.145+00	\N	\N	\N	VN	\N	\N
95	ANTONIN LUC	17	\N	\N	\N	2026-08-31 20:50:11.84+00	\N	\N	\N	VN	\N	\N
96	MAGALI BRUGIER	18	\N	\N	\N	2026-08-31 20:50:12.458+00	\N	\N	\N	VN	\N	\N
97	THOMAS BERT	18	\N	\N	\N	2026-08-31 20:50:13.438+00	\N	\N	\N	VN	\N	\N
98	AZIZ CHOUAY	18	\N	\N	\N	2026-08-31 20:50:14.021+00	\N	\N	\N	VO	\N	\N
99	GEOFFREY SALGUES	19	\N	\N	\N	2026-08-31 20:50:14.173+00	\N	\N	\N	VN	\N	\N
\.


--
-- Data for Name: vendeur_marque; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.vendeur_marque (vendeur_id, marque_id, cree_le, cree_par) FROM stdin;
1	1	2026-08-31 20:49:26.771+00	\N
1	2	2026-08-31 20:49:27.265+00	\N
2	1	2026-08-31 20:49:27.576+00	\N
2	2	2026-08-31 20:49:27.817+00	\N
3	1	2026-08-31 20:49:28.212+00	\N
3	2	2026-08-31 20:49:28.479+00	\N
4	1	2026-08-31 20:49:28.848+00	\N
4	2	2026-08-31 20:49:29.057+00	\N
5	1	2026-08-31 20:49:29.425+00	\N
5	2	2026-08-31 20:49:29.849+00	\N
6	1	2026-08-31 20:49:30.181+00	\N
6	2	2026-08-31 20:49:30.406+00	\N
7	1	2026-08-31 20:49:30.695+00	\N
7	2	2026-08-31 20:49:30.967+00	\N
10	1	2026-08-31 20:49:31.686+00	\N
10	2	2026-08-31 20:49:31.899+00	\N
11	1	2026-08-31 20:49:32.21+00	\N
11	2	2026-08-31 20:49:32.555+00	\N
12	1	2026-08-31 20:49:33.14+00	\N
12	2	2026-08-31 20:49:33.353+00	\N
13	1	2026-08-31 20:49:33.728+00	\N
13	2	2026-08-31 20:49:33.991+00	\N
14	1	2026-08-31 20:49:34.32+00	\N
14	2	2026-08-31 20:49:34.514+00	\N
15	1	2026-08-31 20:49:34.897+00	\N
15	2	2026-08-31 20:49:35.147+00	\N
16	1	2026-08-31 20:49:35.436+00	\N
16	2	2026-08-31 20:49:35.67+00	\N
17	1	2026-08-31 20:49:35.95+00	\N
17	2	2026-08-31 20:49:36.162+00	\N
18	1	2026-08-31 20:49:36.514+00	\N
18	2	2026-08-31 20:49:36.777+00	\N
19	1	2026-08-31 20:49:37.136+00	\N
19	2	2026-08-31 20:49:37.39+00	\N
20	1	2026-08-31 20:49:37.71+00	\N
20	2	2026-08-31 20:49:37.963+00	\N
26	1	2026-08-31 20:49:39.08+00	\N
26	2	2026-08-31 20:49:39.323+00	\N
27	1	2026-08-31 20:49:39.68+00	\N
27	2	2026-08-31 20:49:39.91+00	\N
29	3	2026-08-31 20:49:40.443+00	\N
30	3	2026-08-31 20:49:40.765+00	\N
31	1	2026-08-31 20:49:41.325+00	\N
31	2	2026-08-31 20:49:41.57+00	\N
32	1	2026-08-31 20:49:41.856+00	\N
32	2	2026-08-31 20:49:42.145+00	\N
33	1	2026-08-31 20:49:42.557+00	\N
33	2	2026-08-31 20:49:42.766+00	\N
34	1	2026-08-31 20:49:43.091+00	\N
34	2	2026-08-31 20:49:43.328+00	\N
35	1	2026-08-31 20:49:43.609+00	\N
35	2	2026-08-31 20:49:43.877+00	\N
36	1	2026-08-31 20:49:44.219+00	\N
36	2	2026-08-31 20:49:44.449+00	\N
37	1	2026-08-31 20:49:44.77+00	\N
37	2	2026-08-31 20:49:45.04+00	\N
42	1	2026-08-31 20:49:46.019+00	\N
42	2	2026-08-31 20:49:46.226+00	\N
43	1	2026-08-31 20:49:46.569+00	\N
43	2	2026-08-31 20:49:46.786+00	\N
44	1	2026-08-31 20:49:47.082+00	\N
44	2	2026-08-31 20:49:47.3+00	\N
48	1	2026-08-31 20:49:47.996+00	\N
48	2	2026-08-31 20:49:48.275+00	\N
49	1	2026-08-31 20:49:48.614+00	\N
49	2	2026-08-31 20:49:48.847+00	\N
50	1	2026-08-31 20:49:49.267+00	\N
50	2	2026-08-31 20:49:49.475+00	\N
53	1	2026-08-31 20:49:50.105+00	\N
53	2	2026-08-31 20:49:50.328+00	\N
54	1	2026-08-31 20:49:50.641+00	\N
54	2	2026-08-31 20:49:50.868+00	\N
55	1	2026-08-31 20:49:51.205+00	\N
55	2	2026-08-31 20:49:51.425+00	\N
56	1	2026-08-31 20:49:51.796+00	\N
56	2	2026-08-31 20:49:52.039+00	\N
59	1	2026-08-31 20:49:52.737+00	\N
59	2	2026-08-31 20:49:52.962+00	\N
60	1	2026-08-31 20:49:53.33+00	\N
60	2	2026-08-31 20:49:53.602+00	\N
62	1	2026-08-31 20:49:54.098+00	\N
62	2	2026-08-31 20:49:54.313+00	\N
63	1	2026-08-31 20:49:54.649+00	\N
63	2	2026-08-31 20:49:54.961+00	\N
64	1	2026-08-31 20:49:55.424+00	\N
64	2	2026-08-31 20:49:55.619+00	\N
65	1	2026-08-31 20:49:55.931+00	\N
65	2	2026-08-31 20:49:56.154+00	\N
66	1	2026-08-31 20:49:56.546+00	\N
66	2	2026-08-31 20:49:56.803+00	\N
67	1	2026-08-31 20:49:57.336+00	\N
67	2	2026-08-31 20:49:57.574+00	\N
71	1	2026-08-31 20:49:58.399+00	\N
71	2	2026-08-31 20:49:58.644+00	\N
72	1	2026-08-31 20:49:59.067+00	\N
72	2	2026-08-31 20:49:59.385+00	\N
73	1	2026-08-31 20:49:59.724+00	\N
73	2	2026-08-31 20:49:59.974+00	\N
74	1	2026-08-31 20:50:00.315+00	\N
74	2	2026-08-31 20:50:00.598+00	\N
75	1	2026-08-31 20:50:01.028+00	\N
75	2	2026-08-31 20:50:01.244+00	\N
76	1	2026-08-31 20:50:01.606+00	\N
76	2	2026-08-31 20:50:01.846+00	\N
77	1	2026-08-31 20:50:02.246+00	\N
77	2	2026-08-31 20:50:02.52+00	\N
78	1	2026-08-31 20:50:02.879+00	\N
78	2	2026-08-31 20:50:03.174+00	\N
79	1	2026-08-31 20:50:03.49+00	\N
79	2	2026-08-31 20:50:03.714+00	\N
80	1	2026-08-31 20:50:04.03+00	\N
80	2	2026-08-31 20:50:04.279+00	\N
81	1	2026-08-31 20:50:04.644+00	\N
81	2	2026-08-31 20:50:05.177+00	\N
82	1	2026-08-31 20:50:05.473+00	\N
82	2	2026-08-31 20:50:05.709+00	\N
86	1	2026-08-31 20:50:06.447+00	\N
86	2	2026-08-31 20:50:06.684+00	\N
87	1	2026-08-31 20:50:07.031+00	\N
87	2	2026-08-31 20:50:07.29+00	\N
88	1	2026-08-31 20:50:07.723+00	\N
88	2	2026-08-31 20:50:07.933+00	\N
89	1	2026-08-31 20:50:08.248+00	\N
89	2	2026-08-31 20:50:08.454+00	\N
90	1	2026-08-31 20:50:08.761+00	\N
90	2	2026-08-31 20:50:08.973+00	\N
91	1	2026-08-31 20:50:09.368+00	\N
91	2	2026-08-31 20:50:09.621+00	\N
92	1	2026-08-31 20:50:09.99+00	\N
92	2	2026-08-31 20:50:10.24+00	\N
93	1	2026-08-31 20:50:10.656+00	\N
93	2	2026-08-31 20:50:10.896+00	\N
94	1	2026-08-31 20:50:11.207+00	\N
94	2	2026-08-31 20:50:11.464+00	\N
95	1	2026-08-31 20:50:11.899+00	\N
95	2	2026-08-31 20:50:12.155+00	\N
96	1	2026-08-31 20:50:12.494+00	\N
96	2	2026-08-31 20:50:12.721+00	\N
97	1	2026-08-31 20:50:13.51+00	\N
97	2	2026-08-31 20:50:13.721+00	\N
99	1	2026-08-31 20:50:14.218+00	\N
99	2	2026-08-31 20:50:14.52+00	\N
\.


--
-- Name: affectation_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.affectation_id_seq', 117, true);


--
-- Name: campagne_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.campagne_id_seq', 2, true);


--
-- Name: encadrement_site_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.encadrement_site_id_seq', 109, true);


--
-- Name: marque_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.marque_id_seq', 27, true);


--
-- Name: plaque_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.plaque_id_seq', 4, true);


--
-- Name: rdv_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.rdv_id_seq', 261, true);


--
-- Name: role_campagne_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.role_campagne_id_seq', 11, true);


--
-- Name: session_plaque_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.session_plaque_id_seq', 8, true);


--
-- Name: site_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.site_id_seq', 19, true);


--
-- Name: table_phoning_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.table_phoning_id_seq', 8, true);


--
-- Name: utilisateur_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.utilisateur_id_seq', 91, true);


--
-- Name: vendeur_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.vendeur_id_seq', 158, true);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: affectation affectation_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.affectation
    ADD CONSTRAINT affectation_pkey PRIMARY KEY (id);


--
-- Name: campagne_creneau campagne_creneau_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.campagne_creneau
    ADD CONSTRAINT campagne_creneau_pkey PRIMARY KEY (campagne_id, code);


--
-- Name: campagne_jour campagne_jour_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.campagne_jour
    ADD CONSTRAINT campagne_jour_pkey PRIMARY KEY (campagne_id, jour);


--
-- Name: campagne campagne_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.campagne
    ADD CONSTRAINT campagne_pkey PRIMARY KEY (id);


--
-- Name: encadrement_site encadrement_site_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.encadrement_site
    ADD CONSTRAINT encadrement_site_pkey PRIMARY KEY (id);


--
-- Name: marque marque_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.marque
    ADD CONSTRAINT marque_pkey PRIMARY KEY (id);


--
-- Name: plaque plaque_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.plaque
    ADD CONSTRAINT plaque_pkey PRIMARY KEY (id);


--
-- Name: rdv rdv_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.rdv
    ADD CONSTRAINT rdv_pkey PRIMARY KEY (id);


--
-- Name: role_campagne role_campagne_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.role_campagne
    ADD CONSTRAINT role_campagne_pkey PRIMARY KEY (id);


--
-- Name: role_global role_global_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.role_global
    ADD CONSTRAINT role_global_pkey PRIMARY KEY (utilisateur_id, role);


--
-- Name: session_plaque session_plaque_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.session_plaque
    ADD CONSTRAINT session_plaque_pkey PRIMARY KEY (id);


--
-- Name: site site_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.site
    ADD CONSTRAINT site_pkey PRIMARY KEY (id);


--
-- Name: table_phoning table_phoning_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.table_phoning
    ADD CONSTRAINT table_phoning_pkey PRIMARY KEY (id);


--
-- Name: utilisateur utilisateur_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.utilisateur
    ADD CONSTRAINT utilisateur_pkey PRIMARY KEY (id);


--
-- Name: vendeur_marque vendeur_marque_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.vendeur_marque
    ADD CONSTRAINT vendeur_marque_pkey PRIMARY KEY (vendeur_id, marque_id);


--
-- Name: vendeur vendeur_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.vendeur
    ADD CONSTRAINT vendeur_pkey PRIMARY KEY (id);


--
-- Name: affectation_table_id_vendeur_id_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX affectation_table_id_vendeur_id_key ON relance.affectation USING btree (table_id, vendeur_id);


--
-- Name: affectation_vendeur_id_idx; Type: INDEX; Schema: relance; Owner: -
--

CREATE INDEX affectation_vendeur_id_idx ON relance.affectation USING btree (vendeur_id);


--
-- Name: campagne_libelle_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX campagne_libelle_key ON relance.campagne USING btree (libelle);


--
-- Name: encadrement_site_site_role_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX encadrement_site_site_role_key ON relance.encadrement_site USING btree (site_id, role);


--
-- Name: encadrement_site_utilisateur_id_idx; Type: INDEX; Schema: relance; Owner: -
--

CREATE INDEX encadrement_site_utilisateur_id_idx ON relance.encadrement_site USING btree (utilisateur_id);


--
-- Name: marque_code_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX marque_code_key ON relance.marque USING btree (code);


--
-- Name: plaque_libelle_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX plaque_libelle_key ON relance.plaque USING btree (libelle);


--
-- Name: rdv_campagne_id_jour_creneau_code_idx; Type: INDEX; Schema: relance; Owner: -
--

CREATE INDEX rdv_campagne_id_jour_creneau_code_idx ON relance.rdv USING btree (campagne_id, jour, creneau_code);


--
-- Name: rdv_campagne_id_vendeur_id_idx; Type: INDEX; Schema: relance; Owner: -
--

CREATE INDEX rdv_campagne_id_vendeur_id_idx ON relance.rdv USING btree (campagne_id, vendeur_id);


--
-- Name: role_campagne_campagne_id_utilisateur_id_idx; Type: INDEX; Schema: relance; Owner: -
--

CREATE INDEX role_campagne_campagne_id_utilisateur_id_idx ON relance.role_campagne USING btree (campagne_id, utilisateur_id);


--
-- Name: session_plaque_campagne_id_plaque_id_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX session_plaque_campagne_id_plaque_id_key ON relance.session_plaque USING btree (campagne_id, plaque_id);


--
-- Name: site_code_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX site_code_key ON relance.site USING btree (code);


--
-- Name: table_phoning_marque_id_idx; Type: INDEX; Schema: relance; Owner: -
--

CREATE INDEX table_phoning_marque_id_idx ON relance.table_phoning USING btree (marque_id);


--
-- Name: table_phoning_session_plaque_id_libelle_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX table_phoning_session_plaque_id_libelle_key ON relance.table_phoning USING btree (session_plaque_id, libelle);


--
-- Name: utilisateur_auth_uid_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX utilisateur_auth_uid_key ON relance.utilisateur USING btree (auth_uid);


--
-- Name: utilisateur_login_id_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX utilisateur_login_id_key ON relance.utilisateur USING btree (login_id);


--
-- Name: vendeur_site_id_idx; Type: INDEX; Schema: relance; Owner: -
--

CREATE INDEX vendeur_site_id_idx ON relance.vendeur USING btree (site_id);


--
-- Name: vendeur_utilisateur_id_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX vendeur_utilisateur_id_key ON relance.vendeur USING btree (utilisateur_id);


--
-- Name: affectation affectation_marque_table; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER affectation_marque_table BEFORE INSERT OR UPDATE ON relance.affectation FOR EACH ROW EXECUTE FUNCTION relance.verifier_affectation_marque_table();


--
-- Name: affectation affectation_meme_plaque; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER affectation_meme_plaque BEFORE INSERT OR UPDATE ON relance.affectation FOR EACH ROW EXECUTE FUNCTION relance.verifier_affectation_meme_plaque();


--
-- Name: affectation affectation_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER affectation_pas_de_delete BEFORE DELETE ON relance.affectation FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: affectation affectation_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER affectation_tracabilite BEFORE INSERT ON relance.affectation FOR EACH ROW EXECUTE FUNCTION relance.tracer_creation();


--
-- Name: affectation affectation_unique_par_campagne; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER affectation_unique_par_campagne BEFORE INSERT OR UPDATE ON relance.affectation FOR EACH ROW EXECUTE FUNCTION relance.verifier_affectation_unique();


--
-- Name: campagne campagne_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER campagne_pas_de_delete BEFORE DELETE ON relance.campagne FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: campagne campagne_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER campagne_tracabilite BEFORE INSERT ON relance.campagne FOR EACH ROW EXECUTE FUNCTION relance.tracer_creation();


--
-- Name: encadrement_site encadrement_site_compte_actif; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER encadrement_site_compte_actif BEFORE INSERT OR UPDATE ON relance.encadrement_site FOR EACH ROW EXECUTE FUNCTION relance.verifier_encadrant_actif();


--
-- Name: encadrement_site encadrement_site_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER encadrement_site_pas_de_delete BEFORE DELETE ON relance.encadrement_site FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: encadrement_site encadrement_site_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER encadrement_site_tracabilite BEFORE INSERT ON relance.encadrement_site FOR EACH ROW EXECUTE FUNCTION relance.tracer_creation();


--
-- Name: marque marque_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER marque_pas_de_delete BEFORE DELETE ON relance.marque FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: plaque plaque_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER plaque_pas_de_delete BEFORE DELETE ON relance.plaque FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: rdv rdv_campagne_ouverte; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER rdv_campagne_ouverte BEFORE INSERT OR DELETE OR UPDATE ON relance.rdv FOR EACH ROW EXECUTE FUNCTION relance.verifier_campagne_ouverte();


--
-- Name: rdv rdv_diffusion; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER rdv_diffusion AFTER INSERT OR UPDATE ON relance.rdv FOR EACH ROW EXECUTE FUNCTION relance.diffuser_rdv();


--
-- Name: rdv rdv_marque_autorisee; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER rdv_marque_autorisee BEFORE INSERT OR UPDATE OF vendeur_id, marque_id ON relance.rdv FOR EACH ROW EXECUTE FUNCTION relance.verifier_marque_autorisee();


--
-- Name: rdv rdv_marque_selon_metier; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER rdv_marque_selon_metier BEFORE INSERT OR UPDATE OF vendeur_id, marque_id ON relance.rdv FOR EACH ROW EXECUTE FUNCTION relance.verifier_marque_selon_metier();


--
-- Name: rdv rdv_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER rdv_pas_de_delete BEFORE DELETE ON relance.rdv FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: rdv rdv_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER rdv_tracabilite BEFORE INSERT OR UPDATE ON relance.rdv FOR EACH ROW EXECUTE FUNCTION relance.tracer_modification_rdv();


--
-- Name: rdv rdv_type_coherent; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER rdv_type_coherent BEFORE INSERT OR UPDATE OF vendeur_id, type_vehicule ON relance.rdv FOR EACH ROW EXECUTE FUNCTION relance.verifier_type_coherent();


--
-- Name: role_campagne role_campagne_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER role_campagne_tracabilite BEFORE INSERT ON relance.role_campagne FOR EACH ROW EXECUTE FUNCTION relance.tracer_creation();


--
-- Name: role_global role_global_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER role_global_tracabilite BEFORE INSERT ON relance.role_global FOR EACH ROW EXECUTE FUNCTION relance.tracer_creation();


--
-- Name: session_plaque session_plaque_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER session_plaque_pas_de_delete BEFORE DELETE ON relance.session_plaque FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: session_plaque session_plaque_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER session_plaque_tracabilite BEFORE INSERT ON relance.session_plaque FOR EACH ROW EXECUTE FUNCTION relance.tracer_creation();


--
-- Name: site site_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER site_pas_de_delete BEFORE DELETE ON relance.site FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: table_phoning table_phoning_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER table_phoning_pas_de_delete BEFORE DELETE ON relance.table_phoning FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: table_phoning table_phoning_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER table_phoning_tracabilite BEFORE INSERT ON relance.table_phoning FOR EACH ROW EXECUTE FUNCTION relance.tracer_creation();


--
-- Name: utilisateur utilisateur_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER utilisateur_pas_de_delete BEFORE DELETE ON relance.utilisateur FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: vendeur vendeur_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER vendeur_pas_de_delete BEFORE DELETE ON relance.vendeur FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: vendeur vendeur_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER vendeur_tracabilite BEFORE INSERT ON relance.vendeur FOR EACH ROW EXECUTE FUNCTION relance.tracer_creation();


--
-- Name: affectation affectation_table_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.affectation
    ADD CONSTRAINT affectation_table_id_fkey FOREIGN KEY (table_id) REFERENCES relance.table_phoning(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: affectation affectation_vendeur_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.affectation
    ADD CONSTRAINT affectation_vendeur_id_fkey FOREIGN KEY (vendeur_id) REFERENCES relance.vendeur(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: campagne_creneau campagne_creneau_campagne_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.campagne_creneau
    ADD CONSTRAINT campagne_creneau_campagne_id_fkey FOREIGN KEY (campagne_id) REFERENCES relance.campagne(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: campagne_jour campagne_jour_campagne_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.campagne_jour
    ADD CONSTRAINT campagne_jour_campagne_id_fkey FOREIGN KEY (campagne_id) REFERENCES relance.campagne(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: encadrement_site encadrement_site_site_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.encadrement_site
    ADD CONSTRAINT encadrement_site_site_id_fkey FOREIGN KEY (site_id) REFERENCES relance.site(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: encadrement_site encadrement_site_utilisateur_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.encadrement_site
    ADD CONSTRAINT encadrement_site_utilisateur_id_fkey FOREIGN KEY (utilisateur_id) REFERENCES relance.utilisateur(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: rdv rdv_campagne_id_creneau_code_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.rdv
    ADD CONSTRAINT rdv_campagne_id_creneau_code_fkey FOREIGN KEY (campagne_id, creneau_code) REFERENCES relance.campagne_creneau(campagne_id, code) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: rdv rdv_campagne_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.rdv
    ADD CONSTRAINT rdv_campagne_id_fkey FOREIGN KEY (campagne_id) REFERENCES relance.campagne(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: rdv rdv_campagne_id_jour_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.rdv
    ADD CONSTRAINT rdv_campagne_id_jour_fkey FOREIGN KEY (campagne_id, jour) REFERENCES relance.campagne_jour(campagne_id, jour) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: rdv rdv_marque_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.rdv
    ADD CONSTRAINT rdv_marque_id_fkey FOREIGN KEY (marque_id) REFERENCES relance.marque(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: rdv rdv_vendeur_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.rdv
    ADD CONSTRAINT rdv_vendeur_id_fkey FOREIGN KEY (vendeur_id) REFERENCES relance.vendeur(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: role_campagne role_campagne_campagne_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.role_campagne
    ADD CONSTRAINT role_campagne_campagne_id_fkey FOREIGN KEY (campagne_id) REFERENCES relance.campagne(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: role_campagne role_campagne_plaque_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.role_campagne
    ADD CONSTRAINT role_campagne_plaque_id_fkey FOREIGN KEY (plaque_id) REFERENCES relance.plaque(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: role_campagne role_campagne_site_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.role_campagne
    ADD CONSTRAINT role_campagne_site_id_fkey FOREIGN KEY (site_id) REFERENCES relance.site(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: role_campagne role_campagne_utilisateur_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.role_campagne
    ADD CONSTRAINT role_campagne_utilisateur_id_fkey FOREIGN KEY (utilisateur_id) REFERENCES relance.utilisateur(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: role_global role_global_utilisateur_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.role_global
    ADD CONSTRAINT role_global_utilisateur_id_fkey FOREIGN KEY (utilisateur_id) REFERENCES relance.utilisateur(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: session_plaque session_plaque_campagne_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.session_plaque
    ADD CONSTRAINT session_plaque_campagne_id_fkey FOREIGN KEY (campagne_id) REFERENCES relance.campagne(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: session_plaque session_plaque_plaque_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.session_plaque
    ADD CONSTRAINT session_plaque_plaque_id_fkey FOREIGN KEY (plaque_id) REFERENCES relance.plaque(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: site site_plaque_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.site
    ADD CONSTRAINT site_plaque_id_fkey FOREIGN KEY (plaque_id) REFERENCES relance.plaque(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: table_phoning table_phoning_chef_utilisateur_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.table_phoning
    ADD CONSTRAINT table_phoning_chef_utilisateur_id_fkey FOREIGN KEY (chef_utilisateur_id) REFERENCES relance.utilisateur(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: table_phoning table_phoning_marque_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.table_phoning
    ADD CONSTRAINT table_phoning_marque_id_fkey FOREIGN KEY (marque_id) REFERENCES relance.marque(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: table_phoning table_phoning_session_plaque_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.table_phoning
    ADD CONSTRAINT table_phoning_session_plaque_id_fkey FOREIGN KEY (session_plaque_id) REFERENCES relance.session_plaque(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vendeur_marque vendeur_marque_marque_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.vendeur_marque
    ADD CONSTRAINT vendeur_marque_marque_id_fkey FOREIGN KEY (marque_id) REFERENCES relance.marque(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: vendeur_marque vendeur_marque_vendeur_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.vendeur_marque
    ADD CONSTRAINT vendeur_marque_vendeur_id_fkey FOREIGN KEY (vendeur_id) REFERENCES relance.vendeur(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: vendeur vendeur_site_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.vendeur
    ADD CONSTRAINT vendeur_site_id_fkey FOREIGN KEY (site_id) REFERENCES relance.site(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: vendeur vendeur_utilisateur_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.vendeur
    ADD CONSTRAINT vendeur_utilisateur_id_fkey FOREIGN KEY (utilisateur_id) REFERENCES relance.utilisateur(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: _prisma_migrations; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance._prisma_migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: affectation; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.affectation ENABLE ROW LEVEL SECURITY;

--
-- Name: affectation affectation_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY affectation_creation ON relance.affectation FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: affectation affectation_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY affectation_lecture ON relance.affectation FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: affectation affectation_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY affectation_modification ON relance.affectation FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: campagne; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.campagne ENABLE ROW LEVEL SECURITY;

--
-- Name: campagne campagne_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_creation ON relance.campagne FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: campagne_creneau; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.campagne_creneau ENABLE ROW LEVEL SECURITY;

--
-- Name: campagne_creneau campagne_creneau_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_creneau_creation ON relance.campagne_creneau FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: campagne_creneau campagne_creneau_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_creneau_lecture ON relance.campagne_creneau FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: campagne_creneau campagne_creneau_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_creneau_modification ON relance.campagne_creneau FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: campagne_jour; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.campagne_jour ENABLE ROW LEVEL SECURITY;

--
-- Name: campagne_jour campagne_jour_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_jour_creation ON relance.campagne_jour FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: campagne_jour campagne_jour_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_jour_lecture ON relance.campagne_jour FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: campagne_jour campagne_jour_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_jour_modification ON relance.campagne_jour FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: campagne campagne_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_lecture ON relance.campagne FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: campagne campagne_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_modification ON relance.campagne FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: encadrement_site; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.encadrement_site ENABLE ROW LEVEL SECURITY;

--
-- Name: encadrement_site encadrement_site_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY encadrement_site_creation ON relance.encadrement_site FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs));


--
-- Name: encadrement_site encadrement_site_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY encadrement_site_lecture ON relance.encadrement_site FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: encadrement_site encadrement_site_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY encadrement_site_modification ON relance.encadrement_site FOR UPDATE TO authenticated USING (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs)) WITH CHECK (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs));


--
-- Name: marque; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.marque ENABLE ROW LEVEL SECURITY;

--
-- Name: marque marque_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY marque_creation ON relance.marque FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: marque marque_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY marque_lecture ON relance.marque FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: marque marque_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY marque_modification ON relance.marque FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: plaque; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.plaque ENABLE ROW LEVEL SECURITY;

--
-- Name: plaque plaque_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY plaque_creation ON relance.plaque FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: plaque plaque_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY plaque_lecture ON relance.plaque FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: plaque plaque_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY plaque_modification ON relance.plaque FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: rdv; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.rdv ENABLE ROW LEVEL SECURITY;

--
-- Name: rdv rdv_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY rdv_creation ON relance.rdv FOR INSERT TO authenticated WITH CHECK ((( SELECT relance.peut_saisir(rdv.vendeur_id, rdv.campagne_id) AS peut_saisir) AND ( SELECT relance.campagne_ouverte(rdv.campagne_id) AS campagne_ouverte)));


--
-- Name: rdv rdv_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY rdv_lecture ON relance.rdv FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM relance.perimetre_saisie ps
  WHERE ((ps.campagne_id = rdv.campagne_id) AND (ps.vendeur_id = rdv.vendeur_id)))));


--
-- Name: rdv rdv_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY rdv_modification ON relance.rdv FOR UPDATE TO authenticated USING ((( SELECT relance.peut_saisir(rdv.vendeur_id, rdv.campagne_id) AS peut_saisir) AND ( SELECT relance.campagne_ouverte(rdv.campagne_id) AS campagne_ouverte))) WITH CHECK ((( SELECT relance.peut_saisir(rdv.vendeur_id, rdv.campagne_id) AS peut_saisir) AND ( SELECT relance.campagne_ouverte(rdv.campagne_id) AS campagne_ouverte)));


--
-- Name: role_campagne; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.role_campagne ENABLE ROW LEVEL SECURITY;

--
-- Name: role_campagne role_campagne_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY role_campagne_creation ON relance.role_campagne FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs));


--
-- Name: role_campagne role_campagne_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY role_campagne_lecture ON relance.role_campagne FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: role_campagne role_campagne_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY role_campagne_modification ON relance.role_campagne FOR UPDATE TO authenticated USING (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs)) WITH CHECK (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs));


--
-- Name: role_global; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.role_global ENABLE ROW LEVEL SECURITY;

--
-- Name: role_global role_global_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY role_global_creation ON relance.role_global FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs));


--
-- Name: role_global role_global_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY role_global_lecture ON relance.role_global FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: role_global role_global_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY role_global_modification ON relance.role_global FOR UPDATE TO authenticated USING (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs)) WITH CHECK (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs));


--
-- Name: session_plaque; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.session_plaque ENABLE ROW LEVEL SECURITY;

--
-- Name: session_plaque session_plaque_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY session_plaque_creation ON relance.session_plaque FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: session_plaque session_plaque_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY session_plaque_lecture ON relance.session_plaque FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: session_plaque session_plaque_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY session_plaque_modification ON relance.session_plaque FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: site; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.site ENABLE ROW LEVEL SECURITY;

--
-- Name: site site_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY site_creation ON relance.site FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: site site_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY site_lecture ON relance.site FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: site site_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY site_modification ON relance.site FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: table_phoning; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.table_phoning ENABLE ROW LEVEL SECURITY;

--
-- Name: table_phoning table_phoning_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY table_phoning_creation ON relance.table_phoning FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: table_phoning table_phoning_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY table_phoning_lecture ON relance.table_phoning FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: table_phoning table_phoning_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY table_phoning_modification ON relance.table_phoning FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: utilisateur; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.utilisateur ENABLE ROW LEVEL SECURITY;

--
-- Name: utilisateur utilisateur_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY utilisateur_creation ON relance.utilisateur FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs));


--
-- Name: utilisateur utilisateur_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY utilisateur_lecture ON relance.utilisateur FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: utilisateur utilisateur_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY utilisateur_modification ON relance.utilisateur FOR UPDATE TO authenticated USING (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs)) WITH CHECK (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs));


--
-- Name: vendeur; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.vendeur ENABLE ROW LEVEL SECURITY;

--
-- Name: vendeur vendeur_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY vendeur_creation ON relance.vendeur FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: vendeur vendeur_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY vendeur_lecture ON relance.vendeur FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: vendeur_marque; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.vendeur_marque ENABLE ROW LEVEL SECURITY;

--
-- Name: vendeur_marque vendeur_marque_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY vendeur_marque_creation ON relance.vendeur_marque FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: vendeur_marque vendeur_marque_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY vendeur_marque_lecture ON relance.vendeur_marque FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: vendeur_marque vendeur_marque_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY vendeur_marque_modification ON relance.vendeur_marque FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: vendeur vendeur_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY vendeur_modification ON relance.vendeur FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- PostgreSQL database dump complete
--

\unrestrict 9h6UxezZwrNqEo4JDMWwizvNqVFXkaO2tbKnNG8nKByFiZhIMGR3uSn9wPhpVza

