--
-- PostgreSQL database dump
--

\restrict aZlU4rEymOlcoWVkgqzCuW0uYVcIc7whZhkVCYfMyLA2TEn0HQMRVAyTGc2RtQP

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.11 (Ubuntu 17.11-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: relance; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA relance;


--
-- Name: a_role_global(text); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.a_role_global(p_role text) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
  SELECT EXISTS (
    SELECT 1 FROM relance.role_global rg
    WHERE rg.utilisateur_id = relance.utilisateur_courant()
      AND rg.role = p_role
  )
$$;


--
-- Name: campagne_definir_creneaux(bigint, text[], text[], text, text); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.campagne_definir_creneaux(p_campagne_id bigint, p_codes text[], p_libelles text[], p_mode text DEFAULT NULL::text, p_vers text DEFAULT NULL::text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_administration();
  retires text[];
  ajoutes text[];
  impactes int;
  detail jsonb;
  i int;
BEGIN
  IF p_codes IS NULL OR array_length(p_codes, 1) IS NULL THEN
    RAISE EXCEPTION 'RELANCE: au moins un creneau est requis.';
  END IF;
  IF array_length(p_codes, 1) <> array_length(p_libelles, 1) THEN
    RAISE EXCEPTION 'RELANCE: chaque creneau doit porter un libelle.';
  END IF;
  IF (SELECT count(DISTINCT c) FROM unnest(p_codes) c) <> array_length(p_codes, 1) THEN
    RAISE EXCEPTION 'RELANCE: un creneau est present deux fois.';
  END IF;
  IF NOT relance.campagne_ouverte(p_campagne_id) THEN
    RAISE EXCEPTION 'RELANCE: campagne cloturee, ses creneaux ne sont plus modifiables.';
  END IF;

  SELECT coalesce(array_agg(cc.code ORDER BY cc.ordre), '{}')
    INTO retires
    FROM relance.campagne_creneau cc
   WHERE cc.campagne_id = p_campagne_id AND NOT (cc.code = ANY (p_codes));

  SELECT coalesce(array_agg(c), '{}')
    INTO ajoutes
    FROM unnest(p_codes) c
   WHERE NOT EXISTS (
     SELECT 1 FROM relance.campagne_creneau cc
      WHERE cc.campagne_id = p_campagne_id AND cc.code = c
   );

  SELECT count(*)::int,
         coalesce(jsonb_agg(jsonb_build_object('creneau', s.code, 'actifs', s.actifs, 'archives', s.archives)), '[]'::jsonb)
    INTO impactes, detail
    FROM (
      SELECT r.creneau_code AS code,
             count(*) FILTER (WHERE r.archive_le IS NULL) AS actifs,
             count(*) FILTER (WHERE r.archive_le IS NOT NULL) AS archives
        FROM relance.rdv r
       WHERE r.campagne_id = p_campagne_id AND r.creneau_code = ANY (retires)
       GROUP BY r.creneau_code
    ) s;

  SELECT coalesce(sum((x->>'actifs')::int + (x->>'archives')::int), 0)::int
    INTO impactes FROM jsonb_array_elements(detail) x;

  IF impactes > 0 AND coalesce(p_mode, '') <> 'deplacer' THEN
    RETURN jsonb_build_object(
      'applique', false, 'code', 'RDV_IMPACTES',
      'retires', to_jsonb(retires), 'ajoutes', to_jsonb(ajoutes),
      'impacts', detail, 'creneauxConserves', to_jsonb(p_codes),
      'message', format('Retirer ces creneaux supprimerait le rattachement de %s RDV. Choisir : annuler, ou deplacer ces RDV vers un creneau conserve.', impactes)
    );
  END IF;

  IF impactes > 0 AND (p_vers IS NULL OR NOT (p_vers = ANY (p_codes))) THEN
    RAISE EXCEPTION 'RELANCE: le creneau de destination doit faire partie des creneaux conserves.';
  END IF;

  FOR i IN 1 .. array_length(p_codes, 1) LOOP
    INSERT INTO relance.campagne_creneau (campagne_id, code, libelle, ordre, cree_par)
    VALUES (p_campagne_id, p_codes[i], p_libelles[i], i, moi)
    ON CONFLICT (campagne_id, code) DO UPDATE SET libelle = EXCLUDED.libelle, ordre = EXCLUDED.ordre;
  END LOOP;

  IF impactes > 0 THEN
    UPDATE relance.rdv r
       SET creneau_code = p_vers, modifie_le = now(), modifie_par = moi
     WHERE r.campagne_id = p_campagne_id AND r.creneau_code = ANY (retires);
  END IF;

  IF array_length(retires, 1) IS NOT NULL THEN
    DELETE FROM relance.campagne_creneau cc
     WHERE cc.campagne_id = p_campagne_id AND cc.code = ANY (retires);
  END IF;

  RETURN jsonb_build_object(
    'applique', true, 'retires', to_jsonb(retires), 'ajoutes', to_jsonb(ajoutes),
    'rdvDeplaces', impactes, 'versCreneau', to_jsonb(p_vers),
    'creneaux', (SELECT coalesce(jsonb_agg(jsonb_build_object('code', cc.code, 'libelle', cc.libelle, 'ordre', cc.ordre) ORDER BY cc.ordre), '[]'::jsonb)
                   FROM relance.campagne_creneau cc WHERE cc.campagne_id = p_campagne_id)
  );
END $$;


--
-- Name: campagne_definir_jours(bigint, date[], text, date); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.campagne_definir_jours(p_campagne_id bigint, p_jours date[], p_mode text DEFAULT NULL::text, p_vers date DEFAULT NULL::date) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_administration();
  retires date[];
  ajoutes date[];
  impactes int;
  detail jsonb;
  i int;
BEGIN
  IF p_jours IS NULL OR array_length(p_jours, 1) IS NULL THEN
    RAISE EXCEPTION 'RELANCE: au moins un jour est requis.';
  END IF;
  IF (SELECT count(DISTINCT j) FROM unnest(p_jours) j) <> array_length(p_jours, 1) THEN
    RAISE EXCEPTION 'RELANCE: un jour est present deux fois.';
  END IF;
  IF NOT relance.campagne_ouverte(p_campagne_id) THEN
    RAISE EXCEPTION 'RELANCE: campagne cloturee, ses jours ne sont plus modifiables.';
  END IF;

  SELECT coalesce(array_agg(cj.jour ORDER BY cj.jour), '{}')
    INTO retires
    FROM relance.campagne_jour cj
   WHERE cj.campagne_id = p_campagne_id
     AND NOT (cj.jour = ANY (p_jours));

  SELECT coalesce(array_agg(j ORDER BY j), '{}')
    INTO ajoutes
    FROM unnest(p_jours) j
   WHERE NOT EXISTS (
     SELECT 1 FROM relance.campagne_jour cj
      WHERE cj.campagne_id = p_campagne_id AND cj.jour = j
   );

  -- Les RDV impactes, ARCHIVES COMPRIS : un RDV archive reste rattache a son jour
  -- par la cle etrangere, donc il bloque le retrait exactement comme un actif.
  SELECT count(*)::int,
         coalesce(jsonb_agg(x ORDER BY x->>'jour'), '[]'::jsonb)
    INTO impactes, detail
    FROM (
      SELECT jsonb_build_object(
               'jour', r.jour,
               'actifs', count(*) FILTER (WHERE r.archive_le IS NULL),
               'archives', count(*) FILTER (WHERE r.archive_le IS NOT NULL),
               'vendeurs', coalesce(jsonb_agg(DISTINCT v.nom) FILTER (WHERE r.archive_le IS NULL), '[]'::jsonb)
             ) AS x,
             count(*) AS n
        FROM relance.rdv r
        JOIN relance.vendeur v ON v.id = r.vendeur_id
       WHERE r.campagne_id = p_campagne_id
         AND r.jour = ANY (retires)
       GROUP BY r.jour
    ) s;

  SELECT coalesce(sum((x->>'actifs')::int + (x->>'archives')::int), 0)::int
    INTO impactes
    FROM jsonb_array_elements(detail) x;

  -- SONDAGE : on rend l'impact sans rien modifier. L'interface s'en sert pour
  -- proposer le choix « annuler ou deplacer ».
  IF impactes > 0 AND coalesce(p_mode, '') <> 'deplacer' THEN
    RETURN jsonb_build_object(
      'applique', false,
      'code', 'RDV_IMPACTES',
      'retires', to_jsonb(retires),
      'ajoutes', to_jsonb(ajoutes),
      'impacts', detail,
      'joursConserves', to_jsonb(p_jours),
      'message', format(
        'Retirer %s supprimerait le rattachement de %s RDV. Choisir : annuler la modification, ou deplacer ces RDV vers un jour conserve.',
        CASE WHEN array_length(retires, 1) > 1 THEN 'ces jours' ELSE 'ce jour' END,
        impactes)
    );
  END IF;

  IF impactes > 0 THEN
    IF p_vers IS NULL OR NOT (p_vers = ANY (p_jours)) THEN
      RAISE EXCEPTION 'RELANCE: le jour de destination doit faire partie des jours conserves.';
    END IF;
  END IF;

  -- 1. les jours demandes, crees ou renumerotes
  FOR i IN 1 .. array_length(p_jours, 1) LOOP
    INSERT INTO relance.campagne_jour (campagne_id, jour, ordre, cree_par)
    VALUES (p_campagne_id, p_jours[i], i, moi)
    ON CONFLICT (campagne_id, jour) DO UPDATE SET ordre = EXCLUDED.ordre;
  END LOOP;

  -- 2. les RDV deplaces, APRES la creation des jours de destination
  IF impactes > 0 THEN
    UPDATE relance.rdv r
       SET jour = p_vers, modifie_le = now(), modifie_par = moi
     WHERE r.campagne_id = p_campagne_id
       AND r.jour = ANY (retires);
  END IF;

  -- 3. les jours retires, une fois vides
  IF array_length(retires, 1) IS NOT NULL THEN
    DELETE FROM relance.campagne_jour cj
     WHERE cj.campagne_id = p_campagne_id AND cj.jour = ANY (retires);
  END IF;

  RETURN jsonb_build_object(
    'applique', true,
    'retires', to_jsonb(retires),
    'ajoutes', to_jsonb(ajoutes),
    'rdvDeplaces', impactes,
    'versJour', to_jsonb(p_vers),
    'jours', (SELECT coalesce(jsonb_agg(jsonb_build_object('jour', cj.jour, 'ordre', cj.ordre) ORDER BY cj.ordre), '[]'::jsonb)
                FROM relance.campagne_jour cj WHERE cj.campagne_id = p_campagne_id)
  );
END $$;


--
-- Name: campagne_ouverte(bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.campagne_ouverte(p_campagne_id bigint) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
  SELECT EXISTS (
    SELECT 1 FROM relance.campagne c
    WHERE c.id = p_campagne_id
      AND NOT c.cloturee
      AND c.archive_le IS NULL
  )
$$;


--
-- Name: diffuser_rdv(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.diffuser_rdv() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
BEGIN
  PERFORM realtime.send(
    -- LA CHARGE UTILE NE PORTE NI `client` NI `commentaire`. Meme regle que la vue
    -- `rdv_agrege`, et elle est structurelle : il n'y a pas de champ a oublier de
    -- retirer, il n'y en a jamais eu.
    jsonb_build_object(
      'id', NEW.id::text,
      'vendeurId', NEW.vendeur_id::text,
      'jour', NEW.jour,
      'creneauCode', NEW.creneau_code,
      'marqueId', NEW.marque_id::text,
      'typeVehicule', NEW.type_vehicule,
      'archive', NEW.archive_le IS NOT NULL,
      -- QUI A ECRIT — pour que l'auteur ignore son propre evenement. Il a deja
      -- applique le changement localement (F-C.4) ; le lui rejouer provoquerait un
      -- second rendu, et pendant une saisie au clavier ce scintillement se voit.
      'auteur', coalesce(NEW.modifie_par, NEW.cree_par)::text
    ),
    'rdv',
    'campagne-' || NEW.campagne_id::text,
    true
  );
  RETURN NULL;
END $$;


--
-- Name: exiger_administration(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.exiger_administration() RETURNS bigint
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE moi bigint := relance.utilisateur_courant();
BEGIN
  IF moi IS NULL THEN
    RAISE EXCEPTION 'RELANCE: authentification requise.';
  END IF;
  IF NOT relance.peut_administrer() THEN
    RAISE EXCEPTION 'RELANCE: cette action demande le niveau administrateur ou direction.';
  END IF;
  RETURN moi;
END $$;


--
-- Name: exiger_gestion_comptes(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.exiger_gestion_comptes() RETURNS bigint
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE moi bigint := relance.utilisateur_courant();
BEGIN
  IF moi IS NULL THEN
    RAISE EXCEPTION 'RELANCE: authentification requise.';
  END IF;
  -- `admin` SEUL. C'est la frontiere qui empeche `direction` de se promouvoir,
  -- et elle ne doit jamais etre elargie « pour simplifier ».
  IF NOT relance.peut_gerer_utilisateurs() THEN
    RAISE EXCEPTION 'RELANCE: la gestion des comptes est reservee aux administrateurs.';
  END IF;
  RETURN moi;
END $$;


--
-- Name: exiger_session(bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.exiger_session(p_session_id bigint) RETURNS bigint
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.utilisateur_courant();
  campagne bigint;
BEGIN
  IF moi IS NULL THEN
    RAISE EXCEPTION 'RELANCE: authentification requise.';
  END IF;
  SELECT sp.campagne_id INTO campagne FROM relance.session_plaque sp WHERE sp.id = p_session_id;
  IF campagne IS NULL THEN
    RAISE EXCEPTION 'RELANCE: session introuvable.';
  END IF;
  IF NOT relance.peut_administrer_session(p_session_id) THEN
    RAISE EXCEPTION 'RELANCE: vous n''administrez pas cette plaque sur cette campagne.';
  END IF;
  -- R-C.3. Repete ici parce qu'une session close ne doit pas non plus voir sa
  -- composition changer — le trigger sur `rdv` ne couvre que les RDV.
  IF NOT relance.campagne_ouverte(campagne) THEN
    RAISE EXCEPTION 'RELANCE: cette campagne est cloturee, sa composition n''est plus modifiable.';
  END IF;
  RETURN moi;
END $$;


--
-- Name: interdire_suppression(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.interdire_suppression() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'relance', 'public'
    AS $$
BEGIN
  -- La porte : ouverte pour la duree d'UNE transaction, par la route de purge et
  -- par elle seule. `current_setting(..., true)` rend NULL si le parametre n'a
  -- jamais ete pose — donc le refus est bien le defaut, y compris sur une
  -- connexion neuve.
  IF coalesce(current_setting('relance.purge_autorisee', true), '') = 'oui' THEN
    RETURN NULL; -- trigger STATEMENT : la valeur de retour est ignoree
  END IF;

  RAISE EXCEPTION
    'RELANCE: suppression interdite sur %. Utiliser l''archivage (archive_le ou date_sortie). La purge definitive passe par l''ecran Archivage.',
    TG_TABLE_NAME;
END $$;


--
-- Name: peut_administrer(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.peut_administrer() RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
  SELECT relance.a_role_global('admin') OR relance.a_role_global('direction')
$$;


--
-- Name: peut_administrer_session(bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.peut_administrer_session(p_session_id bigint) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
  SELECT relance.peut_administrer()
      OR EXISTS (
        SELECT 1
        FROM relance.session_plaque sp
        JOIN relance.role_campagne rc
          ON rc.campagne_id = sp.campagne_id
         AND rc.plaque_id = sp.plaque_id
         AND rc.role = 'chef_plaque'
         AND rc.archive_le IS NULL
         AND rc.utilisateur_id = relance.utilisateur_courant()
        WHERE sp.id = p_session_id
      )
$$;


--
-- Name: peut_gerer_utilisateurs(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.peut_gerer_utilisateurs() RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
  SELECT relance.a_role_global('admin')
$$;


--
-- Name: peut_saisir(bigint, bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.peut_saisir(p_vendeur_id bigint, p_campagne_id bigint) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
  SELECT EXISTS (
    SELECT 1 FROM relance.perimetre_saisie ps
    WHERE ps.vendeur_id = p_vendeur_id
      AND ps.campagne_id = p_campagne_id
  )
$$;


--
-- Name: poser_capacites(bigint, bigint[], text, bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.poser_capacites(p_vendeur_id bigint, p_marque_ids bigint[], p_type_vehicule text, p_par bigint) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE m bigint;
BEGIN
  DELETE FROM relance.vendeur_marque WHERE vendeur_id = p_vendeur_id;
  IF p_type_vehicule <> 'VO' AND p_marque_ids IS NOT NULL THEN
    FOREACH m IN ARRAY p_marque_ids LOOP
      INSERT INTO relance.vendeur_marque (vendeur_id, marque_id, cree_par)
      VALUES (p_vendeur_id, m, p_par)
      ON CONFLICT DO NOTHING;
    END LOOP;
  END IF;

  -- PROVENANCE, pas un statut : qui a change les capacites et quand. La notion de
  -- « confirme / placeholder » a ete retiree — un vendeur en base est valide. Ces
  -- deux colonnes servent le jour ou un RDV est refuse sans que personne comprenne.
  UPDATE relance.vendeur
     SET type_vehicule = p_type_vehicule,
         capacites_confirmees_le = now(),
         capacites_confirmees_par = p_par
   WHERE id = p_vendeur_id;
END $$;


--
-- Name: session_appliquer_repartition(bigint, jsonb, boolean); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.session_appliquer_repartition(p_session_id bigint, p_placements jsonb, p_remplacer boolean DEFAULT false) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_session(p_session_id);
  place int := 0;
  p jsonb;
  v jsonb;
  t bigint;
BEGIN
  -- `remplacer` REFAIT la composition entiere : toutes les affectations actives de
  -- la session sont archivees avant de replacer. Derriere une confirmation dans
  -- l'interface, jamais par defaut.
  IF p_remplacer THEN
    UPDATE relance.affectation a SET archive_le = now()
      FROM relance.table_phoning t
     WHERE t.id = a.table_id
       AND t.session_plaque_id = p_session_id
       AND a.archive_le IS NULL;
  END IF;

  FOR p IN SELECT jsonb_array_elements(coalesce(p_placements, '[]'::jsonb)) LOOP
    t := (p->>'tableId')::bigint;

    -- La table doit appartenir A CETTE session : sans ce controle, un appelant
    -- autorise sur sa plaque pourrait ecrire dans les tables d'une autre.
    IF NOT EXISTS (
      SELECT 1 FROM relance.table_phoning tp
       WHERE tp.id = t AND tp.session_plaque_id = p_session_id AND tp.archive_le IS NULL
    ) THEN
      RAISE EXCEPTION 'RELANCE: la table % n''appartient pas a cette session.', t;
    END IF;

    FOR v IN SELECT jsonb_array_elements(coalesce(p->'vendeurIdsAjoutes', '[]'::jsonb)) LOOP
      INSERT INTO relance.affectation (table_id, vendeur_id, origine, cree_par)
      VALUES (t, (v#>>'{}')::bigint, 'auto', moi)
      ON CONFLICT (table_id, vendeur_id) DO UPDATE SET archive_le = NULL, origine = 'auto';
      place := place + 1;
    END LOOP;
  END LOOP;

  RETURN jsonb_build_object('graine', 42, 'remplacer', p_remplacer, 'affectations', place);
END $$;


--
-- Name: session_reprendre(bigint, bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.session_reprendre(p_session_id bigint, p_depuis_campagne_id bigint) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_session(p_session_id);
  plaque bigint;
  campagne bigint;
  source bigint;
  tables_creees int := 0;
  reprises int := 0;
  reportes jsonb := '[]'::jsonb;
  t record;
  a record;
  cible bigint;
  existait boolean;
BEGIN
  SELECT sp.plaque_id, sp.campagne_id INTO plaque, campagne
    FROM relance.session_plaque sp WHERE sp.id = p_session_id;

  IF p_depuis_campagne_id = campagne THEN
    RAISE EXCEPTION 'RELANCE: la campagne source doit etre une AUTRE campagne.';
  END IF;

  SELECT sp.id INTO source
    FROM relance.session_plaque sp
   WHERE sp.campagne_id = p_depuis_campagne_id
     AND sp.plaque_id = plaque
     AND sp.archive_le IS NULL;
  IF source IS NULL THEN
    RAISE EXCEPTION 'RELANCE: cette plaque n''avait aucune session sur la campagne demandee.';
  END IF;

  FOR t IN
    SELECT tp.id, tp.libelle, tp.ordre, tp.chef_utilisateur_id, tp.marque_id
      FROM relance.table_phoning tp
     WHERE tp.session_plaque_id = source AND tp.archive_le IS NULL
     ORDER BY tp.ordre
  LOOP
    SELECT tp.id INTO cible
      FROM relance.table_phoning tp
     WHERE tp.session_plaque_id = p_session_id AND tp.libelle = t.libelle;
    existait := cible IS NOT NULL;

    IF existait THEN
      UPDATE relance.table_phoning
         SET archive_le = NULL, ordre = t.ordre,
             chef_utilisateur_id = t.chef_utilisateur_id, marque_id = t.marque_id
       WHERE id = cible;
    ELSE
      INSERT INTO relance.table_phoning (session_plaque_id, libelle, ordre, chef_utilisateur_id, marque_id, cree_par)
      VALUES (p_session_id, t.libelle, t.ordre, t.chef_utilisateur_id, t.marque_id, moi)
      RETURNING id INTO cible;
      tables_creees := tables_creees + 1;
    END IF;

    FOR a IN
      SELECT v.id, v.nom, v.site_id
        FROM relance.affectation af
        JOIN relance.vendeur v ON v.id = af.vendeur_id
       WHERE af.table_id = t.id AND af.archive_le IS NULL
    LOOP
      -- ELIGIBILITE : present pendant LA NOUVELLE campagne, et toujours de cette
      -- plaque. Les deux conditions sont verifiees ici EN PLUS du trigger, pour
      -- pouvoir NOMMER ceux qu'on laisse de cote plutot que d'echouer en bloc.
      IF NOT EXISTS (
        SELECT 1
          FROM relance.vendeur vv
          JOIN relance.site s ON s.id = vv.site_id
          JOIN relance.campagne c ON c.id = campagne
         WHERE vv.id = a.id
           AND s.plaque_id = plaque
           AND vv.archive_le IS NULL
           AND (vv.date_entree IS NULL OR vv.date_entree <= c.date_fin)
           AND (vv.date_sortie IS NULL OR vv.date_sortie >= c.date_debut)
      ) THEN
        reportes := reportes || jsonb_build_object(
          'nom', a.nom,
          'raison', 'absent de cette campagne, ou rattache a une autre plaque');
        CONTINUE;
      END IF;

      INSERT INTO relance.affectation (table_id, vendeur_id, origine, cree_par)
      VALUES (cible, a.id, 'manuel', moi)
      ON CONFLICT (table_id, vendeur_id) DO UPDATE SET archive_le = NULL;
      reprises := reprises + 1;
    END LOOP;
  END LOOP;

  RETURN jsonb_build_object(
    'tablesCreees', tables_creees,
    'affectationsReprises', reprises,
    'reportes', reportes
  );
END $$;


--
-- Name: table_archiver(bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.table_archiver(p_table_id bigint) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  session_id bigint;
  libelle text;
  n int;
BEGIN
  SELECT t.session_plaque_id, t.libelle INTO session_id, libelle
    FROM relance.table_phoning t WHERE t.id = p_table_id;
  IF session_id IS NULL THEN
    RAISE EXCEPTION 'RELANCE: table introuvable.';
  END IF;
  PERFORM relance.exiger_session(session_id);

  UPDATE relance.table_phoning SET archive_le = now() WHERE id = p_table_id;
  UPDATE relance.affectation SET archive_le = now()
   WHERE table_id = p_table_id AND archive_le IS NULL;
  GET DIAGNOSTICS n = ROW_COUNT;

  RETURN jsonb_build_object(
    'archivee', libelle,
    'affectationsArchivees', n,
    'sessionId', session_id::text,
    'message', format(
      '« %s » est archivee, pas supprimee : sa composition reste consultable. %s vendeur(s) reviennent en reserve et restent saisissables par leur chef de site.',
      libelle, n)
  );
END $$;


--
-- Name: table_definir_vendeurs(bigint, bigint[]); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.table_definir_vendeurs(p_table_id bigint, p_vendeur_ids bigint[]) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint;
  session_id bigint;
  ids bigint[] := coalesce(p_vendeur_ids, '{}');
  retires int;
  v bigint;
BEGIN
  SELECT t.session_plaque_id INTO session_id
    FROM relance.table_phoning t WHERE t.id = p_table_id AND t.archive_le IS NULL;
  IF session_id IS NULL THEN
    RAISE EXCEPTION 'RELANCE: table introuvable ou archivee.';
  END IF;
  moi := relance.exiger_session(session_id);

  UPDATE relance.affectation SET archive_le = now()
   WHERE table_id = p_table_id AND archive_le IS NULL AND NOT (vendeur_id = ANY (ids));
  GET DIAGNOSTICS retires = ROW_COUNT;

  -- Un a un, et non en bloc : les triggers R-B.1 (meme plaque), R-B.4 (une seule
  -- table par campagne) et R-B.5 (marque de la table) sont `FOR EACH ROW`. Leurs
  -- messages, deja ecrits pour un humain, remontent tels quels a l'appelant.
  FOREACH v IN ARRAY ids LOOP
    INSERT INTO relance.affectation (table_id, vendeur_id, origine, cree_par)
    VALUES (p_table_id, v, 'manuel', moi)
    ON CONFLICT (table_id, vendeur_id)
      DO UPDATE SET archive_le = NULL, origine = 'manuel';
  END LOOP;

  RETURN jsonb_build_object(
    'retires', retires,
    'effectif', coalesce(array_length(ids, 1), 0),
    'sessionId', session_id::text
  );
END $$;


--
-- Name: tracer_creation(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.tracer_creation() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.utilisateur_courant();
BEGIN
  IF moi IS NOT NULL THEN
    NEW.cree_par := moi;
  END IF;
  RETURN NEW;
END $$;


--
-- Name: tracer_modification_rdv(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.tracer_modification_rdv() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.utilisateur_courant();
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF moi IS NOT NULL THEN NEW.cree_par := moi; END IF;
    RETURN NEW;
  END IF;

  IF moi IS NOT NULL THEN
    NEW.modifie_par := moi;
    -- L'ARCHIVAGE EST UN UPDATE, c'est la seule facon de retirer un RDV. On veut
    -- donc savoir qui l'a retire, et pas seulement qui l'a modifie en dernier.
    IF NEW.archive_le IS NOT NULL AND OLD.archive_le IS NULL THEN
      NEW.archive_par := moi;
    END IF;
  END IF;
  NEW.modifie_le := now();

  -- `cree_par` et `cree_le` ne se reecrivent jamais. Sans cette ligne, un client
  -- pourrait se declarer auteur d'un RDV saisi par quelqu'un d'autre en le
  -- modifiant — l'attribution serait alors reecrivable a volonte.
  NEW.cree_par := OLD.cree_par;
  NEW.cree_le := OLD.cree_le;
  RETURN NEW;
END $$;


--
-- Name: utilisateur_courant(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.utilisateur_courant() RETURNS bigint
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
  SELECT u.id
  FROM relance.utilisateur u
  WHERE u.auth_uid = auth.uid()
    AND u.actif
    AND u.archive_le IS NULL
$$;


--
-- Name: utilisateur_definir_encadrement(bigint, text, bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.utilisateur_definir_encadrement(p_site_id bigint, p_role text, p_utilisateur_id bigint DEFAULT NULL::bigint) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_gestion_comptes();
BEGIN
  IF p_role NOT IN ('chef_de_site', 'chef_de_vente_vn', 'chef_de_vente_vo') THEN
    RAISE EXCEPTION 'RELANCE: role invalide : chef_de_site, chef_de_vente_vn ou chef_de_vente_vo.';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM relance.site WHERE id = p_site_id AND archive_le IS NULL) THEN
    RAISE EXCEPTION 'RELANCE: site introuvable ou archive.';
  END IF;

  IF p_utilisateur_id IS NULL THEN
    UPDATE relance.encadrement_site SET archive_le = now()
     WHERE site_id = p_site_id AND role = p_role AND archive_le IS NULL;
    RETURN jsonb_build_object('libere', true, 'siteId', p_site_id::text, 'role', p_role);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM relance.utilisateur
     WHERE id = p_utilisateur_id AND actif AND archive_le IS NULL
  ) THEN
    RAISE EXCEPTION 'RELANCE: ce compte est introuvable ou desactive.';
  END IF;

  -- ON LIBERE LE ROLE AVANT DE LE DONNER. L'unique `(site, role)` refuse deux
  -- titulaires : l'ordre inverse echouerait. Meme piege que sur l'ecran des
  -- encadrants, ou deux requetes lancees en parallele se marchaient dessus.
  UPDATE relance.encadrement_site SET archive_le = now()
   WHERE site_id = p_site_id AND role = p_role AND archive_le IS NULL
     AND utilisateur_id <> p_utilisateur_id;

  INSERT INTO relance.encadrement_site (site_id, role, utilisateur_id, cree_par)
  VALUES (p_site_id, p_role, p_utilisateur_id, moi)
  ON CONFLICT (site_id, role) DO UPDATE
    SET utilisateur_id = EXCLUDED.utilisateur_id, archive_le = NULL;

  RETURN jsonb_build_object('siteId', p_site_id::text, 'role', p_role,
                            'utilisateurId', p_utilisateur_id::text);
END $$;


--
-- Name: utilisateur_definir_roles(bigint, text); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.utilisateur_definir_roles(p_utilisateur_id bigint, p_role text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_gestion_comptes();
  etait_admin boolean;
  autres_admins int;
BEGIN
  IF p_role IS NOT NULL AND p_role NOT IN ('admin', 'direction', 'lecteur') THEN
    RAISE EXCEPTION 'RELANCE: role inconnu : admin, direction ou lecteur.';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM relance.utilisateur WHERE id = p_utilisateur_id) THEN
    RAISE EXCEPTION 'RELANCE: compte introuvable.';
  END IF;

  -- LE DERNIER ADMINISTRATEUR NE PEUT PAS ETRE DEGRADE. Sans ce controle,
  -- l'application devient inadministrable et plus personne ne peut creer de compte
  -- — y compris pour se redonner le role.
  SELECT EXISTS (
    SELECT 1 FROM relance.role_global WHERE utilisateur_id = p_utilisateur_id AND role = 'admin'
  ) INTO etait_admin;

  IF etait_admin AND coalesce(p_role, '') <> 'admin' THEN
    SELECT count(*)::int INTO autres_admins
      FROM relance.role_global rg
      JOIN relance.utilisateur u ON u.id = rg.utilisateur_id
     WHERE rg.role = 'admin' AND rg.utilisateur_id <> p_utilisateur_id
       AND u.actif AND u.archive_le IS NULL;
    IF autres_admins = 0 THEN
      RAISE EXCEPTION 'RELANCE: c''est le dernier administrateur actif : le degrader rendrait l''application inadministrable. Nommer un autre administrateur d''abord.';
    END IF;
  END IF;

  DELETE FROM relance.role_global WHERE utilisateur_id = p_utilisateur_id;
  IF p_role IS NOT NULL THEN
    INSERT INTO relance.role_global (utilisateur_id, role, cree_par)
    VALUES (p_utilisateur_id, p_role, moi);
  END IF;

  RETURN jsonb_build_object('utilisateurId', p_utilisateur_id::text, 'role', to_jsonb(p_role));
END $$;


--
-- Name: utilisateur_purger(bigint, text); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.utilisateur_purger(p_utilisateur_id bigint, p_confirmation text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_gestion_comptes();
  nom_exact text;
  attaches text[] := '{}';
BEGIN
  SELECT u.nom INTO nom_exact FROM relance.utilisateur u WHERE u.id = p_utilisateur_id;
  IF nom_exact IS NULL THEN
    RAISE EXCEPTION 'RELANCE: compte introuvable.';
  END IF;
  IF p_utilisateur_id = moi THEN
    RAISE EXCEPTION 'RELANCE: on ne supprime pas son propre compte.';
  END IF;

  -- CE QUI RETIENT UN COMPTE. Un compte qui explique encore quelque chose —
  -- l'auteur d'une saisie, le chef d'une table passee — n'est pas supprimable :
  -- l'historique deviendrait anonyme. Le desactiver conserve la trace sans donner
  -- aucun acces.
  IF EXISTS (SELECT 1 FROM relance.table_phoning WHERE chef_utilisateur_id = p_utilisateur_id) THEN
    attaches := attaches || 'des tables de phoning';
  END IF;
  IF EXISTS (SELECT 1 FROM relance.rdv WHERE cree_par = p_utilisateur_id OR modifie_par = p_utilisateur_id) THEN
    attaches := attaches || 'des RDV saisis';
  END IF;
  IF EXISTS (SELECT 1 FROM relance.vendeur WHERE utilisateur_id = p_utilisateur_id) THEN
    attaches := attaches || 'une fiche vendeur';
  END IF;
  IF array_length(attaches, 1) IS NOT NULL THEN
    RAISE EXCEPTION 'RELANCE: % ne peut pas etre supprime : son compte explique encore %. Le laisser desactive conserve cette trace sans lui donner aucun acces.',
      nom_exact, array_to_string(attaches, ', ');
  END IF;

  IF p_confirmation IS DISTINCT FROM nom_exact THEN
    RAISE EXCEPTION 'RELANCE: pour supprimer definitivement, retaper le nom exact. Attendu : « % ».', nom_exact;
  END IF;

  -- LA PORTE, ouverte pour cette seule transaction. `SET LOCAL` meurt avec elle :
  -- elle ne peut pas rester ouverte par oubli, et aucune autre session n'est
  -- affectee — contrairement a un `ALTER TABLE ... DISABLE TRIGGER`, qui aurait
  -- desarme le garde-fou pour tout le monde, y compris pendant une saisie.
  PERFORM set_config('relance.purge_autorisee', 'oui', true);
  DELETE FROM relance.encadrement_site WHERE utilisateur_id = p_utilisateur_id;
  DELETE FROM relance.role_global WHERE utilisateur_id = p_utilisateur_id;
  DELETE FROM relance.role_campagne WHERE utilisateur_id = p_utilisateur_id;
  DELETE FROM relance.utilisateur WHERE id = p_utilisateur_id;

  RETURN jsonb_build_object('supprime', nom_exact);
END $$;


--
-- Name: vendeur_appliquer_import_marques(jsonb); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.vendeur_appliquer_import_marques(p_lignes jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_administration();
  l jsonb;
  n int := 0;
  marques bigint[];
BEGIN
  FOR l IN SELECT jsonb_array_elements(coalesce(p_lignes, '[]'::jsonb)) LOOP
    SELECT coalesce(array_agg((m#>>'{}')::bigint), '{}')
      INTO marques
      FROM jsonb_array_elements(coalesce(l->'marqueIds', '[]'::jsonb)) m;

    PERFORM relance.poser_capacites(
      (l->>'vendeurId')::bigint, marques, l->>'typeVehicule', moi);
    n := n + 1;
  END LOOP;

  RETURN jsonb_build_object('appliquees', n);
END $$;


--
-- Name: vendeur_creer(text, bigint, text, bigint[], date); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.vendeur_creer(p_nom text, p_site_id bigint, p_type_vehicule text, p_marque_ids bigint[] DEFAULT '{}'::bigint[], p_date_entree date DEFAULT NULL::date) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_administration();
  nouveau bigint;
  nom text := btrim(coalesce(p_nom, ''));
BEGIN
  IF nom = '' THEN
    RAISE EXCEPTION 'RELANCE: le nom du vendeur est requis.';
  END IF;
  IF p_type_vehicule NOT IN ('VN', 'VO') THEN
    RAISE EXCEPTION 'RELANCE: le metier doit etre VN ou VO.';
  END IF;
  IF p_type_vehicule = 'VN' AND coalesce(array_length(p_marque_ids, 1), 0) = 0 THEN
    RAISE EXCEPTION 'RELANCE: un vendeur VN doit porter au moins une marque, sinon sa grille de saisie serait vide.';
  END IF;

  INSERT INTO relance.vendeur (nom, site_id, type_vehicule, date_entree, cree_par)
  VALUES (nom, p_site_id, p_type_vehicule, p_date_entree, moi)
  RETURNING id INTO nouveau;

  PERFORM relance.poser_capacites(nouveau, p_marque_ids, p_type_vehicule, moi);

  RETURN jsonb_build_object('id', nouveau::text, 'nom', nom);
END $$;


--
-- Name: vendeur_modifier(bigint, text, bigint, date, date, boolean, boolean, text, bigint[]); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.vendeur_modifier(p_vendeur_id bigint, p_nom text DEFAULT NULL::text, p_site_id bigint DEFAULT NULL::bigint, p_date_entree date DEFAULT NULL::date, p_date_sortie date DEFAULT NULL::date, p_archiver boolean DEFAULT NULL::boolean, p_changer_capacites boolean DEFAULT false, p_type_vehicule text DEFAULT NULL::text, p_marque_ids bigint[] DEFAULT NULL::bigint[]) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_administration();
BEGIN
  IF NOT EXISTS (SELECT 1 FROM relance.vendeur WHERE id = p_vendeur_id) THEN
    RAISE EXCEPTION 'RELANCE: vendeur introuvable.';
  END IF;

  UPDATE relance.vendeur
     SET nom = coalesce(btrim(p_nom), nom),
         site_id = coalesce(p_site_id, site_id),
         date_entree = CASE WHEN p_date_entree IS NOT NULL THEN p_date_entree ELSE date_entree END,
         date_sortie = CASE WHEN p_date_sortie IS NOT NULL THEN p_date_sortie ELSE date_sortie END,
         archive_le = CASE
                        WHEN p_archiver IS NULL THEN archive_le
                        WHEN p_archiver THEN coalesce(archive_le, now())
                        ELSE NULL
                      END,
         archive_par = CASE
                         WHEN p_archiver IS TRUE THEN moi
                         WHEN p_archiver IS FALSE THEN NULL
                         ELSE archive_par
                       END
   WHERE id = p_vendeur_id;

  IF p_changer_capacites THEN
    IF p_type_vehicule NOT IN ('VN', 'VO') THEN
      RAISE EXCEPTION 'RELANCE: le metier doit etre VN ou VO.';
    END IF;
    IF p_type_vehicule = 'VN' AND coalesce(array_length(p_marque_ids, 1), 0) = 0 THEN
      RAISE EXCEPTION 'RELANCE: un vendeur VN doit porter au moins une marque.';
    END IF;
    PERFORM relance.poser_capacites(p_vendeur_id, p_marque_ids, p_type_vehicule, moi);
  END IF;

  RETURN jsonb_build_object('id', p_vendeur_id::text);
END $$;


--
-- Name: vendeur_purger(bigint, text); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.vendeur_purger(p_vendeur_id bigint, p_confirmation text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_administration();
  nom_exact text;
  archive timestamptz;
  nb_rdv int;
  nb_aff int;
BEGIN
  SELECT v.nom, v.archive_le INTO nom_exact, archive
    FROM relance.vendeur v WHERE v.id = p_vendeur_id;
  IF nom_exact IS NULL THEN
    RAISE EXCEPTION 'RELANCE: vendeur introuvable.';
  END IF;

  -- DEUX VERROUS, ET LES DEUX COMPTENT. L'archivage prealable oblige a passer par
  -- un geste reversible avant l'irreversible ; retaper le nom empeche de purger
  -- une ligne pour une autre depuis une liste.
  IF archive IS NULL THEN
    RAISE EXCEPTION 'RELANCE: ce vendeur doit d''abord etre archive. La purge ne s''applique qu''a une fiche deja retiree.';
  END IF;
  IF p_confirmation IS DISTINCT FROM nom_exact THEN
    RAISE EXCEPTION 'RELANCE: pour purger definitivement, retaper le nom exact du vendeur. Attendu : « % ».', nom_exact;
  END IF;

  SELECT count(*)::int INTO nb_rdv FROM relance.rdv WHERE vendeur_id = p_vendeur_id;
  SELECT count(*)::int INTO nb_aff FROM relance.affectation WHERE vendeur_id = p_vendeur_id;

  PERFORM set_config('relance.purge_autorisee', 'oui', true);
  DELETE FROM relance.rdv WHERE vendeur_id = p_vendeur_id;
  DELETE FROM relance.affectation WHERE vendeur_id = p_vendeur_id;
  DELETE FROM relance.vendeur_marque WHERE vendeur_id = p_vendeur_id;
  DELETE FROM relance.vendeur WHERE id = p_vendeur_id;

  RETURN jsonb_build_object(
    'purge', nom_exact, 'nbRdv', nb_rdv, 'nbAffectations', nb_aff,
    'message', format(
      '%s est definitivement supprime, avec %s RDV et %s affectation(s). Les totaux des campagnes concernees ont change. C''est irreversible.',
      nom_exact, nb_rdv, nb_aff)
  );
END $$;


--
-- Name: verifier_affectation_marque_table(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_affectation_marque_table() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public'
    AS $$
DECLARE
  marque_table   bigint;
  libelle_marque text;
  libelle_table  text;
  type_vendeur   text;
  nom_vendeur    text;
  autorise       boolean;
BEGIN
  -- Une ligne archivee ne rattache plus personne.
  IF NEW.archive_le IS NOT NULL THEN
    RETURN NEW;
  END IF;

  SELECT t.marque_id, t.libelle INTO marque_table, libelle_table
  FROM table_phoning t WHERE t.id = NEW.table_id;

  -- Table mixte : aucune contrainte. Cas normal.
  IF marque_table IS NULL THEN
    RETURN NEW;
  END IF;

  SELECT v.type_vehicule, v.nom INTO type_vendeur, nom_vendeur
  FROM vendeur v WHERE v.id = NEW.vendeur_id;

  IF type_vendeur IS NULL THEN
    -- Vendeur inexistant : la cle etrangere s'en charge, on ne masque pas son
    -- message par le notre.
    RETURN NEW;
  END IF;

  SELECT m.libelle INTO libelle_marque FROM marque m WHERE m.id = marque_table;

  IF type_vendeur = 'VO' THEN
    RAISE EXCEPTION
      'RELANCE: % est un vendeur VO et n''a aucune ventilation par marque : il ne peut pas rejoindre la table "%", specialisee %.',
      nom_vendeur, libelle_table, libelle_marque;
  END IF;

  SELECT EXISTS (
    SELECT 1 FROM vendeur_marque vm
    WHERE vm.vendeur_id = NEW.vendeur_id AND vm.marque_id = marque_table
  ) INTO autorise;

  IF NOT autorise THEN
    RAISE EXCEPTION
      'RELANCE: % n''est pas autorise a vendre % : il ne peut pas rejoindre la table "%", specialisee sur cette marque.',
      nom_vendeur, libelle_marque, libelle_table;
  END IF;

  RETURN NEW;
END $$;


--
-- Name: verifier_affectation_meme_plaque(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_affectation_meme_plaque() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public'
    AS $$
DECLARE
  plaque_table   bigint;
  plaque_vendeur bigint;
  libelle_table  text;
  nom_vendeur    text;
BEGIN
  -- Une ligne archivee ne rattache plus personne : inutile de la contraindre, et
  -- la contraindre empecherait d'archiver une affectation devenue invalide apres
  -- un changement de plaque d'un site.
  IF NEW.archive_le IS NOT NULL THEN
    RETURN NEW;
  END IF;

  SELECT s.plaque_id, t.libelle
    INTO plaque_table, libelle_table
  FROM table_phoning  t
  JOIN session_plaque s ON s.id = t.session_plaque_id
  WHERE t.id = NEW.table_id;

  SELECT si.plaque_id, v.nom
    INTO plaque_vendeur, nom_vendeur
  FROM vendeur v
  JOIN site si ON si.id = v.site_id
  WHERE v.id = NEW.vendeur_id;

  IF plaque_table IS NULL OR plaque_vendeur IS NULL THEN
    -- Table ou vendeur inexistant : les cles etrangeres s'en chargent, on ne
    -- masque pas leur message par le notre.
    RETURN NEW;
  END IF;

  IF plaque_table <> plaque_vendeur THEN
    RAISE EXCEPTION
      'RELANCE: % appartient a une autre plaque que la table "%". Une table ne peut contenir que des vendeurs de sa propre plaque.',
      nom_vendeur, libelle_table;
  END IF;

  RETURN NEW;
END $$;


--
-- Name: verifier_affectation_presence(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_affectation_presence() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  v      record;
  c      record;
BEGIN
  -- ARCHIVER RESTE TOUJOURS POSSIBLE. Sans cette sortie, retirer de sa table un
  -- vendeur qui vient de partir serait refuse par le controle cense l'empecher
  -- d'y etre : on ne pourrait plus corriger la situation qu'on denonce.
  IF NEW.archive_le IS NOT NULL THEN
    RETURN NEW;
  END IF;

  SELECT ve.nom, ve.date_entree, ve.date_sortie, ve.archive_le
    INTO v
    FROM relance.vendeur ve
   WHERE ve.id = NEW.vendeur_id;

  SELECT ca.libelle, ca.date_debut, ca.date_fin
    INTO c
    FROM relance.table_phoning tp
    JOIN relance.session_plaque sp ON sp.id = tp.session_plaque_id
    JOIN relance.campagne ca       ON ca.id = sp.campagne_id
   WHERE tp.id = NEW.table_id;

  IF v IS NULL OR c IS NULL THEN
    RETURN NEW; -- les cles etrangeres s'en chargeront, ce n'est pas notre role
  END IF;

  IF v.archive_le IS NOT NULL THEN
    RAISE EXCEPTION 'RELANCE: % est archive : il ne peut etre affecte a aucune table.', v.nom;
  END IF;

  -- MEME REGLE, MOT POUR MOT, QUE `relance.perimetre_saisie`. Une date nulle
  -- signifie << depuis toujours >> ou << pour toujours >> : le fichier source
  -- n'a pas les dates d'entree des 99 vendeurs importes.
  IF v.date_entree IS NOT NULL AND v.date_entree > c.date_fin THEN
    RAISE EXCEPTION
      'RELANCE: % entre le % : il n''etait pas encore la pendant « % » (% au %).',
      v.nom, to_char(v.date_entree, 'DD/MM/YYYY'), c.libelle,
      to_char(c.date_debut, 'DD/MM/YYYY'), to_char(c.date_fin, 'DD/MM/YYYY');
  END IF;

  IF v.date_sortie IS NOT NULL AND v.date_sortie < c.date_debut THEN
    RAISE EXCEPTION
      'RELANCE: % est sorti le % : il n''etait plus la pendant « % » (% au %).',
      v.nom, to_char(v.date_sortie, 'DD/MM/YYYY'), c.libelle,
      to_char(c.date_debut, 'DD/MM/YYYY'), to_char(c.date_fin, 'DD/MM/YYYY');
  END IF;

  RETURN NEW;
END
$$;


--
-- Name: verifier_affectation_unique(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_affectation_unique() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public'
    AS $$
DECLARE
  autre_table text;
BEGIN
  -- Une ligne archivee ne reserve pas la place du vendeur.
  IF NEW.archive_le IS NOT NULL THEN
    RETURN NEW;
  END IF;

  SELECT t_autre.libelle INTO autre_table
  FROM affectation a
  JOIN table_phoning  t_autre ON t_autre.id = a.table_id
  JOIN session_plaque s_autre ON s_autre.id = t_autre.session_plaque_id
  JOIN table_phoning  t_new   ON t_new.id   = NEW.table_id
  JOIN session_plaque s_new   ON s_new.id   = t_new.session_plaque_id
  WHERE a.vendeur_id = NEW.vendeur_id
    AND a.archive_le IS NULL
    -- Cle METIER, pas identite technique : voir l'explication ci-dessus.
    AND a.table_id <> NEW.table_id
    AND s_autre.campagne_id = s_new.campagne_id
  LIMIT 1;

  IF autre_table IS NOT NULL THEN
    RAISE EXCEPTION 'RELANCE: ce vendeur est deja affecte a la table "%" pour cette campagne.', autre_table;
  END IF;

  RETURN NEW;
END $$;


--
-- Name: verifier_campagne_ouverte(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_campagne_ouverte() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public'
    AS $$
DECLARE
  c record;
BEGIN
  SELECT libelle, cloturee, archive_le INTO c
  FROM campagne
  WHERE id = COALESCE(NEW.campagne_id, OLD.campagne_id);

  IF c.cloturee THEN
    RAISE EXCEPTION 'RELANCE: la campagne "%" est cloturee, plus aucune saisie n''est possible.', c.libelle;
  END IF;

  IF c.archive_le IS NOT NULL THEN
    RAISE EXCEPTION 'RELANCE: la campagne "%" est archivee.', c.libelle;
  END IF;

  RETURN COALESCE(NEW, OLD);
END $$;


--
-- Name: verifier_encadrant_actif(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_encadrant_actif() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public'
    AS $$
DECLARE
  nom_compte text;
  compte_actif boolean;
  compte_archive timestamptz;
BEGIN
  IF NEW.archive_le IS NOT NULL THEN
    RETURN NEW;
  END IF;

  SELECT u.nom, u.actif, u.archive_le
    INTO nom_compte, compte_actif, compte_archive
  FROM utilisateur u WHERE u.id = NEW.utilisateur_id;

  IF nom_compte IS NULL THEN
    RETURN NEW; -- la cle etrangere s'en charge
  END IF;

  IF NOT compte_actif OR compte_archive IS NOT NULL THEN
    RAISE EXCEPTION
      'RELANCE: le compte de % est desactive : il ne peut pas encadrer un site. Le reactiver dans la gestion des comptes.',
      nom_compte;
  END IF;

  RETURN NEW;
END $$;


--
-- Name: verifier_marque_autorisee(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_marque_autorisee() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public'
    AS $$
DECLARE
  nom_vendeur text;
  nom_marque  text;
BEGIN
  IF NEW.marque_id IS NULL THEN
    RETURN NEW;
  END IF;

  IF EXISTS (
    SELECT 1 FROM vendeur_marque vm
    WHERE vm.vendeur_id = NEW.vendeur_id AND vm.marque_id = NEW.marque_id
  ) THEN
    RETURN NEW;
  END IF;

  SELECT v.nom INTO nom_vendeur FROM vendeur v WHERE v.id = NEW.vendeur_id;
  SELECT m.libelle INTO nom_marque FROM marque  m WHERE m.id = NEW.marque_id;

  RAISE EXCEPTION 'RELANCE: % n''est pas autorise a vendre %.',
    COALESCE(nom_vendeur, 'ce vendeur'), COALESCE(nom_marque, 'cette marque');
END $$;


--
-- Name: verifier_marque_selon_metier(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_marque_selon_metier() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public'
    AS $$
DECLARE
  v record;
BEGIN
  SELECT nom, type_vehicule INTO v FROM vendeur WHERE id = NEW.vendeur_id;

  IF v.type_vehicule = 'VO' AND NEW.marque_id IS NOT NULL THEN
    RAISE EXCEPTION 'RELANCE: % est un vendeur VO, ses RDV ne portent pas de marque.', v.nom;
  END IF;

  IF v.type_vehicule = 'VN' AND NEW.marque_id IS NULL THEN
    RAISE EXCEPTION 'RELANCE: % est un vendeur VN, la marque du RDV est obligatoire.', v.nom;
  END IF;

  RETURN NEW;
END $$;


--
-- Name: verifier_type_coherent(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_type_coherent() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public'
    AS $$
DECLARE
  v record;
BEGIN
  SELECT nom, type_vehicule INTO v FROM vendeur WHERE id = NEW.vendeur_id;

  IF v.type_vehicule <> NEW.type_vehicule THEN
    RAISE EXCEPTION 'RELANCE: % est un vendeur %, il ne peut pas recevoir un RDV %.',
      v.nom, v.type_vehicule, NEW.type_vehicule;
  END IF;

  RETURN NEW;
END $$;


--
-- Name: verifier_vendeur_dates_contre_rdv(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_vendeur_dates_contre_rdv() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  conflit record;
BEGIN
  -- Rien a verifier si les deux dates sont inchangees. Un vendeur se modifie
  -- souvent (nom, marques, site) et cette requete n'a pas a tourner pour rien.
  IF TG_OP = 'UPDATE'
     AND NEW.date_entree IS NOT DISTINCT FROM OLD.date_entree
     AND NEW.date_sortie IS NOT DISTINCT FROM OLD.date_sortie THEN
    RETURN NEW;
  END IF;

  IF NEW.date_entree IS NULL AND NEW.date_sortie IS NULL THEN
    RETURN NEW; -- present depuis toujours et pour toujours : rien ne peut clocher
  END IF;

  SELECT c.libelle, c.date_debut, c.date_fin, count(*) AS n
    INTO conflit
    FROM relance.rdv r
    JOIN relance.campagne c ON c.id = r.campagne_id
   WHERE r.vendeur_id = NEW.id
     AND r.archive_le IS NULL
     AND (
       (NEW.date_entree IS NOT NULL AND NEW.date_entree > c.date_fin)
       OR (NEW.date_sortie IS NOT NULL AND NEW.date_sortie < c.date_debut)
     )
   GROUP BY c.id, c.libelle, c.date_debut, c.date_fin
   ORDER BY c.date_debut
   LIMIT 1;

  IF conflit IS NOT NULL THEN
    RAISE EXCEPTION
      'RELANCE: % a % RDV sur « % » (% au %). Ces dates l''en excluraient, et ses RDV disparaitraient des totaux. Archiver ces RDV d''abord si c''est bien voulu.',
      NEW.nom, conflit.n, conflit.libelle,
      to_char(conflit.date_debut, 'DD/MM/YYYY'), to_char(conflit.date_fin, 'DD/MM/YYYY');
  END IF;

  RETURN NEW;
END
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: affectation; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.affectation (
    id bigint NOT NULL,
    table_id bigint NOT NULL,
    vendeur_id bigint NOT NULL,
    origine text DEFAULT 'manuel'::text NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone,
    CONSTRAINT affectation_origine_check CHECK ((origine = ANY (ARRAY['auto'::text, 'manuel'::text])))
);


--
-- Name: affectation_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.affectation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: affectation_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.affectation_id_seq OWNED BY relance.affectation.id;


--
-- Name: campagne; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.campagne (
    id bigint NOT NULL,
    libelle text NOT NULL,
    date_debut date NOT NULL,
    date_fin date NOT NULL,
    cloturee boolean DEFAULT false NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone,
    CONSTRAINT campagne_dates_coherentes_check CHECK ((date_fin >= date_debut))
);


--
-- Name: campagne_creneau; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.campagne_creneau (
    campagne_id bigint NOT NULL,
    code text NOT NULL,
    libelle text NOT NULL,
    ordre integer NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint
);


--
-- Name: campagne_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.campagne_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: campagne_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.campagne_id_seq OWNED BY relance.campagne.id;


--
-- Name: campagne_jour; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.campagne_jour (
    campagne_id bigint NOT NULL,
    jour date NOT NULL,
    ordre integer NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint
);


--
-- Name: encadrement_site; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.encadrement_site (
    id bigint NOT NULL,
    site_id bigint NOT NULL,
    role text NOT NULL,
    utilisateur_id bigint NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT now() NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone,
    CONSTRAINT encadrement_site_role_check CHECK ((role = ANY (ARRAY['chef_de_site'::text, 'chef_de_vente_vn'::text, 'chef_de_vente_vo'::text])))
);


--
-- Name: encadrement_site_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.encadrement_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: encadrement_site_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.encadrement_site_id_seq OWNED BY relance.encadrement_site.id;


--
-- Name: marque; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.marque (
    id bigint NOT NULL,
    code text NOT NULL,
    libelle text NOT NULL,
    ordre integer DEFAULT 0 NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone
);


--
-- Name: marque_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.marque_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: marque_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.marque_id_seq OWNED BY relance.marque.id;


--
-- Name: role_campagne; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.role_campagne (
    id bigint NOT NULL,
    campagne_id bigint NOT NULL,
    utilisateur_id bigint NOT NULL,
    role text NOT NULL,
    plaque_id bigint,
    site_id bigint,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone,
    CONSTRAINT role_campagne_portee_check CHECK ((((role = 'chef_plaque'::text) AND (plaque_id IS NOT NULL) AND (site_id IS NULL)) OR ((role = 'chef_site'::text) AND (site_id IS NOT NULL) AND (plaque_id IS NULL)))),
    CONSTRAINT role_campagne_role_check CHECK ((role = ANY (ARRAY['chef_plaque'::text, 'chef_site'::text])))
);


--
-- Name: session_plaque; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.session_plaque (
    id bigint NOT NULL,
    campagne_id bigint NOT NULL,
    plaque_id bigint NOT NULL,
    mode text DEFAULT 'par_site'::text NOT NULL,
    effectif_cible_table integer,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone,
    CONSTRAINT session_plaque_mode_check CHECK ((mode = ANY (ARRAY['par_site'::text, 'par_table'::text])))
);


--
-- Name: site; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.site (
    id bigint NOT NULL,
    code text NOT NULL,
    libelle text NOT NULL,
    plaque_id bigint NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone
);


--
-- Name: table_phoning; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.table_phoning (
    id bigint NOT NULL,
    session_plaque_id bigint NOT NULL,
    libelle text NOT NULL,
    chef_utilisateur_id bigint,
    ordre integer DEFAULT 0 NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone,
    marque_id bigint
);


--
-- Name: vendeur; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.vendeur (
    id bigint NOT NULL,
    nom text NOT NULL,
    site_id bigint NOT NULL,
    utilisateur_id bigint,
    date_entree date,
    date_sortie date,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    capacites_confirmees_le timestamp(6) with time zone,
    capacites_confirmees_par bigint,
    type_vehicule text NOT NULL,
    archive_le timestamp(6) with time zone,
    archive_par bigint,
    CONSTRAINT vendeur_dates_coherentes_check CHECK (((date_sortie IS NULL) OR (date_entree IS NULL) OR (date_sortie >= date_entree))),
    CONSTRAINT vendeur_type_check CHECK ((type_vehicule = ANY (ARRAY['VN'::text, 'VO'::text])))
);


--
-- Name: perimetre_saisie; Type: VIEW; Schema: relance; Owner: -
--

CREATE VIEW relance.perimetre_saisie AS
 SELECT c.id AS campagne_id,
    v.id AS vendeur_id
   FROM (relance.campagne c
     CROSS JOIN relance.vendeur v)
  WHERE ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL) AND (v.archive_le IS NULL) AND ((v.date_entree IS NULL) OR (v.date_entree <= c.date_fin)) AND ((v.date_sortie IS NULL) OR (v.date_sortie >= c.date_debut)) AND (( SELECT relance.peut_administrer() AS peut_administrer) OR (EXISTS ( SELECT 1
           FROM (relance.role_campagne rc
             JOIN relance.site s ON ((s.id = v.site_id)))
          WHERE ((rc.utilisateur_id = ( SELECT relance.utilisateur_courant() AS utilisateur_courant)) AND (rc.campagne_id = c.id) AND (rc.role = 'chef_plaque'::text) AND (rc.plaque_id = s.plaque_id) AND (rc.archive_le IS NULL)))) OR (EXISTS ( SELECT 1
           FROM relance.role_campagne rc
          WHERE ((rc.utilisateur_id = ( SELECT relance.utilisateur_courant() AS utilisateur_courant)) AND (rc.campagne_id = c.id) AND (rc.role = 'chef_site'::text) AND (rc.site_id = v.site_id) AND (rc.archive_le IS NULL)))) OR (EXISTS ( SELECT 1
           FROM relance.encadrement_site es
          WHERE ((es.utilisateur_id = ( SELECT relance.utilisateur_courant() AS utilisateur_courant)) AND (es.site_id = v.site_id) AND (es.archive_le IS NULL)))) OR (EXISTS ( SELECT 1
           FROM ((relance.affectation a
             JOIN relance.table_phoning t ON ((t.id = a.table_id)))
             JOIN relance.session_plaque sp ON ((sp.id = t.session_plaque_id)))
          WHERE ((a.vendeur_id = v.id) AND (a.archive_le IS NULL) AND (t.archive_le IS NULL) AND (t.chef_utilisateur_id = ( SELECT relance.utilisateur_courant() AS utilisateur_courant)) AND (sp.campagne_id = c.id) AND (sp.archive_le IS NULL))))));


--
-- Name: plaque; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.plaque (
    id bigint NOT NULL,
    libelle text NOT NULL,
    alias text,
    ordre integer DEFAULT 0 NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone
);


--
-- Name: plaque_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.plaque_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: plaque_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.plaque_id_seq OWNED BY relance.plaque.id;


--
-- Name: rdv; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.rdv (
    id bigint NOT NULL,
    campagne_id bigint NOT NULL,
    vendeur_id bigint NOT NULL,
    jour date NOT NULL,
    creneau_code text NOT NULL,
    marque_id bigint,
    type_vehicule text NOT NULL,
    client text NOT NULL,
    commentaire text,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    modifie_le timestamp(6) with time zone,
    modifie_par bigint,
    archive_le timestamp(6) with time zone,
    archive_par bigint,
    CONSTRAINT rdv_client_non_vide_check CHECK ((length(btrim(client)) > 0)),
    CONSTRAINT rdv_type_vehicule_check CHECK ((type_vehicule = ANY (ARRAY['VN'::text, 'VO'::text])))
);


--
-- Name: rdv_agrege; Type: VIEW; Schema: relance; Owner: -
--

CREATE VIEW relance.rdv_agrege AS
 SELECT id,
    campagne_id,
    vendeur_id,
    jour,
    creneau_code,
    marque_id,
    type_vehicule,
    cree_le,
    archive_le
   FROM relance.rdv r
  WHERE (relance.utilisateur_courant() IS NOT NULL);


--
-- Name: rdv_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.rdv_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rdv_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.rdv_id_seq OWNED BY relance.rdv.id;


--
-- Name: role_campagne_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.role_campagne_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: role_campagne_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.role_campagne_id_seq OWNED BY relance.role_campagne.id;


--
-- Name: role_global; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.role_global (
    utilisateur_id bigint NOT NULL,
    role text NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    CONSTRAINT role_global_role_check CHECK ((role = ANY (ARRAY['admin'::text, 'direction'::text, 'lecteur'::text])))
);


--
-- Name: session_plaque_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.session_plaque_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: session_plaque_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.session_plaque_id_seq OWNED BY relance.session_plaque.id;


--
-- Name: site_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: site_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.site_id_seq OWNED BY relance.site.id;


--
-- Name: table_phoning_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.table_phoning_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: table_phoning_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.table_phoning_id_seq OWNED BY relance.table_phoning.id;


--
-- Name: utilisateur; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.utilisateur (
    id bigint NOT NULL,
    login_id text NOT NULL,
    password_hash text NOT NULL,
    nom text NOT NULL,
    actif boolean DEFAULT true NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone,
    auth_uid uuid
);


--
-- Name: COLUMN utilisateur.auth_uid; Type: COMMENT; Schema: relance; Owner: -
--

COMMENT ON COLUMN relance.utilisateur.auth_uid IS 'Identifiant Supabase Auth (auth.users.id). NULL tant que le compte n''a pas ete relie. Aucune FK : voir la migration 20260831200000.';


--
-- Name: utilisateur_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.utilisateur_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: utilisateur_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.utilisateur_id_seq OWNED BY relance.utilisateur.id;


--
-- Name: vendeur_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.vendeur_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vendeur_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.vendeur_id_seq OWNED BY relance.vendeur.id;


--
-- Name: vendeur_marque; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.vendeur_marque (
    vendeur_id bigint NOT NULL,
    marque_id bigint NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint
);


--
-- Name: affectation id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.affectation ALTER COLUMN id SET DEFAULT nextval('relance.affectation_id_seq'::regclass);


--
-- Name: campagne id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.campagne ALTER COLUMN id SET DEFAULT nextval('relance.campagne_id_seq'::regclass);


--
-- Name: encadrement_site id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.encadrement_site ALTER COLUMN id SET DEFAULT nextval('relance.encadrement_site_id_seq'::regclass);


--
-- Name: marque id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.marque ALTER COLUMN id SET DEFAULT nextval('relance.marque_id_seq'::regclass);


--
-- Name: plaque id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.plaque ALTER COLUMN id SET DEFAULT nextval('relance.plaque_id_seq'::regclass);


--
-- Name: rdv id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.rdv ALTER COLUMN id SET DEFAULT nextval('relance.rdv_id_seq'::regclass);


--
-- Name: role_campagne id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.role_campagne ALTER COLUMN id SET DEFAULT nextval('relance.role_campagne_id_seq'::regclass);


--
-- Name: session_plaque id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.session_plaque ALTER COLUMN id SET DEFAULT nextval('relance.session_plaque_id_seq'::regclass);


--
-- Name: site id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.site ALTER COLUMN id SET DEFAULT nextval('relance.site_id_seq'::regclass);


--
-- Name: table_phoning id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.table_phoning ALTER COLUMN id SET DEFAULT nextval('relance.table_phoning_id_seq'::regclass);


--
-- Name: utilisateur id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.utilisateur ALTER COLUMN id SET DEFAULT nextval('relance.utilisateur_id_seq'::regclass);


--
-- Name: vendeur id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.vendeur ALTER COLUMN id SET DEFAULT nextval('relance.vendeur_id_seq'::regclass);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
c3320f35-1cb1-48d3-b154-011a8cfaf156	663bc3222aca5b5f031a3e92f31e1c27d71100c01dd878528b10f6668995fd12	2026-09-01 16:00:01.666769+00	20260901160000_vendeur_dates_contre_rdv	\N	\N	2026-09-01 16:00:01.339588+00	1
034c6337-8f5f-4cc4-bb2c-b0a47266601f	f91fef5197f9ce6f31beb50a6c1cd616ff2e1a0658fcec8952e970f903516ff6	2026-08-31 20:48:17.187601+00	20260828083906_init	\N	\N	2026-08-31 20:48:16.84487+00	1
7e21ca07-0a16-4b73-8f43-e2627375601e	a8435a7dd2f4a6ec9ab7caded693d28463f28a31374df732081b7270e75b5706	2026-08-31 20:48:22.175806+00	20260831201000_rls_portail	\N	\N	2026-08-31 20:48:21.816726+00	1
21ebccf8-3bd5-49c5-a141-e839326a990e	726e168a5281c8963e0ee703fcc9262701c3834d78357c29f95d8147be34a65b	2026-08-31 20:48:17.518104+00	20260828084443_table_phoning_unique	\N	\N	2026-08-31 20:48:17.276477+00	1
f7dd0868-33b8-43e0-a180-6bfa509c20ad	79aafe37634a24daf6351b054e78b9db3cd0d5a7121660e598caedb5aa03240b	2026-08-31 20:48:17.855516+00	20260828084642_marque_code_unique	\N	\N	2026-08-31 20:48:17.608949+00	1
99eae4f4-3ee6-4891-9cfc-18e509016f89	e7873192844e9ad922fdf6d70142b21984b587780f0b30bd7452ea807202651c	2026-08-31 20:48:18.340105+00	20260828090000_invariants	\N	\N	2026-08-31 20:48:17.982293+00	1
d85e8a26-c0b2-465b-be9a-0a0d4cfa03fc	bb7aa8e6c7e08b6ed80c3b0a89ba1a792cc8e9549373777c8e46ce2ddb51f729	2026-08-31 20:48:22.501309+00	20260831202000_triggers_hors_rls	\N	\N	2026-08-31 20:48:22.270654+00	1
a0a1e28b-b64d-4354-ba11-12bef5adf224	48b9288ceed6ca51d370a90c74acda08e77d832ac1014e71eb8bbc6e1f1e6e47	2026-08-31 20:48:18.696869+00	20260828091000_fix_affectation_unique	\N	\N	2026-08-31 20:48:18.452815+00	1
3b5dc4f8-e316-451a-ab05-b74573b23408	08c5fe8ea9d6cb607235f8a64e26fab12d280d0621d17e30d87edd3560417e92	2026-08-31 20:48:19.040117+00	20260828092952_marques_confirmees	\N	\N	2026-08-31 20:48:18.792129+00	1
9a7d8fbc-e799-4c8c-a7f3-29e7633c32ff	4ef1fe153c9bd997429985c5a63f1dae534f2c907fb975cefd10ff2bb9fca77a	2026-08-31 20:48:19.476783+00	20260828121219_vendeur_types_vehicule	\N	\N	2026-08-31 20:48:19.153909+00	1
5eb12b05-cf20-4f66-a0e5-3d9319656d4b	35f523c5ed80dc674eec7bcf015877273434687ab542191724d90c43c3ddaf03	2026-08-31 20:48:22.873781+00	20260831203000_rdv_agrege_compte_actif	\N	\N	2026-08-31 20:48:22.603913+00	1
5b310058-b12b-4151-9848-f467b0bcafbe	906125bc6e4ff14a63a707496d670e8c52ee5eef41be21ee430980b6862d7cfb	2026-08-31 20:48:19.883913+00	20260828140000_vendeur_type_scalaire	\N	\N	2026-08-31 20:48:19.603046+00	1
687baad8-4669-4546-aea8-74e8e6866700	6782c4a8e1c582798e7ab8ef8657cd69725ef1a7e2496aa33025895cdd5a3e05	2026-08-31 20:48:20.230605+00	20260828160000_affectation_meme_plaque	\N	\N	2026-08-31 20:48:19.961444+00	1
7f71923a-d1dd-4f78-a801-5394e5d1f3e2	e2fc62aeae4fdf8ab3f2b3b0ba2d595874fae0203ce025d4c0d3b83dd8e0de50	2026-09-03 08:15:13.054569+00	20260903065812_revoquer_execute_public	\N	\N	2026-09-03 08:15:12.730081+00	1
0b998f60-c78e-47a9-9aea-01e5f0bc24bf	b246a47f533735c55fe3f82fda03bbb0e51ca7e1b2b07d49edd908da7cbbebaa	2026-08-31 20:48:20.594508+00	20260831090000_table_specialisation	\N	\N	2026-08-31 20:48:20.335715+00	1
4fa87ad9-c2fd-4986-8536-7a85f67d65f2	1324cfd0f87dd0599a85c63ba2621853cae0fd29a20500bbc1897ff832abfc1b	2026-08-31 21:08:48.58242+00	20260831210000_rpc_privilegies	\N	\N	2026-08-31 21:08:48.148814+00	1
5ecabbc8-906f-4025-b3d0-51143e3ce56e	b9bc25688197a550d562cefbe3f58cb46e4db8861bbe30070e99ecd933798be0	2026-08-31 20:48:20.995261+00	20260831140000_encadrement_et_purge	\N	\N	2026-08-31 20:48:20.702141+00	1
0b9543be-ee5c-424b-8618-f760e5afb69d	4b915a14c0e99774f99d3cd91e3a544cf77db6fb37b171ace4ff3a2edd22c211	2026-08-31 20:48:21.387548+00	20260831180000_encadrants_comptes	\N	\N	2026-08-31 20:48:21.093345+00	1
a4cbbf19-ca40-438e-98ae-cba138c30915	80d560b4b705f634e6e539b55f834fa8300025c544398a9720839e5fe8a9c530	2026-08-31 20:48:21.71838+00	20260831200000_auth_uid	\N	\N	2026-08-31 20:48:21.486458+00	1
af3ddc2b-6923-4c38-a2d4-2443cae856c0	ed8b975bc704873bf4b3afc146e4176f398a2ead2d3a7c65cf59e167cd9349c6	2026-08-31 21:42:17.980581+00	20260831220000_diffusion_realtime	\N	\N	2026-08-31 21:42:17.649765+00	1
6e95a6cc-d076-49dd-95a6-4e6f2af3e834	cd06454f8dc43f8dac50b3c8220beeb492691d374f495b107fbdffae4758b6fa	2026-08-31 21:59:32.501785+00	20260831230000_canal_sans_deux_points	\N	\N	2026-08-31 21:59:32.192017+00	1
7e1d19d5-af24-4a13-96bc-521473b4fba5	6dc4f8ee43885303e7750b25037c47f3301e4ddb1276cae8302af6bdb6bcc634	2026-09-08 16:05:07.786914+00	20260908160000_perimetre_saisie_appel_unique	\N	\N	2026-09-08 16:05:07.359938+00	1
28aa5e09-b1e9-4c3b-a2c5-a56dc0f1e2d8	8d88252bc75fa3bc6ebb0954d538d4d65d23f7f2527b092ac6f89390f533fd2e	2026-08-31 22:35:04.542758+00	20260901090000_droits_service_role	\N	\N	2026-08-31 22:35:04.201542+00	1
2910245a-bde1-452f-bf19-84b49fb01ed6	03ce6c39b993d79520a474350abe48c953e9a2993ecd95c30a44776447bfeb5a	2026-09-01 15:46:46.856505+00	20260901120000_affectation_vendeur_present	\N	\N	2026-09-01 15:46:46.481453+00	1
\.


--
-- Data for Name: affectation; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.affectation (id, table_id, vendeur_id, origine, cree_le, cree_par, archive_le) FROM stdin;
1	1	20	manuel	2026-08-31 20:50:22.754+00	\N	\N
2	1	21	manuel	2026-08-31 20:50:22.841+00	\N	\N
3	1	10	manuel	2026-08-31 20:50:22.891+00	\N	\N
4	1	11	manuel	2026-08-31 20:50:22.931+00	\N	\N
5	1	27	manuel	2026-08-31 20:50:22.966+00	\N	\N
6	1	5	manuel	2026-08-31 20:50:23.066+00	\N	\N
7	2	25	manuel	2026-08-31 20:50:23.103+00	\N	\N
8	2	22	manuel	2026-08-31 20:50:23.146+00	\N	\N
9	2	29	manuel	2026-08-31 20:50:23.182+00	\N	\N
10	2	15	manuel	2026-08-31 20:50:23.224+00	\N	\N
11	2	3	manuel	2026-08-31 20:50:23.27+00	\N	\N
12	2	4	manuel	2026-08-31 20:50:23.32+00	\N	\N
13	3	13	manuel	2026-08-31 20:50:23.362+00	\N	\N
14	3	23	manuel	2026-08-31 20:50:23.421+00	\N	\N
15	3	16	manuel	2026-08-31 20:50:23.47+00	\N	\N
16	3	17	manuel	2026-08-31 20:50:23.523+00	\N	\N
17	3	26	manuel	2026-08-31 20:50:23.602+00	\N	\N
18	3	30	manuel	2026-08-31 20:50:23.671+00	\N	\N
19	4	24	manuel	2026-08-31 20:50:23.725+00	\N	\N
20	4	12	manuel	2026-08-31 20:50:23.775+00	\N	\N
21	4	18	manuel	2026-08-31 20:50:23.824+00	\N	\N
22	4	2	manuel	2026-08-31 20:50:23.881+00	\N	\N
23	4	6	manuel	2026-08-31 20:50:23.92+00	\N	\N
24	4	7	manuel	2026-08-31 20:50:23.98+00	\N	\N
25	5	28	manuel	2026-08-31 20:50:24.017+00	\N	\N
26	5	8	manuel	2026-08-31 20:50:24.061+00	\N	\N
27	5	9	manuel	2026-08-31 20:50:24.102+00	\N	\N
28	5	1	manuel	2026-08-31 20:50:24.162+00	\N	\N
29	5	19	manuel	2026-08-31 20:50:24.295+00	\N	\N
30	5	14	manuel	2026-08-31 20:50:24.34+00	\N	\N
31	6	62	manuel	2026-08-31 20:50:24.383+00	\N	\N
32	6	60	manuel	2026-08-31 20:50:24.444+00	\N	\N
33	6	57	manuel	2026-08-31 20:50:24.5+00	\N	\N
34	6	54	manuel	2026-08-31 20:50:24.54+00	\N	\N
35	6	68	manuel	2026-08-31 20:50:24.583+00	\N	\N
36	6	65	manuel	2026-08-31 20:50:24.628+00	\N	\N
37	7	55	manuel	2026-08-31 20:50:24.674+00	\N	\N
38	7	56	manuel	2026-08-31 20:50:24.723+00	\N	\N
39	7	66	manuel	2026-08-31 20:50:24.782+00	\N	\N
40	7	67	manuel	2026-08-31 20:50:24.84+00	\N	\N
41	7	61	manuel	2026-08-31 20:50:24.885+00	\N	\N
42	7	70	manuel	2026-08-31 20:50:24.943+00	\N	\N
43	8	53	manuel	2026-08-31 20:50:24.99+00	\N	\N
44	8	58	manuel	2026-08-31 20:50:25.031+00	\N	\N
45	8	59	manuel	2026-08-31 20:50:25.089+00	\N	\N
46	8	69	manuel	2026-08-31 20:50:25.127+00	\N	\N
47	8	63	manuel	2026-08-31 20:50:25.168+00	\N	\N
48	8	64	manuel	2026-08-31 20:50:25.247+00	\N	\N
1486	12	160	manuel	2026-09-08 07:30:14.119778+00	92	\N
961	146	63	manuel	2026-09-02 09:36:56.215824+00	787	2026-09-08 08:00:51.080661+00
503	9	27	manuel	2026-09-01 16:24:32.369555+00	92	\N
975	146	55	manuel	2026-09-02 09:37:18.5654+00	787	\N
122	9	17	manuel	2026-09-01 15:36:17.114882+00	92	\N
123	9	160	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:28:00.741819+00
966	146	68	manuel	2026-09-02 09:37:08.756176+00	787	\N
921	144	881	manuel	2026-09-02 09:29:26.909987+00	787	2026-09-08 08:00:58.958651+00
933	144	57	manuel	2026-09-02 09:30:07.304445+00	787	\N
1003	10	212	manuel	2026-09-02 12:33:32.457659+00	92	2026-09-08 07:27:36.404195+00
514	10	213	manuel	2026-09-01 16:24:34.424935+00	92	\N
527	10	25	manuel	2026-09-01 16:25:56.052063+00	92	2026-09-01 16:26:12.847571+00
120	9	11	auto	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
121	9	16	auto	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
126	9	25	auto	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
404	9	213	manuel	2026-09-01 16:18:22.397405+00	92	2026-09-01 16:24:34.330589+00
380	10	15	manuel	2026-09-01 16:15:50.843134+00	92	2026-09-01 16:29:39.236415+00
398	13	18	manuel	2026-09-01 16:17:49.152953+00	92	2026-09-01 16:22:39.790055+00
118	12	27	manuel	2026-09-01 15:33:01.648281+00	92	2026-09-01 15:36:17.114882+00
940	145	66	manuel	2026-09-02 09:31:49.297693+00	787	\N
954	145	882	manuel	2026-09-02 09:36:22.618244+00	787	\N
945	145	70	manuel	2026-09-02 09:32:11.551854+00	787	\N
634	10	8	manuel	2026-09-01 16:26:49.055013+00	92	2026-09-02 12:32:25.575309+00
420	12	28	manuel	2026-09-01 16:19:11.844782+00	92	2026-09-01 16:26:10.134249+00
377	13	3	manuel	2026-09-01 16:14:54.37136+00	92	2026-09-01 16:27:58.053286+00
492	9	212	manuel	2026-09-01 16:24:29.121256+00	92	2026-09-02 12:33:32.338735+00
386	10	17	manuel	2026-09-01 16:17:01.059119+00	92	2026-09-01 16:26:47.012437+00
125	9	8	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:26:48.967169+00
918	144	56	manuel	2026-09-01 16:49:47.200314+00	787	2026-09-04 15:10:50.024022+00
542	10	28	manuel	2026-09-01 16:26:10.237926+00	92	\N
557	12	25	manuel	2026-09-01 16:26:12.935278+00	92	2026-09-08 07:28:53.386443+00
480	12	211	manuel	2026-09-01 16:24:10.226691+00	92	\N
458	11	18	manuel	2026-09-01 16:22:39.942687+00	92	\N
119	11	12	manuel	2026-09-01 15:33:24.773285+00	92	\N
355	11	29	manuel	2026-09-01 16:10:29.873494+00	92	\N
445	12	4	manuel	2026-09-01 16:21:19.493923+00	92	2026-09-08 07:26:54.04251+00
295	13	9	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:09:58.492635+00
284	11	8	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:42.573896+00
416	10	160	manuel	2026-09-01 16:19:00.878121+00	92	2026-09-01 16:26:31.851005+00
289	12	17	auto	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:04.929551+00
143	12	21	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:29:36.691409+00
917	144	66	manuel	2026-09-01 16:47:05.541155+00	787	2026-09-01 16:47:07.940102+00
133	11	7	auto	2026-09-01 15:36:17.114882+00	92	2026-09-01 15:54:28.676692+00
278	10	16	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:44.395376+00
271	9	2	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:20.23679+00
132	10	13	auto	2026-09-01 15:36:17.114882+00	92	2026-09-01 15:38:19.167368+00
277	10	23	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:46.005143+00
287	12	5	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:06.932049+00
269	9	12	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:21.546654+00
150	13	20	auto	2026-09-01 15:36:17.114882+00	92	2026-09-01 15:45:32.849189+00
131	10	18	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:10:24.634513+00
290	12	14	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:10.728207+00
286	12	10	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:12.65505+00
282	11	3	auto	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:14.313187+00
139	12	23	auto	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
141	12	22	auto	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
142	12	3	auto	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
144	12	30	auto	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
134	11	6	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
135	11	1	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
130	10	12	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
127	10	5	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
128	10	10	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
149	13	15	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
145	13	4	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
148	13	24	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
376	11	214	manuel	2026-09-01 16:14:31.621838+00	92	2026-09-08 07:25:59.093525+00
136	11	27	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
393	10	9	manuel	2026-09-01 16:17:30.068762+00	92	\N
138	11	9	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
147	13	28	auto	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:52.678846+00
294	13	26	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:09:54.677259+00
292	13	1	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:09:56.738521+00
146	13	2	manuel	2026-09-01 15:36:17.114882+00	92	\N
834	12	15	manuel	2026-09-01 16:29:39.331892+00	92	\N
268	9	15	auto	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:16.655365+00
140	12	19	manuel	2026-09-01 15:36:17.114882+00	92	\N
717	9	3	manuel	2026-09-01 16:27:58.173895+00	92	2026-09-02 12:32:03.585855+00
129	10	29	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:10:29.738855+00
288	12	11	manuel	2026-09-01 16:09:41.773837+00	92	\N
970	146	53	manuel	2026-09-02 09:37:16.501982+00	787	\N
272	9	22	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:17.83428+00
137	11	26	manuel	2026-09-01 15:36:17.114882+00	92	\N
963	146	65	manuel	2026-09-02 09:37:01.762322+00	787	\N
981	146	61	manuel	2026-09-02 09:37:22.936546+00	787	\N
273	9	30	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:18.959226+00
283	11	4	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:32.613245+00
280	11	24	manuel	2026-09-01 16:09:41.773837+00	92	\N
281	11	19	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:35.611782+00
291	13	160	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-08 07:30:14.023231+00
378	9	26	manuel	2026-09-01 16:15:05.564154+00	92	2026-09-01 16:20:50.469134+00
285	11	25	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:38.518255+00
486	13	215	manuel	2026-09-01 16:24:16.765847+00	92	\N
384	13	23	manuel	2026-09-01 16:16:51.960836+00	92	\N
949	145	54	manuel	2026-09-02 09:36:14.095636+00	787	\N
942	145	67	manuel	2026-09-02 09:31:53.883002+00	787	\N
960	145	59	manuel	2026-09-02 09:36:30.814978+00	787	\N
276	10	27	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:24:32.298307+00
279	10	21	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-08 07:27:31.76096+00
463	13	16	manuel	2026-09-01 16:22:44.394464+00	92	\N
428	13	10	manuel	2026-09-01 16:19:37.585581+00	92	\N
270	9	6	manuel	2026-09-01 16:09:41.773837+00	92	\N
449	9	5	manuel	2026-09-01 16:21:31.222739+00	92	\N
124	9	14	manuel	2026-09-01 15:36:17.114882+00	92	\N
939	144	60	manuel	2026-09-02 09:30:15.856488+00	787	\N
924	144	69	manuel	2026-09-02 09:29:36.971986+00	787	\N
520	10	22	manuel	2026-09-01 16:24:40.341832+00	92	\N
1466	12	2	manuel	2026-09-08 07:29:49.235401+00	92	2026-09-08 07:29:58.854265+00
919	144	62	manuel	2026-09-02 09:27:24.480863+00	787	\N
\.


--
-- Data for Name: campagne; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.campagne (id, libelle, date_debut, date_fin, cloturee, cree_le, cree_par, archive_le) FROM stdin;
1	Juin 2026	2026-06-11	2026-06-15	f	2026-08-31 20:50:17.444+00	\N	\N
2	Septembre 2026	2026-09-10	2026-09-14	f	2026-08-31 20:50:19.52+00	\N	\N
\.


--
-- Data for Name: campagne_creneau; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.campagne_creneau (campagne_id, code, libelle, ordre, cree_le, cree_par) FROM stdin;
1	08:00-09:00	8h-9h	1	2026-08-31 20:50:17.821+00	\N
1	09:00-10:00	9h-10h	2	2026-08-31 20:50:17.921+00	\N
1	10:00-11:00	10h-11h	3	2026-08-31 20:50:17.96+00	\N
1	11:00-12:00	11h-12h	4	2026-08-31 20:50:18.014+00	\N
1	12:00-13:00	12h-13h	5	2026-08-31 20:50:18.058+00	\N
1	13:00-14:00	13h-14h	6	2026-08-31 20:50:18.099+00	\N
1	14:00-15:00	14h-15h	7	2026-08-31 20:50:18.149+00	\N
1	15:00-16:00	15h-16h	8	2026-08-31 20:50:18.19+00	\N
1	16:00-17:00	16h-17h	9	2026-08-31 20:50:18.23+00	\N
1	17:00-18:00	17h-18h	10	2026-08-31 20:50:18.273+00	\N
1	18:00-19:00	18h-19h	11	2026-08-31 20:50:18.323+00	\N
2	08:00-09:00	8h-9h	1	2026-08-31 20:50:19.849+00	\N
2	09:00-10:00	9h-10h	2	2026-08-31 20:50:19.889+00	\N
2	10:00-11:00	10h-11h	3	2026-08-31 20:50:19.934+00	\N
2	11:00-12:00	11h-12h	4	2026-08-31 20:50:19.987+00	\N
2	12:00-13:00	12h-13h	5	2026-08-31 20:50:20.044+00	\N
2	13:00-14:00	13h-14h	6	2026-08-31 20:50:20.085+00	\N
2	14:00-15:00	14h-15h	7	2026-08-31 20:50:20.161+00	\N
2	15:00-16:00	15h-16h	8	2026-08-31 20:50:20.199+00	\N
2	16:00-17:00	16h-17h	9	2026-08-31 20:50:20.243+00	\N
2	17:00-18:00	17h-18h	10	2026-08-31 20:50:20.284+00	\N
2	18:00-19:00	18h-19h	11	2026-08-31 20:50:20.408+00	\N
\.


--
-- Data for Name: campagne_jour; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.campagne_jour (campagne_id, jour, ordre, cree_le, cree_par) FROM stdin;
1	2026-06-11	1	2026-08-31 20:50:17.546+00	\N
1	2026-06-12	2	2026-08-31 20:50:17.644+00	\N
1	2026-06-13	3	2026-08-31 20:50:17.691+00	\N
1	2026-06-14	4	2026-08-31 20:50:17.737+00	\N
1	2026-06-15	5	2026-08-31 20:50:17.78+00	\N
2	2026-09-10	1	2026-08-31 20:50:19.56+00	\N
2	2026-09-11	2	2026-08-31 20:50:19.607+00	\N
2	2026-09-12	3	2026-08-31 20:50:19.649+00	\N
2	2026-09-13	4	2026-08-31 20:50:19.713+00	\N
2	2026-09-14	5	2026-08-31 20:50:19.779+00	\N
\.


--
-- Data for Name: encadrement_site; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.encadrement_site (id, site_id, role, utilisateur_id, cree_le, cree_par, archive_le) FROM stdin;
544	15	chef_de_site	1777	2026-09-04 09:47:04.446432+00	1	\N
545	14	chef_de_site	1776	2026-09-04 09:47:15.417471+00	1	\N
546	18	chef_de_site	1775	2026-09-04 09:47:25.190832+00	1	\N
547	13	chef_de_site	1778	2026-09-04 09:48:03.668553+00	1	\N
549	12	chef_de_site	1779	2026-09-04 09:49:33.361849+00	1	\N
550	17	chef_de_site	1780	2026-09-04 09:51:20.89576+00	1	\N
551	16	chef_de_site	1781	2026-09-04 09:51:31.002306+00	1	\N
552	12	chef_de_vente_vn	1778	2026-09-04 09:53:41.284847+00	1	\N
119	7	chef_de_vente_vn	1782	2026-09-01 13:03:08.910207+00	92	\N
554	8	chef_de_vente_vn	1783	2026-09-07 13:55:54.0902+00	92	\N
123	9	chef_de_site	95	2026-09-01 13:04:32.927457+00	92	2026-09-08 07:37:50.305+00
548	19	chef_de_site	1778	2026-09-04 09:48:16.272587+00	1	2026-09-08 14:13:41.30356+00
35	2	chef_de_vente_vn	12	2026-08-31 20:53:18.168+00	\N	2026-09-01 16:28:32.236+00
110	3	chef_de_vente_vn	5	2026-09-01 12:01:04.526057+00	10	\N
555	710	chef_de_site	1778	2026-09-08 08:19:21.964003+00	1784	2026-09-08 14:14:05.474919+00
111	5	chef_de_site	94	2026-09-01 13:00:01.411095+00	92	\N
34	3	chef_de_site	94	2026-08-31 20:53:17.946+00	\N	\N
113	3	chef_de_vente_vo	6	2026-09-01 13:00:15.179147+00	92	\N
114	1	chef_de_site	2	2026-09-01 13:00:21.513463+00	92	\N
115	2	chef_de_site	4	2026-09-01 13:00:34.781521+00	92	\N
116	4	chef_de_site	3	2026-09-01 13:00:56.770605+00	92	\N
117	7	chef_de_site	96	2026-09-01 13:02:03.428751+00	92	\N
118	8	chef_de_site	96	2026-09-01 13:03:01.351951+00	92	\N
120	6	chef_de_site	96	2026-09-01 13:03:21.300404+00	92	\N
121	6	chef_de_vente_vn	97	2026-09-01 13:03:43.943745+00	92	\N
122	11	chef_de_site	9	2026-09-01 13:04:10.655272+00	92	\N
124	9	chef_de_vente_vn	8	2026-09-01 13:04:38.333952+00	92	\N
125	9	chef_de_vente_vo	8	2026-09-01 13:04:44.588092+00	92	\N
126	10	chef_de_site	7	2026-09-01 13:04:53.644516+00	92	\N
\.


--
-- Data for Name: marque; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.marque (id, code, libelle, ordre, cree_le, cree_par, archive_le) FROM stdin;
1	RENAULT	Renault	1	2026-08-31 20:49:25.026+00	\N	\N
2	DACIA	Dacia	2	2026-08-31 20:49:25.128+00	\N	\N
3	ALPINE	Alpine	3	2026-08-31 20:49:25.174+00	\N	\N
\.


--
-- Data for Name: plaque; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.plaque (id, libelle, alias, ordre, cree_le, cree_par, archive_le) FROM stdin;
1	CENTRE	EAA	1	2026-08-31 20:49:25.236+00	\N	\N
2	NORD	\N	2	2026-08-31 20:49:25.332+00	\N	\N
3	SUD	\N	3	2026-08-31 20:49:25.371+00	\N	\N
4	SUD-OUEST	\N	4	2026-08-31 20:49:25.41+00	\N	\N
\.


--
-- Data for Name: rdv; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.rdv (id, campagne_id, vendeur_id, jour, creneau_code, marque_id, type_vehicule, client, commentaire, cree_le, cree_par, modifie_le, modifie_par, archive_le, archive_par) FROM stdin;
161	2	3	2026-09-10	08:00-09:00	1	VN	CONTROLE NAVIGATEURSAISIE ECRAN	\N	2026-08-31 21:50:44.921383+00	12	2026-08-31 22:00:23.239731+00	12	2026-08-31 22:00:22.212+00	\N
162	2	3	2026-09-10	09:00-10:00	1	VN	CLIENT DEPUIS LA GRILLE	\N	2026-08-31 21:51:54.608775+00	12	2026-08-31 22:00:23.239731+00	\N	2026-08-31 22:00:22.212+00	\N
194	2	1	2026-09-10	18:00-19:00	1	VN	DEPUIS LE TERMINAL	\N	2026-08-31 22:00:00.426+00	\N	2026-08-31 22:00:23.239731+00	\N	2026-08-31 22:00:22.212+00	\N
262	1	10	2026-06-11	09:00-10:00	1	VN	DELATOURAS	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
263	1	10	2026-06-12	09:00-10:00	1	VN	CHARDON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
264	1	10	2026-06-13	09:00-10:00	1	VN	TERON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
265	1	10	2026-06-14	09:00-10:00	1	VN	PERNET	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
266	1	10	2026-06-11	10:00-11:00	1	VN	CREMIEUX	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
267	1	10	2026-06-13	10:00-11:00	1	VN	MARI	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
268	1	10	2026-06-14	10:00-11:00	1	VN	FORMENTI	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
269	1	10	2026-06-11	11:00-12:00	1	VN	PICOT	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
270	1	10	2026-06-14	11:00-12:00	1	VN	CHAMBRE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
271	1	10	2026-06-12	12:00-13:00	1	VN	CHOMEILLE*	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
272	1	10	2026-06-12	14:00-15:00	1	VN	ZAMORA	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
273	1	10	2026-06-13	14:00-15:00	1	VN	VIALTAIX	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
274	1	10	2026-06-14	14:00-15:00	1	VN	ALVES	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
275	1	10	2026-06-11	16:00-17:00	1	VN	MARTIN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
276	1	10	2026-06-13	16:00-17:00	1	VN	BRETTE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
277	1	10	2026-06-14	16:00-17:00	1	VN	RAGOT 208	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
278	1	11	2026-06-12	09:00-10:00	1	VN	JELADE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
279	1	11	2026-06-13	09:00-10:00	1	VN	DEBLOIS	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
280	1	11	2026-06-11	10:00-11:00	1	VN	CHILE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
281	1	11	2026-06-15	10:00-11:00	1	VN	THEVENET	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
282	1	11	2026-06-12	11:00-12:00	1	VN	TARTRY	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
283	1	11	2026-06-15	11:00-12:00	1	VN	MESTRE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
284	1	11	2026-06-11	12:00-13:00	1	VN	VASSET	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
285	1	11	2026-06-12	12:00-13:00	1	VN	DE LA COTARDIERE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
286	1	11	2026-06-15	13:00-14:00	1	VN	ABEL	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
287	1	11	2026-06-12	14:00-15:00	1	VN	GUITTARD	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
288	1	11	2026-06-15	14:00-15:00	1	VN	BONNET	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
289	1	11	2026-06-15	16:00-17:00	1	VN	DELODDE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
290	1	11	2026-06-11	14:00-15:00	2	VN	CABANAC	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
291	1	11	2026-06-12	15:00-16:00	2	VN	MONNERON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
292	1	11	2026-06-11	16:00-17:00	2	VN	GOUTAIN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
293	1	11	2026-06-12	16:00-17:00	2	VN	POSSON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
294	1	11	2026-06-11	18:00-19:00	2	VN	GOUTEFANGEAT	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
295	1	12	2026-06-11	08:00-09:00	2	VN	RICCARDELLI (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
296	1	12	2026-06-12	09:00-10:00	2	VN	DELORME (BIGSTER)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
297	1	12	2026-06-13	09:00-10:00	2	VN	SCHAMPERS (JOGGER)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
298	1	12	2026-06-14	09:00-10:00	2	VN	DUREL (DUSTER)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
299	1	12	2026-06-11	10:00-11:00	2	VN	BERNIGAUD (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
300	1	12	2026-06-12	10:00-11:00	2	VN	DAMIANI (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
301	1	12	2026-06-13	10:00-11:00	2	VN	TROUCAS (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
302	1	12	2026-06-14	10:00-11:00	2	VN	PAILHE (SANDERO STEPWAY)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
303	1	12	2026-06-15	10:00-11:00	2	VN	VAGNE (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
304	1	12	2026-06-11	11:00-12:00	2	VN	CHAVAROCHE  (DUSTER)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
305	1	12	2026-06-12	11:00-12:00	2	VN	AMBLARD (BIGSTER)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
306	1	12	2026-06-11	14:00-15:00	2	VN	LEMONIER (STEPWAY)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
307	1	12	2026-06-12	14:00-15:00	2	VN	LEMOINE (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
308	1	12	2026-06-14	14:00-15:00	2	VN	FRANCES (DUSTER)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
309	1	12	2026-06-15	15:00-16:00	2	VN	BEAL (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
310	1	12	2026-06-14	16:00-17:00	2	VN	DUMAS (JOGGER)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
311	1	12	2026-06-11	17:00-18:00	2	VN	QUERART (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
312	1	12	2026-06-12	17:00-18:00	2	VN	MAILLET (BIGSTER)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
313	1	12	2026-06-13	17:00-18:00	2	VN	NUGER (JOGGER)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
314	1	12	2026-06-11	18:00-19:00	2	VN	JACQUIER (sandero)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
315	1	13	2026-06-11	09:00-10:00	1	VN	ARTAUD	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
316	1	13	2026-06-14	09:00-10:00	1	VN	BERKOUN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
317	1	13	2026-06-12	09:00-10:00	2	VN	NORE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
318	1	13	2026-06-13	09:00-10:00	2	VN	ALBERT	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
319	1	13	2026-06-11	10:00-11:00	2	VN	COUESNON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
320	1	13	2026-06-13	10:00-11:00	2	VN	OUDARD	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
321	1	13	2026-06-14	10:00-11:00	2	VN	VERNIERE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
322	1	13	2026-06-11	11:00-12:00	2	VN	CLAVELOU	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
323	1	13	2026-06-12	11:00-12:00	2	VN	DEGRANGE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
324	1	13	2026-06-11	13:00-14:00	2	VN	SAINTE ARROMAN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
325	1	13	2026-06-14	14:00-15:00	2	VN	DREUX	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
326	1	13	2026-06-14	15:00-16:00	2	VN	GORALSKI	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
327	1	13	2026-06-15	15:00-16:00	2	VN	GUIENNE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
328	1	14	2026-06-11	16:00-17:00	1	VN	LECHARPENTIER (Twingo ou Spring)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
329	1	14	2026-06-11	08:00-09:00	2	VN	GUERINO (Sandero)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
330	1	14	2026-06-12	09:00-10:00	2	VN	MUCIENTES (Sandero)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
331	1	14	2026-06-14	09:00-10:00	2	VN	CHANTELAUZE (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
332	1	14	2026-06-13	10:00-11:00	2	VN	RADINI (Duster 4x4 diesel reprise)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
333	1	14	2026-06-13	13:00-14:00	2	VN	GENINO (Sandero)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
334	1	14	2026-06-11	14:00-15:00	2	VN	LEMAIRE (DUster)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
335	1	14	2026-06-14	14:00-15:00	2	VN	FAURIOL (Bigster)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
336	1	14	2026-06-13	15:00-16:00	2	VN	GULF (jogger 7 places)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
337	1	14	2026-06-14	16:00-17:00	2	VN	ESCURE (Duster, reprise DUstuer diesel 4x4)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
338	1	14	2026-06-11	17:00-18:00	2	VN	ASTARI (Sandero)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
339	1	14	2026-06-12	18:00-19:00	2	VN	COL (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
340	1	15	2026-06-13	09:00-10:00	1	VN	SARDIER	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
341	1	15	2026-06-14	09:00-10:00	1	VN	JUNG	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
342	1	15	2026-06-15	09:00-10:00	1	VN	TISON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
343	1	15	2026-06-13	10:00-11:00	1	VN	JAMOT	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
344	1	15	2026-06-15	10:00-11:00	1	VN	GODARD	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
345	1	15	2026-06-11	14:00-15:00	1	VN	FAYARD	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
346	1	15	2026-06-15	14:00-15:00	1	VN	MARCHAND	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
347	1	15	2026-06-11	09:00-10:00	2	VN	NEGRONIE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
348	1	15	2026-06-12	09:00-10:00	2	VN	NAULT	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
349	1	15	2026-06-11	11:00-12:00	2	VN	MIAUX	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
350	1	15	2026-06-12	11:00-12:00	2	VN	FAURE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
351	1	15	2026-06-12	14:00-15:00	2	VN	DARTOIS	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
352	1	15	2026-06-13	14:00-15:00	2	VN	DUBOIS	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
353	1	15	2026-06-12	16:00-17:00	2	VN	MONTOLOY	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
354	1	15	2026-06-12	17:00-18:00	2	VN	EYDIEUX	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
355	1	16	2026-06-11	09:00-10:00	1	VN	JALAN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
356	1	16	2026-06-15	09:00-10:00	1	VN	RAMBEAU	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
357	1	16	2026-06-12	10:00-11:00	1	VN	STRADY	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
358	1	16	2026-06-14	10:00-11:00	1	VN	RAMBAUD	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
359	1	16	2026-06-15	10:00-11:00	1	VN	BAYDE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
360	1	16	2026-06-11	11:00-12:00	1	VN	MEUNIER	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
361	1	16	2026-06-12	11:00-12:00	1	VN	VOLDOIRE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
362	1	16	2026-06-12	12:00-13:00	1	VN	LAGACHE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
363	1	16	2026-06-13	12:00-13:00	1	VN	MONTOUTON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
364	1	16	2026-06-12	14:00-15:00	1	VN	ROUX	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
365	1	16	2026-06-13	14:00-15:00	1	VN	COUDERT	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
366	1	16	2026-06-14	14:00-15:00	1	VN	JOURNIAC	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
367	1	16	2026-06-12	16:00-17:00	1	VN	CHEVALIER	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
368	1	16	2026-06-11	17:00-18:00	1	VN	ZAKARIA	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
369	1	16	2026-06-15	17:00-18:00	1	VN	BARRA	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
370	1	17	2026-06-11	09:00-10:00	1	VN	SIGURET	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
371	1	17	2026-06-13	09:00-10:00	1	VN	CEYRAS	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
372	1	17	2026-06-14	09:00-10:00	1	VN	HABRIAL	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
373	1	17	2026-06-15	09:00-10:00	1	VN	LECOIN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
374	1	17	2026-06-11	10:00-11:00	1	VN	GAUDICHON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
375	1	17	2026-06-14	10:00-11:00	1	VN	SAUSSAC	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
376	1	17	2026-06-15	11:00-12:00	1	VN	DEKEYSER	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
377	1	17	2026-06-11	13:00-14:00	1	VN	KANIT	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
378	1	17	2026-06-12	13:00-14:00	1	VN	CORDIESE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
379	1	17	2026-06-11	14:00-15:00	1	VN	MAILHOT	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
380	1	17	2026-06-12	14:00-15:00	1	VN	BONNIN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
381	1	17	2026-06-13	14:00-15:00	1	VN	BERTIN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
382	1	17	2026-06-14	14:00-15:00	1	VN	VAYSSADE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
383	1	17	2026-06-13	15:00-16:00	1	VN	MONTBOISSE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
384	1	17	2026-06-15	15:00-16:00	1	VN	CURADO	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
385	1	17	2026-06-11	16:00-17:00	1	VN	FOZEN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
386	1	17	2026-06-13	17:00-18:00	1	VN	CHALLET	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
387	1	17	2026-06-15	17:00-18:00	1	VN	FLORES	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
388	1	18	2026-06-12	09:00-10:00	1	VN	LAON (R4)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
389	1	18	2026-06-13	09:00-10:00	1	VN	MR BAYARD	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
390	1	18	2026-06-11	10:00-11:00	1	VN	ABRANTES (TWINGO ETECH)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
391	1	18	2026-06-12	10:00-11:00	1	VN	HOUZEAU (AUSTRAl)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
392	1	18	2026-06-15	10:00-11:00	1	VN	GLAIZE (R4 E TECH)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
393	1	18	2026-06-11	14:00-15:00	1	VN	MARTINEZ (CLIO 6)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
394	1	18	2026-06-12	14:00-15:00	1	VN	MARQUES (CAPTUR)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
395	1	18	2026-06-13	14:00-15:00	1	VN	GAILLER (CLIO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
396	1	18	2026-06-14	14:00-15:00	1	VN	CHANUDET (R5)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
397	1	18	2026-06-15	14:00-15:00	1	VN	MEAUGER (TWINGO ETECH)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
398	1	18	2026-06-12	15:00-16:00	1	VN	ROUGIER (CLIO 6 ECO G)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
399	1	18	2026-06-13	15:00-16:00	1	VN	CHAPER (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
400	1	18	2026-06-11	16:00-17:00	1	VN	DUMONT (R5 ETECH)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
401	1	18	2026-06-11	17:00-18:00	1	VN	DAGUNA (TWINGO etech)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
402	1	18	2026-06-15	18:00-19:00	1	VN	DAULAT	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
403	1	19	2026-06-11	08:00-09:00	1	VN	MIGLIAVACCA (Clio)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
404	1	19	2026-06-12	08:00-09:00	1	VN	BELOT (R5)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
405	1	19	2026-06-11	09:00-10:00	1	VN	TARDIVAT (Captur)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
406	1	19	2026-06-13	09:00-10:00	1	VN	PENOT (Twingo electrique)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
407	1	19	2026-06-14	09:00-10:00	1	VN	MISSONIER (R5)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
408	1	19	2026-06-15	09:00-10:00	1	VN	RODIER (Clio)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
409	1	19	2026-06-11	10:00-11:00	1	VN	GROSSE (Twingo)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
410	1	19	2026-06-12	10:00-11:00	1	VN	LOUIS Isabelle (R5)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
411	1	19	2026-06-13	10:00-11:00	1	VN	SAHUC (reprise Twingo)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
412	1	19	2026-06-14	10:00-11:00	1	VN	HEALY (fin solde)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
413	1	19	2026-06-13	11:00-12:00	1	VN	PIRONNET (Captur)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
414	1	19	2026-06-11	14:00-15:00	1	VN	SALGADO (Twingo)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
415	1	19	2026-06-14	14:00-15:00	1	VN	DALLOUBEIX (reprise Captur)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
416	1	19	2026-06-12	15:00-16:00	1	VN	SEVAILLE (R5 Megane elec)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
417	1	19	2026-06-11	16:00-17:00	1	VN	DEBONNO (Captur)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
418	1	19	2026-06-12	16:00-17:00	1	VN	DEPRESLE (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
419	1	19	2026-06-13	16:00-17:00	1	VN	LAPORTE (reprise Captur)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
420	1	19	2026-06-12	17:00-18:00	1	VN	CLAVEL (Clio)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
421	1	19	2026-06-13	17:00-18:00	1	VN	GUILLON COTARD (Captur)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
422	1	19	2026-06-15	17:00-18:00	1	VN	PETIT (CLio)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
423	1	20	2026-06-12	11:00-12:00	2	VN	ROUX	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
424	1	20	2026-06-13	11:00-12:00	2	VN	NICODEME	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
425	1	20	2026-06-15	11:00-12:00	2	VN	BARDOTTI	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
426	1	20	2026-06-12	14:00-15:00	2	VN	MOULY	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
427	1	20	2026-06-15	14:00-15:00	2	VN	PLANE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
428	1	20	2026-06-13	16:00-17:00	2	VN	SERRE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
429	1	20	2026-06-14	16:00-17:00	2	VN	GOGEOUR	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
430	1	20	2026-06-15	16:00-17:00	2	VN	BRUSTEL	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
431	1	20	2026-06-12	17:00-18:00	2	VN	JARNIAL	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
432	1	20	2026-06-15	18:00-19:00	2	VN	PEDRINI	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
433	1	21	2026-06-15	09:00-10:00	\N	VO	ESPOSITO	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
434	1	21	2026-06-13	10:00-11:00	\N	VO	PERETON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
435	1	21	2026-06-15	10:00-11:00	\N	VO	FERREIRA	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
436	1	21	2026-06-15	11:00-12:00	\N	VO	COURAGEOT	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
437	1	21	2026-06-13	14:00-15:00	\N	VO	JAFFEUX	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
438	1	21	2026-06-14	14:00-15:00	\N	VO	SOUCHER	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
439	1	21	2026-06-14	16:00-17:00	\N	VO	LARVOL	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
440	1	21	2026-06-12	17:00-18:00	\N	VO	VANDEVILLE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
441	1	21	2026-06-14	17:00-18:00	\N	VO	PLANCHER	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
442	1	21	2026-06-15	18:00-19:00	\N	VO	PETIT	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
443	1	22	2026-06-11	10:00-11:00	\N	VO	SEBASTIEN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
444	1	22	2026-06-13	10:00-11:00	\N	VO	BONIN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
445	1	22	2026-06-13	11:00-12:00	\N	VO	TERKIHADJ	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
446	1	22	2026-06-14	14:00-15:00	\N	VO	FRANCK	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
447	1	22	2026-06-11	15:00-16:00	\N	VO	MARTIN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
448	1	22	2026-06-13	15:00-16:00	\N	VO	MARET	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
449	1	22	2026-06-14	16:00-17:00	\N	VO	FAURE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
450	1	22	2026-06-15	16:00-17:00	\N	VO	BOULANGER	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
451	1	22	2026-06-11	17:00-18:00	\N	VO	PERREIRA	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
452	1	23	2026-06-11	09:00-10:00	\N	VO	SOYDARI	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
453	1	23	2026-06-14	09:00-10:00	\N	VO	COLON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
454	1	23	2026-06-12	10:00-11:00	\N	VO	HANNARD	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
455	1	23	2026-06-11	11:00-12:00	\N	VO	DAMON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
456	1	23	2026-06-11	13:00-14:00	\N	VO	GENESTIER	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
457	1	23	2026-06-12	14:00-15:00	\N	VO	LANDILLON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
458	1	23	2026-06-11	17:00-18:00	\N	VO	PAYET	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
459	1	24	2026-06-12	09:00-10:00	\N	VO	LAMBAIN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
460	1	24	2026-06-14	09:00-10:00	\N	VO	ROUFFET	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
461	1	24	2026-06-14	10:00-11:00	\N	VO	BENIER (CAPTUR)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N
462	1	24	2026-06-13	11:00-12:00	\N	VO	RICHARD	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
463	1	24	2026-06-12	14:00-15:00	\N	VO	ROUDIER (CLIO DIESEL)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
464	1	24	2026-06-13	14:00-15:00	\N	VO	CHEREL (CLIO 5 hev)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
465	1	24	2026-06-14	16:00-17:00	\N	VO	FRUQUIERE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
466	1	24	2026-06-15	16:00-17:00	\N	VO	MALLET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
467	1	24	2026-06-12	17:00-18:00	\N	VO	ADDEO (CLIO)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
468	1	24	2026-06-15	17:00-18:00	\N	VO	GATIGNOL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
469	1	25	2026-06-13	09:00-10:00	\N	VO	EHMIG	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
470	1	25	2026-06-14	09:00-10:00	\N	VO	ROUFFET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
471	1	25	2026-06-11	14:00-15:00	\N	VO	ROUVET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
472	1	25	2026-06-13	14:00-15:00	\N	VO	GORY	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
473	1	25	2026-06-15	14:00-15:00	\N	VO	DEVERNOIS	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
474	1	25	2026-06-14	16:00-17:00	\N	VO	FRUQUIERE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
475	1	25	2026-06-11	17:00-18:00	\N	VO	GHIAB	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
476	1	25	2026-06-12	17:00-18:00	\N	VO	MAUME	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
477	1	25	2026-06-13	17:00-18:00	\N	VO	BONNET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
478	1	25	2026-06-15	17:00-18:00	\N	VO	ANADON LUIS	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
479	1	25	2026-06-15	14:00-15:00	\N	VO	DE SOUSA	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
480	1	3	2026-06-12	09:00-10:00	1	VN	GIAMPRETIE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
481	1	3	2026-06-13	09:00-10:00	1	VN	ALLENDE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
482	1	3	2026-06-14	10:00-11:00	1	VN	BELKADI	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
483	1	3	2026-06-13	11:00-12:00	1	VN	SEMA	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
484	1	3	2026-06-13	14:00-15:00	1	VN	GUYONNET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
485	1	3	2026-06-14	14:00-15:00	1	VN	BERTRAND	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
486	1	3	2026-06-12	15:00-16:00	1	VN	FUZET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
487	1	3	2026-06-15	15:00-16:00	1	VN	LASTIQUE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
488	1	3	2026-06-13	16:00-17:00	1	VN	MUNOZ	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
489	1	3	2026-06-15	16:00-17:00	1	VN	CLEMENT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
490	1	3	2026-06-12	17:00-18:00	1	VN	BRONGNIART	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
491	1	3	2026-06-13	17:00-18:00	1	VN	VERGNE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
492	1	3	2026-06-14	17:00-18:00	1	VN	CHONAL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
493	1	3	2026-06-15	10:00-11:00	2	VN	CHELLES	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
494	1	3	2026-06-12	14:00-15:00	2	VN	PINET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
495	1	3	2026-06-14	14:00-15:00	2	VN	GIUSIANO	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
496	1	3	2026-06-12	16:00-17:00	2	VN	MORIOL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
497	1	4	2026-06-12	08:00-09:00	1	VN	THOMAS	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
498	1	4	2026-06-11	09:00-10:00	1	VN	KUNTZ	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
499	1	4	2026-06-12	09:00-10:00	1	VN	FRADETAL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
500	1	4	2026-06-11	10:00-11:00	1	VN	SEGUIN	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
501	1	4	2026-06-14	10:00-11:00	1	VN	MARTINET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
502	1	4	2026-06-13	11:00-12:00	1	VN	PERONNET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
503	1	4	2026-06-12	14:00-15:00	1	VN	GRAVIL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
504	1	4	2026-06-13	14:00-15:00	1	VN	ARNAUD	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
505	1	4	2026-06-14	14:00-15:00	1	VN	GRENIER	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
506	1	4	2026-06-12	15:00-16:00	1	VN	IMBERT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
507	1	4	2026-06-13	15:00-16:00	1	VN	DECLOUX	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
508	1	4	2026-06-11	17:00-18:00	1	VN	PETITCOLLIN	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
509	1	4	2026-06-13	10:00-11:00	2	VN	ARDAILLON	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
510	1	4	2026-06-11	11:00-12:00	2	VN	COUDERT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
511	1	4	2026-06-11	14:00-15:00	2	VN	BONNOT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
512	1	4	2026-06-13	14:00-15:00	2	VN	ARCHAMBEAU	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
513	1	4	2026-06-11	16:00-17:00	2	VN	CHARVEL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
514	1	4	2026-06-12	17:00-18:00	2	VN	MENUGE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
515	1	5	2026-06-11	09:00-10:00	1	VN	GUERIOT ANNA	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
516	1	5	2026-06-12	09:00-10:00	1	VN	GONZALEZ	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
517	1	5	2026-06-14	09:00-10:00	1	VN	PEROL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
518	1	5	2026-06-14	10:00-11:00	1	VN	TINEL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
519	1	5	2026-06-11	11:00-12:00	1	VN	DUMAS	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
520	1	5	2026-06-11	14:00-15:00	1	VN	PREVOT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
521	1	5	2026-06-12	14:00-15:00	1	VN	PETIT CLEMENT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
522	1	5	2026-06-15	14:00-15:00	1	VN	DEGUIS	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
523	1	5	2026-06-11	15:00-16:00	1	VN	SCHANK	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
524	1	5	2026-06-13	17:00-18:00	1	VN	MARION GILLES	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
525	1	5	2026-06-13	18:00-19:00	1	VN	SCANDELLA	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
526	1	5	2026-06-12	09:00-10:00	2	VN	MORLIN	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
527	1	5	2026-06-11	10:00-11:00	2	VN	SAUVADET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
528	1	5	2026-06-13	11:00-12:00	2	VN	GOUT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
529	1	5	2026-06-11	17:00-18:00	2	VN	GILON	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
530	1	6	2026-06-12	09:00-10:00	1	VN	ROULLEAU (CLIO)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
531	1	6	2026-06-14	09:00-10:00	1	VN	GIRAUD (CAPTUR)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
532	1	6	2026-06-13	10:00-11:00	1	VN	THEUIL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
533	1	6	2026-06-14	10:00-11:00	1	VN	AMBLARD (ESPACE)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
534	1	6	2026-06-15	10:00-11:00	1	VN	DIOGON (AUSTRAL OU RAFALE)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
535	1	6	2026-06-14	11:00-12:00	1	VN	VACHER ( CAPTUR)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
536	1	6	2026-06-13	14:00-15:00	1	VN	DEVILLARD (R5 E TECH)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
537	1	6	2026-06-14	14:00-15:00	1	VN	ESSARD (R5 E TYECH)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
538	1	6	2026-06-14	15:00-16:00	1	VN	CHARMETON (AUSTRAL)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
539	1	6	2026-06-11	16:00-17:00	1	VN	ROAESTER (CLIO)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
540	1	6	2026-06-13	16:00-17:00	1	VN	BOUSSEARE (R5)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
541	1	6	2026-06-11	17:00-18:00	1	VN	BASQUE (R5)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
542	1	6	2026-06-12	18:00-19:00	1	VN	CALDEIRA (CLIO 5 OU 6)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
543	1	6	2026-06-12	08:00-09:00	2	VN	HEMAR (JOGGER)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
544	1	6	2026-06-11	09:00-10:00	2	VN	Thors (Stepway)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
545	1	6	2026-06-11	10:00-11:00	2	VN	FOUCAUD (STEPWAY)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
546	1	6	2026-06-13	11:00-12:00	2	VN	MALARD (SPRING)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
547	1	6	2026-06-11	15:00-16:00	2	VN	PELLET (DUSTER)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
548	1	6	2026-06-11	18:00-19:00	2	VN	FRESCENAUNAI (JOGGER)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
549	1	7	2026-06-13	09:00-10:00	1	VN	MONIER (SCENIC E TECH)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
550	1	7	2026-06-11	10:00-11:00	1	VN	DEBAIN (R5)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
551	1	7	2026-06-12	10:00-11:00	1	VN	BOLLATON (R5)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
552	1	7	2026-06-11	14:00-15:00	1	VN	BRASSIER (CAPTUR)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
553	1	7	2026-06-12	14:00-15:00	1	VN	RASTERO (scenic etech)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
554	1	7	2026-06-13	14:00-15:00	1	VN	PIROIRE MEGANE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
555	1	7	2026-06-15	14:00-15:00	1	VN	RM	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
556	1	7	2026-06-13	15:00-16:00	1	VN	MAGUIGNOU (CLIO 6)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
557	1	7	2026-06-12	16:00-17:00	1	VN	BELLET (R5 ETECH)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
558	1	7	2026-06-13	16:00-17:00	1	VN	FAURE (R4 ETECH)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
559	1	7	2026-06-11	17:00-18:00	1	VN	COURTIAL CLIO 6	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
560	1	7	2026-06-13	10:00-11:00	2	VN	DEBEZ(sandero)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
561	1	7	2026-06-11	11:00-12:00	2	VN	MARTINS (jOGGER)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
562	1	7	2026-06-13	11:00-12:00	2	VN	BELLE SANDERO OU DUSTER	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
563	1	7	2026-06-15	15:00-16:00	2	VN	PONNA SANDERO	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
564	1	7	2026-06-14	17:00-18:00	2	VN	POUILLY (SCENIC)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
565	1	8	2026-06-11	08:00-09:00	\N	VO	THIALLET (Espace 6)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
566	1	8	2026-06-12	08:00-09:00	\N	VO	BIDET (DUSTER)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
567	1	8	2026-06-11	09:00-10:00	\N	VO	PLANCHAT (CLio 5)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
568	1	8	2026-06-13	09:00-10:00	\N	VO	MALESTROIT (DUster)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
569	1	8	2026-06-11	10:00-11:00	\N	VO	SUGERE (ARKANA)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
570	1	8	2026-06-13	10:00-11:00	\N	VO	MORGAN (Clio)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
571	1	8	2026-06-14	10:00-11:00	\N	VO	ABDALAH (reprise clio)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
572	1	8	2026-06-11	11:00-12:00	\N	VO	BOUAJAY (Sandero)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
573	1	8	2026-06-13	11:00-12:00	\N	VO	FIGUERIDO (Megane)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
574	1	8	2026-06-14	11:00-12:00	\N	VO	LIGIER (DOkker)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
575	1	8	2026-06-11	14:00-15:00	\N	VO	ROLLIN (Captur)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
576	1	8	2026-06-13	14:00-15:00	\N	VO	BAUDOIN (Austral)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
577	1	8	2026-06-14	14:00-15:00	\N	VO	DA SILVA (CLio)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
578	1	8	2026-06-15	14:00-15:00	\N	VO	CLEMENT (Captur)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
579	1	8	2026-06-14	15:00-16:00	\N	VO	TESSANDIER (CAPTUR)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
580	1	8	2026-06-13	16:00-17:00	\N	VO	MAZZOLINI (reprise Zoé)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
581	1	8	2026-06-12	17:00-18:00	\N	VO	FOURNIER (Arkana)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
582	1	8	2026-06-15	18:00-19:00	\N	VO	LANDRO (Sandero)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
583	1	9	2026-06-12	08:00-09:00	\N	VO	CORNOT (Austral?)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
584	1	9	2026-06-14	10:00-11:00	\N	VO	PERTIN (CLio)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
585	1	9	2026-06-11	11:00-12:00	\N	VO	AVRIL (Jogger)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
586	1	9	2026-06-13	11:00-12:00	\N	VO	Mairie de BORNES les MIMOSA (Master benne)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
587	1	9	2026-06-14	11:00-12:00	\N	VO	PERTIN (Captur)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
588	1	9	2026-06-11	14:00-15:00	\N	VO	PRADA (Sandero)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
589	1	9	2026-06-12	14:00-15:00	\N	VO	GARDON (Renouvellement elec)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
590	1	9	2026-06-13	14:00-15:00	\N	VO	LAMBERT (Clio hybride 145)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
591	1	9	2026-06-14	14:00-15:00	\N	VO	BAFOURD (Clio)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
592	1	9	2026-06-11	15:00-16:00	\N	VO	VAURE - DENIS (LOA elec)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
593	1	9	2026-06-14	15:00-16:00	\N	VO	MAZE (CLio)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
594	1	9	2026-06-11	16:00-17:00	\N	VO	DEVEAUX (Sandero)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
595	1	9	2026-06-11	17:00-18:00	\N	VO	BOURJIS (Zoé ?)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
596	1	26	2026-06-11	11:00-12:00	1	VN	SIMMONOT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
597	1	26	2026-06-12	14:00-15:00	1	VN	REDONDY	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
598	1	26	2026-06-13	14:00-15:00	1	VN	SULTAN	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
599	1	26	2026-06-13	16:00-17:00	1	VN	CHABOT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
600	1	26	2026-06-11	10:00-11:00	2	VN	BELLEGUEULE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
601	1	26	2026-06-14	11:00-12:00	2	VN	MALAQUI	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
602	1	26	2026-06-12	16:00-17:00	2	VN	JACOB	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
603	1	27	2026-06-11	08:00-09:00	1	VN	¨GOIFFON	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
604	1	27	2026-06-13	10:00-11:00	1	VN	PAREL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
605	1	27	2026-06-14	10:00-11:00	1	VN	FAUGERAS	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
606	1	27	2026-06-13	11:00-12:00	1	VN	SCHOENMAKERS	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
607	1	27	2026-06-12	14:00-15:00	1	VN	NIN	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
608	1	27	2026-06-13	14:00-15:00	1	VN	ARNOULT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
609	1	27	2026-06-11	16:00-17:00	1	VN	GOUYO	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
610	1	27	2026-06-12	11:00-12:00	2	VN	TREUIL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
611	1	27	2026-06-12	15:00-16:00	2	VN	SABOURIN	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
612	1	27	2026-06-13	16:00-17:00	2	VN	JAKSIK	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
613	1	28	2026-06-13	08:00-09:00	\N	VO	GUGGER (DUSTER)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
614	1	28	2026-06-13	09:00-10:00	\N	VO	NOEL (Arkana)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
615	1	28	2026-06-14	10:00-11:00	\N	VO	PRELAT (Spring)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
616	1	28	2026-06-12	14:00-15:00	\N	VO	COSTERO (DUSTER)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
617	1	28	2026-06-13	15:00-16:00	\N	VO	CELERIER (Captur)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
618	1	28	2026-06-14	15:00-16:00	\N	VO	DUPONT (VO)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
619	1	28	2026-06-12	17:00-18:00	\N	VO	BARRAGE (Duster)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
620	1	29	2026-06-13	09:00-10:00	3	VN	MATHE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
621	1	29	2026-06-13	10:00-11:00	3	VN	DUMAZET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
622	1	29	2026-06-14	10:00-11:00	3	VN	DELENCLOS	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
623	1	29	2026-06-12	11:00-12:00	3	VN	BERGOGNE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
624	1	29	2026-06-13	11:00-12:00	3	VN	LEHMAN	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
625	1	29	2026-06-14	11:00-12:00	3	VN	BATISSON	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
626	1	29	2026-06-12	14:00-15:00	3	VN	MOREL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
627	1	29	2026-06-13	14:00-15:00	3	VN	ZHAO	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
628	1	29	2026-06-14	14:00-15:00	3	VN	IERA	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
629	1	29	2026-06-13	15:00-16:00	3	VN	VALETTE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
630	1	29	2026-06-14	15:00-16:00	3	VN	MINET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
631	1	29	2026-06-12	16:00-17:00	3	VN	MEZIN	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
632	1	29	2026-06-13	16:00-17:00	3	VN	BILLEBAULT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
633	1	29	2026-06-13	17:00-18:00	3	VN	BILLEBAULT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
634	1	30	2026-06-12	09:00-10:00	3	VN	lacroix  (l,nore)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
635	1	30	2026-06-11	10:00-11:00	3	VN	THEVENET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
636	1	30	2026-06-12	10:00-11:00	3	VN	IZARD	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
637	1	30	2026-06-13	10:00-11:00	3	VN	CABANO	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
638	1	30	2026-06-14	10:00-11:00	3	VN	chevasson (l,nore)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
639	1	30	2026-06-12	11:00-12:00	3	VN	ramon (l,nore)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
640	1	30	2026-06-13	13:00-14:00	3	VN	garret (l,nore)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
641	1	30	2026-06-11	14:00-15:00	3	VN	PESTANA	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
642	1	30	2026-06-12	14:00-15:00	3	VN	DUCROT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
643	1	30	2026-06-13	14:00-15:00	3	VN	COMBETTES	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
644	1	30	2026-06-14	14:00-15:00	3	VN	gieze (l,nore)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
645	1	30	2026-06-13	15:00-16:00	3	VN	POUZET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
646	1	30	2026-06-11	16:00-17:00	3	VN	SEVESTRE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
647	1	30	2026-06-12	16:00-17:00	3	VN	LAVERGNE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
648	1	30	2026-06-12	17:00-18:00	3	VN	BERNAT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
649	1	1	2026-06-11	09:00-10:00	1	VN	MOUSTEY (Megane VO)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
650	1	1	2026-06-13	09:00-10:00	1	VN	MOURTON (Scenic)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
651	1	1	2026-06-15	09:00-10:00	1	VN	CHEVALIER (CLio 6)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
652	1	1	2026-06-14	10:00-11:00	1	VN	BOUANET (R5)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
653	1	1	2026-06-13	11:00-12:00	1	VN	VIAL (Duster 4x4)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
654	1	1	2026-06-14	11:00-12:00	1	VN	PECOL (R4)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
655	1	1	2026-06-13	15:00-16:00	1	VN	PUERTAS (SANDERO)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
656	1	1	2026-06-12	12:00-13:00	2	VN	ENSMINGER (Spring ou Sandero)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
657	1	1	2026-06-12	15:00-16:00	2	VN	BRIGO (Sandero bleu)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
658	1	2	2026-06-11	09:00-10:00	1	VN	MERCIER (CLIO EVO)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
659	1	2	2026-06-14	09:00-10:00	1	VN	SOULE (GAMME EV)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
660	1	2	2026-06-15	09:00-10:00	1	VN	BOUCHERIE TAVES /VERNY	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
661	1	2	2026-06-12	10:00-11:00	1	VN	Esperaing (Twingo)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N
662	1	2	2026-06-11	11:00-12:00	1	VN	DOME SANCY ARTENSE( KANGOO)	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
663	1	2	2026-06-13	11:00-12:00	1	VN	TERPENEAU (R5)	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
664	1	2	2026-06-11	14:00-15:00	1	VN	PETIT (R5 ETECH)	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
862	1	49	2026-06-12	15:00-16:00	1	VN	Derbias	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
665	1	2	2026-06-13	14:00-15:00	1	VN	MONIER (TWINGO OU R5)	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
666	1	2	2026-06-12	17:00-18:00	1	VN	DARPHIN (TWINGO)	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
667	1	2	2026-06-13	09:00-10:00	2	VN	BERGER SANDERO	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
668	1	2	2026-06-11	16:00-17:00	2	VN	Guillon Duster	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
669	1	42	2026-06-12	09:00-10:00	2	VN	Laustriat Jogger	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
670	1	42	2026-06-13	09:00-10:00	2	VN	Laborde Duster	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
671	1	42	2026-06-11	10:00-11:00	2	VN	Gaillard Sandero	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
672	1	42	2026-06-14	10:00-11:00	2	VN	Molle Sandero	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
673	1	42	2026-06-13	11:00-12:00	2	VN	Fardeau Sandero	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
674	1	42	2026-06-11	14:00-15:00	2	VN	Schmalzle Sandero	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
675	1	42	2026-06-13	14:00-15:00	2	VN	Hissler Sandero	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
676	1	42	2026-06-11	15:00-16:00	2	VN	Mousse Sandero	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
677	1	42	2026-06-12	15:00-16:00	2	VN	Caillavet	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
678	1	42	2026-06-14	15:00-16:00	2	VN	Ferret Sandero	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
679	1	42	2026-06-13	16:00-17:00	2	VN	Gauthier Bigster	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
680	1	42	2026-06-11	17:00-18:00	2	VN	Jonier Duster	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
681	1	42	2026-06-12	17:00-18:00	2	VN	Plet Sandero	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
682	1	43	2026-06-11	08:00-09:00	1	VN	Tourreau Symbioz	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
683	1	43	2026-06-12	08:00-09:00	1	VN	Coudrot Twingo/R5	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
684	1	43	2026-06-13	08:00-09:00	1	VN	Rouyer Clio 6	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
685	1	43	2026-06-14	08:00-09:00	1	VN	Bechonnet R5	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
686	1	43	2026-06-15	08:00-09:00	1	VN	Michon Twingo	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
687	1	43	2026-06-11	09:00-10:00	1	VN	Pontonier Rafale	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
688	1	43	2026-06-13	09:00-10:00	1	VN	Michon R4	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
689	1	43	2026-06-12	10:00-11:00	1	VN	Novac LC R5	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
690	1	43	2026-06-13	10:00-11:00	1	VN	Charpit R4	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
691	1	43	2026-06-13	11:00-12:00	1	VN	Raymond LC R5	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
692	1	43	2026-06-13	14:00-15:00	1	VN	Gammet Austral	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
693	1	43	2026-06-13	15:00-16:00	1	VN	Dumont LC Twingo	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
694	1	43	2026-06-12	16:00-17:00	1	VN	Gibert Symbioz	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
695	1	43	2026-06-15	17:00-18:00	1	VN	Pozzi LC Austral	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
696	1	43	2026-06-12	14:00-15:00	2	VN	Roux LC Duster	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
697	1	43	2026-06-14	14:00-15:00	2	VN	Chouchkaiev Duster	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
698	1	43	2026-06-13	15:00-16:00	2	VN	Gauthier duster	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
699	1	44	2026-06-11	08:00-09:00	1	VN	Bernard Megane E Tech	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
700	1	44	2026-06-11	09:00-10:00	1	VN	Fosse R5	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
701	1	44	2026-06-12	09:00-10:00	1	VN	Guilloux Symbioz	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
702	1	44	2026-06-11	10:00-11:00	1	VN	Danodier	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
703	1	44	2026-06-13	10:00-11:00	1	VN	Laborde R5	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
704	1	44	2026-06-15	10:00-11:00	1	VN	Berrat R5	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
705	1	44	2026-06-12	11:00-12:00	1	VN	Belland Master benne	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
706	1	44	2026-06-13	11:00-12:00	1	VN	Prudhomme R5	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
707	1	44	2026-06-14	11:00-12:00	1	VN	Normand R5	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
708	1	44	2026-06-12	14:00-15:00	1	VN	Singery Clio	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
709	1	44	2026-06-13	14:00-15:00	1	VN	Bertrand Twingo	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
710	1	44	2026-06-14	14:00-15:00	1	VN	Bostivois R5	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
711	1	44	2026-06-12	15:00-16:00	1	VN	Petitjean Twingo	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
712	1	44	2026-06-15	15:00-16:00	1	VN	Riollet Scenic	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
713	1	44	2026-06-12	16:00-17:00	1	VN	Sennepin Austral	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
714	1	44	2026-06-12	18:00-19:00	1	VN	Esnard Baillon clio 6	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
715	1	44	2026-06-11	15:00-16:00	2	VN	Moroy	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
716	1	45	2026-06-14	08:00-09:00	\N	VO	Repos	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
717	1	45	2026-06-13	11:00-12:00	\N	VO	Froliche Clio	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
718	1	45	2026-06-13	15:00-16:00	\N	VO	Lamouche	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
719	1	45	2026-06-11	16:00-17:00	\N	VO	Techer	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
720	1	46	2026-06-13	09:00-10:00	\N	VO	Maire André	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
721	1	46	2026-06-14	09:00-10:00	\N	VO	Da costa	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
722	1	46	2026-06-12	11:00-12:00	\N	VO	Delaye Gladys	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
723	1	46	2026-06-12	17:00-18:00	\N	VO	chapelet Romain	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
724	1	47	2026-06-14	10:00-11:00	\N	VO	El Asheb	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
725	1	47	2026-06-13	14:00-15:00	\N	VO	Auclair	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
726	1	47	2026-06-14	14:00-15:00	\N	VO	Peyrin	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
727	1	47	2026-06-14	15:00-16:00	\N	VO	Bordes	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
728	1	47	2026-06-12	15:00-16:00	\N	VO	Lopez-lage Sandero	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
729	1	31	2026-06-11	09:00-10:00	2	VN	DEPLACE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
730	1	31	2026-06-12	09:00-10:00	2	VN	OCTAVE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
731	1	31	2026-06-13	09:00-10:00	2	VN	MACE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
732	1	31	2026-06-14	09:00-10:00	2	VN	DIOT	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
733	1	31	2026-06-11	10:00-11:00	2	VN	NAJEAN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
734	1	31	2026-06-12	10:00-11:00	2	VN	PERROUX	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
735	1	31	2026-06-11	11:00-12:00	2	VN	RACAT	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
736	1	31	2026-06-11	14:00-15:00	2	VN	MECHIN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
737	1	31	2026-06-12	14:00-15:00	2	VN	M LORQUIN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
738	1	31	2026-06-13	14:00-15:00	2	VN	M BEAUDRON	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
739	1	31	2026-06-14	17:00-18:00	2	VN	MERCIER	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
740	1	32	2026-06-11	09:00-10:00	2	VN	BIGOT	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
741	1	32	2026-06-12	09:00-10:00	2	VN	BUTLER	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
742	1	32	2026-06-13	09:00-10:00	2	VN	RIBES PAPA	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
743	1	32	2026-06-14	09:00-10:00	2	VN	LECLERC	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
744	1	32	2026-06-15	09:00-10:00	2	VN	DESCHAMPS	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
745	1	32	2026-06-12	10:00-11:00	2	VN	STANITTA	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
746	1	32	2026-06-13	10:00-11:00	2	VN	RIBES MAMAN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
747	1	32	2026-06-11	11:00-12:00	2	VN	FERBOS	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
748	1	32	2026-06-13	11:00-12:00	2	VN	RIBES FILLE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
749	1	32	2026-06-11	14:00-15:00	2	VN	COULPIER	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
750	1	32	2026-06-12	14:00-15:00	2	VN	DUBUSSET	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
751	1	32	2026-06-13	14:00-15:00	2	VN	FERREIRA	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
752	1	32	2026-06-14	14:00-15:00	2	VN	MAYER	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
753	1	32	2026-06-11	16:00-17:00	2	VN	GUILLOT	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
754	1	32	2026-06-12	16:00-17:00	2	VN	VASSAL	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
755	1	32	2026-06-11	17:00-18:00	2	VN	LECOIN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
756	1	32	2026-06-12	17:00-18:00	2	VN	LAFONT GAGNIERE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
757	1	32	2026-06-12	18:00-19:00	2	VN	SIMONET	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
758	1	33	2026-06-11	09:00-10:00	1	VN	M ODIN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
759	1	33	2026-06-12	09:00-10:00	1	VN	M VILLE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
760	1	33	2026-06-13	09:00-10:00	1	VN	GARDETTE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
761	1	33	2026-06-14	09:00-10:00	1	VN	TRAFARSKI	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
762	1	33	2026-06-11	10:00-11:00	1	VN	MUYARD	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
763	1	33	2026-06-12	10:00-11:00	1	VN	RIGAUDIAS	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
764	1	33	2026-06-13	10:00-11:00	1	VN	THOUVENET	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
765	1	33	2026-06-14	10:00-11:00	1	VN	BAL	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
766	1	33	2026-06-15	10:00-11:00	1	VN	COURTOIS	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
767	1	33	2026-06-11	11:00-12:00	1	VN	PUCCPCCI	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
768	1	33	2026-06-12	11:00-12:00	1	VN	M TROTIN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
769	1	33	2026-06-13	11:00-12:00	1	VN	BUVAT	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
770	1	33	2026-06-14	11:00-12:00	1	VN	STONS	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
771	1	33	2026-06-11	12:00-13:00	1	VN	M GENESTE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
772	1	33	2026-06-11	14:00-15:00	1	VN	LOMBARD	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
773	1	33	2026-06-12	14:00-15:00	1	VN	GONCALVES	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
774	1	33	2026-06-13	14:00-15:00	1	VN	PAGES	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
775	1	33	2026-06-11	15:00-16:00	1	VN	DAVID	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
776	1	33	2026-06-13	15:00-16:00	1	VN	FARRET	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
777	1	33	2026-06-11	16:00-17:00	1	VN	DECORAY	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
778	1	33	2026-06-12	16:00-17:00	1	VN	M RIESEN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
779	1	33	2026-06-13	16:00-17:00	1	VN	JEUDI	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
780	1	33	2026-06-14	16:00-17:00	1	VN	M RIGAUDIAS	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
781	1	33	2026-06-11	17:00-18:00	1	VN	M HENRIOT	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
782	1	33	2026-06-12	17:00-18:00	1	VN	LE VAN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
783	1	33	2026-06-13	17:00-18:00	1	VN	BOUILLERAND	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
784	1	33	2026-06-15	17:00-18:00	1	VN	MAITRIAS	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
785	1	33	2026-06-11	18:00-19:00	1	VN	CHARLIEU	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
786	1	33	2026-06-12	18:00-19:00	1	VN	ALLIGIER	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
787	1	33	2026-06-13	18:00-19:00	1	VN	M ROUSSEL	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
788	1	34	2026-06-11	09:00-10:00	1	VN	DUJARDIN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
789	1	34	2026-06-13	09:00-10:00	1	VN	LEDOUX	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
790	1	34	2026-06-15	09:00-10:00	1	VN	BELVEDERE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
791	1	34	2026-06-11	10:00-11:00	1	VN	MOREL	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
792	1	34	2026-06-12	10:00-11:00	1	VN	WEIDELICH	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
793	1	34	2026-06-14	10:00-11:00	1	VN	BRANCHI	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
794	1	34	2026-06-11	11:00-12:00	1	VN	BERNARD ALPINE 290	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
795	1	34	2026-06-12	11:00-12:00	1	VN	DEBUSSY	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
796	1	34	2026-06-13	11:00-12:00	1	VN	TETU	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
797	1	34	2026-06-11	15:00-16:00	1	VN	LETIZIA	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
798	1	34	2026-06-12	15:00-16:00	1	VN	JOUFFRE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
799	1	34	2026-06-13	15:00-16:00	1	VN	EVEILLAU	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
800	1	34	2026-06-14	15:00-16:00	1	VN	BEAUDEAN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
801	1	34	2026-06-14	16:00-17:00	1	VN	KOUDOUGOU	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
802	1	34	2026-06-11	17:00-18:00	1	VN	BEAUMET	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
803	1	34	2026-06-12	17:00-18:00	1	VN	DUPRE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
804	1	34	2026-06-13	17:00-18:00	1	VN	MECHIN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
805	1	34	2026-06-15	17:00-18:00	1	VN	GUILLON	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
806	1	34	2026-06-12	18:00-19:00	1	VN	IMBERDIS PAPA	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
807	1	34	2026-06-12	08:00-09:00	2	VN	IMBERDI FILLE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
808	1	35	2026-06-11	08:00-09:00	1	VN	REGNY	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
809	1	35	2026-06-12	08:00-09:00	1	VN	DURANTET	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
810	1	35	2026-06-11	09:00-10:00	1	VN	AMIGO	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
811	1	35	2026-06-12	10:00-11:00	1	VN	GLADINE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
812	1	35	2026-06-13	10:00-11:00	1	VN	TALABARD	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
813	1	35	2026-06-14	10:00-11:00	1	VN	CARRICO	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
814	1	35	2026-06-11	11:00-12:00	1	VN	BUTEY	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
815	1	35	2026-06-11	14:00-15:00	1	VN	DOCHEZ	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
816	1	35	2026-06-13	14:00-15:00	1	VN	MARTIN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
817	1	35	2026-06-14	14:00-15:00	1	VN	SOPHIE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
818	1	35	2026-06-12	16:00-17:00	1	VN	GOUGAT	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
819	1	35	2026-06-11	17:00-18:00	1	VN	GUERET	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
820	1	35	2026-06-14	17:00-18:00	1	VN	REVENU	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
821	1	36	2026-06-11	09:00-10:00	1	VN	BERTHAULT	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
822	1	36	2026-06-11	10:00-11:00	1	VN	MEGE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
823	1	36	2026-06-13	10:00-11:00	1	VN	DURANTET	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
824	1	36	2026-06-12	11:00-12:00	1	VN	JANIQUE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
825	1	36	2026-06-13	15:00-16:00	1	VN	LEMAITRE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
826	1	36	2026-06-14	15:00-16:00	1	VN	PORTTIN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
827	1	36	2026-06-11	16:00-17:00	1	VN	VLACH	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
828	1	36	2026-06-12	16:00-17:00	1	VN	SOCOL	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
829	1	36	2026-06-13	17:00-18:00	1	VN	ROTTAT	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
830	1	39	2026-06-11	09:00-10:00	\N	VO	DAPZOL	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
831	1	39	2026-06-12	09:00-10:00	\N	VO	LABUSSIERE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
832	1	39	2026-06-14	09:00-10:00	\N	VO	DAMPURE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
833	1	39	2026-06-12	14:00-15:00	\N	VO	CASILE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
834	1	39	2026-06-15	14:00-15:00	\N	VO	PROVOST	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
835	1	39	2026-06-13	16:00-17:00	\N	VO	ALIGIER	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
836	1	39	2026-06-11	17:00-18:00	\N	VO	CHANTELOUP	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
837	1	39	2026-06-12	18:00-19:00	\N	VO	MILLER	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
838	1	40	2026-06-11	10:00-11:00	\N	VO	HEDOO	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
839	1	40	2026-06-13	10:00-11:00	\N	VO	LAGACHE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
840	1	40	2026-06-14	11:00-12:00	\N	VO	BONJEAN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
841	1	40	2026-06-11	15:00-16:00	\N	VO	LEDENTU	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
842	1	40	2026-06-14	15:00-16:00	\N	VO	ETIENNE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
843	1	41	2026-06-13	09:00-10:00	\N	VO	GABARD	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
844	1	41	2026-06-14	10:00-11:00	\N	VO	DENNE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
845	1	41	2026-06-13	11:00-12:00	\N	VO	VEYNE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
846	1	41	2026-06-13	14:00-15:00	\N	VO	EYMARD	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
847	1	41	2026-06-14	15:00-16:00	\N	VO	HUSSAR	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
848	1	41	2026-06-12	16:00-17:00	\N	VO	TOUREAU	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
849	1	41	2026-06-13	16:00-17:00	\N	VO	BELOT	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
850	1	41	2026-06-15	16:00-17:00	\N	VO	NAVARRE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
851	1	41	2026-06-11	17:00-18:00	\N	VO	PATON	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
852	1	48	2026-06-13	08:00-09:00	1	VN	Absent	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
853	1	48	2026-06-11	09:00-10:00	1	VN	M Languedoc	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
854	1	48	2026-06-12	11:00-12:00	1	VN	M Crohas	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
855	1	48	2026-06-11	18:00-19:00	1	VN	M Massimino	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
856	1	48	2026-06-12	09:00-10:00	2	VN	M Legay	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
857	1	49	2026-06-11	09:00-10:00	1	VN	M Gardes	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
858	1	49	2026-06-13	09:00-10:00	1	VN	Thiers	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
859	1	49	2026-06-15	09:00-10:00	1	VN	M Pasquet	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
860	1	49	2026-06-11	10:00-11:00	1	VN	M Fayolle	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
861	1	49	2026-06-12	11:00-12:00	1	VN	Fouillot	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N
863	1	49	2026-06-13	16:00-17:00	1	VN	Chouvel	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
864	1	49	2026-06-14	10:00-11:00	2	VN	Buvat	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
865	1	49	2026-06-12	11:00-12:00	2	VN	Chefdeville	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
866	1	49	2026-06-11	14:00-15:00	2	VN	M Gouttetoque	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
867	1	49	2026-06-13	14:00-15:00	2	VN	Culpo	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
868	1	50	2026-06-13	09:00-10:00	1	VN	M Roccetto	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
869	1	50	2026-06-14	09:00-10:00	1	VN	M Dartois	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
870	1	50	2026-06-11	10:00-11:00	1	VN	M Gentil	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
871	1	50	2026-06-12	10:00-11:00	1	VN	M Haverland	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
872	1	50	2026-06-13	10:00-11:00	1	VN	M Goutefangheas	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
873	1	50	2026-06-14	10:00-11:00	1	VN	M Mathe	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
874	1	50	2026-06-11	14:00-15:00	1	VN	M Arnaud	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
875	1	50	2026-06-12	14:00-15:00	1	VN	Mme Bonnal	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
876	1	50	2026-06-14	14:00-15:00	1	VN	M Raymond	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
877	1	50	2026-06-15	14:00-15:00	1	VN	M Privat	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
878	1	50	2026-06-11	15:00-16:00	1	VN	M Escailler	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
879	1	50	2026-06-12	15:00-16:00	1	VN	M Couturier	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
880	1	50	2026-06-14	15:00-16:00	1	VN	M Roche	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
881	1	50	2026-06-11	17:00-18:00	1	VN	M Ferrier	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
882	1	50	2026-06-12	18:00-19:00	1	VN	Mme Mazellier	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
883	1	51	2026-06-14	09:00-10:00	\N	VO	M Perrin	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
884	1	51	2026-06-11	10:00-11:00	\N	VO	M Monteilhet	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
885	1	51	2026-06-14	15:00-16:00	\N	VO	M Pousset	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
886	1	51	2026-06-11	18:00-19:00	\N	VO	M Gomez	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
887	1	52	2026-06-14	08:00-09:00	\N	VO	absent	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
888	1	52	2026-06-13	09:00-10:00	\N	VO	M Roussillon	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
889	1	52	2026-06-11	10:00-11:00	\N	VO	M Montpetroux	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
890	1	52	2026-06-12	10:00-11:00	\N	VO	M Delbege	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
891	1	52	2026-06-13	10:00-11:00	\N	VO	M Plazenet	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
892	1	52	2026-06-13	11:00-12:00	\N	VO	M Montereal	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
893	1	52	2026-06-11	14:00-15:00	\N	VO	M Leudir	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
894	1	52	2026-06-11	15:00-16:00	\N	VO	M Borel	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
895	1	52	2026-06-12	15:00-16:00	\N	VO	M Brugas	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
896	1	52	2026-06-11	16:00-17:00	\N	VO	M Nicolas	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
897	1	52	2026-06-11	17:00-18:00	\N	VO	M Barge	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
898	1	52	2026-06-12	17:00-18:00	\N	VO	M Poquet	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
899	1	62	2026-06-13	09:00-10:00	1	VN	Mr DOUIX	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
900	1	62	2026-06-14	10:00-11:00	1	VN	Mme DEGOUDE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
901	1	62	2026-06-13	11:00-12:00	1	VN	Mme PALKHIVALA	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
902	1	62	2026-06-13	14:00-15:00	1	VN	JEANNNOT	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
903	1	62	2026-06-14	14:00-15:00	1	VN	MmeTAMAGNI	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
904	1	62	2026-06-11	15:00-16:00	1	VN	Mme APTEL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
905	1	62	2026-06-13	15:00-16:00	1	VN	GROLIERE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
906	1	62	2026-06-14	16:00-17:00	1	VN	Mme MORVAN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
907	1	62	2026-06-11	17:00-18:00	1	VN	Mme VALENTE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
908	1	62	2026-06-14	15:00-16:00	2	VN	Mme RODIER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
909	1	63	2026-06-13	10:00-11:00	1	VN	ROBILLON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
910	1	63	2026-06-12	11:00-12:00	1	VN	PINET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
911	1	63	2026-06-12	15:00-16:00	1	VN	DUMAS	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
912	1	63	2026-06-13	15:00-16:00	1	VN	ABOU SAMRA	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
913	1	63	2026-06-14	15:00-16:00	1	VN	DELORME	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
914	1	63	2026-06-13	17:00-18:00	1	VN	GARTILLON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
915	1	63	2026-06-14	10:00-11:00	2	VN	DELBOS	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
916	1	63	2026-06-13	11:00-12:00	2	VN	SAUVESTRE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
917	1	63	2026-06-13	14:00-15:00	2	VN	FIORENTINO	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
918	1	63	2026-06-11	15:00-16:00	2	VN	HALLIROL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
919	1	63	2026-06-11	16:00-17:00	2	VN	COMPTE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
920	1	63	2026-06-12	16:00-17:00	2	VN	DALBE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
921	1	63	2026-06-13	16:00-17:00	2	VN	CONTOUX	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
922	1	63	2026-06-11	17:00-18:00	2	VN	BELLY	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
923	1	65	2026-06-11	08:00-09:00	1	VN	Mme BERTRAND	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
924	1	65	2026-06-11	09:00-10:00	1	VN	Mr MORAND	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
925	1	65	2026-06-14	11:00-12:00	1	VN	Mr FOURNIER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
926	1	65	2026-06-14	14:00-15:00	1	VN	BESSON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
927	1	65	2026-06-12	15:00-16:00	1	VN	DEAN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
928	1	65	2026-06-13	18:00-19:00	1	VN	Mr SELLIN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
929	1	65	2026-06-11	09:00-10:00	2	VN	DEMANGE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
930	1	65	2026-06-14	09:00-10:00	2	VN	M VIGANOTTI	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
931	1	65	2026-06-11	11:00-12:00	2	VN	M MOLLE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
932	1	65	2026-06-11	14:00-15:00	2	VN	Mme  CROS	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
933	1	66	2026-06-11	09:00-10:00	1	VN	MAHAUT	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
934	1	66	2026-06-11	11:00-12:00	1	VN	CAUTAL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
935	1	66	2026-06-13	11:00-12:00	1	VN	JEANNOT	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
936	1	66	2026-06-11	14:00-15:00	1	VN	LECOCALI	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
937	1	66	2026-06-12	14:00-15:00	1	VN	RAMEL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
938	1	66	2026-06-12	15:00-16:00	1	VN	BRAS	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
939	1	66	2026-06-12	16:00-17:00	1	VN	PILLON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
940	1	66	2026-06-11	10:00-11:00	2	VN	GIOAN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
941	1	66	2026-06-12	10:00-11:00	2	VN	DUPART	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
942	1	66	2026-06-13	10:00-11:00	2	VN	MEURIE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
943	1	66	2026-06-15	10:00-11:00	2	VN	BRUCIAMACCHIE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
944	1	66	2026-06-13	12:00-13:00	2	VN	GROLIERES	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
945	1	66	2026-06-13	13:00-14:00	2	VN	BACHAYTER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
946	1	66	2026-06-14	14:00-15:00	2	VN	BEABIN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
947	1	66	2026-06-14	15:00-16:00	2	VN	ESTRADE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
948	1	66	2026-06-11	16:00-17:00	2	VN	ZYMAN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
949	1	66	2026-06-11	17:00-18:00	2	VN	NARCE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
950	1	66	2026-06-11	18:00-19:00	2	VN	NARCE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
951	1	67	2026-06-15	09:00-10:00	1	VN	I	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
952	1	67	2026-06-11	10:00-11:00	1	VN	CROS	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
953	1	67	2026-06-14	10:00-11:00	1	VN	OUDOUL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
954	1	67	2026-06-14	11:00-12:00	1	VN	DUFEUTEULE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
955	1	67	2026-06-12	14:00-15:00	1	VN	CARBASSE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
956	1	67	2026-06-14	15:00-16:00	1	VN	ROCHES	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
957	1	67	2026-06-12	17:00-18:00	1	VN	BOUQUET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
958	1	67	2026-06-13	18:00-19:00	1	VN	BOURDON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
959	1	67	2026-06-11	09:00-10:00	2	VN	MEUNIER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
960	1	67	2026-06-12	09:00-10:00	2	VN	HERITIER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
961	1	67	2026-06-13	09:00-10:00	2	VN	ROBILLON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
962	1	67	2026-06-13	10:00-11:00	2	VN	PEDRONETTO	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
963	1	67	2026-06-13	11:00-12:00	2	VN	MAISONNEUVE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
964	1	67	2026-06-11	14:00-15:00	2	VN	TISSERAND	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
965	1	67	2026-06-12	16:00-17:00	2	VN	ROFFET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
966	1	67	2026-06-14	16:00-17:00	2	VN	ANSELLEME	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
967	1	68	2026-06-11	08:00-09:00	\N	VO	DAUBARD	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
968	1	68	2026-06-12	08:00-09:00	\N	VO	TRASSOUDAINE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
969	1	68	2026-06-11	09:00-10:00	\N	VO	Mme DELPAGNE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
970	1	68	2026-06-11	10:00-11:00	\N	VO	I	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
971	1	68	2026-06-13	10:00-11:00	\N	VO	Mme BICHERAY	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
972	1	68	2026-06-11	14:00-15:00	\N	VO	Mme SEMBEL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
973	1	68	2026-06-11	08:00-09:00	\N	VO	COSTON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
974	1	68	2026-06-12	10:00-11:00	\N	VO	MAZET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
975	1	68	2026-06-13	14:00-15:00	\N	VO	MMe PARDANAUD	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
976	1	68	2026-06-12	16:00-17:00	\N	VO	Mme GARINOT	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
977	1	69	2026-06-13	10:00-11:00	\N	VO	TALLOBRE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
978	1	69	2026-06-13	14:00-15:00	\N	VO	PORTEIX	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
979	1	69	2026-06-11	18:00-19:00	\N	VO	MONDILLON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
980	1	70	2026-06-11	09:00-10:00	\N	VO	NOUGUIER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
981	1	70	2026-06-13	09:00-10:00	\N	VO	PLANTIN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
982	1	70	2026-06-13	10:00-11:00	\N	VO	DIAS	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
983	1	70	2026-06-11	11:00-12:00	\N	VO	DUCHER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
984	1	70	2026-06-11	14:00-15:00	\N	VO	PERRIN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
985	1	70	2026-06-13	14:00-15:00	\N	VO	BENKEMOUN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
986	1	70	2026-06-11	15:00-16:00	\N	VO	PRANYES	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
987	1	70	2026-06-11	16:00-17:00	\N	VO	BREJAUD	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
988	1	70	2026-06-11	08:00-09:00	\N	VO	ANGLADE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
989	1	70	2026-06-11	10:00-11:00	\N	VO	LAPELEGERIE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
990	1	70	2026-06-12	10:00-11:00	\N	VO	BARD	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
991	1	70	2026-06-12	11:00-12:00	\N	VO	VANDERSUISSE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
992	1	53	2026-06-11	08:00-09:00	1	VN	DELALANDE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
993	1	53	2026-06-11	09:00-10:00	1	VN	CHABERT	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
994	1	53	2026-06-11	10:00-11:00	1	VN	VIGOUROUX	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
995	1	53	2026-06-13	10:00-11:00	1	VN	LYOTARD	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
996	1	53	2026-06-14	10:00-11:00	1	VN	VILLESECHE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
997	1	53	2026-06-13	11:00-12:00	1	VN	FAURE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
998	1	53	2026-06-11	14:00-15:00	1	VN	SAGNARD	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
999	1	53	2026-06-12	14:00-15:00	1	VN	BEGEY	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1000	1	53	2026-06-13	14:00-15:00	1	VN	CHARBONNEL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1001	1	53	2026-06-12	15:00-16:00	1	VN	CHABERT	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1002	1	53	2026-06-13	15:00-16:00	1	VN	OUILON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1003	1	53	2026-06-14	15:00-16:00	1	VN	ORFEUBRE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1004	1	53	2026-06-12	16:00-17:00	1	VN	DELUBAC	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1005	1	53	2026-06-13	16:00-17:00	1	VN	AURELLE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1006	1	53	2026-06-14	16:00-17:00	1	VN	MAUACI	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1007	1	53	2026-06-12	17:00-18:00	1	VN	SOUCHON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1008	1	53	2026-06-12	18:00-19:00	1	VN	MAGNE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1009	1	53	2026-06-12	13:00-14:00	2	VN	VALLET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1010	1	53	2026-06-11	15:00-16:00	2	VN	RAFFARD DE BRIENNE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1011	1	54	2026-06-11	09:00-10:00	1	VN	M GUILLON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1012	1	54	2026-06-12	10:00-11:00	1	VN	Mr PILlOT	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1013	1	54	2026-06-14	10:00-11:00	1	VN	Mr COURTIAL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1014	1	54	2026-06-11	11:00-12:00	1	VN	ART FLORAL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1015	1	54	2026-06-12	11:00-12:00	1	VN	MR LAUBUGE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1016	1	54	2026-06-12	14:00-15:00	1	VN	Mme TEYSSIER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1017	1	54	2026-06-12	17:00-18:00	1	VN	Mme VAUZELLE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1018	1	54	2026-06-13	09:00-10:00	2	VN	Mme ROCHETTE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1019	1	54	2026-06-11	13:00-14:00	2	VN	Mme PAQUIN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1020	1	55	2026-06-11	09:00-10:00	1	VN	DAVID / LANGEAC	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1021	1	55	2026-06-13	09:00-10:00	1	VN	DREYFUS	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1022	1	55	2026-06-11	10:00-11:00	1	VN	BESSON / LANGEAC	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1023	1	55	2026-06-15	14:00-15:00	1	VN	GERANTON / VOREY	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1024	1	55	2026-06-11	09:00-10:00	2	VN	GOBELET / LANGEAC	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1025	1	55	2026-06-11	14:00-15:00	2	VN	GIRARD / SERVEL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1026	1	55	2026-06-12	14:00-15:00	2	VN	BESSON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1027	1	55	2026-06-11	17:00-18:00	2	VN	MARIN / BIGSTER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1028	1	56	2026-06-12	10:00-11:00	1	VN	DUPUIS	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1029	1	56	2026-06-13	10:00-11:00	1	VN	JOUANNY	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1030	1	56	2026-06-14	10:00-11:00	1	VN	PONTVIANNE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1031	1	56	2026-06-15	10:00-11:00	1	VN	BOUCHET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1032	1	56	2026-06-11	11:00-12:00	1	VN	BONNET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1033	1	56	2026-06-13	13:00-14:00	1	VN	BATTONET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1034	1	56	2026-06-15	14:00-15:00	1	VN	CROS	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1035	1	56	2026-06-13	15:00-16:00	1	VN	NOUVET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1036	1	56	2026-06-14	16:00-17:00	1	VN	AVOUAC	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1037	1	56	2026-06-15	16:00-17:00	1	VN	MAZET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1038	1	56	2026-06-11	10:00-11:00	2	VN	MULLER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1039	1	57	2026-06-13	09:00-10:00	\N	VO	M COURJAUD	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1040	1	57	2026-06-14	09:00-10:00	\N	VO	9h30 Berger	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1041	1	57	2026-06-13	11:00-12:00	\N	VO	Mr MEZIN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1042	1	57	2026-06-12	14:00-15:00	\N	VO	MMe BOSSAERT	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1043	1	58	2026-06-11	10:00-11:00	\N	VO	ROUSSET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1044	1	58	2026-06-14	10:00-11:00	\N	VO	TORRESAN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1045	1	58	2026-06-13	11:00-12:00	\N	VO	VIALVIELLE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1046	1	58	2026-06-13	13:00-14:00	\N	VO	DARBOUSSET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1047	1	58	2026-06-11	14:00-15:00	\N	VO	DAMIEN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1048	1	58	2026-06-12	14:00-15:00	\N	VO	CIODOIU	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1049	1	58	2026-06-11	15:00-16:00	\N	VO	JEANNIN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1050	1	58	2026-06-11	16:00-17:00	\N	VO	CLUZEL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1051	1	58	2026-06-14	16:00-17:00	\N	VO	DUMOND	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1052	1	58	2026-06-12	17:00-18:00	\N	VO	RODRIGUES	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1053	1	58	2026-06-11	18:00-19:00	\N	VO	LIOGIER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1054	1	59	2026-06-12	09:00-10:00	1	VN	TAULAMESSE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1055	1	59	2026-06-13	09:00-10:00	1	VN	BADUEL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1056	1	59	2026-06-11	10:00-11:00	1	VN	MARCU	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1057	1	59	2026-06-13	10:00-11:00	1	VN	BERNIER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1058	1	59	2026-06-14	10:00-11:00	1	VN	HERME	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1059	1	59	2026-06-14	11:00-12:00	1	VN	CALANDRE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1060	1	59	2026-06-13	14:00-15:00	1	VN	PEPIN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1061	1	59	2026-06-11	16:00-17:00	1	VN	LEITAO	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N
1062	1	59	2026-06-15	16:00-17:00	1	VN	COLLET	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1063	1	59	2026-06-13	17:00-18:00	1	VN	BRUNET	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1064	1	59	2026-06-11	18:00-19:00	1	VN	OZIOL	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1065	1	59	2026-06-12	10:00-11:00	2	VN	PELOTHIER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1066	1	59	2026-06-12	14:00-15:00	2	VN	SEGOLA	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1067	1	59	2026-06-14	14:00-15:00	2	VN	POUDEVIGNE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1068	1	59	2026-06-12	15:00-16:00	2	VN	BROJAN	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1069	1	59	2026-06-12	16:00-17:00	2	VN	FOURNIER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1070	1	59	2026-06-12	17:00-18:00	2	VN	GAUGAIN	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1071	1	61	2026-06-12	10:00-11:00	\N	VO	REMISE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1072	1	61	2026-06-15	10:00-11:00	\N	VO	SOANE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1073	1	61	2026-06-11	14:00-15:00	\N	VO	JIMENEZ	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1074	1	61	2026-06-13	14:00-15:00	\N	VO	DELRIEU	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1075	1	61	2026-06-14	14:00-15:00	\N	VO	PORTAL	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1076	1	61	2026-06-12	09:00-10:00	\N	VO	DELON	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1077	1	61	2026-06-14	10:00-11:00	\N	VO	MONIEZ	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1078	1	61	2026-06-12	14:00-15:00	\N	VO	MONTESANI	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1079	1	61	2026-06-13	16:00-17:00	\N	VO	REMIZE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1080	1	61	2026-06-12	17:00-18:00	\N	VO	ASTIER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1081	1	61	2026-06-12	18:00-19:00	\N	VO	TROCELLIER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1082	1	79	2026-06-13	09:00-10:00	1	VN	BONAMI DUSTER CAPTUR	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1083	1	79	2026-06-11	10:00-11:00	1	VN	LEGRAND TWINGO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1084	1	79	2026-06-12	11:00-12:00	1	VN	BELLIERE R4	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1085	1	79	2026-06-13	15:00-16:00	1	VN	GARIN TW3 OU R5	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1086	1	79	2026-06-12	16:00-17:00	2	VN	DELOUS SANDERO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1087	1	79	2026-06-13	16:00-17:00	2	VN	DOMERGUES SPRING OU SANDERO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1088	1	79	2026-06-11	17:00-18:00	2	VN	BARBIER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1089	1	79	2026-06-13	17:00-18:00	2	VN	GARCIA CLIO 6	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1090	1	80	2026-06-11	08:00-09:00	1	VN	OLIVIER TWINGO VD	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1091	1	80	2026-06-11	09:00-10:00	1	VN	GUTFREND CLIO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1092	1	80	2026-06-12	09:00-10:00	1	VN	AURIOL TWINGO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1093	1	80	2026-06-13	09:00-10:00	1	VN	ESPINASSE RENOUV ZOE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1094	1	80	2026-06-11	10:00-11:00	1	VN	VASILIC TWINGO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1095	1	80	2026-06-12	10:00-11:00	1	VN	CROS CLIO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1096	1	80	2026-06-13	10:00-11:00	1	VN	CARRIERE RENOUV MEGANE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1097	1	80	2026-06-15	10:00-11:00	1	VN	BLANC	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1098	1	80	2026-06-11	11:00-12:00	1	VN	DUBAR CAPTUR	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1099	1	80	2026-06-15	11:00-12:00	1	VN	LACLEDE RENOUV MEGANE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1100	1	80	2026-06-11	12:00-13:00	1	VN	MOULY RENOUV ZOE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1101	1	80	2026-06-11	13:00-14:00	1	VN	MOLINIER CAPTUR	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1102	1	80	2026-06-11	14:00-15:00	1	VN	MAZARS	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1103	1	80	2026-06-12	14:00-15:00	1	VN	FLEURY SCENIC	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1104	1	80	2026-06-12	15:00-16:00	1	VN	DELOUS CLIO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1105	1	80	2026-06-11	16:00-17:00	1	VN	JOULIA	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1106	1	80	2026-06-11	17:00-18:00	1	VN	MERCIER A VOIR	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1107	1	80	2026-06-11	18:00-19:00	1	VN	ROUSSELLE RENOUV ZOE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1108	1	81	2026-06-14	14:00-15:00	1	VN	GRIBBAL TWINGO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1109	1	81	2026-06-11	18:00-19:00	1	VN	CHENE CHRISTOPHE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1110	1	81	2026-06-12	09:00-10:00	2	VN	BARRETTE SANDERO VD	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1111	1	81	2026-06-11	10:00-11:00	2	VN	QUENHE JOGGER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1112	1	81	2026-06-12	11:00-12:00	2	VN	GATIMEL DUSTER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1113	1	81	2026-06-14	12:00-13:00	2	VN	FOUCAT SANDERO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1114	1	81	2026-06-11	16:00-17:00	2	VN	FABIE SANDERO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1115	1	82	2026-06-11	09:00-10:00	1	VN	CARLES	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1116	1	82	2026-06-13	09:00-10:00	1	VN	ROGUET MEGANE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1117	1	82	2026-06-11	10:00-11:00	1	VN	FAGES	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1118	1	82	2026-06-12	10:00-11:00	1	VN	VERNES CLIO 6	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1119	1	82	2026-06-13	10:00-11:00	1	VN	MURAT SCENIC	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1120	1	82	2026-06-15	10:00-11:00	1	VN	PHOUMAN CLIO 5	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1121	1	82	2026-06-13	11:00-12:00	1	VN	DELMAS TWINGO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1122	1	82	2026-06-13	12:00-13:00	1	VN	NOWFOL R4	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1123	1	82	2026-06-13	14:00-15:00	1	VN	ALONZO CLIO 6	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1124	1	82	2026-06-13	16:00-17:00	1	VN	FRUNEAU TWINGO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1125	1	82	2026-06-11	17:00-18:00	1	VN	GEMARIN	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1126	1	82	2026-06-12	17:00-18:00	1	VN	ALBERT SCENIC	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1127	1	82	2026-06-12	09:00-10:00	2	VN	LERIDENT BIGSTER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1128	1	82	2026-06-11	14:00-15:00	2	VN	DEGUIRARD DUSTER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1129	1	82	2026-06-13	15:00-16:00	2	VN	DOMERGUES JOGGER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1130	1	82	2026-06-11	17:00-18:00	2	VN	BLANQUET SANDERO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1131	1	83	2026-06-13	10:00-11:00	\N	VO	HYGONET	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1132	1	83	2026-06-12	11:00-12:00	\N	VO	MER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1133	1	83	2026-06-14	11:00-12:00	\N	VO	REDOULES	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1134	1	83	2026-06-13	15:00-16:00	\N	VO	LADET TWINGO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1135	1	83	2026-06-14	15:00-16:00	\N	VO	MOUNIRAT	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1136	1	83	2026-06-11	16:00-17:00	\N	VO	COMBRET SPRING	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1137	1	83	2026-06-13	16:00-17:00	\N	VO	ALFONSO JOGGER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1138	1	83	2026-06-14	16:00-17:00	\N	VO	BEN DAOUD	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1139	1	84	2026-06-13	09:00-10:00	\N	VO	LEONNARD CLIO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1140	1	84	2026-06-12	15:00-16:00	\N	VO	THERON CLIO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1141	1	84	2026-06-11	17:00-18:00	\N	VO	MAUME ZOE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1142	1	84	2026-06-12	17:00-18:00	\N	VO	LACAN MELANIE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1143	1	84	2026-06-13	17:00-18:00	\N	VO	ESTELLE CAVALERIE ZE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1144	1	85	2026-06-12	10:00-11:00	\N	VO	AGUERA AUDI A1	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1145	1	85	2026-06-15	11:00-12:00	\N	VO	PANOT	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1146	1	85	2026-06-12	14:00-15:00	\N	VO	BLANC CAPTUR	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1147	1	85	2026-06-12	15:00-16:00	\N	VO	RAYNAL CAPTUR	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1148	1	92	2026-06-11	10:00-11:00	1	VN	TOVAR	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1149	1	92	2026-06-12	10:00-11:00	1	VN	MERDRIGNAC	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1150	1	92	2026-06-11	11:00-12:00	1	VN	NOZIERES	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1151	1	92	2026-06-12	11:00-12:00	1	VN	GARD	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1152	1	92	2026-06-12	14:00-15:00	1	VN	OGLAZA	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1153	1	92	2026-06-13	14:00-15:00	1	VN	CONSTENSOU	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1154	1	92	2026-06-12	15:00-16:00	1	VN	SOULIER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1155	1	92	2026-06-13	15:00-16:00	1	VN	MEZGHANI	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1156	1	92	2026-06-11	16:00-17:00	1	VN	LUSSIER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1157	1	92	2026-06-12	16:00-17:00	1	VN	PICARONNY	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1158	1	92	2026-06-11	17:00-18:00	1	VN	MESTRIES	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1159	1	92	2026-06-12	17:00-18:00	1	VN	THEATE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1160	1	92	2026-06-15	17:00-18:00	1	VN	DEGUIRARD	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1161	1	92	2026-06-11	18:00-19:00	1	VN	HEBRARD	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1162	1	92	2026-06-12	18:00-19:00	1	VN	BEDOUSSAC	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1163	1	92	2026-06-11	09:00-10:00	2	VN	GUILLERON	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1164	1	92	2026-06-13	09:00-10:00	2	VN	KAIQUE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1165	1	92	2026-06-13	17:00-18:00	2	VN	CHAILLOU	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1166	1	93	2026-06-11	09:00-10:00	1	VN	MOISSINAC	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1167	1	93	2026-06-13	09:00-10:00	1	VN	FALIES	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1168	1	93	2026-06-13	10:00-11:00	1	VN	BESSE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1169	1	93	2026-06-11	11:00-12:00	1	VN	LACROZE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1170	1	93	2026-06-11	14:00-15:00	1	VN	LIMBERTIE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1171	1	93	2026-06-12	14:00-15:00	1	VN	KIALA	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1172	1	93	2026-06-15	14:00-15:00	1	VN	LASFAUX	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1173	1	93	2026-06-12	15:00-16:00	1	VN	TRIN	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1174	1	93	2026-06-13	15:00-16:00	1	VN	LALOIS	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1175	1	93	2026-06-15	17:00-18:00	1	VN	NEY	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1176	1	93	2026-06-11	10:00-11:00	2	VN	PUECH	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1177	1	93	2026-06-13	17:00-18:00	2	VN	REUR	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1178	1	94	2026-06-13	09:00-10:00	1	VN	VEYRIERES	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1179	1	94	2026-06-15	09:00-10:00	1	VN	CHARMES	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1180	1	94	2026-06-12	10:00-11:00	1	VN	LORCY	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1181	1	94	2026-06-11	11:00-12:00	1	VN	PRUNIERES	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1182	1	94	2026-06-12	14:00-15:00	1	VN	LAJARRIGE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1183	1	94	2026-06-13	14:00-15:00	1	VN	COUET	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1184	1	94	2026-06-15	15:00-16:00	1	VN	ESPALIEU	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1185	1	94	2026-06-15	17:00-18:00	1	VN	VEILLY	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1186	1	94	2026-06-15	18:00-19:00	1	VN	RODDE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1187	1	94	2026-06-13	10:00-11:00	2	VN	ROCHE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1188	1	94	2026-06-15	10:00-11:00	2	VN	CONSTANT	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1189	1	94	2026-06-13	11:00-12:00	2	VN	DANIS	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1190	1	94	2026-06-12	17:00-18:00	2	VN	FREYTET	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1191	1	86	2026-06-15	09:00-10:00	1	VN	GINESTET (Clio GPL)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1192	1	86	2026-06-11	10:00-11:00	1	VN	GUILLEMIN (Espace VD)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1193	1	86	2026-06-12	10:00-11:00	1	VN	BERNADMONT (Twingo)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1194	1	86	2026-06-13	10:00-11:00	1	VN	BLANC (Clio)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1195	1	86	2026-06-14	11:00-12:00	1	VN	GUIBBERT (Clio VI)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1196	1	86	2026-06-12	14:00-15:00	1	VN	MALLAT (Twingo)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1197	1	86	2026-06-13	14:00-15:00	1	VN	PERSEGOL (Captur)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1198	1	86	2026-06-14	14:00-15:00	1	VN	HURGON (Captur)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1199	1	86	2026-06-15	14:00-15:00	1	VN	BELMOTKAR  (Captur)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1200	1	86	2026-06-11	15:00-16:00	1	VN	GAVALDA (Clio)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1201	1	86	2026-06-13	16:00-17:00	1	VN	GALZIN (Rafale)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1202	1	86	2026-06-11	17:00-18:00	1	VN	CHEVALIER (Clio ou Captur)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1203	1	86	2026-06-12	18:00-19:00	1	VN	RAVELEAU (Clio)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1204	1	87	2026-06-11	09:00-10:00	2	VN	MAURY (Duster)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1205	1	87	2026-06-13	09:00-10:00	2	VN	RICHARD (Master VO)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1206	1	87	2026-06-12	10:00-11:00	2	VN	BOONEFOUS (duster)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1207	1	87	2026-06-11	11:00-12:00	2	VN	WILLERMACK (Duster LOA)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1208	1	87	2026-06-12	11:00-12:00	2	VN	GINESTE (Sandero)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1209	1	87	2026-06-13	11:00-12:00	2	VN	DANILL (Duster LOA)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1210	1	87	2026-06-15	11:00-12:00	2	VN	ROCHER (Sandero)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1211	1	87	2026-06-11	14:00-15:00	2	VN	VIALE (Jogger en LOA)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1212	1	87	2026-06-12	14:00-15:00	2	VN	LAMOTTE (Sandero)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1213	1	87	2026-06-13	14:00-15:00	2	VN	BOURDAIS (etech)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1214	1	87	2026-06-11	15:00-16:00	2	VN	GAL (Sandero LOA)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1215	1	87	2026-06-13	15:00-16:00	2	VN	AMDRAUD (Sandero)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1216	1	87	2026-06-13	16:00-17:00	2	VN	Carriere (Bigster)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1217	1	71	2026-06-11	09:00-10:00	1	VN	JANIN Rafale	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1218	1	71	2026-06-12	09:00-10:00	1	VN	POMPIER Scenic	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1219	1	71	2026-06-13	10:00-11:00	1	VN	CARRE R5	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1220	1	71	2026-06-11	11:00-12:00	1	VN	RAFRE Scenic	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1221	1	71	2026-06-12	11:00-12:00	1	VN	DURIF R5	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1222	1	71	2026-06-11	14:00-15:00	1	VN	RICARDOU Twingo	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1223	1	71	2026-06-11	15:00-16:00	1	VN	CHEVILLER R5	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1224	1	71	2026-06-12	15:00-16:00	1	VN	PAILLASSA R5	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1225	1	71	2026-06-13	15:00-16:00	1	VN	DABLANC Kangoo	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1226	1	71	2026-06-11	17:00-18:00	1	VN	AUZAN R5	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1227	1	72	2026-06-11	09:00-10:00	1	VN	VARLET Megane	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1228	1	72	2026-06-12	09:00-10:00	1	VN	PATAQUI R5	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1229	1	72	2026-06-11	10:00-11:00	1	VN	LEVY Captur	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1230	1	72	2026-06-12	10:00-11:00	1	VN	CHAPLIN Clio	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1231	1	72	2026-06-11	11:00-12:00	1	VN	PEREZ Captur	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1232	1	72	2026-06-11	14:00-15:00	1	VN	PANADERO Twingo	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1233	1	72	2026-06-12	14:00-15:00	1	VN	MOSTARDI Twingo	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1234	1	72	2026-06-11	15:00-16:00	1	VN	MARIE Megane	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1235	1	72	2026-06-13	15:00-16:00	1	VN	PORTAL Clio	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1236	1	72	2026-06-11	16:00-17:00	1	VN	DEMEURE Espace	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1237	1	72	2026-06-12	16:00-17:00	1	VN	NAVARRO Twingo	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1238	1	72	2026-06-13	16:00-17:00	1	VN	FILLION E Tech	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1239	1	72	2026-06-11	17:00-18:00	1	VN	SALANDIN Austral	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1240	1	72	2026-06-13	17:00-18:00	1	VN	GOMEZ Twingo	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1241	1	72	2026-06-11	18:00-19:00	1	VN	LEFEVRE Scenic	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1242	1	73	2026-06-11	09:00-10:00	1	VN	BARRE Megane	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1243	1	73	2026-06-13	09:00-10:00	1	VN	BARTHE R5	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1244	1	73	2026-06-13	10:00-11:00	1	VN	BIBAL Clio	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1245	1	73	2026-06-12	11:00-12:00	1	VN	BELIERE Clio	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1246	1	73	2026-06-12	14:00-15:00	1	VN	FIGUIERE R5	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1247	1	73	2026-06-11	15:00-16:00	1	VN	BALKE Captur	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1248	1	73	2026-06-12	15:00-16:00	1	VN	PIBERNAT Twingo	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1249	1	73	2026-06-11	16:00-17:00	1	VN	BONNET Kangoo	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1250	1	73	2026-06-11	17:00-18:00	1	VN	SOULIE Twingo	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1251	1	73	2026-06-11	10:00-11:00	2	VN	DELMAS Sandero	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1252	1	73	2026-06-12	16:00-17:00	2	VN	MILLET Spring	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1253	1	74	2026-06-11	10:00-11:00	1	VN	GRANGE Twingo	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1254	1	74	2026-06-13	10:00-11:00	1	VN	DUBUY Clio	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1255	1	74	2026-06-13	11:00-12:00	1	VN	ANTERIEUR Kex	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1256	1	74	2026-06-11	14:00-15:00	1	VN	TRAPAS Twingo	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1257	1	74	2026-06-13	14:00-15:00	1	VN	BERNARDIN Clio	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1258	1	74	2026-06-12	16:00-17:00	1	VN	TAILLEFER Clio	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1259	1	74	2026-06-11	17:00-18:00	1	VN	SOULA Megane	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1260	1	74	2026-06-12	17:00-18:00	1	VN	ROBIN Clio	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1261	1	74	2026-06-12	18:00-19:00	1	VN	NAVARRO R5	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N
1262	1	74	2026-06-12	10:00-11:00	2	VN	RAHAL Jogger	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1263	1	75	2026-06-11	09:00-10:00	1	VN	DELEBECQUE Scenic	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1264	1	75	2026-06-11	11:00-12:00	1	VN	SAUVAGE Captur	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1265	1	75	2026-06-12	15:00-16:00	1	VN	CHALIEZ Clio	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1266	1	75	2026-06-11	17:00-18:00	1	VN	LIMOUZY Rafale	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1267	1	75	2026-06-11	10:00-11:00	2	VN	FORMAGE Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1268	1	75	2026-06-13	10:00-11:00	2	VN	TISSIER Spring	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1269	1	75	2026-06-12	11:00-12:00	2	VN	ABBES Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1270	1	75	2026-06-13	11:00-12:00	2	VN	MONCHAMP Spring	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1271	1	75	2026-06-15	12:00-13:00	2	VN	DELAIRE Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1272	1	75	2026-06-11	14:00-15:00	2	VN	MASSA Spring	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1273	1	75	2026-06-11	15:00-16:00	2	VN	LAUNAY Twingo	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1274	1	75	2026-06-11	16:00-17:00	2	VN	DRAGUTIN R5	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1275	1	76	2026-06-11	10:00-11:00	1	VN	PERRINE Kangoo	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1276	1	76	2026-06-13	10:00-11:00	1	VN	COUDOURNAC R4	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1277	1	76	2026-06-12	11:00-12:00	1	VN	DEFAUS Megane	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1278	1	76	2026-06-15	17:00-18:00	1	VN	MERCIER R5	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1279	1	76	2026-06-13	14:00-15:00	2	VN	ALBOUY Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1280	1	78	2026-06-11	08:00-09:00	1	VN	DELRIEU Arkana	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1281	1	78	2026-06-11	10:00-11:00	1	VN	DA SILVA Scenic	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1282	1	78	2026-06-12	10:00-11:00	1	VN	LAURENT Captur	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1283	1	78	2026-06-11	11:00-12:00	1	VN	CAUGUEZ R5	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1284	1	78	2026-06-12	11:00-12:00	1	VN	LEVIGUELOUX R5	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1285	1	78	2026-06-14	11:00-12:00	1	VN	TASSEL R5	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1286	1	78	2026-06-11	12:00-13:00	1	VN	GAVALDA TWINGO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1287	1	78	2026-06-11	14:00-15:00	1	VN	ORTHE Captur	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1288	1	78	2026-06-12	14:00-15:00	1	VN	SOUNGOULA Austral	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1289	1	78	2026-06-13	14:00-15:00	1	VN	THOUNANA Captur	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1290	1	78	2026-06-14	14:00-15:00	1	VN	VILLEDIEU CLIO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1291	1	78	2026-06-11	15:00-16:00	1	VN	MARTINAUD Twingo	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1292	1	78	2026-06-13	15:00-16:00	1	VN	CHARTROU Austral	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1293	1	78	2026-06-12	16:00-17:00	1	VN	CAZELLE Captur	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1294	1	78	2026-06-15	16:00-17:00	1	VN	DUCROS Twingo	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1295	1	78	2026-06-11	17:00-18:00	1	VN	RUDELLE Clio	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1296	1	78	2026-06-12	17:00-18:00	1	VN	BIAU Clio	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1297	1	78	2026-06-13	17:00-18:00	1	VN	BOURDON Clio	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1298	1	99	2026-06-12	10:00-11:00	1	VN	ROUSSILHES Clio	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1299	1	99	2026-06-13	10:00-11:00	1	VN	ASSIE Captur	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1300	1	99	2026-06-14	10:00-11:00	1	VN	DASTE Captur	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1301	1	99	2026-06-12	15:00-16:00	1	VN	BEAUGENDRE R4	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1302	1	99	2026-06-12	16:00-17:00	1	VN	RAYSSAC Megane	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1303	1	99	2026-06-13	16:00-17:00	1	VN	HERAIL Megane	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1304	1	99	2026-06-12	09:00-10:00	2	VN	CANTAGREL Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1305	1	99	2026-06-15	09:00-10:00	2	VN	BACHELERI Bigster	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1306	1	99	2026-06-11	10:00-11:00	2	VN	PICARD Duster	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1307	1	99	2026-06-15	10:00-11:00	2	VN	ISSALLI Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1308	1	99	2026-06-12	11:00-12:00	2	VN	GANGLOF Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1309	1	99	2026-06-11	14:00-15:00	2	VN	ALLEGRE Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1310	1	99	2026-06-13	14:00-15:00	2	VN	GEMAIN Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1311	1	99	2026-06-14	14:00-15:00	2	VN	PUTEAU Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1312	1	99	2026-06-15	14:00-15:00	2	VN	KOSTIL Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1313	1	99	2026-06-11	16:00-17:00	2	VN	MAURAISIN Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1314	1	99	2026-06-15	16:00-17:00	2	VN	VERDIS Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1315	1	99	2026-06-12	18:00-19:00	2	VN	VERDIN Duster	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1316	1	99	2026-06-15	18:00-19:00	2	VN	MUNOZ Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1317	1	96	2026-06-11	09:00-10:00	1	VN	BESSIERE TWINGO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1318	1	96	2026-06-12	09:00-10:00	1	VN	BONSANG CLIO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1319	1	96	2026-06-13	10:00-11:00	1	VN	ARTIGUES TWINGO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1320	1	96	2026-06-11	14:00-15:00	1	VN	LALOEUF TWINGO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1321	1	96	2026-06-12	14:00-15:00	1	VN	ROUZIES CAPTUR	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1322	1	96	2026-06-15	14:00-15:00	1	VN	LAGARRIGUE TWINGO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1323	1	96	2026-06-13	15:00-16:00	1	VN	CIPRIANO R5	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1324	1	96	2026-06-15	15:00-16:00	1	VN	AUDOUY R5	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1325	1	96	2026-06-11	16:00-17:00	1	VN	CAPABIDY TWINGO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1326	1	96	2026-06-12	17:00-18:00	1	VN	ESTIVAL CAPTUR	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1327	1	96	2026-06-13	17:00-18:00	1	VN	MARUEJOULS CLIO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1328	1	96	2026-06-15	17:00-18:00	1	VN	PACHIN CLIO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1329	1	96	2026-06-13	09:00-10:00	2	VN	TOUPENSE DUSTER	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1330	1	96	2026-06-11	10:00-11:00	2	VN	LATAPIE DUSTER	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1331	1	96	2026-06-12	10:00-11:00	2	VN	CHAMEROYS DUSTER	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1332	1	96	2026-06-15	10:00-11:00	2	VN	GINESTE SANDERO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1333	1	96	2026-06-13	14:00-15:00	2	VN	MOGADOR SPRING	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1334	1	97	2026-06-11	09:00-10:00	1	VN	DAENILKIT TRAFIC	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1335	1	97	2026-06-13	10:00-11:00	1	VN	BERT R5	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1336	1	97	2026-06-15	10:00-11:00	1	VN	POIGNANT MEGANE	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1337	1	97	2026-06-11	16:00-17:00	1	VN	CONTE CLIO 6	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1338	1	97	2026-06-11	10:00-11:00	2	VN	DEFOIS DUSTER BIGSTER	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1339	1	97	2026-06-12	10:00-11:00	2	VN	LEGRUE DUSTER	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1340	1	97	2026-06-11	14:00-15:00	2	VN	GILBERT	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1341	1	97	2026-06-13	14:00-15:00	2	VN	JORIS DUSTER	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1342	1	97	2026-06-12	15:00-16:00	2	VN	ROQUES SPRING	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1343	1	89	2026-06-13	09:00-10:00	1	VN	bagreo twingo	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1344	1	89	2026-06-14	09:00-10:00	1	VN	BOMBAISI CLIO 6	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1345	1	89	2026-06-12	11:00-12:00	1	VN	COSSARD CLIO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1346	1	89	2026-06-11	14:00-15:00	1	VN	calmels clio	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1347	1	89	2026-06-13	14:00-15:00	1	VN	ERVIE TWINGO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1348	1	89	2026-06-12	15:00-16:00	1	VN	chambon austral	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1349	1	89	2026-06-11	17:00-18:00	1	VN	CHANDELIER AUSTRAL	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1350	1	89	2026-06-12	10:00-11:00	2	VN	ARIES SANDERO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1351	1	89	2026-06-13	11:00-12:00	2	VN	SALLES SPRING	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1352	1	89	2026-06-13	16:00-17:00	2	VN	CIPIERE SPRING	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1353	1	89	2026-06-15	16:00-17:00	2	VN	mazard spring	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1354	1	89	2026-06-12	17:00-18:00	2	VN	LABRE SANDERO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1355	1	90	2026-06-12	09:00-10:00	1	VN	PEGOURIE R5	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1356	1	90	2026-06-13	09:00-10:00	1	VN	TEYSSEDOU CLIO6	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1357	1	90	2026-06-12	11:00-12:00	1	VN	GOACHET AUSTRAL	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1358	1	90	2026-06-13	11:00-12:00	1	VN	hotzalari clio 6	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1359	1	90	2026-06-11	14:00-15:00	1	VN	BERTHIN SCENIC	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1360	1	90	2026-06-12	14:00-15:00	1	VN	GUILIVERT CLIO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1361	1	90	2026-06-13	16:00-17:00	1	VN	AMIEL CLIO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1362	1	90	2026-06-11	17:00-18:00	1	VN	MARTY R5	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1363	1	90	2026-06-12	10:00-11:00	2	VN	BRUN SANDERO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1364	1	91	2026-06-11	10:00-11:00	1	VN	GALTHIER CAPTUR	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1365	1	91	2026-06-12	11:00-12:00	1	VN	COSTE SANDERO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1366	1	91	2026-06-15	11:00-12:00	1	VN	FAURE CAPTUR	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1367	1	91	2026-06-12	18:00-19:00	1	VN	DEBORD SCENIC	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1368	1	91	2026-06-11	18:00-19:00	2	VN	SENTIS BIGSTER SPRING	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N
1541	2	66	2026-09-10	15:00-16:00	1	VN	TEST	\N	2026-09-02 09:40:26.168786+00	787	2026-09-02 09:41:06.325855+00	787	2026-09-02 09:41:06.94+00	787
1542	2	66	2026-09-11	10:00-11:00	2	VN	TEST 2	\N	2026-09-02 09:40:30.034751+00	787	2026-09-02 09:41:08.434615+00	787	2026-09-02 09:41:08.993+00	787
1562	2	25	2026-09-10	08:00-09:00	\N	VO	ESSAI PREMIER	\N	2026-09-03 07:13:11.195526+00	92	2026-09-03 07:14:31.272781+00	92	2026-09-03 07:14:30.928+00	92
1563	2	25	2026-09-10	08:00-09:00	\N	VO	ESSAI SECOND	\N	2026-09-03 07:14:18.986022+00	92	2026-09-03 07:14:49.003273+00	92	2026-09-03 07:14:48.684+00	92
1630	2	881	2026-09-10	08:00-09:00	1	VN	test	\N	2026-09-07 11:52:49.746693+00	92	2026-09-07 11:53:00.662423+00	92	2026-09-07 11:52:59.903+00	92
1632	2	881	2026-09-11	11:00-12:00	1	VN	hhhhhhhh	\N	2026-09-07 14:27:08.19074+00	96	2026-09-07 14:27:20.700042+00	96	2026-09-07 14:27:20.734+00	96
1631	2	881	2026-09-10	08:00-09:00	1	VN	test	\N	2026-09-07 13:04:00.760291+00	92	2026-09-07 14:27:20.786674+00	92	2026-09-07 14:27:20.393+00	92
1634	2	78	2026-09-12	10:00-11:00	1	VN	RDV 2	\N	2026-09-07 14:44:41.490721+00	1784	2026-09-07 14:44:59.814091+00	1784	2026-09-07 14:44:59.715+00	1784
1633	2	78	2026-09-11	09:00-10:00	1	VN	RDV 1	\N	2026-09-07 14:44:21.906911+00	1784	2026-09-07 14:45:01.370525+00	1784	2026-09-07 14:45:01.287+00	1784
1635	2	78	2026-09-11	09:00-10:00	1	VN	rdv 1	\N	2026-09-07 15:17:48.507447+00	1784	2026-09-07 15:18:09.14237+00	1784	2026-09-07 15:18:08.911+00	1784
1636	2	92	2026-09-11	09:00-10:00	2	VN	TUPHE	\N	2026-09-08 08:23:55.528329+00	1780	\N	\N	\N	\N
1637	2	95	2026-09-10	14:00-15:00	1	VN	ESTEVES	\N	2026-09-08 08:41:46.910696+00	1780	\N	\N	\N	\N
1638	2	95	2026-09-11	10:00-11:00	1	VN	CHAZETTE	\N	2026-09-08 08:42:02.223552+00	1780	\N	\N	\N	\N
1639	2	95	2026-09-11	11:00-12:00	2	VN	ESTIVE	\N	2026-09-08 08:42:13.0491+00	1780	\N	\N	\N	\N
1640	2	97	2026-09-10	10:00-11:00	1	VN	LADE MEGANE	\N	2026-09-08 08:52:50.467548+00	1775	\N	\N	\N	\N
1641	2	81	2026-09-10	09:00-10:00	1	VN	REBOUL R4	\N	2026-09-08 08:53:01.691902+00	1776	\N	\N	\N	\N
1642	2	81	2026-09-10	10:00-11:00	2	VN	JORCIN BIGSTER	\N	2026-09-08 08:53:26.225039+00	1776	\N	\N	\N	\N
1643	2	97	2026-09-11	10:00-11:00	1	VN	BONNAL AUSTRAL	\N	2026-09-08 08:53:27.345865+00	1775	\N	\N	\N	\N
1644	2	81	2026-09-10	13:00-14:00	1	VN	COMBETTE TW3	\N	2026-09-08 08:53:49.583263+00	1776	\N	\N	\N	\N
1647	2	1886	2026-09-10	08:00-09:00	2	VN	QUERBES DUSTER	\N	2026-09-08 09:03:20.020041+00	1776	\N	\N	\N	\N
1648	2	1886	2026-09-10	10:00-11:00	2	VN	LEBLOND SRPING	\N	2026-09-08 09:03:29.933128+00	1776	\N	\N	\N	\N
1649	2	1886	2026-09-10	15:00-16:00	2	VN	BIOTTET JOGGER	\N	2026-09-08 09:03:48.265559+00	1776	\N	\N	\N	\N
1646	2	89	2026-09-11	10:00-11:00	1	VN	cloarec	\N	2026-09-08 09:02:20.025075+00	1781	2026-09-08 09:04:13.67721+00	1781	2026-09-08 09:04:14.643+00	1781
1645	2	89	2026-09-10	14:00-15:00	2	VN	estival	\N	2026-09-08 09:01:37.606245+00	1781	2026-09-08 09:04:22.152835+00	1781	2026-09-08 09:04:23.124+00	1781
1650	2	90	2026-09-11	10:00-11:00	1	VN	cloarec	\N	2026-09-08 09:04:37.467106+00	1781	\N	\N	\N	\N
1651	2	90	2026-09-10	14:00-15:00	2	VN	estival	\N	2026-09-08 09:04:57.368312+00	1781	\N	\N	\N	\N
1652	2	97	2026-09-11	16:00-17:00	1	VN	MABILLON CLIO	\N	2026-09-08 09:08:06.982586+00	1775	\N	\N	\N	\N
1653	2	97	2026-09-12	11:00-12:00	1	VN	PIZZI TWINGO	\N	2026-09-08 09:08:22.994527+00	1775	\N	\N	\N	\N
1654	2	50	2026-09-13	12:00-13:00	1	VN	TEST	\N	2026-09-08 09:08:35.781911+00	1783	2026-09-08 09:09:34.363913+00	1783	2026-09-08 09:09:36.219+00	1783
1655	2	96	2026-09-12	17:00-18:00	1	VN	LACOMBE R5	\N	2026-09-08 09:13:02.603364+00	1775	\N	\N	\N	\N
1656	2	96	2026-09-13	14:00-15:00	2	VN	NAFAHAPI DUSTER	\N	2026-09-08 09:13:21.594621+00	1775	\N	\N	\N	\N
1657	2	96	2026-09-14	14:00-15:00	1	VN	LATOUR CLIO	\N	2026-09-08 09:13:33.778889+00	1775	\N	\N	\N	\N
1658	2	89	2026-09-10	18:00-19:00	1	VN	robett	\N	2026-09-08 09:14:25.497493+00	1781	\N	\N	\N	\N
1661	2	94	2026-09-10	15:00-16:00	1	VN	PULLES	\N	2026-09-08 09:17:17.116572+00	1780	\N	\N	\N	\N
1662	2	99	2026-09-10	10:00-11:00	2	VN	FERNANDEZ	\N	2026-09-08 09:17:48.616996+00	1778	2026-09-08 09:17:55.007968+00	1778	2026-09-08 09:17:54.726+00	1778
1663	2	99	2026-09-10	14:00-15:00	2	VN	BONNAFOUS	\N	2026-09-08 09:18:20.865902+00	1778	\N	\N	\N	\N
1664	2	94	2026-09-10	11:00-12:00	1	VN	SABLON	\N	2026-09-08 09:18:23.300593+00	1780	\N	\N	\N	\N
1665	2	99	2026-09-11	10:00-11:00	2	VN	LE FRANCOIS	\N	2026-09-08 09:18:36.285615+00	1778	\N	\N	\N	\N
1666	2	94	2026-09-14	18:00-19:00	1	VN	LEROUSSEAU	\N	2026-09-08 09:18:38.4719+00	1780	\N	\N	\N	\N
1667	2	41	2026-09-14	09:00-10:00	\N	VO	corvey biron	\N	2026-09-08 09:18:48.670399+00	97	\N	\N	\N	\N
1668	2	47	2026-09-12	14:00-15:00	\N	VO	RENIER Arkana 14h30	\N	2026-09-08 09:18:48.980608+00	1782	\N	\N	\N	\N
1669	2	41	2026-09-11	10:00-11:00	\N	VO	soulis	\N	2026-09-08 09:18:54.363738+00	97	\N	\N	\N	\N
1670	2	99	2026-09-10	13:00-14:00	2	VN	ALLEGRE	\N	2026-09-08 09:18:54.9814+00	1778	\N	\N	\N	\N
1671	2	74	2026-09-10	09:00-10:00	1	VN	FAURET	\N	2026-09-08 09:19:21.043875+00	1778	\N	\N	\N	\N
1672	2	74	2026-09-10	10:00-11:00	1	VN	GOMBERT	\N	2026-09-08 09:19:31.354115+00	1778	\N	\N	\N	\N
1673	2	74	2026-09-10	14:00-15:00	1	VN	CARRONDO	\N	2026-09-08 09:19:39.722258+00	1778	\N	\N	\N	\N
1674	2	74	2026-09-10	16:00-17:00	2	VN	AUBRY	\N	2026-09-08 09:19:48.107168+00	1778	\N	\N	\N	\N
1675	2	74	2026-09-12	09:00-10:00	1	VN	MARTINEZ	\N	2026-09-08 09:20:09.999666+00	1778	\N	\N	\N	\N
1676	2	74	2026-09-12	14:00-15:00	1	VN	ROUSSELET	\N	2026-09-08 09:20:14.92979+00	1778	\N	\N	\N	\N
1677	2	73	2026-09-10	10:00-11:00	1	VN	OLIVIER	\N	2026-09-08 09:20:45.985507+00	1778	\N	\N	\N	\N
1678	2	73	2026-09-10	11:00-12:00	1	VN	BURRUS	\N	2026-09-08 09:20:57.15924+00	1778	\N	\N	\N	\N
1679	2	73	2026-09-10	14:00-15:00	2	VN	ABDILAHI	\N	2026-09-08 09:21:15.709054+00	1778	2026-09-08 09:21:24.225633+00	1778	2026-09-08 09:21:23.657+00	1778
1681	2	73	2026-09-10	16:00-17:00	2	VN	HISSETE	\N	2026-09-08 09:21:30.065391+00	1778	\N	\N	\N	\N
1680	2	17	2026-09-10	11:00-12:00	1	VN	test	\N	2026-09-08 09:21:29.463722+00	5	2026-09-08 09:21:33.589388+00	5	2026-09-08 09:21:33.899+00	5
1684	2	73	2026-09-11	11:00-12:00	1	VN	TANNEAU	\N	2026-09-08 09:21:56.077416+00	1778	\N	\N	\N	\N
1686	2	73	2026-09-11	14:00-15:00	1	VN	ONTENIENTE	\N	2026-09-08 09:22:18.916535+00	1778	2026-09-08 09:22:20.523947+00	1778	2026-09-08 09:22:20.24+00	1778
1685	2	42	2026-09-10	16:00-17:00	1	VN	DRUETTE SANDERO	\N	2026-09-08 09:22:06.736837+00	1782	2026-09-08 10:27:40.302491+00	1782	2026-09-08 10:27:40.107+00	1782
1687	2	42	2026-09-11	11:00-12:00	1	VN	FRANCHIN DUSTER	\N	2026-09-08 09:22:21.118047+00	1782	2026-09-08 10:27:56.655993+00	1782	2026-09-08 10:27:56.46+00	1782
1660	2	89	2026-09-11	17:00-18:00	1	VN	vayrac r5	\N	2026-09-08 09:16:13.691331+00	1781	2026-09-08 15:04:10.487943+00	1781	\N	\N
1659	2	89	2026-09-11	15:00-16:00	2	VN	lacroix sandero	\N	2026-09-08 09:15:03.762707+00	1781	2026-09-08 15:04:32.901059+00	1781	\N	\N
1706	2	49	2026-09-10	14:00-15:00	1	VN	M RODARIE	\N	2026-09-08 09:26:00.359576+00	1783	\N	\N	\N	\N
1715	2	53	2026-09-10	16:00-17:00	2	VN	CUSSAC	\N	2026-09-08 09:27:25.679373+00	9	\N	\N	\N	\N
1718	2	55	2026-09-10	11:00-12:00	1	VN	BOIRON	\N	2026-09-08 09:28:22.633195+00	9	\N	\N	\N	\N
1719	2	55	2026-09-10	15:00-16:00	1	VN	BAILLEUL	\N	2026-09-08 09:28:31.025968+00	9	\N	\N	\N	\N
1688	2	42	2026-09-11	14:00-15:00	1	VN	GAYET BIGSTER	\N	2026-09-08 09:22:30.22117+00	1782	2026-09-08 10:28:02.468503+00	1782	2026-09-08 10:28:02.272+00	1782
1691	2	42	2026-09-11	16:00-17:00	1	VN	PICCAND BIGSTER	\N	2026-09-08 09:22:46.72217+00	1782	2026-09-08 10:28:08.093042+00	1782	2026-09-08 10:28:07.873+00	1782
1689	2	73	2026-09-11	15:00-16:00	2	VN	ADER	\N	2026-09-08 09:22:34.833993+00	1778	\N	\N	\N	\N
1690	2	85	2026-09-10	10:00-11:00	\N	VO	DUPUIS BROSSY	\N	2026-09-08 09:22:45.086638+00	1776	\N	\N	\N	\N
1705	2	49	2026-09-10	10:00-11:00	1	VN	M PERDEREAU	\N	2026-09-08 09:25:53.555599+00	1783	\N	\N	\N	\N
1714	2	53	2026-09-14	14:00-15:00	1	VN	ETEMAD	\N	2026-09-08 09:27:14.98468+00	9	\N	\N	\N	\N
1700	2	32	2026-09-10	15:00-16:00	1	VN	falchetto	\N	2026-09-08 09:24:05.338606+00	97	2026-09-08 15:25:30.301352+00	97	2026-09-08 15:25:30.51+00	97
1692	2	73	2026-09-11	17:00-18:00	2	VN	CONDE	\N	2026-09-08 09:22:48.437888+00	1778	\N	\N	\N	\N
1712	2	53	2026-09-11	17:00-18:00	1	VN	COUDIGNAT	\N	2026-09-08 09:26:58.249492+00	9	\N	\N	\N	\N
1716	2	53	2026-09-11	10:00-11:00	2	VN	ETTEN	\N	2026-09-08 09:27:33.303764+00	9	\N	\N	\N	\N
1697	2	32	2026-09-10	10:00-11:00	1	VN	gomard	\N	2026-09-08 09:23:30.813364+00	97	2026-09-08 15:21:50.711393+00	97	2026-09-08 15:21:49.059+00	97
1693	2	85	2026-09-12	15:00-16:00	\N	VO	BILLARD BROSS	\N	2026-09-08 09:22:59.248937+00	1776	\N	\N	\N	\N
1694	2	73	2026-09-11	18:00-19:00	1	VN	BRADFER	\N	2026-09-08 09:23:02.463865+00	1778	\N	\N	\N	\N
1703	2	51	2026-09-12	14:00-15:00	\N	VO	M NACHIMY	\N	2026-09-08 09:24:31.109576+00	1783	\N	\N	\N	\N
1711	2	53	2026-09-11	10:00-11:00	1	VN	DUPUY	\N	2026-09-08 09:26:49.565371+00	9	\N	\N	\N	\N
1717	2	53	2026-09-12	09:00-10:00	2	VN	GOMMET	\N	2026-09-08 09:27:36.987598+00	9	\N	\N	\N	\N
1695	2	42	2026-09-12	09:00-10:00	1	VN	PERIN 9H30 DACIA	\N	2026-09-08 09:23:10.43796+00	1782	2026-09-08 10:28:13.170945+00	1782	2026-09-08 10:28:12.373+00	1782
1699	2	32	2026-09-10	11:00-12:00	1	VN	ribes	\N	2026-09-08 09:23:45.603392+00	97	2026-09-08 15:22:02.595021+00	97	2026-09-08 15:22:02.004+00	97
1696	2	85	2026-09-12	16:00-17:00	\N	VO	DOMERGUE KANGOO	\N	2026-09-08 09:23:22.818866+00	1776	\N	\N	\N	\N
1704	2	160	2026-09-10	08:00-09:00	1	VN	test	\N	2026-09-08 09:25:26.110306+00	2	2026-09-08 09:25:30.804557+00	2	2026-09-08 09:25:31.597+00	2
1710	2	53	2026-09-10	16:00-17:00	1	VN	THEUREL	\N	2026-09-08 09:26:34.237244+00	9	\N	\N	\N	\N
1713	2	53	2026-09-12	15:00-16:00	1	VN	JOUBERT	\N	2026-09-08 09:27:09.628867+00	9	\N	\N	\N	\N
1698	2	42	2026-09-13	11:00-12:00	1	VN	MARIE DUSTER	\N	2026-09-08 09:23:32.324379+00	1782	2026-09-08 10:28:19.568281+00	1782	2026-09-08 10:28:19.373+00	1782
1702	2	42	2026-09-14	14:00-15:00	1	VN	MITAULT SPRING	\N	2026-09-08 09:24:24.715633+00	1782	2026-09-08 10:28:33.56922+00	1782	2026-09-08 10:28:33.37+00	1782
1707	2	97	2026-09-10	14:00-15:00	1	VN	MAYRAT R5	\N	2026-09-08 09:26:10.840015+00	1775	\N	\N	\N	\N
1708	2	53	2026-09-10	10:00-11:00	1	VN	ROLLAND-ROBERT	\N	2026-09-08 09:26:11.702611+00	9	\N	\N	\N	\N
1709	2	53	2026-09-10	11:00-12:00	1	VN	COLLIN	\N	2026-09-08 09:26:16.139923+00	9	\N	\N	\N	\N
1720	2	55	2026-09-14	15:00-16:00	1	VN	DOFFIN	\N	2026-09-08 09:28:49.935649+00	9	\N	\N	\N	\N
1721	2	29	2026-09-10	09:00-10:00	3	VN	HOTEL MURA	\N	2026-09-08 09:30:08.766175+00	4	\N	\N	\N	\N
1722	2	55	2026-09-14	17:00-18:00	1	VN	LARCISI	\N	2026-09-08 09:30:14.812857+00	9	\N	\N	\N	\N
1723	2	29	2026-09-10	14:00-15:00	3	VN	LOGIK2A	\N	2026-09-08 09:30:30.213002+00	4	\N	\N	\N	\N
1724	2	29	2026-09-10	10:00-11:00	3	VN	GALPIER	\N	2026-09-08 09:30:34.539376+00	4	\N	\N	\N	\N
1725	2	61	2026-09-11	10:00-11:00	\N	VO	LYON	\N	2026-09-08 09:30:35.939412+00	9	\N	\N	\N	\N
1726	2	61	2026-09-11	14:00-15:00	\N	VO	MARTIN	\N	2026-09-08 09:30:42.570065+00	9	\N	\N	\N	\N
1727	2	29	2026-09-10	11:00-12:00	3	VN	OVEROCK	\N	2026-09-08 09:30:46.470314+00	4	\N	\N	\N	\N
1728	2	29	2026-09-10	18:00-19:00	3	VN	LAPORTE	\N	2026-09-08 09:30:52.457386+00	4	\N	\N	\N	\N
1729	2	61	2026-09-12	09:00-10:00	\N	VO	CORRAL	\N	2026-09-08 09:30:52.969382+00	9	\N	\N	\N	\N
1730	2	61	2026-09-12	14:00-15:00	\N	VO	JULIEN	\N	2026-09-08 09:30:56.678674+00	9	\N	\N	\N	\N
1731	2	68	2026-09-10	09:00-10:00	\N	VO	DEPAILLER	\N	2026-09-08 09:31:24.120704+00	9	\N	\N	\N	\N
1732	2	213	2026-09-10	09:00-10:00	\N	VO	PIERRON	\N	2026-09-08 09:31:31.599764+00	6	\N	\N	\N	\N
1733	2	68	2026-09-10	14:00-15:00	\N	VO	SLAGHENAUFI	\N	2026-09-08 09:31:38.264356+00	9	\N	\N	\N	\N
1734	2	68	2026-09-10	17:00-18:00	\N	VO	VRIGNON	\N	2026-09-08 09:31:53.618402+00	9	\N	\N	\N	\N
1735	2	68	2026-09-11	15:00-16:00	\N	VO	COUDERT	\N	2026-09-08 09:31:57.954515+00	9	\N	\N	\N	\N
1736	2	213	2026-09-10	08:00-09:00	\N	VO	LAGARDE	\N	2026-09-08 09:32:31.234482+00	6	\N	\N	\N	\N
1738	2	80	2026-09-10	08:00-09:00	1	VN	CALDIER KANGOO	\N	2026-09-08 09:33:06.523173+00	1776	\N	\N	\N	\N
1739	2	28	2026-09-12	11:00-12:00	\N	VO	EZZINE	\N	2026-09-08 09:33:08.425505+00	6	\N	\N	\N	\N
1740	2	65	2026-09-10	11:00-12:00	2	VN	ALDEGUER	\N	2026-09-08 09:33:12.303751+00	9	\N	\N	\N	\N
1741	2	80	2026-09-10	09:00-10:00	1	VN	MERCADIER MEG EL	\N	2026-09-08 09:33:13.715521+00	1776	\N	\N	\N	\N
1742	2	80	2026-09-10	10:00-11:00	1	VN	DUSSOAUCY MELEC	\N	2026-09-08 09:33:29.033383+00	1776	\N	\N	\N	\N
1743	2	80	2026-09-10	14:00-15:00	1	VN	ROUQUIER R5	\N	2026-09-08 09:33:34.745208+00	1776	\N	\N	\N	\N
1744	2	28	2026-09-12	15:00-16:00	\N	VO	BEGOT	\N	2026-09-08 09:33:35.835926+00	6	\N	\N	\N	\N
1746	2	24	2026-09-12	10:00-11:00	\N	VO	MANSARD	\N	2026-09-08 09:33:47.147145+00	4	\N	\N	\N	\N
1747	2	65	2026-09-10	17:00-18:00	2	VN	BERNAL	\N	2026-09-08 09:34:04.759582+00	9	\N	\N	\N	\N
1748	2	215	2026-09-10	15:00-16:00	\N	VO	BEGON ZOE	\N	2026-09-08 09:34:05.997319+00	3	\N	\N	\N	\N
1749	2	65	2026-09-10	08:00-09:00	1	VN	CLINIQUE VETERINAIRE	\N	2026-09-08 09:34:13.587241+00	9	\N	\N	\N	\N
1745	2	65	2026-09-10	08:00-09:00	2	VN	CLINIQUE VETERINAIRE	\N	2026-09-08 09:33:44.478591+00	9	2026-09-08 09:34:18.426492+00	9	2026-09-08 09:34:18.128+00	9
1750	2	2	2026-09-14	18:00-19:00	1	VN	POILROUX CLIO6	\N	2026-09-08 09:35:15.728001+00	3	\N	\N	\N	\N
1751	2	1886	2026-09-11	10:00-11:00	2	VN	SERRE DUSTER	\N	2026-09-08 09:35:15.849572+00	1776	\N	\N	\N	\N
1752	2	1886	2026-09-11	13:00-14:00	2	VN	SENEZERGUES SANDERO	\N	2026-09-08 09:35:28.900961+00	1776	\N	\N	\N	\N
1753	2	81	2026-09-10	10:00-11:00	1	VN	MASSOL R5	\N	2026-09-08 09:35:59.170268+00	1776	\N	\N	\N	\N
1754	2	2	2026-09-13	11:00-12:00	1	VN	DELMAS	\N	2026-09-08 09:36:11.255463+00	3	\N	\N	\N	\N
1755	2	81	2026-09-10	14:00-15:00	1	VN	SAHQUIE MEGANE ELEC	\N	2026-09-08 09:36:15.615754+00	1776	\N	\N	\N	\N
1757	2	12	2026-09-10	10:00-11:00	1	VN	CHEVALLET DUSTER	\N	2026-09-08 09:37:20.830365+00	4	2026-09-09 16:21:16.482652+00	92	2026-09-09 16:21:16.118+00	92
1760	2	79	2026-09-10	09:00-10:00	1	VN	DESMESURE TW3	\N	2026-09-08 09:37:39.318763+00	1776	\N	\N	\N	\N
1761	2	19	2026-09-10	09:00-10:00	1	VN	BAILLY TWINGO	\N	2026-09-08 09:37:41.439415+00	2	\N	\N	\N	\N
1763	2	65	2026-09-10	14:00-15:00	1	VN	HENIN	\N	2026-09-08 09:37:54.665795+00	9	\N	\N	\N	\N
1764	2	79	2026-09-10	10:00-11:00	1	VN	FLOTTES R5	\N	2026-09-08 09:38:06.081947+00	1776	\N	\N	\N	\N
1765	2	19	2026-09-10	10:00-11:00	1	VN	BAUD R5	\N	2026-09-08 09:38:13.686585+00	2	\N	\N	\N	\N
1766	2	27	2026-09-10	14:00-15:00	1	VN	MME DUFAURE CLIO	\N	2026-09-08 09:39:59.271983+00	5	\N	\N	\N	\N
1767	2	15	2026-09-10	09:00-10:00	1	VN	SOL AUSTRAL	\N	2026-09-08 09:40:01.281664+00	2	\N	\N	\N	\N
1768	2	97	2026-09-12	14:00-15:00	1	VN	HERNANDEZ R5	\N	2026-09-08 09:40:20.476768+00	1775	\N	\N	\N	\N
1770	2	5	2026-09-10	08:00-09:00	1	VN	MR BRULURU POUR CLIO	\N	2026-09-08 09:41:52.425444+00	5	\N	\N	\N	\N
1771	2	71	2026-09-10	10:00-11:00	1	VN	VERDAN	\N	2026-09-08 09:41:57.66497+00	1778	\N	\N	\N	\N
1772	2	5	2026-09-10	09:00-10:00	1	VN	MME BENOIT POUR R5	\N	2026-09-08 09:42:05.461433+00	5	\N	\N	\N	\N
1773	2	71	2026-09-10	14:00-15:00	1	VN	HOARAU	\N	2026-09-08 09:42:09.389202+00	1778	\N	\N	\N	\N
1774	2	5	2026-09-10	10:00-11:00	1	VN	MR CARLEY POUR MEGANE	\N	2026-09-08 09:42:17.639012+00	5	\N	\N	\N	\N
1775	2	71	2026-09-10	18:00-19:00	1	VN	ALIBERT	\N	2026-09-08 09:42:19.188686+00	1778	\N	\N	\N	\N
1776	2	84	2026-09-12	09:00-10:00	\N	VO	PISTRE	\N	2026-09-08 09:42:21.681933+00	1776	\N	\N	\N	\N
1777	2	84	2026-09-10	09:00-10:00	\N	VO	PUEL ZOE	\N	2026-09-08 09:42:32.291406+00	1776	\N	\N	\N	\N
1778	2	71	2026-09-11	09:00-10:00	1	VN	POMPONE	\N	2026-09-08 09:42:34.683117+00	1778	\N	\N	\N	\N
1779	2	84	2026-09-11	09:00-10:00	\N	VO	COMBRET TWINGO	\N	2026-09-08 09:42:46.991396+00	1776	\N	\N	\N	\N
1780	2	71	2026-09-11	14:00-15:00	1	VN	CAVALIE	\N	2026-09-08 09:42:49.771474+00	1778	\N	\N	\N	\N
1781	2	71	2026-09-11	16:00-17:00	1	VN	DABLAN	\N	2026-09-08 09:43:00.403504+00	1778	\N	\N	\N	\N
1782	2	71	2026-09-12	10:00-11:00	1	VN	GERY	\N	2026-09-08 09:43:13.212759+00	1778	\N	\N	\N	\N
1783	2	84	2026-09-11	10:00-11:00	\N	VO	BLANC TW3 LOA	\N	2026-09-08 09:43:15.510312+00	1776	\N	\N	\N	\N
1701	2	32	2026-09-10	16:00-17:00	1	VN	descriaux	\N	2026-09-08 09:24:15.101165+00	97	2026-09-08 15:30:41.856672+00	97	2026-09-08 15:29:00.199+00	97
1737	2	213	2026-09-12	09:00-10:00	\N	VO	la brosse	\N	2026-09-08 09:32:41.542063+00	6	2026-09-08 16:01:29.53813+00	6	\N	\N
1758	2	12	2026-09-10	11:00-12:00	1	VN	ALEDO DUSTER	\N	2026-09-08 09:37:35.099855+00	4	2026-09-09 16:21:31.566696+00	92	2026-09-09 16:21:31.193+00	92
1762	2	12	2026-09-10	14:00-15:00	1	VN	TRONCHERE JOGGER	\N	2026-09-08 09:37:51.142586+00	4	2026-09-09 16:22:02.588211+00	92	2026-09-09 16:22:02.238+00	92
1769	2	6	2026-09-10	08:00-09:00	1	VN	MR FOLLEAS SANDERO	\N	2026-09-08 09:41:31.262959+00	5	2026-09-09 16:25:04.478111+00	92	2026-09-09 16:25:04.144+00	92
1785	2	211	2026-09-12	10:00-11:00	\N	VO	DEGEZ  SYMBIOZ	\N	2026-09-08 09:43:50.057815+00	2	\N	\N	\N	\N
1786	2	53	2026-09-12	10:00-11:00	1	VN	BONGIRAUD	\N	2026-09-08 09:46:23.622073+00	9	\N	\N	\N	\N
1787	2	41	2026-09-10	14:00-15:00	\N	VO	baudesson	\N	2026-09-08 09:47:45.540011+00	97	\N	\N	\N	\N
1788	2	1887	2026-09-12	09:00-10:00	\N	VO	M HADDAD	\N	2026-09-08 09:47:47.786602+00	1783	\N	\N	\N	\N
1789	2	41	2026-09-10	16:00-17:00	\N	VO	teyssier	\N	2026-09-08 09:47:55.282205+00	97	\N	\N	\N	\N
1790	2	50	2026-09-10	15:00-16:00	1	VN	M BONNET	\N	2026-09-08 09:47:59.675115+00	1783	\N	\N	\N	\N
1791	2	51	2026-09-11	18:00-19:00	\N	VO	M HEMET	\N	2026-09-08 09:48:13.184423+00	1783	\N	\N	\N	\N
1792	2	95	2026-09-10	18:00-19:00	2	VN	CHALVIGNAC	\N	2026-09-08 09:48:20.387809+00	1780	\N	\N	\N	\N
1793	2	41	2026-09-11	14:00-15:00	\N	VO	faucher garros	\N	2026-09-08 09:48:27.589053+00	97	\N	\N	\N	\N
1794	2	95	2026-09-11	09:00-10:00	1	VN	SALESSE	\N	2026-09-08 09:48:32.53648+00	1780	\N	\N	\N	\N
1795	2	95	2026-09-11	17:00-18:00	1	VN	GUILLOU	\N	2026-09-08 09:48:40.542519+00	1780	\N	\N	\N	\N
1796	2	41	2026-09-12	10:00-11:00	\N	VO	pawelczyk	\N	2026-09-08 09:48:54.157463+00	97	\N	\N	\N	\N
1797	2	93	2026-09-10	14:00-15:00	1	VN	GRENIER	\N	2026-09-08 09:49:03.736144+00	1780	\N	\N	\N	\N
1798	2	41	2026-09-14	17:00-18:00	\N	VO	roddier	\N	2026-09-08 09:49:09.809776+00	97	\N	\N	\N	\N
1799	2	93	2026-09-10	16:00-17:00	1	VN	MALGOUZOU	\N	2026-09-08 09:49:13.632228+00	1780	\N	\N	\N	\N
1800	2	93	2026-09-12	09:00-10:00	2	VN	BRIANCEAU	\N	2026-09-08 09:49:24.381684+00	1780	\N	\N	\N	\N
1802	2	65	2026-09-11	09:00-10:00	2	VN	DESGRUGILLERS	\N	2026-09-08 09:49:45.565745+00	9	\N	\N	\N	\N
1803	2	60	2026-09-10	09:00-10:00	2	VN	MOUSTADRAF	\N	2026-09-08 09:49:48.826484+00	7	\N	\N	\N	\N
1805	2	92	2026-09-11	11:00-12:00	1	VN	BUCHON	\N	2026-09-08 09:50:04.113582+00	1780	\N	\N	\N	\N
1806	2	60	2026-09-10	11:00-12:00	2	VN	KIRCHER	\N	2026-09-08 09:50:07.757054+00	7	\N	\N	\N	\N
1807	2	92	2026-09-12	09:00-10:00	1	VN	VANTALON	\N	2026-09-08 09:50:14.746762+00	1780	\N	\N	\N	\N
1808	2	60	2026-09-11	10:00-11:00	2	VN	RICARD	\N	2026-09-08 09:50:17.388037+00	7	\N	\N	\N	\N
1809	2	92	2026-09-12	10:00-11:00	2	VN	DUCROS	\N	2026-09-08 09:50:39.335721+00	1780	\N	\N	\N	\N
1810	2	60	2026-09-11	14:00-15:00	2	VN	PAULHIAC	\N	2026-09-08 09:50:40.516669+00	7	\N	\N	\N	\N
1811	2	82	2026-09-10	09:00-10:00	1	VN	CHAMPREDONDE MEGA	\N	2026-09-08 09:50:44.652509+00	1776	\N	\N	\N	\N
1812	2	17	2026-09-10	10:00-11:00	1	VN	TINEL SYMBIOZ	\N	2026-09-08 09:51:01.476466+00	5	\N	\N	\N	\N
1813	2	82	2026-09-10	10:00-11:00	2	VN	PERRICHOU SP	\N	2026-09-08 09:51:03.217754+00	1776	2026-09-08 09:51:10.36912+00	1776	\N	\N
1816	2	35	2026-09-10	09:00-10:00	1	VN	gil	\N	2026-09-08 09:51:12.956307+00	97	\N	\N	\N	\N
1814	2	92	2026-09-12	14:00-15:00	1	VN	ANESA	\N	2026-09-08 09:51:05.663171+00	1780	2026-09-08 09:51:19.380391+00	1780	2026-09-08 09:51:16.479+00	1780
1818	2	35	2026-09-10	14:00-15:00	1	VN	vales	\N	2026-09-08 09:51:22.940505+00	97	\N	\N	\N	\N
1819	2	82	2026-09-10	11:00-12:00	1	VN	LOUIS CLIO 5	\N	2026-09-08 09:51:27.498404+00	1776	\N	\N	\N	\N
1815	2	92	2026-09-12	14:00-15:00	1	VN	ANESA	\N	2026-09-08 09:51:09.309534+00	1780	2026-09-08 09:51:31.321112+00	1780	2026-09-08 09:51:30.762+00	1780
1817	2	17	2026-09-10	14:00-15:00	1	VN	GUILLEMON SCENIC	\N	2026-09-08 09:51:16.673419+00	5	2026-09-08 09:51:33.008873+00	5	\N	\N
1821	2	35	2026-09-10	17:00-18:00	1	VN	jourdil	\N	2026-09-08 09:51:37.97741+00	97	\N	\N	\N	\N
1822	2	17	2026-09-10	15:00-16:00	1	VN	TERRIAS CLIO	\N	2026-09-08 09:51:43.153063+00	5	\N	\N	\N	\N
1825	2	53	2026-09-10	09:00-10:00	1	VN	POMOGIER	\N	2026-09-08 09:51:47.327661+00	9	\N	\N	\N	\N
1824	2	82	2026-09-10	14:00-15:00	1	VN	PORTIER M3 ELC	\N	2026-09-08 09:51:46.218277+00	1776	2026-09-08 09:51:51.813035+00	1776	2026-09-08 09:51:51.756+00	1776
1826	2	17	2026-09-10	16:00-17:00	1	VN	MARTINS R5	\N	2026-09-08 09:51:53.65314+00	5	\N	\N	\N	\N
1827	2	35	2026-09-11	09:00-10:00	1	VN	roussin	\N	2026-09-08 09:51:53.852407+00	97	\N	\N	\N	\N
1820	2	60	2026-09-11	14:00-15:00	1	VN	BRAZ	\N	2026-09-08 09:51:30.709399+00	7	2026-09-08 09:51:57.414981+00	7	2026-09-08 09:51:57.272+00	7
1828	2	17	2026-09-10	17:00-18:00	1	VN	LAPEYRE SANDERO	\N	2026-09-08 09:52:01.274869+00	5	\N	\N	\N	\N
1829	2	82	2026-09-10	14:00-15:00	1	VN	PORTIER M3	\N	2026-09-08 09:52:05.645065+00	1776	2026-09-08 09:52:10.759212+00	1776	2026-09-08 09:52:11.07+00	1776
1830	2	35	2026-09-12	14:00-15:00	1	VN	chafotte	\N	2026-09-08 09:52:12.158247+00	97	\N	\N	\N	\N
1831	2	57	2026-09-11	14:00-15:00	\N	VO	BRAZ	\N	2026-09-08 09:52:13.653527+00	7	\N	\N	\N	\N
1832	2	35	2026-09-14	11:00-12:00	1	VN	meilland	\N	2026-09-08 09:52:26.081954+00	97	\N	\N	\N	\N
1833	2	82	2026-09-10	14:00-15:00	1	VN	PORTIER M3	\N	2026-09-08 09:52:43.163822+00	1776	\N	\N	\N	\N
1834	2	57	2026-09-12	14:00-15:00	\N	VO	COLIC DINO	\N	2026-09-08 09:52:47.156567+00	7	\N	\N	\N	\N
1835	2	82	2026-09-10	16:00-17:00	1	VN	PUECHAGUT SCENIC EL	\N	2026-09-08 09:52:58.306891+00	1776	\N	\N	\N	\N
1836	2	82	2026-09-10	17:00-18:00	1	VN	PUECH SYMBIOZ	\N	2026-09-08 09:53:09.95063+00	1776	\N	\N	\N	\N
1837	2	82	2026-09-11	10:00-11:00	1	VN	GUIBERT CAPTUR	\N	2026-09-08 09:53:24.693288+00	1776	\N	\N	\N	\N
1838	2	81	2026-09-11	09:00-10:00	1	VN	BESSIERE R4	\N	2026-09-08 09:54:00.11229+00	1776	\N	\N	\N	\N
1839	2	72	2026-09-10	09:00-10:00	1	VN	PAULIN	\N	2026-09-08 09:54:00.455501+00	1778	\N	\N	\N	\N
1840	2	81	2026-09-11	15:00-16:00	1	VN	CLEMENT CLIO 6	\N	2026-09-08 09:54:11.13023+00	1776	\N	\N	\N	\N
1841	2	72	2026-09-10	11:00-12:00	1	VN	AUGE	\N	2026-09-08 09:54:18.022801+00	1778	\N	\N	\N	\N
1842	2	72	2026-09-10	14:00-15:00	2	VN	PARRA	\N	2026-09-08 09:54:30.404554+00	1778	\N	\N	\N	\N
1843	2	72	2026-09-10	16:00-17:00	1	VN	ROBIN	\N	2026-09-08 09:54:33.603379+00	1778	\N	\N	\N	\N
1844	2	60	2026-09-11	16:00-17:00	1	VN	TROUSSELIER	\N	2026-09-08 09:54:37.25368+00	7	\N	\N	\N	\N
1845	2	72	2026-09-10	17:00-18:00	2	VN	CABRI	\N	2026-09-08 09:54:37.323742+00	1778	\N	\N	\N	\N
1846	2	43	2026-09-11	09:00-10:00	1	VN	ARRAULT R5	\N	2026-09-08 09:54:54.841745+00	1782	\N	\N	\N	\N
1847	2	72	2026-09-12	10:00-11:00	1	VN	GORDON	\N	2026-09-08 09:55:00.78317+00	1778	\N	\N	\N	\N
1848	2	72	2026-09-12	11:00-12:00	1	VN	BOYER	\N	2026-09-08 09:55:05.164075+00	1778	\N	\N	\N	\N
1849	2	43	2026-09-12	09:00-10:00	1	VN	PIC AUSTRAL	\N	2026-09-08 09:55:06.754641+00	1782	\N	\N	\N	\N
1850	2	72	2026-09-12	14:00-15:00	1	VN	LOUBERSSAC	\N	2026-09-08 09:55:09.192711+00	1778	\N	\N	\N	\N
1851	2	72	2026-09-14	14:00-15:00	1	VN	SALANDIN	\N	2026-09-08 09:55:19.229623+00	1778	\N	\N	\N	\N
1852	2	60	2026-09-12	14:00-15:00	2	VN	TINTILLIER	\N	2026-09-08 09:55:38.258925+00	7	\N	\N	\N	\N
1804	2	32	2026-09-11	16:00-17:00	1	VN	viguie	\N	2026-09-08 09:49:49.333125+00	97	2026-09-08 15:39:23.553655+00	97	2026-09-08 15:39:23.282+00	97
1823	2	92	2026-09-12	14:00-15:00	1	VN	ANESA	\N	2026-09-08 09:51:43.115029+00	1780	2026-09-08 16:07:58.059288+00	1780	2026-09-08 16:07:57.755+00	1780
1853	2	43	2026-09-12	14:00-15:00	1	VN	COMMEAUSIGN R5	\N	2026-09-08 09:55:39.862397+00	1782	\N	\N	\N	\N
1854	2	60	2026-09-13	10:00-11:00	2	VN	SAUMADE	\N	2026-09-08 09:55:56.900593+00	7	\N	\N	\N	\N
1865	2	44	2026-09-10	11:00-12:00	1	VN	GOURNON AUSTRAM	\N	2026-09-08 09:57:28.898737+00	1782	2026-09-08 09:57:52.56666+00	1782	2026-09-08 09:57:52.339+00	1782
1889	2	47	2026-09-12	13:00-14:00	\N	VO	MARTIN SERGE 0606459077	\N	2026-09-08 10:01:43.632605+00	1782	\N	\N	\N	\N
1891	2	66	2026-09-10	09:00-10:00	1	VN	COUDERT / TWINGO	\N	2026-09-08 10:02:31.358979+00	8	\N	\N	\N	\N
1895	2	66	2026-09-11	17:00-18:00	2	VN	CAVELIER / DUSTER	\N	2026-09-08 10:03:01.556699+00	8	\N	\N	\N	\N
1899	2	70	2026-09-10	09:00-10:00	\N	VO	LOZE / MEGANE VO	\N	2026-09-08 10:03:49.88022+00	8	\N	\N	\N	\N
1904	2	70	2026-09-10	10:00-11:00	\N	VO	ECHALIER /  VO GPL	\N	2026-09-08 10:04:18.82975+00	8	\N	\N	\N	\N
1906	2	87	2026-09-10	16:00-17:00	2	VN	ROYER - DUSTER VN	\N	2026-09-08 10:04:33.337639+00	1777	\N	\N	\N	\N
1920	2	87	2026-09-14	18:00-19:00	2	VN	LAVIEILLE - ARKANA A RENOUVELER	\N	2026-09-08 10:06:07.57324+00	1777	\N	\N	\N	\N
1855	2	43	2026-09-13	10:00-11:00	1	VN	REVERDY TWINGO	\N	2026-09-08 09:55:59.792707+00	1782	\N	\N	\N	\N
1860	2	74	2026-09-11	09:00-10:00	2	VN	ORIENTE	\N	2026-09-08 09:56:34.05638+00	1778	\N	\N	\N	\N
1861	2	74	2026-09-11	10:00-11:00	2	VN	ARCA	\N	2026-09-08 09:56:39.194819+00	1778	\N	\N	\N	\N
1863	2	74	2026-09-10	16:00-17:00	1	VN	ESTEVE	\N	2026-09-08 09:57:11.508376+00	1778	\N	\N	\N	\N
1867	2	62	2026-09-10	10:00-11:00	2	VN	MONCET	\N	2026-09-08 09:57:42.913771+00	7	\N	\N	\N	\N
1870	2	44	2026-09-11	11:00-12:00	1	VN	LASNI	\N	2026-09-08 09:58:00.782675+00	1782	\N	\N	\N	\N
1908	2	78	2026-09-11	17:00-18:00	1	VN	BESSETES	\N	2026-09-08 10:04:43.505792+00	1778	\N	\N	\N	\N
1922	2	1885	2026-09-10	15:00-16:00	1	VN	ALLINAT - DUSTER VO	\N	2026-09-08 10:06:39.326094+00	1777	\N	\N	\N	\N
1924	2	59	2026-09-10	09:00-10:00	1	VN	SAINT LEGER / CAPTUR	\N	2026-09-08 10:07:10.704162+00	8	\N	\N	\N	\N
1927	2	59	2026-09-10	10:00-11:00	1	VN	CELLIER / TWINGO	\N	2026-09-08 10:07:40.911267+00	8	\N	\N	\N	\N
1856	2	53	2026-09-12	11:00-12:00	2	VN	TENDIL	\N	2026-09-08 09:56:05.745322+00	9	\N	\N	\N	\N
1926	2	1885	2026-09-12	11:00-12:00	1	VN	GERVAUD VNSO	\N	2026-09-08 10:07:27.884438+00	1777	\N	\N	\N	\N
1930	2	59	2026-09-10	16:00-17:00	1	VN	FILET / R4	\N	2026-09-08 10:08:25.195276+00	8	\N	\N	\N	\N
1857	2	74	2026-09-14	15:00-16:00	1	VN	ROUSSEAU	\N	2026-09-08 09:56:07.314868+00	1778	\N	\N	\N	\N
1868	2	44	2026-09-10	10:00-11:00	1	VN	GOURNON AUSTRAL	\N	2026-09-08 09:57:46.761359+00	1782	\N	\N	\N	\N
1877	2	44	2026-09-13	11:00-12:00	1	VN	CHAMIGNON	\N	2026-09-08 09:58:26.781506+00	1782	\N	\N	\N	\N
1883	2	62	2026-09-12	15:00-16:00	1	VN	MAGNIER PERE	\N	2026-09-08 09:59:32.321943+00	7	\N	\N	\N	\N
1890	2	96	2026-09-10	09:00-10:00	1	VN	DEAL CASE MASTER	\N	2026-09-08 10:02:04.674604+00	1775	\N	\N	\N	\N
1894	2	78	2026-09-10	14:00-15:00	1	VN	SOLER	\N	2026-09-08 10:02:56.353371+00	1778	\N	\N	\N	\N
1910	2	87	2026-09-10	18:00-19:00	2	VN	BACQUET - CAPTUR VN	\N	2026-09-08 10:04:56.038832+00	1777	\N	\N	\N	\N
1915	2	70	2026-09-11	17:00-18:00	\N	VO	BOUGNES / CLIO	\N	2026-09-08 10:05:33.938529+00	8	2026-09-08 10:05:41.936506+00	8	\N	\N
1918	2	78	2026-09-13	10:00-11:00	1	VN	FONTES	\N	2026-09-08 10:05:52.645641+00	1778	\N	\N	\N	\N
1858	2	60	2026-09-13	13:00-14:00	2	VN	ANDRE	\N	2026-09-08 09:56:14.346299+00	7	\N	\N	\N	\N
1862	2	74	2026-09-11	15:00-16:00	2	VN	VERAT	\N	2026-09-08 09:56:48.835483+00	1778	\N	\N	\N	\N
1869	2	76	2026-09-10	14:00-15:00	1	VN	MONTESQUIEU	\N	2026-09-08 09:57:59.828994+00	1778	\N	\N	\N	\N
1874	2	62	2026-09-10	14:00-15:00	1	VN	BADUEL	\N	2026-09-08 09:58:13.728392+00	7	\N	\N	\N	\N
1875	2	44	2026-09-12	16:00-17:00	1	VN	LABBE	\N	2026-09-08 09:58:21.521122+00	1782	\N	\N	\N	\N
1878	2	62	2026-09-11	11:00-12:00	2	VN	LEGILLON	\N	2026-09-08 09:58:34.795797+00	7	\N	\N	\N	\N
1880	2	76	2026-09-12	10:00-11:00	1	VN	ARTUSO	\N	2026-09-08 09:58:53.151907+00	1778	\N	\N	\N	\N
1886	2	96	2026-09-13	10:00-11:00	1	VN	CHALARD CLIO	\N	2026-09-08 10:00:36.064897+00	1775	\N	\N	\N	\N
1897	2	78	2026-09-10	16:00-17:00	1	VN	MAMBETOV	\N	2026-09-08 10:03:08.324332+00	1778	\N	\N	\N	\N
1919	2	70	2026-09-12	14:00-15:00	\N	VO	MAZOYER / CAPTUR	\N	2026-09-08 10:06:00.841859+00	8	\N	\N	\N	\N
1921	2	70	2026-09-12	16:00-17:00	\N	VO	VERNUS / CAPTUR	\N	2026-09-08 10:06:14.323555+00	8	\N	\N	\N	\N
1923	2	1885	2026-09-10	17:00-18:00	1	VN	MONTEILLET - VO DIVERS	\N	2026-09-08 10:06:53.343255+00	1777	\N	\N	\N	\N
1859	2	74	2026-09-14	09:00-10:00	1	VN	CORAIL	\N	2026-09-08 09:56:17.694849+00	1778	\N	\N	\N	\N
1866	2	76	2026-09-11	10:00-11:00	2	VN	DECHAUME	\N	2026-09-08 09:57:39.199757+00	1778	\N	\N	\N	\N
1872	2	76	2026-09-11	14:00-15:00	2	VN	JULIEN	\N	2026-09-08 09:58:11.05131+00	1778	\N	\N	\N	\N
1876	2	76	2026-09-12	14:00-15:00	1	VN	MORGADO	\N	2026-09-08 09:58:24.848581+00	1778	\N	\N	\N	\N
1882	2	62	2026-09-12	14:00-15:00	1	VN	RODIER	\N	2026-09-08 09:59:17.81274+00	7	\N	\N	\N	\N
1888	2	47	2026-09-12	12:00-13:00	\N	VO	BRENON CAROLE 0686043729	\N	2026-09-08 10:01:16.551998+00	1782	2026-09-08 10:01:28.272934+00	1782	\N	\N
1900	2	94	2026-09-12	14:00-15:00	1	VN	FERNANDEZ	\N	2026-09-08 10:04:02.464963+00	1780	\N	\N	\N	\N
1901	2	87	2026-09-10	09:00-10:00	2	VN	BOYER - MEG VO	\N	2026-09-08 10:04:06.517803+00	1777	\N	\N	\N	\N
1902	2	78	2026-09-10	17:00-18:00	2	VN	POTE	\N	2026-09-08 10:04:16.858387+00	1778	\N	\N	\N	\N
1907	2	70	2026-09-10	17:00-18:00	\N	VO	ROMAN / CLIO	\N	2026-09-08 10:04:33.577165+00	8	\N	\N	\N	\N
1909	2	78	2026-09-12	09:00-10:00	1	VN	BONNET	\N	2026-09-08 10:04:47.330487+00	1778	\N	\N	\N	\N
1928	2	68	2026-09-12	11:00-12:00	\N	VO	DISSAY	\N	2026-09-08 10:07:44.336409+00	9	\N	\N	\N	\N
1864	2	44	2026-09-10	09:00-10:00	1	VN	DHERET	\N	2026-09-08 09:57:17.843251+00	1782	\N	\N	\N	\N
1871	2	62	2026-09-10	11:00-12:00	2	VN	BACONNET	\N	2026-09-08 09:58:03.021408+00	7	\N	\N	\N	\N
1881	2	62	2026-09-12	11:00-12:00	1	VN	RODIER	\N	2026-09-08 09:58:54.441496+00	7	2026-09-08 09:59:09.964897+00	7	2026-09-08 09:59:09.935+00	7
1911	2	70	2026-09-11	09:00-10:00	\N	VO	VALENTE / VO ELEC	\N	2026-09-08 10:04:56.04629+00	8	\N	\N	\N	\N
1873	2	44	2026-09-11	13:00-14:00	1	VN	RESSOT	\N	2026-09-08 09:58:12.49399+00	1782	\N	\N	\N	\N
1884	2	62	2026-09-12	16:00-17:00	1	VN	MANIER  FILS	\N	2026-09-08 09:59:42.528317+00	7	\N	\N	\N	\N
1887	2	47	2026-09-12	13:00-14:00	\N	VO	MARTIN SERGE 0606459077	\N	2026-09-08 10:00:38.921398+00	1782	2026-09-08 10:01:20.019991+00	1782	2026-09-08 10:01:19.836+00	1782
1892	2	78	2026-09-10	09:00-10:00	1	VN	BASSO	\N	2026-09-08 10:02:47.266806+00	1778	\N	\N	\N	\N
1893	2	66	2026-09-10	10:00-11:00	1	VN	BERTHON / R4	\N	2026-09-08 10:02:49.516711+00	8	\N	\N	\N	\N
1898	2	78	2026-09-10	17:00-18:00	1	VN	POTE	\N	2026-09-08 10:03:22.424164+00	1778	2026-09-08 10:04:21.268974+00	1778	2026-09-08 10:04:19.846+00	1778
1912	2	78	2026-09-12	14:00-15:00	1	VN	SYLVESTRE	\N	2026-09-08 10:05:03.282595+00	1778	\N	\N	\N	\N
1913	2	87	2026-09-11	17:00-18:00	2	VN	VALTAT - CLIO VN	\N	2026-09-08 10:05:13.228427+00	1777	\N	\N	\N	\N
1916	2	87	2026-09-14	14:00-15:00	2	VN	LAURENT - SANDERO / CLIO	\N	2026-09-08 10:05:35.345423+00	1777	\N	\N	\N	\N
1925	2	1885	2026-09-11	14:00-15:00	1	VN	GALLINQUE - DUSTER VN	\N	2026-09-08 10:07:17.113401+00	1777	\N	\N	\N	\N
1879	2	76	2026-09-14	09:00-10:00	1	VN	DURAND	\N	2026-09-08 09:58:39.282248+00	1778	\N	\N	\N	\N
1896	2	92	2026-09-11	18:00-19:00	2	VN	VITTORI	\N	2026-09-08 10:03:06.628126+00	1780	\N	\N	\N	\N
1903	2	94	2026-09-11	10:00-11:00	1	VN	BLEUZET	\N	2026-09-08 10:04:16.898011+00	1780	\N	\N	\N	\N
1914	2	78	2026-09-12	16:00-17:00	1	VN	VIREZILIER	\N	2026-09-08 10:05:18.654109+00	1778	\N	\N	\N	\N
1917	2	87	2026-09-14	15:00-16:00	2	VN	DRUART - CLIO VN	\N	2026-09-08 10:05:47.760201+00	1777	\N	\N	\N	\N
1929	2	59	2026-09-10	11:00-12:00	1	VN	VANOVERMEIRE / CAPTUR	\N	2026-09-08 10:08:12.684772+00	8	\N	\N	\N	\N
1885	2	62	2026-09-12	09:00-10:00	1	VN	ROSSIGNOL	\N	2026-09-08 09:59:54.015525+00	7	\N	\N	\N	\N
1905	2	87	2026-09-10	14:00-15:00	2	VN	GASSIN - CAPTUR VN	\N	2026-09-08 10:04:25.448754+00	1777	\N	\N	\N	\N
1931	2	59	2026-09-10	18:00-19:00	2	VN	MAILLET / SANDERO	\N	2026-09-08 10:08:39.627699+00	8	\N	\N	\N	\N
1932	2	59	2026-09-11	09:00-10:00	2	VN	SALENDRE / SANDERO	\N	2026-09-08 10:09:09.462882+00	8	\N	\N	\N	\N
1933	2	59	2026-09-11	10:00-11:00	1	VN	VIGNEMASSE / CAPTUR	\N	2026-09-08 10:09:31.41844+00	8	\N	\N	\N	\N
1934	2	59	2026-09-11	15:00-16:00	1	VN	REDON / CLIO	\N	2026-09-08 10:09:43.78823+00	8	\N	\N	\N	\N
1935	2	59	2026-09-11	16:00-17:00	2	VN	SCHMID / DUSTER	\N	2026-09-08 10:10:06.557908+00	8	\N	\N	\N	\N
1936	2	59	2026-09-11	18:00-19:00	1	VN	ANINO / CLIO	\N	2026-09-08 10:10:23.530522+00	8	\N	\N	\N	\N
1938	2	18	2026-09-10	09:00-10:00	1	VN	fadigrand clio	\N	2026-09-08 10:11:00.884739+00	4	\N	\N	\N	\N
1937	2	59	2026-09-12	10:00-11:00	1	VN	SALENDRE / CAPTUR	\N	2026-09-08 10:10:56.941395+00	8	2026-09-08 10:11:08.693752+00	8	\N	\N
1939	2	18	2026-09-10	18:00-19:00	1	VN	rodier clio	\N	2026-09-08 10:11:18.8069+00	4	\N	\N	\N	\N
1940	2	59	2026-09-13	14:00-15:00	1	VN	HALLEUX / CLIO	\N	2026-09-08 10:11:32.943887+00	8	\N	\N	\N	\N
1941	2	27	2026-09-12	11:00-12:00	1	VN	CESSAC CLIO	\N	2026-09-08 10:11:42.918528+00	5	\N	\N	\N	\N
1942	2	18	2026-09-10	17:00-18:00	1	VN	rispal twingo	\N	2026-09-08 10:11:47.130224+00	4	\N	\N	\N	\N
1944	2	59	2026-09-14	10:00-11:00	2	VN	CHASTEL / SANDERO	\N	2026-09-08 10:12:04.170845+00	8	\N	\N	\N	\N
1943	2	27	2026-09-10	10:00-11:00	1	VN	MANCHEZ SANDERO	\N	2026-09-08 10:11:57.030945+00	5	2026-09-08 10:12:11.767625+00	5	\N	\N
1945	2	34	2026-09-10	09:00-10:00	1	VN	lacroix	\N	2026-09-08 10:12:18.776836+00	97	\N	\N	\N	\N
1946	2	27	2026-09-11	10:00-11:00	1	VN	LEGROS JOGGER	\N	2026-09-08 10:12:23.790139+00	5	\N	\N	\N	\N
1947	2	34	2026-09-11	16:00-17:00	1	VN	chambon	\N	2026-09-08 10:12:38.092196+00	97	\N	\N	\N	\N
1948	2	59	2026-09-14	15:00-16:00	1	VN	DE LESCURE / MEGANE	\N	2026-09-08 10:12:38.769812+00	8	\N	\N	\N	\N
1949	2	27	2026-09-12	10:00-11:00	1	VN	MUSELER R5	\N	2026-09-08 10:12:40.999922+00	5	\N	\N	\N	\N
1950	2	34	2026-09-11	17:00-18:00	1	VN	ducand	\N	2026-09-08 10:12:44.0254+00	97	\N	\N	\N	\N
1951	2	34	2026-09-12	09:00-10:00	1	VN	blanc	\N	2026-09-08 10:12:55.699608+00	97	\N	\N	\N	\N
1952	2	34	2026-09-12	11:00-12:00	1	VN	claret	\N	2026-09-08 10:13:01.62949+00	97	\N	\N	\N	\N
1953	2	9	2026-09-10	10:00-11:00	\N	VO	dinquer	\N	2026-09-08 10:13:02.755385+00	6	\N	\N	\N	\N
1954	2	215	2026-09-10	10:00-11:00	\N	VO	VERLAGUET	\N	2026-09-08 10:13:04.737279+00	3	\N	\N	\N	\N
1956	2	34	2026-09-12	14:00-15:00	1	VN	casiot	\N	2026-09-08 10:13:11.686687+00	97	\N	\N	\N	\N
1957	2	34	2026-09-13	10:00-11:00	1	VN	randoing	\N	2026-09-08 10:13:16.474844+00	97	\N	\N	\N	\N
1955	2	59	2026-09-14	17:00-18:00	1	VN	SCHMID / MEGANE	\N	2026-09-08 10:13:07.293562+00	8	2026-09-08 10:13:17.282482+00	8	\N	\N
1958	2	215	2026-09-11	09:00-10:00	\N	VO	ENFANTIN	\N	2026-09-08 10:13:18.222956+00	3	\N	\N	\N	\N
1960	2	9	2026-09-11	11:00-12:00	\N	VO	peinturier	\N	2026-09-08 10:13:23.762943+00	6	\N	\N	\N	\N
1961	2	34	2026-09-13	14:00-15:00	1	VN	delmotte	\N	2026-09-08 10:13:33.460929+00	97	\N	\N	\N	\N
1959	2	34	2026-09-13	13:00-14:00	1	VN	delmotte	\N	2026-09-08 10:13:22.058686+00	97	2026-09-08 10:13:38.035572+00	97	2026-09-08 10:13:38.291+00	97
1962	2	9	2026-09-11	16:00-17:00	\N	VO	rossler	\N	2026-09-08 10:13:41.563186+00	6	\N	\N	\N	\N
1963	2	23	2026-09-10	10:00-11:00	\N	VO	MOULIN	\N	2026-09-08 10:13:59.672587+00	3	\N	\N	\N	\N
1964	2	9	2026-09-13	09:00-10:00	\N	VO	alidra	\N	2026-09-08 10:14:09.355454+00	6	\N	\N	\N	\N
1966	2	9	2026-09-13	10:00-11:00	\N	VO	gerbin	\N	2026-09-08 10:14:18.143787+00	6	\N	\N	\N	\N
1967	2	53	2026-09-13	11:00-12:00	1	VN	PROTO	\N	2026-09-08 10:15:35.707451+00	9	\N	\N	\N	\N
1968	2	33	2026-09-10	09:00-10:00	1	VN	maillaud	\N	2026-09-08 10:15:35.87194+00	97	\N	\N	\N	\N
1969	2	33	2026-09-10	10:00-11:00	1	VN	guglielmini	\N	2026-09-08 10:15:44.139036+00	97	\N	\N	\N	\N
1970	2	33	2026-09-10	11:00-12:00	1	VN	letiers	\N	2026-09-08 10:15:50.730239+00	97	\N	\N	\N	\N
1971	2	54	2026-09-10	14:00-15:00	2	VN	VERGRIETTE / SANDERO	\N	2026-09-08 10:15:51.775837+00	8	\N	\N	\N	\N
1973	2	33	2026-09-10	14:00-15:00	1	VN	mougne	\N	2026-09-08 10:15:58.072109+00	97	\N	\N	\N	\N
1972	2	60	2026-09-12	09:00-10:00	2	VN	FIORI	\N	2026-09-08 10:15:54.209958+00	7	2026-09-08 10:16:02.222317+00	7	\N	\N
1974	2	33	2026-09-10	15:00-16:00	1	VN	balestrino	\N	2026-09-08 10:16:07.053624+00	97	\N	\N	\N	\N
1975	2	54	2026-09-10	10:00-11:00	1	VN	SCOTTI / R5	\N	2026-09-08 10:16:13.827148+00	8	\N	\N	\N	\N
1976	2	33	2026-09-10	18:00-19:00	1	VN	bidaud	\N	2026-09-08 10:16:21.876258+00	97	\N	\N	\N	\N
1977	2	33	2026-09-11	09:00-10:00	1	VN	desforges	\N	2026-09-08 10:16:38.538394+00	97	\N	\N	\N	\N
1978	2	29	2026-09-11	10:00-11:00	3	VN	LAROYE	\N	2026-09-08 10:16:43.652405+00	4	\N	\N	\N	\N
1979	2	33	2026-09-11	10:00-11:00	1	VN	hernandez	\N	2026-09-08 10:16:46.045281+00	97	\N	\N	\N	\N
1980	2	29	2026-09-11	14:00-15:00	3	VN	RICHARD	\N	2026-09-08 10:16:48.587866+00	4	\N	\N	\N	\N
1982	2	33	2026-09-11	15:00-16:00	1	VN	dardier	\N	2026-09-08 10:16:55.538815+00	97	\N	\N	\N	\N
1983	2	882	2026-09-12	16:00-17:00	\N	VO	CHAMBAUD / VO	\N	2026-09-08 10:17:05.803889+00	8	\N	\N	\N	\N
1984	2	33	2026-09-11	14:00-15:00	1	VN	joumel	\N	2026-09-08 10:17:05.862962+00	97	\N	\N	\N	\N
1981	2	33	2026-09-11	14:00-15:00	1	VN	joumel	\N	2026-09-08 10:16:50.503195+00	97	2026-09-08 10:17:20.867889+00	97	2026-09-08 10:17:21.098+00	97
1986	2	882	2026-09-11	17:00-18:00	\N	VO	DE RAILLE	\N	2026-09-08 10:17:24.02647+00	8	\N	\N	\N	\N
1987	2	33	2026-09-11	16:00-17:00	1	VN	varennes	\N	2026-09-08 10:17:38.515183+00	97	\N	\N	\N	\N
1988	2	29	2026-09-11	16:00-17:00	3	VN	CHANEAC	\N	2026-09-08 10:17:40.012548+00	4	\N	\N	\N	\N
1989	2	33	2026-09-11	18:00-19:00	1	VN	fradin	\N	2026-09-08 10:17:45.779652+00	97	\N	\N	\N	\N
1990	2	24	2026-09-11	15:00-16:00	\N	VO	FARGE	\N	2026-09-08 10:17:46.408364+00	4	\N	\N	\N	\N
1991	2	29	2026-09-11	11:00-12:00	3	VN	CUBIZOL	\N	2026-09-08 10:18:32.909512+00	4	\N	\N	\N	\N
1992	2	69	2026-09-10	14:00-15:00	\N	VO	ROCHE	\N	2026-09-08 10:18:34.168951+00	7	\N	\N	\N	\N
1993	2	69	2026-09-10	16:00-17:00	\N	VO	MORS	\N	2026-09-08 10:18:44.285158+00	7	\N	\N	\N	\N
1994	2	69	2026-09-11	14:00-15:00	\N	VO	SOLIGNAT	\N	2026-09-08 10:19:13.789031+00	7	\N	\N	\N	\N
1995	2	213	2026-09-11	10:00-11:00	\N	VO	flament	\N	2026-09-08 10:19:33.949087+00	6	\N	\N	\N	\N
1997	2	28	2026-09-11	18:00-19:00	\N	VO	bounhoure	\N	2026-09-08 10:20:13.007402+00	6	\N	\N	\N	\N
1996	2	27	2026-09-13	15:00-16:00	1	VN	SANDONIN AUSTRAL	\N	2026-09-08 10:20:09.014722+00	5	2026-09-08 16:08:59.405328+00	3	2026-09-08 16:08:59.332+00	3
2001	2	68	2026-09-10	08:00-09:00	\N	VO	ABRIOL	\N	2026-09-08 10:20:51.223884+00	9	\N	\N	\N	\N
2019	2	11	2026-09-12	09:00-10:00	1	VN	GENESTOUX CAPTUR	\N	2026-09-08 10:23:27.930311+00	2	\N	\N	\N	\N
2028	2	54	2026-09-11	10:00-11:00	2	VN	CARCAGAGUE / SANDERO	\N	2026-09-08 10:24:53.677238+00	8	\N	\N	\N	\N
2031	2	42	2026-09-10	16:00-17:00	2	VN	DRUETTE SANDERO	\N	2026-09-08 10:25:10.703402+00	1782	\N	\N	\N	\N
2052	2	66	2026-09-13	15:00-16:00	1	VN	FIGUEIREDO / R5	\N	2026-09-08 10:27:32.535073+00	8	\N	\N	\N	\N
2020	2	42	2026-09-10	18:00-19:00	1	VN	CHEDE SANDERO	\N	2026-09-08 10:23:33.45409+00	1782	2026-09-08 10:27:46.82825+00	1782	2026-09-08 10:27:46.636+00	1782
2054	2	10	2026-09-11	16:00-17:00	1	VN	KIRSH	\N	2026-09-08 10:28:09.662457+00	3	\N	\N	\N	\N
1998	2	14	2026-09-10	09:00-10:00	1	VN	SCATOLIN DUSTER	\N	2026-09-08 10:20:26.443687+00	5	2026-09-09 16:23:14.537614+00	92	2026-09-09 16:23:14.161+00	92
2000	2	49	2026-09-11	10:00-11:00	1	VN	M BEAUDIAU	\N	2026-09-08 10:20:43.717537+00	1783	\N	\N	\N	\N
2006	2	26	2026-09-10	16:00-17:00	1	VN	CHEMINADE SANDERO	\N	2026-09-08 10:21:27.736296+00	4	\N	\N	\N	\N
2018	2	75	2026-09-10	17:00-18:00	2	VN	STEPHAN	\N	2026-09-08 10:23:26.058484+00	1778	\N	\N	\N	\N
2023	2	11	2026-09-13	09:00-10:00	1	VN	GENESTOUX CAPTUR	\N	2026-09-08 10:23:43.624478+00	2	2026-09-08 10:24:04.474326+00	2	2026-09-08 10:24:05.317+00	2
2065	2	6	2026-09-10	16:00-17:00	1	VN	BOSSIR CLIO 5	\N	2026-09-08 10:29:54.194389+00	5	\N	\N	\N	\N
2071	2	67	2026-09-10	13:00-14:00	1	VN	PORTEFAIS / MEGANE	\N	2026-09-08 10:30:35.111461+00	8	\N	\N	\N	\N
2082	2	10	2026-09-12	08:00-09:00	1	VN	ROGOWCZ	\N	2026-09-08 10:31:38.495999+00	3	\N	\N	\N	\N
2087	2	19	2026-09-10	16:00-17:00	1	VN	MORLET MEGANE	\N	2026-09-08 10:32:12.092986+00	2	\N	\N	\N	\N
2004	2	50	2026-09-10	10:00-11:00	1	VN	M SANTARELLI	\N	2026-09-08 10:21:14.681686+00	1783	2026-09-08 16:11:43.650023+00	1783	\N	\N
1999	2	14	2026-09-10	14:00-15:00	1	VN	DIOUGAN DUSTER	\N	2026-09-08 10:20:39.750373+00	5	2026-09-09 16:23:45.928775+00	92	2026-09-09 16:23:45.6+00	92
2002	2	1887	2026-09-12	11:00-12:00	\N	VO	M METRO	\N	2026-09-08 10:20:58.019389+00	1783	\N	\N	\N	\N
2034	2	10	2026-09-10	11:00-12:00	1	VN	LATRY	\N	2026-09-08 10:25:38.648378+00	3	\N	\N	\N	\N
2012	2	11	2026-09-10	16:00-17:00	1	VN	CACELA	\N	2026-09-08 10:22:33.00889+00	2	2026-09-08 10:25:40.798538+00	2	\N	\N
2042	2	42	2026-09-11	14:00-15:00	2	VN	GAYET BIGSTER	\N	2026-09-08 10:26:30.685499+00	1782	\N	\N	\N	\N
2050	2	10	2026-09-10	17:00-18:00	1	VN	ARAGON	\N	2026-09-08 10:27:07.383242+00	3	\N	\N	\N	\N
2051	2	42	2026-09-14	15:00-16:00	2	VN	GAGNOL DUSTER	\N	2026-09-08 10:27:13.30696+00	1782	\N	\N	\N	\N
1683	2	42	2026-09-10	14:00-15:00	1	VN	BELIN DUSTER	\N	2026-09-08 09:21:50.970047+00	1782	2026-09-08 10:27:33.754652+00	1782	2026-09-08 10:27:33.55+00	1782
2053	2	10	2026-09-11	14:00-15:00	1	VN	MONCE	\N	2026-09-08 10:27:37.497518+00	3	\N	\N	\N	\N
2055	2	99	2026-09-10	09:00-10:00	2	VN	FERNANDEZ	\N	2026-09-08 10:28:11.662379+00	1778	\N	\N	\N	\N
2056	2	41	2026-09-12	09:00-10:00	\N	VO	dubost	\N	2026-09-08 10:28:52.167466+00	97	\N	\N	\N	\N
2060	2	83	2026-09-10	14:00-15:00	\N	VO	JOGGER GAILLAC	\N	2026-09-08 10:29:31.18286+00	1776	2026-09-08 10:30:04.848939+00	1776	\N	\N
2080	2	67	2026-09-11	15:00-16:00	1	VN	JOSEPH / SCENIC	\N	2026-09-08 10:31:27.578239+00	8	\N	\N	\N	\N
2005	2	26	2026-09-11	09:00-10:00	1	VN	CONTET JOGGER	\N	2026-09-08 10:21:17.240127+00	4	\N	\N	\N	\N
2007	2	5	2026-09-11	09:00-10:00	1	VN	HANIEZ CAPTUR	\N	2026-09-08 10:21:46.810508+00	5	2026-09-08 10:21:57.946453+00	5	\N	\N
2010	2	5	2026-09-11	14:00-15:00	1	VN	GOIGGOU JOGGER	\N	2026-09-08 10:22:12.662533+00	5	2026-09-08 10:22:19.385507+00	5	\N	\N
2016	2	75	2026-09-10	15:00-16:00	2	VN	MASSIER	\N	2026-09-08 10:23:08.969846+00	1778	\N	\N	\N	\N
2021	2	2	2026-09-10	09:00-10:00	1	VN	MAGAUD TWINGO	\N	2026-09-08 10:23:35.126025+00	3	\N	\N	\N	\N
2009	2	11	2026-09-10	09:00-10:00	1	VN	LEMOINE CLIO6	\N	2026-09-08 10:22:04.871415+00	2	2026-09-08 10:25:33.264405+00	2	\N	\N
2013	2	11	2026-09-10	17:00-18:00	1	VN	PRIVAT CLIO6	\N	2026-09-08 10:22:48.385667+00	2	2026-09-08 10:25:51.037699+00	2	\N	\N
2041	2	66	2026-09-11	09:00-10:00	1	VN	DUFRECHOU / CLIO	\N	2026-09-08 10:26:25.832399+00	8	\N	\N	\N	\N
1682	2	42	2026-09-10	10:00-11:00	1	VN	DESCRIAUX DUSTER	\N	2026-09-08 09:21:41.849278+00	1782	2026-09-08 10:27:25.859096+00	1782	2026-09-08 10:27:25.255+00	1782
2075	2	67	2026-09-10	14:00-15:00	2	VN	MONTAGNON / DUSTER	\N	2026-09-08 10:30:58.220819+00	8	\N	\N	\N	\N
2079	2	87	2026-09-11	10:00-11:00	2	VN	PORTES - DACIA	\N	2026-09-08 10:31:25.679898+00	1777	\N	\N	\N	\N
2027	2	10	2026-09-10	09:00-10:00	1	VN	PLANTELIGNE	\N	2026-09-08 10:24:52.361408+00	3	2026-09-08 15:18:10.305396+00	3	2026-09-08 15:18:10.133+00	3
2003	2	14	2026-09-10	16:00-17:00	1	VN	BESSERVE TWINGO	\N	2026-09-08 10:21:01.757645+00	5	2026-09-09 16:23:55.31433+00	92	2026-09-09 16:23:54.984+00	92
2008	2	11	2026-09-10	08:00-09:00	1	VN	THEROND R5	\N	2026-09-08 10:21:56.761387+00	2	2026-09-08 10:25:17.366815+00	2	\N	\N
2038	2	42	2026-09-11	09:00-10:00	2	VN	THOMAS BIGSTER	\N	2026-09-08 10:26:18.37207+00	1782	\N	\N	\N	\N
2040	2	160	2026-09-12	10:00-11:00	1	VN	HERBST CAPTUR	\N	2026-09-08 10:26:24.382088+00	2	\N	\N	\N	\N
2043	2	42	2026-09-11	16:00-17:00	2	VN	PICCAND BIGSTER	\N	2026-09-08 10:26:35.920658+00	1782	\N	\N	\N	\N
2049	2	42	2026-09-14	14:00-15:00	2	VN	MITAULT SPRING	\N	2026-09-08 10:27:04.178898+00	1782	\N	\N	\N	\N
2024	2	42	2026-09-11	09:00-10:00	1	VN	THOMAS BIGSTER	\N	2026-09-08 10:24:05.767771+00	1782	2026-09-08 10:27:51.575799+00	1782	2026-09-08 10:27:51.392+00	1782
2058	2	99	2026-09-11	16:00-17:00	1	VN	RAYSSAC	\N	2026-09-08 10:29:15.875387+00	1778	\N	\N	\N	\N
2070	2	36	2026-09-11	15:00-16:00	1	VN	auroy	\N	2026-09-08 10:30:22.513475+00	97	\N	\N	\N	\N
2077	2	36	2026-09-13	10:00-11:00	1	VN	pothonnier	\N	2026-09-08 10:31:12.911388+00	97	\N	\N	\N	\N
2078	2	99	2026-09-14	10:00-11:00	2	VN	AMALRIC	\N	2026-09-08 10:31:17.20278+00	1778	\N	\N	\N	\N
2011	2	5	2026-09-11	16:00-17:00	1	VN	DOGAS TWINGO	\N	2026-09-08 10:22:27.695996+00	5	\N	\N	\N	\N
2030	2	42	2026-09-10	14:00-15:00	2	VN	BELIN DUSTER	\N	2026-09-08 10:25:03.597543+00	1782	\N	\N	\N	\N
2046	2	66	2026-09-12	11:00-12:00	1	VN	ASTIER / CLIO	\N	2026-09-08 10:26:48.631533+00	8	\N	\N	\N	\N
2025	2	42	2026-09-14	15:00-16:00	1	VN	GAGNOL DUSTER	\N	2026-09-08 10:24:27.547138+00	1782	2026-09-08 10:28:37.700246+00	1782	2026-09-08 10:28:37.513+00	1782
2059	2	36	2026-09-10	10:00-11:00	1	VN	guilloud	\N	2026-09-08 10:29:18.589887+00	97	\N	\N	\N	\N
2057	2	6	2026-09-10	14:00-15:00	1	VN	TINEL SYMBIOZ	\N	2026-09-08 10:29:13.388736+00	5	2026-09-08 10:29:22.353389+00	5	\N	\N
2067	2	67	2026-09-10	10:00-11:00	1	VN	THOMAIN / R5	\N	2026-09-08 10:30:00.299538+00	8	\N	\N	\N	\N
2069	2	99	2026-09-12	16:00-17:00	1	VN	DUBUY	\N	2026-09-08 10:30:20.5829+00	1778	\N	\N	\N	\N
2022	2	75	2026-09-11	10:00-11:00	2	VN	GIRAUD	\N	2026-09-08 10:23:37.374447+00	1778	\N	\N	\N	\N
2014	2	11	2026-09-13	09:00-10:00	1	VN	GENESTOUX CAPTUR	\N	2026-09-08 10:23:00.085575+00	2	2026-09-08 10:23:40.241403+00	2	2026-09-08 10:23:38.598+00	2
2032	2	70	2026-09-12	10:00-11:00	\N	VO	TENOT / CLIO	\N	2026-09-08 10:25:31.43122+00	8	\N	\N	\N	\N
2033	2	42	2026-09-10	18:00-19:00	2	VN	CHEDE SANDERO	\N	2026-09-08 10:25:37.640404+00	1782	\N	\N	\N	\N
2036	2	66	2026-09-10	14:00-15:00	1	VN	GUSTA	\N	2026-09-08 10:26:09.205284+00	8	\N	\N	\N	\N
2037	2	10	2026-09-11	10:00-11:00	1	VN	MARGOUM	\N	2026-09-08 10:26:16.980264+00	3	2026-09-08 10:26:25.730756+00	3	\N	\N
2047	2	42	2026-09-13	11:00-12:00	2	VN	MARIE DUSTER	\N	2026-09-08 10:26:52.03752+00	1782	\N	\N	\N	\N
1985	2	10	2026-09-13	17:00-18:00	1	VN	BEAUFILS CAPTUR	\N	2026-09-08 10:17:11.661767+00	3	2026-09-08 10:29:27.871403+00	3	2026-09-08 10:29:29.784+00	3
2072	2	36	2026-09-11	16:00-17:00	1	VN	kroudo	\N	2026-09-08 10:30:42.570634+00	97	\N	\N	\N	\N
2074	2	99	2026-09-13	10:00-11:00	1	VN	FERENZEC	\N	2026-09-08 10:30:52.678555+00	1778	\N	\N	\N	\N
2061	2	6	2026-09-10	15:00-16:00	1	VN	DUTUEL SANDERO	\N	2026-09-08 10:29:34.477275+00	5	2026-09-09 16:24:38.127549+00	92	2026-09-09 16:24:37.764+00	92
2015	2	75	2026-09-10	14:00-15:00	2	VN	BENIMELIS	\N	2026-09-08 10:23:02.160797+00	1778	\N	\N	\N	\N
2017	2	11	2026-09-13	15:00-16:00	1	VN	DUMAS AUSTRAL	\N	2026-09-08 10:23:17.867055+00	2	2026-09-08 10:24:12.118015+00	2	2026-09-08 10:24:12.904+00	2
2026	2	11	2026-09-12	15:00-16:00	1	VN	DUMAS  AUSTRAL	\N	2026-09-08 10:24:33.941161+00	2	\N	\N	\N	\N
2035	2	10	2026-09-11	09:00-10:00	1	VN	TEISSEDRE	\N	2026-09-08 10:25:58.933382+00	3	\N	\N	\N	\N
2044	2	66	2026-09-12	09:00-10:00	1	VN	NIS / SCENIC R5	\N	2026-09-08 10:26:41.439833+00	8	\N	\N	\N	\N
2083	2	10	2026-09-12	16:00-17:00	1	VN	COUFIGNAL	\N	2026-09-08 10:31:46.276801+00	3	\N	\N	\N	\N
2086	2	99	2026-09-13	14:00-15:00	1	VN	MUPHATO	\N	2026-09-08 10:31:59.246228+00	1778	\N	\N	\N	\N
2089	2	19	2026-09-10	18:00-19:00	1	VN	AUBERT CLIO6	\N	2026-09-08 10:32:34.383387+00	2	\N	\N	\N	\N
2090	2	2	2026-09-13	16:00-17:00	1	VN	MONIER	\N	2026-09-08 10:32:49.337799+00	3	\N	\N	\N	\N
2029	2	42	2026-09-10	10:00-11:00	2	VN	DESCRIAUX DUSTER	\N	2026-09-08 10:24:57.034689+00	1782	\N	\N	\N	\N
2045	2	42	2026-09-12	09:00-10:00	2	VN	PERIN 9H30 DACIA	\N	2026-09-08 10:26:45.12962+00	1782	\N	\N	\N	\N
2048	2	66	2026-09-13	14:00-15:00	1	VN	BLANDIN / SCENIC	\N	2026-09-08 10:27:03.540716+00	8	\N	\N	\N	\N
2063	2	36	2026-09-10	17:00-18:00	1	VN	richard	\N	2026-09-08 10:29:41.69784+00	97	\N	\N	\N	\N
2066	2	36	2026-09-11	10:00-11:00	1	VN	benassy	\N	2026-09-08 10:29:56.111798+00	97	\N	\N	\N	\N
2068	2	36	2026-09-11	14:00-15:00	1	VN	marié	\N	2026-09-08 10:30:06.474834+00	97	\N	\N	\N	\N
2076	2	1885	2026-09-10	10:00-11:00	1	VN	CASTEILLE - VN R	\N	2026-09-08 10:31:11.54951+00	1777	\N	\N	\N	\N
2081	2	19	2026-09-10	11:00-12:00	1	VN	LAURIERE R5	\N	2026-09-08 10:31:33.453931+00	2	\N	\N	\N	\N
2039	2	42	2026-09-11	11:00-12:00	2	VN	FRANCHIN DUSTER	\N	2026-09-08 10:26:23.582796+00	1782	\N	\N	\N	\N
2064	2	10	2026-09-13	18:00-19:00	1	VN	BEAUFILS	\N	2026-09-08 10:29:43.278903+00	3	\N	\N	\N	\N
2073	2	36	2026-09-11	18:00-19:00	1	VN	dajoux	\N	2026-09-08 10:30:51.089135+00	97	\N	\N	\N	\N
2084	2	19	2026-09-10	14:00-15:00	1	VN	POURTON CAPTUR	\N	2026-09-08 10:31:49.883196+00	2	\N	\N	\N	\N
2085	2	67	2026-09-12	11:00-12:00	2	VN	CUENA / SANDERO	\N	2026-09-08 10:31:51.280715+00	8	\N	\N	\N	\N
2088	2	10	2026-09-14	17:00-18:00	1	VN	LOPEZ	\N	2026-09-08 10:32:23.522548+00	3	\N	\N	\N	\N
2091	2	15	2026-09-10	11:00-12:00	1	VN	DELABRE TWINGO	\N	2026-09-08 10:33:29.013919+00	2	\N	\N	\N	\N
2093	2	16	2026-09-10	09:00-10:00	1	VN	BRUNEL	\N	2026-09-08 10:33:45.408483+00	3	\N	\N	\N	\N
2094	2	15	2026-09-10	17:00-18:00	1	VN	VIALLE R5	\N	2026-09-08 10:33:46.115368+00	2	\N	\N	\N	\N
2092	2	17	2026-09-11	09:00-10:00	1	VN	VILLATA MR	\N	2026-09-08 10:33:41.245648+00	5	2026-09-08 10:33:47.929473+00	5	\N	\N
2096	2	16	2026-09-10	14:00-15:00	1	VN	CARMIR	\N	2026-09-08 10:33:56.737797+00	3	\N	\N	\N	\N
2097	2	16	2026-09-10	17:00-18:00	1	VN	RICHARD	\N	2026-09-08 10:34:00.332944+00	3	\N	\N	\N	\N
2095	2	17	2026-09-11	10:00-11:00	1	VN	VILLATTA MME	\N	2026-09-08 10:33:53.573422+00	5	2026-09-08 10:34:06.173388+00	5	\N	\N
2098	2	16	2026-09-11	17:00-18:00	1	VN	TRABUT	\N	2026-09-08 10:34:14.789628+00	3	\N	\N	\N	\N
2099	2	16	2026-09-11	18:00-19:00	1	VN	BAILLARD	\N	2026-09-08 10:34:18.148393+00	3	\N	\N	\N	\N
2100	2	69	2026-09-12	11:00-12:00	\N	VO	JANVION	\N	2026-09-08 10:34:21.839545+00	7	\N	\N	\N	\N
2101	2	211	2026-09-12	14:00-15:00	\N	VO	PIRON SYMBIOZ	\N	2026-09-08 10:34:28.31625+00	2	\N	\N	\N	\N
2102	2	44	2026-09-13	15:00-16:00	1	VN	GUICHARD CLIO	\N	2026-09-08 10:34:42.107026+00	1782	\N	\N	\N	\N
2103	2	16	2026-09-12	14:00-15:00	1	VN	BARDY	\N	2026-09-08 10:34:43.219766+00	3	\N	\N	\N	\N
2104	2	16	2026-09-13	10:00-11:00	1	VN	MESURE	\N	2026-09-08 10:34:53.012159+00	3	\N	\N	\N	\N
2105	2	44	2026-09-11	15:00-16:00	1	VN	BRUN CLIO	\N	2026-09-08 10:34:55.258701+00	1782	\N	\N	\N	\N
2106	2	16	2026-09-13	15:00-16:00	1	VN	DALY	\N	2026-09-08 10:35:06.963057+00	3	\N	\N	\N	\N
2107	2	68	2026-09-10	11:00-12:00	\N	VO	SARRON	\N	2026-09-08 10:35:08.364241+00	9	\N	\N	\N	\N
2108	2	882	2026-09-10	14:00-15:00	\N	VO	FORCE / VO	\N	2026-09-08 10:36:11.081047+00	8	\N	\N	\N	\N
2110	2	9	2026-09-10	17:00-18:00	\N	VO	causse	\N	2026-09-08 10:36:25.250575+00	6	\N	\N	\N	\N
2111	2	23	2026-09-11	16:00-17:00	\N	VO	AUSSET	\N	2026-09-08 10:36:27.476303+00	3	\N	\N	\N	\N
2113	2	9	2026-09-12	14:00-15:00	\N	VO	villanne	\N	2026-09-08 10:36:46.318853+00	6	\N	\N	\N	\N
2114	2	67	2026-09-13	09:00-10:00	1	VN	KUSNIEREK / CLIO	\N	2026-09-08 10:36:52.526219+00	8	\N	\N	\N	\N
2115	2	9	2026-09-12	08:00-09:00	\N	VO	fernandes	\N	2026-09-08 10:36:59.670798+00	6	\N	\N	\N	\N
2116	2	215	2026-09-11	17:00-18:00	\N	VO	PORTAL	\N	2026-09-08 10:37:03.662197+00	3	\N	\N	\N	\N
2117	2	215	2026-09-11	18:00-19:00	\N	VO	FORISSIER	\N	2026-09-08 10:37:15.754949+00	3	\N	\N	\N	\N
2118	2	67	2026-09-11	09:00-10:00	1	VN	TRIDOT / ESPACE	\N	2026-09-08 10:37:18.180288+00	8	\N	\N	\N	\N
2120	2	54	2026-09-11	14:00-15:00	1	VN	BESSON	\N	2026-09-08 10:37:40.159301+00	8	\N	\N	\N	\N
2124	2	57	2026-09-11	09:00-10:00	\N	VO	GURODON	\N	2026-09-08 10:38:29.905246+00	92	\N	\N	\N	\N
2125	2	18	2026-09-10	16:00-17:00	1	VN	BOUSSIRON CLIO	\N	2026-09-08 10:38:37.973396+00	4	\N	\N	\N	\N
2126	2	18	2026-09-11	09:00-10:00	1	VN	CHINCHILLA CLIO	\N	2026-09-08 10:38:56.014572+00	4	\N	\N	\N	\N
2127	2	18	2026-09-10	10:00-11:00	1	VN	MASSARD R5	\N	2026-09-08 10:39:04.519151+00	4	\N	\N	\N	\N
2129	2	55	2026-09-12	14:00-15:00	2	VN	JOURDAIN	\N	2026-09-08 10:39:40.208068+00	9	\N	\N	\N	\N
2131	2	44	2026-09-10	18:00-19:00	1	VN	PETIT MEGANE E TECH	\N	2026-09-08 10:39:55.415117+00	1782	\N	\N	\N	\N
2132	2	53	2026-09-14	17:00-18:00	1	VN	LANGLADE	\N	2026-09-08 10:40:25.588194+00	9	\N	\N	\N	\N
2134	2	61	2026-09-13	10:00-11:00	\N	VO	PERE	\N	2026-09-08 10:41:05.538899+00	9	\N	\N	\N	\N
2135	2	61	2026-09-14	14:00-15:00	\N	VO	MORIN	\N	2026-09-08 10:41:14.027939+00	9	\N	\N	\N	\N
2136	2	61	2026-09-12	11:00-12:00	\N	VO	VALETTE	\N	2026-09-08 10:41:28.086872+00	9	\N	\N	\N	\N
2138	2	9	2026-09-10	11:00-12:00	\N	VO	quinsat	\N	2026-09-08 10:42:30.257478+00	6	\N	\N	\N	\N
2141	2	9	2026-09-11	18:00-19:00	\N	VO	billet	\N	2026-09-08 10:44:04.032545+00	6	\N	\N	\N	\N
2142	2	66	2026-09-14	10:00-11:00	1	VN	TEISSEDRE / CLIO	\N	2026-09-08 10:44:10.08692+00	8	\N	\N	\N	\N
2130	2	12	2026-09-11	17:00-18:00	1	VN	LAFEUILLE SANDERO	\N	2026-09-08 10:39:47.712523+00	4	2026-09-09 16:22:39.616546+00	92	2026-09-09 16:22:39.239+00	92
2139	2	9	2026-09-11	14:00-15:00	\N	VO	marcilhac	\N	2026-09-08 10:43:30.692832+00	6	2026-09-08 10:43:42.427393+00	6	\N	\N
2140	2	9	2026-09-11	17:00-18:00	\N	VO	croizet	\N	2026-09-08 10:43:55.341665+00	6	\N	\N	\N	\N
2144	2	9	2026-09-12	10:00-11:00	\N	VO	faure	\N	2026-09-08 10:44:18.875244+00	6	\N	\N	\N	\N
2145	2	9	2026-09-13	11:00-12:00	\N	VO	otsmane	\N	2026-09-08 10:44:30.042875+00	6	\N	\N	\N	\N
2146	2	9	2026-09-13	14:00-15:00	\N	VO	pitiot	\N	2026-09-08 10:44:39.192957+00	6	\N	\N	\N	\N
2147	2	67	2026-09-12	14:00-15:00	1	VN	SUGERE / CLIO	\N	2026-09-08 10:45:56.267801+00	8	\N	\N	\N	\N
2148	2	48	2026-09-10	09:00-10:00	1	VN	M Vigier	\N	2026-09-08 10:47:27.80418+00	1783	\N	\N	\N	\N
2149	2	48	2026-09-10	10:00-11:00	1	VN	M Simonet	\N	2026-09-08 10:47:35.310295+00	1783	\N	\N	\N	\N
2152	2	48	2026-09-10	11:00-12:00	1	VN	Mme Simonet	\N	2026-09-08 10:48:12.104509+00	1783	\N	\N	\N	\N
2121	2	12	2026-09-11	09:00-10:00	1	VN	MIOCHE SPRING	\N	2026-09-08 10:37:43.221199+00	4	2026-09-09 16:21:04.358826+00	92	2026-09-09 16:21:03.992+00	92
2122	2	12	2026-09-11	11:00-12:00	1	VN	GAILLARD SANDERO	\N	2026-09-08 10:37:56.300392+00	4	2026-09-09 16:21:36.202388+00	92	2026-09-09 16:21:35.866+00	92
2137	2	12	2026-09-10	13:00-14:00	1	VN	JORDA DUSTER	\N	2026-09-08 10:42:29.095371+00	4	2026-09-09 16:21:51.80269+00	92	2026-09-09 16:21:51.449+00	92
2123	2	12	2026-09-11	14:00-15:00	1	VN	FLORY CLIO	\N	2026-09-08 10:38:11.903288+00	4	2026-09-09 16:22:06.656017+00	92	2026-09-09 16:22:06.257+00	92
2128	2	12	2026-09-11	15:00-16:00	1	VN	ROBERT SANDERO	\N	2026-09-08 10:39:31.39627+00	4	2026-09-09 16:22:18.350049+00	92	2026-09-09 16:22:17.991+00	92
2112	2	12	2026-09-10	17:00-18:00	1	VN	CAILLE SANDERO	\N	2026-09-08 10:36:30.525116+00	4	2026-09-09 16:22:29.747025+00	92	2026-09-09 16:22:29.339+00	92
2119	2	12	2026-09-10	18:00-19:00	1	VN	AUBERT SANDERO	\N	2026-09-08 10:37:19.048403+00	4	2026-09-09 16:22:36.123634+00	92	2026-09-09 16:22:35.786+00	92
2062	2	6	2026-09-10	15:00-16:00	1	VN	DUTUEL SANDERO	\N	2026-09-08 10:29:39.732594+00	5	2026-09-09 16:25:19.084927+00	92	2026-09-09 16:25:18.701+00	92
2151	2	17	2026-09-11	11:00-12:00	1	VN	TOURNADRE TWINGO	\N	2026-09-08 10:47:45.766566+00	5	2026-09-10 15:25:05.825133+00	5	2026-09-10 15:25:06.035+00	5
2158	2	51	2026-09-13	10:00-11:00	\N	VO	M FONTANIER	\N	2026-09-08 10:49:07.036291+00	1783	\N	\N	\N	\N
2159	2	6	2026-09-11	08:00-09:00	1	VN	SE2A AUSTRAL	\N	2026-09-08 10:49:13.021577+00	5	\N	\N	\N	\N
2162	2	49	2026-09-11	11:00-12:00	1	VN	M MARQUES	\N	2026-09-08 10:49:51.812179+00	1783	\N	\N	\N	\N
2153	2	14	2026-09-10	17:00-18:00	1	VN	MEGRESIF BIGSTER	\N	2026-09-08 10:48:19.006161+00	5	2026-09-09 16:23:57.774563+00	92	2026-09-09 16:23:57.445+00	92
2154	2	49	2026-09-11	14:00-15:00	1	VN	M VACHER	\N	2026-09-08 10:48:26.211408+00	1783	\N	\N	\N	\N
2155	2	49	2026-09-13	10:00-11:00	1	VN	M FONTANIER	\N	2026-09-08 10:48:36.918473+00	1783	2026-09-08 10:48:47.35567+00	1783	2026-09-08 10:48:49.134+00	1783
2157	2	6	2026-09-10	18:00-19:00	1	VN	MASSON TWINO	\N	2026-09-08 10:49:02.204825+00	5	\N	\N	\N	\N
2160	2	51	2026-09-13	11:00-12:00	\N	VO	M PLANTELIGNE	\N	2026-09-08 10:49:29.742935+00	1783	\N	\N	\N	\N
2163	2	5	2026-09-13	09:00-10:00	1	VN	GUYO MEGANE	\N	2026-09-08 10:50:00.131373+00	5	\N	\N	\N	\N
2164	2	5	2026-09-13	15:00-16:00	1	VN	HARY AUSTRAL	\N	2026-09-08 10:50:06.080298+00	5	\N	\N	\N	\N
2166	2	48	2026-09-11	16:00-17:00	1	VN	MME MALLEVAL	\N	2026-09-08 10:50:53.52646+00	1783	\N	\N	\N	\N
2169	2	35	2026-09-14	14:00-15:00	1	VN	sallet	\N	2026-09-08 10:52:00.892864+00	97	\N	\N	\N	\N
2161	2	6	2026-09-11	10:00-11:00	1	VN	CHOMILLER DUSTER	\N	2026-09-08 10:49:30.768494+00	5	2026-09-09 16:25:11.464099+00	92	2026-09-09 16:25:11.118+00	92
2156	2	6	2026-09-10	17:00-18:00	1	VN	KALINSKI DUSTER	\N	2026-09-08 10:48:49.001715+00	5	2026-09-09 16:25:32.527167+00	92	2026-09-09 16:25:32.188+00	92
2165	2	48	2026-09-11	16:00-17:00	1	VN	M MALLEVAL	\N	2026-09-08 10:50:15.583399+00	1783	\N	\N	\N	\N
2167	2	50	2026-09-11	14:00-15:00	1	VN	LEZOUX ELECTRICITE	\N	2026-09-08 10:51:11.667621+00	1783	\N	\N	\N	\N
2168	2	35	2026-09-11	14:00-15:00	1	VN	gleizes	\N	2026-09-08 10:51:53.166883+00	97	\N	\N	\N	\N
2170	2	29	2026-09-12	09:00-10:00	3	VN	DOUNON	\N	2026-09-08 10:53:19.933777+00	4	\N	\N	\N	\N
2171	2	29	2026-09-12	14:00-15:00	3	VN	HUGUES	\N	2026-09-08 10:53:29.078797+00	4	\N	\N	\N	\N
2172	2	29	2026-09-12	15:00-16:00	3	VN	PRAT	\N	2026-09-08 10:53:33.257428+00	4	\N	\N	\N	\N
2173	2	29	2026-09-13	10:00-11:00	3	VN	DUMONT	\N	2026-09-08 10:53:41.511956+00	4	\N	\N	\N	\N
2174	2	11	2026-09-10	15:00-16:00	1	VN	FRANCOIS CLIO6	\N	2026-09-08 11:00:33.54364+00	2	\N	\N	\N	\N
2175	2	19	2026-09-11	09:00-10:00	1	VN	QUENOT CAPTUR	\N	2026-09-08 11:01:11.168283+00	2	\N	\N	\N	\N
2176	2	19	2026-09-11	14:00-15:00	1	VN	GENEVRIER R5	\N	2026-09-08 11:01:29.011637+00	2	\N	\N	\N	\N
2177	2	2	2026-09-11	09:00-10:00	1	VN	CARRIES	\N	2026-09-08 11:03:03.498528+00	3	\N	\N	\N	\N
2178	2	2	2026-09-10	11:00-12:00	1	VN	RUIZ	\N	2026-09-08 11:03:12.478681+00	3	\N	\N	\N	\N
2179	2	881	2026-09-10	09:00-10:00	1	VN	test	\N	2026-09-08 13:50:45.669854+00	92	2026-09-08 13:50:51.38377+00	92	2026-09-08 13:50:50.351+00	92
2180	2	28	2026-09-13	15:00-16:00	\N	VO	PICHERI	\N	2026-09-08 13:53:54.096638+00	6	\N	\N	\N	\N
2181	2	28	2026-09-12	10:00-11:00	\N	VO	ROUGET	\N	2026-09-08 13:54:03.544273+00	6	\N	\N	\N	\N
2182	2	28	2026-09-13	10:00-11:00	\N	VO	LY	\N	2026-09-08 13:54:12.800096+00	6	\N	\N	\N	\N
2183	2	213	2026-09-10	15:00-16:00	\N	VO	BARGE	\N	2026-09-08 13:54:46.498761+00	6	\N	\N	\N	\N
2184	2	1889	2026-09-10	10:00-11:00	\N	VO	vettese	\N	2026-09-08 13:54:49.275421+00	1775	\N	\N	\N	\N
2185	2	1889	2026-09-10	16:00-17:00	\N	VO	boissiere	\N	2026-09-08 13:55:03.871234+00	1775	\N	\N	\N	\N
2186	2	1889	2026-09-11	10:00-11:00	\N	VO	valentin	\N	2026-09-08 13:55:19.724375+00	1775	\N	\N	\N	\N
2187	2	1889	2026-09-11	14:00-15:00	\N	VO	pailhoux	\N	2026-09-08 13:55:36.781774+00	1775	\N	\N	\N	\N
2188	2	1889	2026-09-11	15:00-16:00	\N	VO	do rosario	\N	2026-09-08 13:55:53.869573+00	1775	\N	\N	\N	\N
2189	2	1889	2026-09-12	10:00-11:00	\N	VO	henri juliette	\N	2026-09-08 13:56:26.428218+00	1775	\N	\N	\N	\N
2190	2	1889	2026-09-12	15:00-16:00	\N	VO	blasquez	\N	2026-09-08 13:56:44.06095+00	1775	\N	\N	\N	\N
2191	2	97	2026-09-14	09:00-10:00	1	VN	causse twingo	\N	2026-09-08 14:00:41.886821+00	1775	\N	\N	\N	\N
2192	2	29	2026-09-13	09:00-10:00	3	VN	BOUCHET	\N	2026-09-08 14:05:16.713005+00	4	\N	\N	\N	\N
2193	2	29	2026-09-13	11:00-12:00	3	VN	BRUNMUROL	\N	2026-09-08 14:05:33.02248+00	4	\N	\N	\N	\N
2194	2	29	2026-09-13	13:00-14:00	3	VN	VIEIRA	\N	2026-09-08 14:05:47.894569+00	4	\N	\N	\N	\N
2195	2	29	2026-09-13	14:00-15:00	3	VN	MALLET	\N	2026-09-08 14:05:54.86101+00	4	\N	\N	\N	\N
2196	2	29	2026-09-13	15:00-16:00	3	VN	LAPLACE	\N	2026-09-08 14:05:58.805459+00	4	\N	\N	\N	\N
2197	2	29	2026-09-13	16:00-17:00	3	VN	BONJOUR	\N	2026-09-08 14:06:03.904622+00	4	\N	\N	\N	\N
2198	2	24	2026-09-11	10:00-11:00	\N	VO	COURSOL	\N	2026-09-08 14:13:36.017264+00	4	\N	\N	\N	\N
2199	2	96	2026-09-11	10:00-11:00	1	VN	trebosc	\N	2026-09-08 14:13:41.703063+00	1775	\N	\N	\N	\N
2200	2	26	2026-09-10	09:00-10:00	1	VN	DOUBLET CAPTUR	\N	2026-09-08 14:14:18.447732+00	4	\N	\N	\N	\N
2201	2	26	2026-09-10	10:00-11:00	1	VN	CHABANNE CAPTUR	\N	2026-09-08 14:14:27.862038+00	4	\N	\N	\N	\N
2202	2	26	2026-09-10	14:00-15:00	1	VN	ARFEUILLE R5	\N	2026-09-08 14:14:37.562959+00	4	\N	\N	\N	\N
2203	2	26	2026-09-12	09:00-10:00	1	VN	BOUIGE	\N	2026-09-08 14:14:54.752878+00	4	\N	\N	\N	\N
2204	2	26	2026-09-13	10:00-11:00	1	VN	VINCENT SPRING	\N	2026-09-08 14:15:07.910891+00	4	\N	\N	\N	\N
2205	2	26	2026-09-13	14:00-15:00	1	VN	DURET	\N	2026-09-08 14:15:15.270229+00	4	\N	\N	\N	\N
2206	2	96	2026-09-10	08:00-09:00	2	VN	alcouffe sandero	\N	2026-09-08 14:15:25.892743+00	1775	\N	\N	\N	\N
2207	2	26	2026-09-14	14:00-15:00	1	VN	BOUDOT TWINGO	\N	2026-09-08 14:15:31.009925+00	4	\N	\N	\N	\N
2208	2	80	2026-09-11	14:00-15:00	1	VN	CAPDECOUME	\N	2026-09-08 14:15:36.052516+00	1776	\N	\N	\N	\N
2210	2	80	2026-09-10	15:00-16:00	1	VN	PALLOT REN ZOE	\N	2026-09-08 14:15:55.21113+00	1776	2026-09-08 14:16:03.39915+00	1776	\N	\N
2209	2	80	2026-09-11	15:00-16:00	1	VN	2	\N	2026-09-08 14:15:50.245865+00	1776	2026-09-08 14:16:06.876903+00	1776	2026-09-08 14:16:07.191+00	1776
2211	2	1885	2026-09-12	14:00-15:00	1	VN	LABAUME - VN	\N	2026-09-08 14:16:10.379802+00	1777	\N	\N	\N	\N
2212	2	1885	2026-09-11	16:00-17:00	1	VN	CAPELLE - TWINGO	\N	2026-09-08 14:16:35.516699+00	1777	\N	\N	\N	\N
2213	2	81	2026-09-11	17:00-18:00	2	VN	GALY BIGSTER	\N	2026-09-08 14:17:26.808057+00	1776	\N	\N	\N	\N
2214	2	81	2026-09-14	10:00-11:00	1	VN	PATENERE R	\N	2026-09-08 14:17:44.88551+00	1776	\N	\N	\N	\N
2215	2	215	2026-09-11	10:00-11:00	\N	VO	RAYNAUD	\N	2026-09-08 14:17:47.214355+00	3	\N	\N	\N	\N
2216	2	87	2026-09-10	17:00-18:00	2	VN	SAULLES - DUSTER VN	\N	2026-09-08 14:17:54.286128+00	1777	\N	\N	\N	\N
2217	2	87	2026-09-12	10:00-11:00	2	VN	CHEYRON - SANDERO	\N	2026-09-08 14:18:06.499403+00	1777	\N	\N	\N	\N
2221	2	73	2026-09-10	14:00-15:00	2	VN	ABDILAHI	\N	2026-09-08 14:18:34.726317+00	1778	\N	\N	\N	\N
2222	2	215	2026-09-10	09:00-10:00	\N	VO	OZER	\N	2026-09-08 14:18:40.919794+00	3	\N	\N	\N	\N
2225	2	73	2026-09-11	16:00-17:00	1	VN	ONTENIENTE	\N	2026-09-08 14:19:07.257052+00	1778	\N	\N	\N	\N
2226	2	73	2026-09-12	09:00-10:00	1	VN	MESTE	\N	2026-09-08 14:19:19.774067+00	1778	\N	\N	\N	\N
2227	2	73	2026-09-12	10:00-11:00	1	VN	BIBAL	\N	2026-09-08 14:19:27.611411+00	1778	\N	\N	\N	\N
2228	2	73	2026-09-12	11:00-12:00	1	VN	BOYER	\N	2026-09-08 14:19:36.708623+00	1778	\N	\N	\N	\N
2229	2	73	2026-09-12	12:00-13:00	1	VN	BUVAT	\N	2026-09-08 14:19:50.31835+00	1778	\N	\N	\N	\N
2230	2	73	2026-09-12	15:00-16:00	1	VN	FONTAINE	\N	2026-09-08 14:19:59.327272+00	1778	\N	\N	\N	\N
2231	2	73	2026-09-14	10:00-11:00	1	VN	BOUNDUH	\N	2026-09-08 14:20:18.469888+00	1778	\N	\N	\N	\N
2232	2	99	2026-09-12	10:00-11:00	2	VN	DERROIR	\N	2026-09-08 14:21:37.636328+00	1778	\N	\N	\N	\N
2233	2	99	2026-09-11	14:00-15:00	2	VN	MICHAUD	\N	2026-09-08 14:21:48.421598+00	1778	\N	\N	\N	\N
2234	2	99	2026-09-14	15:00-16:00	1	VN	CARDONA	\N	2026-09-08 14:22:04.663969+00	1778	\N	\N	\N	\N
2235	2	99	2026-09-11	18:00-19:00	2	VN	GARRIC	\N	2026-09-08 14:22:30.518721+00	1778	\N	\N	\N	\N
2236	2	18	2026-09-14	10:00-11:00	1	VN	BOUZY CAPTUR	\N	2026-09-08 14:22:33.78149+00	4	\N	\N	\N	\N
2223	2	31	2026-09-12	15:00-16:00	1	VN	brun	\N	2026-09-08 14:18:45.752141+00	97	2026-09-08 15:48:03.414815+00	97	2026-09-08 15:47:11.603+00	97
2219	2	31	2026-09-11	17:00-18:00	1	VN	buchard	\N	2026-09-08 14:18:29.54489+00	97	2026-09-08 15:50:22.074752+00	97	2026-09-08 15:50:07.721+00	97
2220	2	31	2026-09-11	16:00-17:00	1	VN	brenet	\N	2026-09-08 14:18:33.733703+00	97	2026-09-08 15:50:36.448431+00	97	2026-09-08 15:50:22.146+00	97
2237	2	99	2026-09-11	15:00-16:00	2	VN	LAGARDE	\N	2026-09-08 14:22:53.728287+00	1778	\N	\N	\N	\N
2238	2	99	2026-09-13	16:00-17:00	1	VN	BOULE	\N	2026-09-08 14:23:30.541616+00	1778	\N	\N	\N	\N
2239	2	99	2026-09-13	15:00-16:00	1	VN	GONIN	\N	2026-09-08 14:23:43.200075+00	1778	\N	\N	\N	\N
2240	2	2	2026-09-14	17:00-18:00	1	VN	BOYER	\N	2026-09-08 14:23:51.678206+00	3	\N	\N	\N	\N
2241	2	2	2026-09-11	18:00-19:00	1	VN	RUAT	\N	2026-09-08 14:24:18.320223+00	3	\N	\N	\N	\N
2242	2	99	2026-09-12	11:00-12:00	1	VN	RAYNAL	\N	2026-09-08 14:24:25.058871+00	1778	\N	\N	\N	\N
2246	2	81	2026-09-10	11:00-12:00	2	VN	LADEUX SPRING	\N	2026-09-08 14:29:01.818532+00	1776	\N	\N	\N	\N
2251	2	1886	2026-09-14	09:00-10:00	2	VN	BOISSONNADE SANDERO	\N	2026-09-08 14:29:44.061995+00	1776	\N	\N	\N	\N
2254	2	1886	2026-09-12	09:00-10:00	2	VN	QULIN DUSTER	\N	2026-09-08 14:29:58.520726+00	1776	\N	\N	\N	\N
2258	2	12	2026-09-12	16:00-17:00	1	VN	FERNANDES SANDERO	\N	2026-09-08 14:30:40.024102+00	4	2026-09-09 16:22:46.226749+00	92	2026-09-09 16:22:45.879+00	92
2260	2	85	2026-09-12	11:00-12:00	\N	VO	ROUSSEAU CAPTUR	\N	2026-09-08 14:31:03.042872+00	1776	\N	\N	\N	\N
2261	2	85	2026-09-11	10:00-11:00	\N	VO	GUIRODI R	\N	2026-09-08 14:31:24.690261+00	1776	\N	\N	\N	\N
2262	2	18	2026-09-13	10:00-11:00	1	VN	CARRE R5	\N	2026-09-08 14:32:41.670455+00	4	\N	\N	\N	\N
2263	2	18	2026-09-10	08:00-09:00	1	VN	BERNARD R5	\N	2026-09-08 14:33:24.350885+00	4	\N	\N	\N	\N
2264	2	81	2026-09-11	11:00-12:00	2	VN	RAYNAL DUSTER	\N	2026-09-08 14:33:40.295356+00	1776	\N	\N	\N	\N
2265	2	29	2026-09-12	11:00-12:00	3	VN	MONTREY	\N	2026-09-08 14:33:42.227592+00	4	\N	\N	\N	\N
2266	2	29	2026-09-12	11:00-12:00	3	VN	MONTREY	\N	2026-09-08 14:33:50.283846+00	4	\N	\N	\N	\N
2267	2	24	2026-09-12	09:00-10:00	\N	VO	FABRE	\N	2026-09-08 14:34:48.47311+00	4	\N	\N	\N	\N
2268	2	15	2026-09-11	10:00-11:00	1	VN	LEBRAUD SYMBIOZ	\N	2026-09-08 14:34:57.972589+00	2	\N	\N	\N	\N
2270	2	15	2026-09-12	14:00-15:00	2	VN	LAFOUGERE DUSTER	\N	2026-09-08 14:35:24.307948+00	2	\N	\N	\N	\N
2269	2	15	2026-09-11	14:00-15:00	1	VN	LAFOUGERE	\N	2026-09-08 14:35:16.993262+00	2	2026-09-08 14:35:28.58875+00	2	2026-09-08 14:35:29.429+00	2
2271	2	23	2026-09-11	10:00-11:00	\N	VO	GRAUWIN	\N	2026-09-08 14:35:31.266586+00	3	\N	\N	\N	\N
2272	2	15	2026-09-11	17:00-18:00	1	VN	MARCHAND TWINGO	\N	2026-09-08 14:35:40.445498+00	2	\N	\N	\N	\N
2273	2	23	2026-09-11	17:00-18:00	\N	VO	COUSTEIX	\N	2026-09-08 14:35:49.094639+00	3	\N	\N	\N	\N
2274	2	23	2026-09-10	09:00-10:00	\N	VO	BLANC	\N	2026-09-08 14:36:06.951146+00	3	\N	\N	\N	\N
1965	2	23	2026-09-10	13:00-14:00	\N	VO	BOUCHEIX	\N	2026-09-08 10:14:10.819269+00	3	2026-09-08 14:36:19.537453+00	3	2026-09-08 14:36:19.351+00	3
2275	2	23	2026-09-10	14:00-15:00	\N	VO	BOUCHEIX	\N	2026-09-08 14:36:24.96678+00	3	\N	\N	\N	\N
2276	2	15	2026-09-12	14:00-15:00	1	VN	GUILLET CLIO6	\N	2026-09-08 14:37:04.987726+00	2	\N	\N	\N	\N
2277	2	28	2026-09-11	15:00-16:00	\N	VO	magout	\N	2026-09-08 14:37:54.399752+00	6	\N	\N	\N	\N
2278	2	97	2026-09-14	17:00-18:00	1	VN	herbin kangoo ze	\N	2026-09-08 14:37:55.933525+00	1775	\N	\N	\N	\N
2279	2	15	2026-09-14	10:00-11:00	2	VN	POTRINEAU SANDERO	\N	2026-09-08 14:38:07.840729+00	2	\N	\N	\N	\N
2280	2	28	2026-09-13	16:00-17:00	\N	VO	fourengare	\N	2026-09-08 14:38:22.68007+00	6	\N	\N	\N	\N
2281	2	74	2026-09-12	11:00-12:00	1	VN	PORTAL	\N	2026-09-08 14:38:36.898402+00	1778	\N	\N	\N	\N
2282	2	211	2026-09-11	11:00-12:00	\N	VO	REINA CLIO	\N	2026-09-08 14:38:49.965014+00	2	\N	\N	\N	\N
2283	2	40	2026-09-10	10:00-11:00	\N	VO	colon	\N	2026-09-08 14:39:06.579604+00	97	\N	\N	\N	\N
2284	2	9	2026-09-10	18:00-19:00	\N	VO	filandon	\N	2026-09-08 14:39:08.682137+00	6	\N	\N	\N	\N
2285	2	211	2026-09-12	16:00-17:00	\N	VO	VIRZI 2008	\N	2026-09-08 14:39:12.457413+00	2	\N	\N	\N	\N
2286	2	40	2026-09-10	14:00-15:00	\N	VO	chades	\N	2026-09-08 14:39:23.611687+00	97	\N	\N	\N	\N
2287	2	4	2026-09-10	09:00-10:00	1	VN	TARDIF  TWINGO	\N	2026-09-08 14:39:26.135534+00	4	\N	\N	\N	\N
2143	2	9	2026-09-12	10:00-11:00	\N	VO	faure	\N	2026-09-08 10:44:11.946273+00	6	2026-09-08 14:39:31.701941+00	6	2026-09-08 14:39:31.506+00	6
2288	2	4	2026-09-11	15:00-16:00	1	VN	MICHEL  CLIO	\N	2026-09-08 14:39:34.990051+00	4	\N	\N	\N	\N
2289	2	40	2026-09-11	09:00-10:00	\N	VO	crozatier	\N	2026-09-08 14:39:43.881654+00	97	\N	\N	\N	\N
2290	2	74	2026-09-12	10:00-11:00	1	VN	SAGE	\N	2026-09-08 14:39:48.795753+00	1778	\N	\N	\N	\N
2291	2	19	2026-09-11	17:00-18:00	1	VN	ROCHEGUCH SCENIC	\N	2026-09-08 14:39:54.067292+00	2	\N	\N	\N	\N
2292	2	4	2026-09-11	17:00-18:00	1	VN	BOUFFONNET  AUSTRAL	\N	2026-09-08 14:39:54.418701+00	4	\N	\N	\N	\N
2293	2	60	2026-09-10	14:00-15:00	2	VN	BRUEL	\N	2026-09-08 14:39:58.370453+00	7	\N	\N	\N	\N
2294	2	4	2026-09-13	10:00-11:00	1	VN	DELON  CLIO	\N	2026-09-08 14:40:00.532008+00	4	\N	\N	\N	\N
2295	2	213	2026-09-12	14:00-15:00	\N	VO	poissonnet	\N	2026-09-08 14:40:06.053564+00	6	\N	\N	\N	\N
2296	2	40	2026-09-11	14:00-15:00	\N	VO	etienne	\N	2026-09-08 14:40:07.666634+00	97	\N	\N	\N	\N
2297	2	4	2026-09-11	11:00-12:00	1	VN	TELLES  TWINGO	\N	2026-09-08 14:40:13.010405+00	4	\N	\N	\N	\N
2298	2	19	2026-09-12	09:00-10:00	1	VN	TONNEAU MEGANE	\N	2026-09-08 14:40:15.671383+00	2	\N	\N	\N	\N
2299	2	19	2026-09-12	10:00-11:00	1	VN	TONNEAU MEGANE	\N	2026-09-08 14:40:31.295407+00	2	\N	\N	\N	\N
2300	2	19	2026-09-12	11:00-12:00	1	VN	COUTERON SCENIC	\N	2026-09-08 14:41:18.280032+00	2	\N	\N	\N	\N
2302	2	84	2026-09-12	17:00-18:00	\N	VO	BASCOUL CAPTUR	\N	2026-09-08 14:41:56.604366+00	1776	\N	\N	\N	\N
2303	2	11	2026-09-13	10:00-11:00	2	VN	TIXIER SANDERO	\N	2026-09-08 14:41:56.628484+00	2	\N	\N	\N	\N
2305	2	84	2026-09-12	10:00-11:00	\N	VO	GOURDON SANDERO	\N	2026-09-08 14:42:11.589219+00	1776	\N	\N	\N	\N
2252	2	32	2026-09-13	09:00-10:00	1	VN	duchassin	\N	2026-09-08 14:29:49.85389+00	97	2026-09-08 15:20:54.917378+00	97	2026-09-08 15:20:55.066+00	97
2253	2	32	2026-09-13	11:00-12:00	1	VN	renard	\N	2026-09-08 14:29:53.835654+00	97	2026-09-08 15:22:24.899402+00	97	2026-09-08 15:22:22.461+00	97
2249	2	32	2026-09-12	14:00-15:00	1	VN	julien	\N	2026-09-08 14:29:27.782406+00	97	2026-09-08 15:23:18.458298+00	97	2026-09-08 15:23:17.823+00	97
2257	2	32	2026-09-14	14:00-15:00	1	VN	fieschi	\N	2026-09-08 14:30:31.882826+00	97	2026-09-08 15:24:27.963062+00	97	2026-09-08 15:24:27.665+00	97
2250	2	32	2026-09-12	15:00-16:00	1	VN	despalles	\N	2026-09-08 14:29:33.656852+00	97	2026-09-08 15:25:25.176837+00	97	2026-09-08 15:25:24.136+00	97
2259	2	32	2026-09-14	17:00-18:00	1	VN	chanat	\N	2026-09-08 14:30:41.008617+00	97	2026-09-08 15:26:33.588775+00	97	2026-09-08 15:26:19.966+00	97
2244	2	12	2026-09-11	10:00-11:00	1	VN	DA SILVA SPRING	\N	2026-09-08 14:27:48.49197+00	4	2026-09-09 16:21:19.239936+00	92	2026-09-09 16:21:18.864+00	92
2248	2	12	2026-09-12	11:00-12:00	1	VN	BOGTOB BIGSTER	\N	2026-09-08 14:29:23.228625+00	4	2026-09-09 16:21:38.945548+00	92	2026-09-09 16:21:38.613+00	92
2256	2	12	2026-09-12	13:00-14:00	1	VN	NAULT SANDERO	\N	2026-09-08 14:30:07.647112+00	4	2026-09-09 16:21:56.079992+00	92	2026-09-09 16:21:55.736+00	92
2304	2	71	2026-09-12	14:00-15:00	1	VN	HIMED	\N	2026-09-08 14:42:03.68611+00	1778	\N	\N	\N	\N
2307	2	11	2026-09-13	11:00-12:00	2	VN	ZEHE SANDERO	\N	2026-09-08 14:42:21.087862+00	2	\N	\N	\N	\N
2308	2	71	2026-09-12	09:00-10:00	1	VN	REVAILLER	\N	2026-09-08 14:42:26.660055+00	1778	\N	\N	\N	\N
2309	2	84	2026-09-11	16:00-17:00	\N	VO	CANIVENQ CLIO	\N	2026-09-08 14:42:27.961711+00	1776	\N	\N	\N	\N
2306	2	11	2026-09-13	11:00-12:00	1	VN	ZEHE	\N	2026-09-08 14:42:14.264416+00	2	2026-09-08 14:43:36.500136+00	2	2026-09-08 14:43:37.261+00	2
2326	2	34	2026-09-14	10:00-11:00	1	VN	jozat	\N	2026-09-08 14:44:41.087795+00	97	\N	\N	\N	\N
2301	2	11	2026-09-13	10:00-11:00	1	VN	TIXIER	\N	2026-09-08 14:41:48.577101+00	2	2026-09-08 14:42:04.744031+00	2	2026-09-08 14:42:05.527+00	2
2316	2	34	2026-09-10	14:00-15:00	1	VN	auger	\N	2026-09-08 14:43:19.635601+00	97	\N	\N	\N	\N
2319	2	34	2026-09-11	09:00-10:00	1	VN	debost	\N	2026-09-08 14:43:35.40495+00	97	\N	\N	\N	\N
2322	2	1885	2026-09-12	09:00-10:00	1	VN	AGNES - VN RENAULT	\N	2026-09-08 14:44:04.27308+00	1777	2026-09-08 14:44:26.899465+00	1777	\N	\N
2332	2	43	2026-09-13	09:00-10:00	1	VN	BONJEAN CAPTUR	\N	2026-09-08 14:47:38.87283+00	1782	\N	\N	\N	\N
2310	2	71	2026-09-12	11:00-12:00	1	VN	LEJAY	\N	2026-09-08 14:42:39.321394+00	1778	2026-09-08 14:42:55.426743+00	1778	\N	\N
2313	2	87	2026-09-11	14:00-15:00	2	VN	GAL - SANDERO VN	\N	2026-09-08 14:42:56.500538+00	1777	\N	\N	\N	\N
2329	2	90	2026-09-12	14:00-15:00	1	VN	grunenwald	\N	2026-09-08 14:45:27.76248+00	1781	\N	\N	\N	\N
2311	2	11	2026-09-14	14:00-15:00	1	VN	DUTEIL	\N	2026-09-08 14:42:41.65049+00	2	2026-09-08 14:43:07.8944+00	2	2026-09-08 14:43:08.508+00	2
2321	2	75	2026-09-10	11:00-12:00	1	VN	PORTE	\N	2026-09-08 14:44:01.026883+00	1778	\N	\N	\N	\N
2323	2	34	2026-09-13	15:00-16:00	1	VN	landrieaux	\N	2026-09-08 14:44:07.068411+00	97	\N	\N	\N	\N
2330	2	47	2026-09-10	08:00-09:00	\N	VO	ROMBAUT SANDERO	\N	2026-09-08 14:46:10.218566+00	1782	\N	\N	\N	\N
2331	2	44	2026-09-14	11:00-12:00	1	VN	CHASSAING	\N	2026-09-08 14:46:44.430309+00	1782	\N	\N	\N	\N
2314	2	11	2026-09-14	18:00-19:00	1	VN	PELOUX CAPTUR	\N	2026-09-08 14:42:59.622851+00	2	\N	\N	\N	\N
2318	2	90	2026-09-10	18:00-19:00	1	VN	st marc	\N	2026-09-08 14:43:26.456404+00	1781	\N	\N	\N	\N
2312	2	11	2026-09-14	14:00-15:00	2	VN	DUTEIL SPRING	\N	2026-09-08 14:42:49.527209+00	2	2026-09-08 14:43:30.39823+00	2	\N	\N
2315	2	71	2026-09-12	12:00-13:00	1	VN	DUZAC	\N	2026-09-08 14:43:06.81877+00	1778	\N	\N	\N	\N
2324	2	34	2026-09-13	16:00-17:00	1	VN	passat	\N	2026-09-08 14:44:11.392043+00	97	\N	\N	\N	\N
2317	2	34	2026-09-10	15:00-16:00	1	VN	soudan	\N	2026-09-08 14:43:23.670851+00	97	\N	\N	\N	\N
2327	2	90	2026-09-11	14:00-15:00	1	VN	moissie	\N	2026-09-08 14:44:47.219543+00	1781	\N	\N	\N	\N
2320	2	1885	2026-09-12	15:00-16:00	1	VN	LALOY - CLIO VI	\N	2026-09-08 14:43:45.633794+00	1777	\N	\N	\N	\N
2325	2	90	2026-09-10	17:00-18:00	2	VN	lemaitre	\N	2026-09-08 14:44:16.575883+00	1781	\N	\N	\N	\N
2328	2	75	2026-09-10	09:00-10:00	1	VN	CAMINADE	\N	2026-09-08 14:45:11.706939+00	1778	\N	\N	\N	\N
2333	2	23	2026-09-10	18:00-19:00	\N	VO	SERVANTI	\N	2026-09-08 14:49:14.502507+00	3	\N	\N	\N	\N
2334	2	27	2026-09-14	17:00-18:00	1	VN	SIBIAL DUSTER	\N	2026-09-08 14:50:41.821793+00	5	\N	\N	\N	\N
2335	2	27	2026-09-13	10:00-11:00	1	VN	BORDAS CLIO	\N	2026-09-08 14:50:54.04882+00	5	\N	\N	\N	\N
2336	2	215	2026-09-14	09:00-10:00	\N	VO	HABRIAL	\N	2026-09-08 14:51:05.670142+00	3	\N	\N	\N	\N
2337	2	6	2026-09-11	15:00-16:00	1	VN	MATHIEU SCENIC E TECH	\N	2026-09-08 14:51:19.935803+00	5	\N	\N	\N	\N
2338	2	6	2026-09-11	17:00-18:00	1	VN	SURER R5 ETETCH	\N	2026-09-08 14:51:31.376093+00	5	\N	\N	\N	\N
2339	2	60	2026-09-12	11:00-12:00	2	VN	JURET	\N	2026-09-08 14:51:42.223204+00	7	\N	\N	\N	\N
2341	2	6	2026-09-12	09:00-10:00	1	VN	BOURBONNER TWINGO	\N	2026-09-08 14:52:00.781446+00	5	\N	\N	\N	\N
2343	2	6	2026-09-12	14:00-15:00	1	VN	ACHIN AUSTRAL	\N	2026-09-08 14:52:19.685918+00	5	\N	\N	\N	\N
2344	2	1887	2026-09-10	14:00-15:00	\N	VO	M DUBOIS	\N	2026-09-08 14:52:21.855705+00	1783	\N	\N	\N	\N
2345	2	49	2026-09-12	09:00-10:00	1	VN	M DEBEUF	\N	2026-09-08 14:52:36.683442+00	1783	\N	\N	\N	\N
2346	2	6	2026-09-12	15:00-16:00	1	VN	DI SOCCIO TWINGO	\N	2026-09-08 14:52:38.716291+00	5	\N	\N	\N	\N
2347	2	49	2026-09-12	11:00-12:00	1	VN	M LOZERAL	\N	2026-09-08 14:52:44.320383+00	1783	\N	\N	\N	\N
2348	2	6	2026-09-12	17:00-18:00	1	VN	ZIMANOSKI MEGANE	\N	2026-09-08 14:52:56.062019+00	5	\N	\N	\N	\N
2349	2	49	2026-09-12	16:00-17:00	1	VN	M CHABANE	\N	2026-09-08 14:52:56.180145+00	1783	\N	\N	\N	\N
2350	2	50	2026-09-11	17:00-18:00	1	VN	M BONNAL	\N	2026-09-08 14:53:07.7629+00	1783	\N	\N	\N	\N
2352	2	50	2026-09-12	10:00-11:00	1	VN	M ARCHEMI	\N	2026-09-08 14:53:16.899489+00	1783	\N	\N	\N	\N
2353	2	48	2026-09-11	10:00-11:00	1	VN	M AUSSERT	\N	2026-09-08 14:53:32.507681+00	1783	\N	\N	\N	\N
2354	2	1887	2026-09-12	14:00-15:00	\N	VO	M DOGAN	\N	2026-09-08 14:53:44.260606+00	1783	\N	\N	\N	\N
2356	2	42	2026-09-14	16:00-17:00	2	VN	CROUES SANDERO	\N	2026-09-08 14:53:59.294876+00	1782	\N	\N	\N	\N
2357	2	50	2026-09-12	15:00-16:00	1	VN	MME MOINS	\N	2026-09-08 14:54:01.547146+00	1783	\N	\N	\N	\N
2359	2	42	2026-09-10	09:00-10:00	2	VN	THOMAS SANDERO	\N	2026-09-08 14:54:09.851403+00	1782	\N	\N	\N	\N
2361	2	50	2026-09-12	11:00-12:00	1	VN	M NORMANS	\N	2026-09-08 14:54:25.655418+00	1783	\N	\N	\N	\N
2364	2	6	2026-09-14	16:00-17:00	1	VN	ASTAIX AUSTRAL	\N	2026-09-08 14:54:55.988464+00	5	2026-09-09 16:29:23.068613+00	92	2026-09-09 16:29:22.748+00	92
2363	2	94	2026-09-12	16:00-17:00	1	VN	VEILLY	\N	2026-09-08 14:54:44.43329+00	1780	\N	\N	\N	\N
2365	2	94	2026-09-11	11:00-12:00	1	VN	LOUBIERES	\N	2026-09-08 14:55:06.622119+00	1780	\N	\N	\N	\N
2367	2	94	2026-09-12	11:00-12:00	1	VN	CANCHES	\N	2026-09-08 14:55:32.169144+00	1780	\N	\N	\N	\N
2371	2	5	2026-09-10	14:00-15:00	1	VN	TAILLANDIER MASTER	\N	2026-09-08 14:57:11.99243+00	5	\N	\N	\N	\N
2372	2	5	2026-09-10	15:00-16:00	1	VN	LABE KANGOO VU	\N	2026-09-08 14:57:20.683594+00	5	\N	\N	\N	\N
2373	2	5	2026-09-10	17:00-18:00	1	VN	BRUNEL AUSTRAL	\N	2026-09-08 14:57:27.301615+00	5	\N	\N	\N	\N
2374	2	87	2026-09-11	11:00-12:00	2	VN	BARBAUD - TWGO VO	\N	2026-09-08 14:57:28.761687+00	1777	\N	\N	\N	\N
2375	2	73	2026-09-11	09:00-10:00	1	VN	MICHEL	\N	2026-09-08 14:58:00.354019+00	1778	\N	\N	\N	\N
2377	2	882	2026-09-13	11:00-12:00	\N	VO	DARDELET / SCENIC VO	\N	2026-09-08 14:58:15.868206+00	8	\N	\N	\N	\N
2378	2	35	2026-09-11	17:00-18:00	1	VN	boukra	\N	2026-09-08 14:58:51.144306+00	97	\N	\N	\N	\N
2379	2	35	2026-09-12	11:00-12:00	1	VN	fouillot	\N	2026-09-08 14:59:06.778106+00	97	\N	\N	\N	\N
2380	2	35	2026-09-12	15:00-16:00	1	VN	desmaret	\N	2026-09-08 14:59:36.596967+00	97	\N	\N	\N	\N
2381	2	57	2026-09-12	16:00-17:00	\N	VO	CASTENET	\N	2026-09-08 14:59:49.486512+00	7	\N	\N	\N	\N
2382	2	90	2026-09-10	10:00-11:00	2	VN	garnier	\N	2026-09-08 15:01:12.850043+00	1781	\N	\N	\N	\N
2383	2	89	2026-09-12	09:00-10:00	1	VN	pons r5	\N	2026-09-08 15:03:06.471027+00	1781	2026-09-08 15:03:16.580768+00	1781	\N	\N
2384	2	1886	2026-09-10	16:00-17:00	2	VN	PUECH DUSTER	\N	2026-09-08 15:03:18.356684+00	1776	\N	\N	\N	\N
2385	2	89	2026-09-10	10:00-11:00	1	VN	brechet clio	\N	2026-09-08 15:03:32.477861+00	1781	\N	\N	\N	\N
2386	2	1886	2026-09-10	18:00-19:00	2	VN	VIARGUES SANDERO	\N	2026-09-08 15:03:34.622546+00	1776	\N	\N	\N	\N
2387	2	89	2026-09-10	15:00-16:00	2	VN	espinasse spring	\N	2026-09-08 15:03:53.713778+00	1781	\N	\N	\N	\N
2388	2	51	2026-09-14	14:00-15:00	\N	VO	M HALIME	\N	2026-09-08 15:03:59.766679+00	1783	\N	\N	\N	\N
2389	2	89	2026-09-12	11:00-12:00	1	VN	mas r5	\N	2026-09-08 15:04:23.733956+00	1781	\N	\N	\N	\N
2390	2	89	2026-09-12	17:00-18:00	1	VN	bost clio	\N	2026-09-08 15:04:40.969832+00	1781	\N	\N	\N	\N
2391	2	89	2026-09-14	14:00-15:00	2	VN	darbilly sand	\N	2026-09-08 15:05:16.937583+00	1781	\N	\N	\N	\N
2392	2	97	2026-09-12	16:00-17:00	1	VN	serres clio	\N	2026-09-08 15:05:19.23775+00	1775	\N	\N	\N	\N
2393	2	89	2026-09-14	17:00-18:00	1	VN	chambon austral	\N	2026-09-08 15:05:35.222165+00	1781	\N	\N	\N	\N
2394	2	16	2026-09-10	11:00-12:00	1	VN	PUYFAGE	\N	2026-09-08 15:06:00.756116+00	3	\N	\N	\N	\N
2395	2	16	2026-09-12	17:00-18:00	1	VN	GRENIER	\N	2026-09-08 15:06:09.598557+00	3	\N	\N	\N	\N
2396	2	60	2026-09-10	17:00-18:00	2	VN	TOURNADRE	\N	2026-09-08 15:06:10.228603+00	7	\N	\N	\N	\N
2397	2	79	2026-09-10	15:00-16:00	1	VN	GASSIM CAPTUR	\N	2026-09-08 15:07:23.666609+00	1776	\N	\N	\N	\N
2370	2	62	2026-09-11	16:00-17:00	2	VN	CROCOMBETTE	\N	2026-09-08 14:56:56.696468+00	7	2026-09-08 16:53:16.061021+00	7	2026-09-08 16:53:16.219+00	7
2368	2	14	2026-09-11	11:00-12:00	1	VN	MARTIN SANDERO	\N	2026-09-08 14:55:41.253918+00	5	2026-09-09 16:23:39.958981+00	92	2026-09-09 16:23:39.621+00	92
2369	2	14	2026-09-11	14:00-15:00	1	VN	SAURIN DUSTER	\N	2026-09-08 14:55:55.774048+00	5	2026-09-09 16:23:49.211481+00	92	2026-09-09 16:23:48.883+00	92
2358	2	6	2026-09-14	14:00-15:00	1	VN	ROYER SANDERO	\N	2026-09-08 14:54:05.819402+00	5	2026-09-09 16:24:51.650454+00	92	2026-09-09 16:24:51.187+00	92
2342	2	6	2026-09-12	10:00-11:00	1	VN	FOURNER SPRING	\N	2026-09-08 14:52:07.151384+00	5	2026-09-09 16:28:53.929554+00	92	2026-09-09 16:28:53.619+00	92
2351	2	6	2026-09-13	10:00-11:00	1	VN	JEANJEAN SANDERO	\N	2026-09-08 14:53:10.041403+00	5	2026-09-09 16:29:00.353062+00	92	2026-09-09 16:29:00.006+00	92
2355	2	6	2026-09-14	09:00-10:00	1	VN	BONABRI SPRING	\N	2026-09-08 14:53:45.746422+00	5	2026-09-09 16:29:05.641288+00	92	2026-09-09 16:29:05.298+00	92
2362	2	6	2026-09-14	15:00-16:00	1	VN	EVENO SANDERO	\N	2026-09-08 14:54:34.712788+00	5	2026-09-09 16:29:19.907925+00	92	2026-09-09 16:29:19.579+00	92
2398	2	42	2026-09-12	10:00-11:00	2	VN	BISSON SANDERO	\N	2026-09-08 15:07:31.244727+00	1782	\N	\N	\N	\N
2405	2	72	2026-09-11	15:00-16:00	1	VN	RAVAZIO	\N	2026-09-08 15:09:04.058403+00	1778	\N	\N	\N	\N
2410	2	54	2026-09-10	09:00-10:00	1	VN	BOYER / TWINGO	\N	2026-09-08 15:09:39.903241+00	8	\N	\N	\N	\N
2399	2	15	2026-09-12	10:00-11:00	2	VN	GABRILLARGUES DUSTER	\N	2026-09-08 15:07:53.693795+00	2	\N	\N	\N	\N
2417	2	80	2026-09-12	15:00-16:00	1	VN	RAYNAL CLIO 5	\N	2026-09-08 15:10:49.375036+00	1776	\N	\N	\N	\N
1759	2	79	2026-09-10	09:00-10:00	1	VN	DESMESURE TW3	\N	2026-09-08 09:37:38.329405+00	1776	2026-09-08 15:07:54.312782+00	1776	2026-09-08 15:07:54.308+00	1776
2400	2	9	2026-09-12	15:00-16:00	\N	VO	vaz	\N	2026-09-08 15:08:16.335851+00	6	\N	\N	\N	\N
2401	2	18	2026-09-10	14:00-15:00	1	VN	SEGAUD SCENIC	\N	2026-09-08 15:08:28.6541+00	4	\N	\N	\N	\N
2407	2	18	2026-09-11	10:00-11:00	1	VN	DAOULAS CLIO	\N	2026-09-08 15:09:18.45764+00	4	\N	\N	\N	\N
2415	2	80	2026-09-11	10:00-11:00	1	VN	RIEU CLIO 6	\N	2026-09-08 15:10:17.413401+00	1776	\N	\N	\N	\N
2402	2	54	2026-09-13	09:00-10:00	1	VN	SYLVESTRE / ALPINE A 290	\N	2026-09-08 15:08:32.51981+00	8	\N	\N	\N	\N
2403	2	72	2026-09-11	09:00-10:00	1	VN	GASTON	\N	2026-09-08 15:08:57.504238+00	1778	\N	\N	\N	\N
2411	2	72	2026-09-14	10:00-11:00	1	VN	JOUNEAU	\N	2026-09-08 15:09:56.410616+00	1778	\N	\N	\N	\N
2404	2	57	2026-09-11	17:00-18:00	\N	VO	RAYNAUD	\N	2026-09-08 15:09:00.431404+00	7	\N	\N	\N	\N
2414	2	23	2026-09-12	10:00-11:00	\N	VO	CALVIRAC	\N	2026-09-08 15:10:10.893028+00	3	\N	\N	\N	\N
2406	2	72	2026-09-11	17:00-18:00	1	VN	JOUCLA	\N	2026-09-08 15:09:10.8225+00	1778	\N	\N	\N	\N
2409	2	80	2026-09-11	09:00-10:00	1	VN	CHERUE CLIO 6	\N	2026-09-08 15:09:34.977783+00	1776	2026-09-08 15:09:37.064007+00	1776	2026-09-08 15:09:37.387+00	1776
2412	2	80	2026-09-11	09:00-10:00	1	VN	CHERUE	\N	2026-09-08 15:09:58.916036+00	1776	\N	\N	\N	\N
2408	2	72	2026-09-11	11:00-12:00	2	VN	MEHAYE	\N	2026-09-08 15:09:25.445096+00	1778	\N	\N	\N	\N
2416	2	80	2026-09-12	09:00-10:00	1	VN	BLAZY TW3	\N	2026-09-08 15:10:37.049507+00	1776	\N	\N	\N	\N
2413	2	41	2026-09-13	10:00-11:00	\N	VO	youssef	\N	2026-09-08 15:10:10.711395+00	97	\N	\N	\N	\N
2418	2	54	2026-09-10	09:00-10:00	2	VN	PIGNOL /	\N	2026-09-08 15:11:46.746762+00	8	\N	\N	\N	\N
2419	2	84	2026-09-11	11:00-12:00	\N	VO	LALO CAPTUR	\N	2026-09-08 15:11:56.415886+00	1776	\N	\N	\N	\N
2420	2	84	2026-09-12	11:00-12:00	\N	VO	LACAN KADJAR	\N	2026-09-08 15:12:10.556281+00	1776	\N	\N	\N	\N
2421	2	85	2026-09-11	14:00-15:00	\N	VO	VEZY TWINGO	\N	2026-09-08 15:13:08.362022+00	1776	\N	\N	\N	\N
2243	2	215	2026-09-12	09:00-10:00	\N	VO	N GOUA	\N	2026-09-08 14:24:35.900236+00	3	2026-09-08 15:13:18.969076+00	3	\N	\N
2422	2	215	2026-09-12	10:00-11:00	\N	VO	SAVATIER	\N	2026-09-08 15:13:28.889393+00	3	\N	\N	\N	\N
2423	2	87	2026-09-14	11:00-12:00	2	VN	PIERRON - R5	\N	2026-09-08 15:13:47.312912+00	1777	\N	\N	\N	\N
2424	2	10	2026-09-10	14:00-15:00	1	VN	PRAX	\N	2026-09-08 15:14:04.76672+00	3	\N	\N	\N	\N
2425	2	92	2026-09-10	09:00-10:00	1	VN	NOUVEL	\N	2026-09-08 15:14:08.343894+00	1780	\N	\N	\N	\N
2426	2	92	2026-09-10	10:00-11:00	2	VN	MIRKA	\N	2026-09-08 15:14:21.512203+00	1780	\N	\N	\N	\N
2427	2	92	2026-09-10	11:00-12:00	1	VN	SCLAFERT	\N	2026-09-08 15:14:26.026809+00	1780	\N	\N	\N	\N
2428	2	92	2026-09-10	14:00-15:00	1	VN	BLANCHET	\N	2026-09-08 15:14:31.173127+00	1780	\N	\N	\N	\N
2429	2	92	2026-09-10	15:00-16:00	1	VN	VILLEMIN	\N	2026-09-08 15:14:37.297645+00	1780	\N	\N	\N	\N
2430	2	92	2026-09-10	16:00-17:00	2	VN	PIGNOT	\N	2026-09-08 15:14:43.483558+00	1780	\N	\N	\N	\N
2431	2	92	2026-09-10	17:00-18:00	2	VN	RIEHL	\N	2026-09-08 15:14:53.513738+00	1780	\N	\N	\N	\N
2433	2	33	2026-09-12	10:00-11:00	1	VN	prevot	\N	2026-09-08 15:15:03.278608+00	97	\N	\N	\N	\N
2434	2	33	2026-09-12	09:00-10:00	1	VN	bach	\N	2026-09-08 15:15:13.124208+00	97	\N	\N	\N	\N
2435	2	33	2026-09-12	11:00-12:00	1	VN	vallin	\N	2026-09-08 15:15:21.998269+00	97	\N	\N	\N	\N
2436	2	55	2026-09-10	10:00-11:00	1	VN	LAURENT	\N	2026-09-08 15:15:28.09585+00	9	\N	\N	\N	\N
2437	2	33	2026-09-12	13:00-14:00	1	VN	deshaies	\N	2026-09-08 15:15:34.072046+00	97	\N	\N	\N	\N
2439	2	33	2026-09-12	14:00-15:00	1	VN	touly	\N	2026-09-08 15:15:40.650299+00	97	\N	\N	\N	\N
2441	2	33	2026-09-12	15:00-16:00	1	VN	bouillerand	\N	2026-09-08 15:15:54.056169+00	97	\N	\N	\N	\N
2442	2	55	2026-09-10	14:00-15:00	1	VN	QUITTERIE COGNON	\N	2026-09-08 15:15:55.958704+00	9	\N	\N	\N	\N
2438	2	95	2026-09-11	15:00-16:00	1	VN	SOUQUIERES	\N	2026-09-08 15:15:40.084802+00	1780	2026-09-08 15:15:58.296705+00	1780	2026-09-08 15:15:57.783+00	1780
2440	2	95	2026-09-11	16:00-17:00	1	VN	LEVERT	\N	2026-09-08 15:15:45.48628+00	1780	2026-09-08 15:16:02.542408+00	1780	2026-09-08 15:16:01.71+00	1780
2443	2	55	2026-09-11	14:00-15:00	1	VN	SERRE	\N	2026-09-08 15:16:03.506282+00	9	\N	\N	\N	\N
2444	2	33	2026-09-12	16:00-17:00	1	VN	dumet	\N	2026-09-08 15:16:08.682434+00	97	\N	\N	\N	\N
2446	2	92	2026-09-11	15:00-16:00	1	VN	SOUQUIERES	\N	2026-09-08 15:16:18.685311+00	1780	\N	\N	\N	\N
2447	2	92	2026-09-11	16:00-17:00	1	VN	LEVERT	\N	2026-09-08 15:16:24.671861+00	1780	\N	\N	\N	\N
2448	2	92	2026-09-11	17:00-18:00	2	VN	TERNAT	\N	2026-09-08 15:16:29.101385+00	1780	\N	\N	\N	\N
2449	2	33	2026-09-12	17:00-18:00	1	VN	bigot	\N	2026-09-08 15:16:32.682386+00	97	\N	\N	\N	\N
2452	2	92	2026-09-12	11:00-12:00	1	VN	CARRIERE	\N	2026-09-08 15:16:43.618718+00	1780	\N	\N	\N	\N
2459	2	14	2026-09-13	09:00-10:00	1	VN	JIMENEZ DUSTER	\N	2026-09-08 15:17:29.863573+00	5	2026-09-09 16:23:20.592899+00	92	2026-09-09 16:23:20.224+00	92
2453	2	55	2026-09-14	14:00-15:00	1	VN	JOUFFRE	\N	2026-09-08 15:16:47.46278+00	9	\N	\N	\N	\N
2451	2	90	2026-09-12	10:00-11:00	2	VN	despeyroux	\N	2026-09-08 15:16:40.91539+00	1781	2026-09-08 15:16:50.400703+00	1781	\N	\N
2432	2	33	2026-09-12	09:00-10:00	1	VN	bach	\N	2026-09-08 15:14:56.306554+00	97	2026-09-08 15:16:56.265403+00	97	2026-09-08 15:16:55.925+00	97
2454	2	33	2026-09-13	10:00-11:00	1	VN	thouvenet	\N	2026-09-08 15:17:14.489169+00	97	\N	\N	\N	\N
2456	2	95	2026-09-12	09:00-10:00	2	VN	FRANC	\N	2026-09-08 15:17:18.603722+00	1780	\N	\N	\N	\N
2457	2	33	2026-09-13	11:00-12:00	1	VN	butey	\N	2026-09-08 15:17:23.379547+00	97	\N	\N	\N	\N
2458	2	95	2026-09-12	11:00-12:00	1	VN	DUCAYLAR	\N	2026-09-08 15:17:26.824905+00	1780	\N	\N	\N	\N
2460	2	95	2026-09-12	14:00-15:00	1	VN	BASTIDE	\N	2026-09-08 15:17:34.512117+00	1780	\N	\N	\N	\N
2461	2	10	2026-09-10	18:00-19:00	1	VN	FRAISSABGE	\N	2026-09-08 15:17:37.910287+00	3	\N	\N	\N	\N
2462	2	33	2026-09-13	14:00-15:00	1	VN	diccio	\N	2026-09-08 15:17:43.116894+00	97	\N	\N	\N	\N
2464	2	33	2026-09-13	15:00-16:00	1	VN	blanchet	\N	2026-09-08 15:17:54.472237+00	97	\N	\N	\N	\N
2465	2	74	2026-09-14	16:00-17:00	1	VN	BENETTI	\N	2026-09-08 15:18:07.009332+00	1778	\N	\N	\N	\N
2466	2	75	2026-09-11	09:00-10:00	2	VN	ROUQUET	\N	2026-09-08 15:18:31.124247+00	1778	\N	\N	\N	\N
2468	2	93	2026-09-10	09:00-10:00	2	VN	GILLES	\N	2026-09-08 15:18:58.018401+00	1780	\N	\N	\N	\N
2470	2	93	2026-09-10	10:00-11:00	1	VN	BAU	\N	2026-09-08 15:19:05.054963+00	1780	\N	\N	\N	\N
2471	2	93	2026-09-10	11:00-12:00	1	VN	MOLTENI	\N	2026-09-08 15:19:13.418887+00	1780	\N	\N	\N	\N
2472	2	68	2026-09-10	18:00-19:00	\N	VO	DESENCLOS	\N	2026-09-08 15:19:18.095523+00	9	\N	\N	\N	\N
2474	2	93	2026-09-10	15:00-16:00	2	VN	CHARREIRE	\N	2026-09-08 15:19:30.834965+00	1780	\N	\N	\N	\N
2475	2	90	2026-09-12	16:00-17:00	1	VN	senelier meg	\N	2026-09-08 15:19:39.464405+00	1781	\N	\N	\N	\N
2476	2	93	2026-09-11	15:00-16:00	1	VN	SEINCE	\N	2026-09-08 15:19:51.045165+00	1780	\N	\N	\N	\N
2477	2	93	2026-09-11	16:00-17:00	2	VN	COULON	\N	2026-09-08 15:20:04.179034+00	1780	\N	\N	\N	\N
2478	2	93	2026-09-12	14:00-15:00	2	VN	LAMOTTE	\N	2026-09-08 15:20:19.40165+00	1780	\N	\N	\N	\N
2479	2	32	2026-09-12	09:00-10:00	2	VN	guigen	\N	2026-09-08 15:20:21.021714+00	97	\N	\N	\N	\N
2481	2	32	2026-09-13	09:00-10:00	2	VN	duchassin	\N	2026-09-08 15:20:30.717053+00	97	\N	\N	\N	\N
2247	2	32	2026-09-12	09:00-10:00	1	VN	guigum	\N	2026-09-08 14:29:22.826539+00	97	2026-09-08 15:20:37.324715+00	97	2026-09-08 15:20:36.151+00	97
2483	2	93	2026-09-12	11:00-12:00	1	VN	MILLE	\N	2026-09-08 15:20:46.199322+00	1780	\N	\N	\N	\N
2485	2	17	2026-09-12	09:00-10:00	1	VN	ROLLEY R4	\N	2026-09-08 15:21:01.4455+00	5	\N	\N	\N	\N
2469	2	14	2026-09-14	09:00-10:00	1	VN	GAMBIER SANDERO	\N	2026-09-08 15:19:03.595305+00	5	2026-09-09 16:23:23.700593+00	92	2026-09-09 16:23:23.345+00	92
2463	2	14	2026-09-13	10:00-11:00	1	VN	GUILLO SANDERO	\N	2026-09-08 15:17:51.123309+00	5	2026-09-09 16:23:34.5208+00	92	2026-09-09 16:23:34.196+00	92
2445	2	14	2026-09-11	17:00-18:00	1	VN	DELPRAT JOGGER	\N	2026-09-08 15:16:16.734408+00	5	2026-09-09 16:24:00.386934+00	92	2026-09-09 16:24:00.044+00	92
2467	2	14	2026-09-13	17:00-18:00	1	VN	DUCHE DUSTER	\N	2026-09-08 15:18:52.977068+00	5	2026-09-09 16:24:03.736832+00	92	2026-09-09 16:24:03.402+00	92
2473	2	14	2026-09-14	17:00-18:00	1	VN	CHANTENAIS SANDERO	\N	2026-09-08 15:19:20.007523+00	5	2026-09-09 16:24:06.500251+00	92	2026-09-09 16:24:06.121+00	92
2480	2	17	2026-09-11	15:00-16:00	1	VN	PINO TWINGO	\N	2026-09-08 15:20:29.785408+00	5	2026-09-08 15:20:38.874774+00	5	\N	\N
2482	2	17	2026-09-11	16:00-17:00	1	VN	PINEAU TWINGO	\N	2026-09-08 15:20:35.537569+00	5	2026-09-08 15:20:52.24895+00	5	\N	\N
2484	2	3	2026-09-11	14:00-15:00	1	VN	MORIN  R5	\N	2026-09-08 15:20:52.456292+00	4	\N	\N	\N	\N
2486	2	93	2026-09-12	15:00-16:00	2	VN	RAJEWICZ	\N	2026-09-08 15:21:03.375396+00	1780	\N	\N	\N	\N
2487	2	3	2026-09-11	15:00-16:00	1	VN	MORIN  CAPTUR	\N	2026-09-08 15:21:05.855225+00	4	\N	\N	\N	\N
2489	2	32	2026-09-10	11:00-12:00	2	VN	ribes	\N	2026-09-08 15:21:15.539468+00	97	\N	\N	\N	\N
2490	2	32	2026-09-13	11:00-12:00	2	VN	renard	\N	2026-09-08 15:21:18.996994+00	97	\N	\N	\N	\N
2491	2	17	2026-09-12	10:00-11:00	1	VN	GROSSENS SCENIC	\N	2026-09-08 15:21:21.663644+00	5	\N	\N	\N	\N
2492	2	3	2026-09-12	10:00-11:00	1	VN	MALLET SANDERO	\N	2026-09-08 15:21:26.747388+00	4	\N	\N	\N	\N
2493	2	93	2026-09-12	17:00-18:00	1	VN	MULLER	\N	2026-09-08 15:21:32.102163+00	1780	\N	\N	\N	\N
2488	2	32	2026-09-10	10:00-11:00	2	VN	gomard	\N	2026-09-08 15:21:11.505807+00	97	2026-09-08 15:21:37.674282+00	97	2026-09-08 15:21:37.489+00	97
2495	2	17	2026-09-12	13:00-14:00	1	VN	VENERAI R5	\N	2026-09-08 15:21:42.942442+00	5	\N	\N	\N	\N
2496	2	78	2026-09-13	14:00-15:00	1	VN	JOLY	\N	2026-09-08 15:21:49.856401+00	1778	\N	\N	\N	\N
2497	2	17	2026-09-12	14:00-15:00	1	VN	TARDIEU CLIO	\N	2026-09-08 15:21:57.467226+00	5	\N	\N	\N	\N
2526	2	32	2026-09-10	16:00-17:00	2	VN	descriaux	\N	2026-09-08 15:29:15.937972+00	97	\N	\N	\N	\N
2494	2	17	2026-09-12	13:00-14:00	1	VN	VERNERAI	\N	2026-09-08 15:21:32.417746+00	5	2026-09-08 15:22:09.916506+00	5	2026-09-08 15:22:02.721+00	5
2499	2	32	2026-09-10	10:00-11:00	2	VN	gomard	\N	2026-09-08 15:22:20.991388+00	97	\N	\N	\N	\N
2498	2	17	2026-09-12	16:00-17:00	1	VN	PICHARD CLIO	\N	2026-09-08 15:22:20.904014+00	5	2026-09-08 15:22:30.332757+00	5	\N	\N
2500	2	71	2026-09-11	17:00-18:00	1	VN	DOYE	\N	2026-09-08 15:22:39.307403+00	1778	\N	\N	\N	\N
2501	2	71	2026-09-11	17:00-18:00	1	VN	DOYE	\N	2026-09-08 15:22:45.614835+00	1778	\N	\N	\N	\N
2504	2	32	2026-09-11	14:00-15:00	2	VN	kramer	\N	2026-09-08 15:22:51.413395+00	97	\N	\N	\N	\N
2505	2	17	2026-09-13	10:00-11:00	1	VN	GOVERI SCENIC	\N	2026-09-08 15:22:52.125324+00	5	\N	\N	\N	\N
1801	2	32	2026-09-11	14:00-15:00	1	VN	kramer	\N	2026-09-08 09:49:37.371014+00	97	2026-09-08 15:22:58.786601+00	97	2026-09-08 15:22:58.821+00	97
2502	2	4	2026-09-10	17:00-18:00	1	VN	DUMAS  CLIO	\N	2026-09-08 15:22:46.529843+00	4	2026-09-08 15:23:04.195468+00	4	2026-09-08 15:23:01.463+00	4
2503	2	17	2026-09-13	10:00-11:00	1	VN	GOVERI SCENIC	\N	2026-09-08 15:22:50.072946+00	5	2026-09-08 15:23:05.403436+00	5	2026-09-08 15:23:01.704+00	5
2507	2	32	2026-09-12	14:00-15:00	2	VN	julien	\N	2026-09-08 15:23:13.561636+00	97	\N	\N	\N	\N
2508	2	19	2026-09-12	12:00-13:00	1	VN	ROUSSEL R4	\N	2026-09-08 15:23:15.722217+00	2	\N	\N	\N	\N
2506	2	4	2026-09-10	17:00-18:00	1	VN	DUMAS CLIO	\N	2026-09-08 15:22:53.808144+00	4	2026-09-08 15:23:25.516313+00	4	2026-09-08 15:23:23.434+00	4
2509	2	17	2026-09-13	15:00-16:00	1	VN	VUSINIC R5	\N	2026-09-08 15:23:26.351694+00	5	\N	\N	\N	\N
2511	2	32	2026-09-13	14:00-15:00	2	VN	louzat	\N	2026-09-08 15:23:43.34743+00	97	\N	\N	\N	\N
2510	2	19	2026-09-12	14:00-15:00	1	VN	DESGEOGES MEGANE	\N	2026-09-08 15:23:36.046962+00	2	2026-09-08 15:23:52.191623+00	2	\N	\N
2512	2	87	2026-09-12	14:00-15:00	2	VN	FEVRE - CLIO VI VN	\N	2026-09-08 15:23:43.385377+00	1777	2026-09-08 15:23:52.226307+00	1777	\N	\N
2255	2	32	2026-09-13	14:00-15:00	1	VN	louzat	\N	2026-09-08 14:29:59.792059+00	97	2026-09-08 15:23:53.548438+00	97	2026-09-08 15:23:53.688+00	97
2516	2	211	2026-09-11	10:00-11:00	\N	VO	CORNET CLIO5	\N	2026-09-08 15:24:24.539045+00	2	\N	\N	\N	\N
2517	2	32	2026-09-14	14:00-15:00	2	VN	fieschi	\N	2026-09-08 15:24:25.336369+00	97	\N	\N	\N	\N
2519	2	17	2026-09-11	18:00-19:00	1	VN	RAYMON DUSTER	\N	2026-09-08 15:24:38.628808+00	5	\N	\N	\N	\N
2513	2	17	2026-09-14	16:00-17:00	1	VN	GAUTHIER TWINGO	\N	2026-09-08 15:23:54.86481+00	5	2026-09-08 15:24:48.301594+00	5	2026-09-08 15:24:42.571+00	5
2518	2	17	2026-09-14	15:00-16:00	1	VN	GAUTHIER TWINGO	\N	2026-09-08 15:24:35.537018+00	5	2026-09-08 15:24:54.7891+00	5	2026-09-08 15:24:54.846+00	5
2542	2	61	2026-09-11	17:00-18:00	\N	VO	PASSEBOIS	\N	2026-09-08 15:41:04.290796+00	9	\N	\N	\N	\N
2514	2	17	2026-09-14	16:00-17:00	1	VN	GAUTHIER TWINGO	\N	2026-09-08 15:24:01.062987+00	5	2026-09-08 15:25:23.087931+00	5	2026-09-08 15:25:08.988+00	5
2522	2	211	2026-09-11	14:00-15:00	\N	VO	GUILLOU KANGOO VU	\N	2026-09-08 15:25:32.660888+00	2	\N	\N	\N	\N
2523	2	32	2026-09-12	15:00-16:00	2	VN	despalles	\N	2026-09-08 15:25:36.448092+00	97	\N	\N	\N	\N
2524	2	32	2026-09-10	15:00-16:00	2	VN	falchetto	\N	2026-09-08 15:25:38.886802+00	97	\N	\N	\N	\N
2520	2	211	2026-09-11	14:00-15:00	\N	VO	GUILLOU KANGOO VU	\N	2026-09-08 15:25:02.166514+00	2	2026-09-08 15:29:44.804321+00	2	2026-09-08 15:29:08.805+00	2
2515	2	211	2026-09-11	10:00-11:00	\N	VO	CORNET CLIO5	\N	2026-09-08 15:24:21.879419+00	2	2026-09-08 15:25:48.707071+00	2	2026-09-08 15:25:27.025+00	2
2525	2	32	2026-09-14	17:00-18:00	2	VN	chanat	\N	2026-09-08 15:27:03.698061+00	97	\N	\N	\N	\N
2538	2	213	2026-09-11	11:00-12:00	\N	VO	floment	\N	2026-09-08 15:39:01.679671+00	6	2026-09-08 15:39:45.264919+00	6	2026-09-08 15:39:44.892+00	6
2540	2	31	2026-09-13	11:00-12:00	2	VN	lambert	\N	2026-09-08 15:40:38.90103+00	97	\N	\N	\N	\N
2528	2	32	2026-09-11	16:00-17:00	2	VN	viguie	\N	2026-09-08 15:30:44.033523+00	97	\N	\N	\N	\N
2529	2	1885	2026-09-11	17:00-18:00	1	VN	DEJEAN - VN R	\N	2026-09-08 15:33:53.078713+00	1777	\N	\N	\N	\N
2530	2	1885	2026-09-11	11:00-12:00	1	VN	ROUSSEAU - VN	\N	2026-09-08 15:33:54.76228+00	1777	\N	\N	\N	\N
2533	2	24	2026-09-12	15:00-16:00	\N	VO	VALERO	\N	2026-09-08 15:34:56.470379+00	4	\N	\N	\N	\N
2535	2	69	2026-09-12	14:00-15:00	\N	VO	chabriere	\N	2026-09-08 15:35:02.500844+00	7	\N	\N	\N	\N
2536	2	4	2026-09-10	17:00-18:00	1	VN	DUMAS CLIO	\N	2026-09-08 15:35:19.799795+00	4	\N	\N	\N	\N
2527	2	4	2026-09-10	17:00-18:00	1	VN	DUMAS CLIO	\N	2026-09-08 15:30:43.374205+00	4	2026-09-08 15:38:55.122076+00	4	2026-09-08 15:38:55.051+00	4
2539	2	213	2026-09-11	11:00-12:00	\N	VO	flament	\N	2026-09-08 15:39:13.912395+00	6	\N	\N	\N	\N
2224	2	31	2026-09-13	11:00-12:00	1	VN	lambert	\N	2026-09-08 14:18:54.664299+00	97	2026-09-08 15:40:53.591036+00	97	2026-09-08 15:40:50.835+00	97
2541	2	74	2026-09-12	15:00-16:00	1	VN	BRELHIAT	\N	2026-09-08 15:40:54.317933+00	1778	2026-09-08 15:41:07.781213+00	1778	\N	\N
2543	2	31	2026-09-11	14:00-15:00	2	VN	lorderon	\N	2026-09-08 15:41:13.401653+00	97	\N	\N	\N	\N
2218	2	31	2026-09-11	14:00-15:00	1	VN	lorderon	\N	2026-09-08 14:18:17.594584+00	97	2026-09-08 15:41:17.705499+00	97	2026-09-08 15:41:14.95+00	97
2544	2	61	2026-09-12	16:00-17:00	\N	VO	BRUN	\N	2026-09-08 15:41:20.408404+00	9	\N	\N	\N	\N
2546	2	74	2026-09-12	16:00-17:00	1	VN	JORDY	\N	2026-09-08 15:41:22.327975+00	1778	\N	\N	\N	\N
2547	2	31	2026-09-12	15:00-16:00	2	VN	brun	\N	2026-09-08 15:43:09.627666+00	97	\N	\N	\N	\N
2537	2	67	2026-09-10	18:00-19:00	1	VN	BAILLON	\N	2026-09-08 15:35:54.435911+00	8	2026-09-08 15:53:59.982324+00	8	2026-09-08 15:53:58.943+00	8
2556	2	10	2026-09-12	10:00-11:00	1	VN	SAINT JOANNIS	\N	2026-09-08 15:49:04.509045+00	3	2026-09-08 16:00:10.420216+00	3	2026-09-08 16:00:10.276+00	3
2521	2	211	2026-09-11	14:00-15:00	\N	VO	GUILLOU KANGOO VU	\N	2026-09-08 15:25:14.900408+00	2	2026-09-08 16:02:39.6707+00	2	2026-09-08 16:02:40.43+00	2
2531	2	69	2026-09-12	14:00-15:00	\N	VO	chabriere	\N	2026-09-08 15:34:32.783885+00	7	2026-09-08 16:14:52.246492+00	7	2026-09-08 16:14:52.405+00	7
2532	2	67	2026-09-10	18:00-19:00	1	VN	BAILLON / R	\N	2026-09-08 15:34:55.697018+00	8	2026-09-08 15:46:11.045899+00	8	2026-09-08 15:45:43.046+00	8
2545	2	74	2026-09-12	16:00-17:00	1	VN	JORDY	\N	2026-09-08 15:41:20.222403+00	1778	2026-09-08 15:43:12.440225+00	1778	2026-09-08 15:42:12.171+00	1778
2548	2	33	2026-09-14	11:00-12:00	1	VN	thillet	\N	2026-09-08 15:43:15.433244+00	97	\N	\N	\N	\N
2551	2	75	2026-09-13	11:00-12:00	2	VN	LAPARRA	\N	2026-09-08 15:45:43.454315+00	1778	\N	\N	\N	\N
2555	2	55	2026-09-12	16:00-17:00	1	VN	MOREL	\N	2026-09-08 15:48:14.423664+00	9	\N	\N	\N	\N
2560	2	31	2026-09-11	17:00-18:00	2	VN	buchard	\N	2026-09-08 15:50:55.624388+00	97	\N	\N	\N	\N
2561	2	31	2026-09-11	16:00-17:00	2	VN	brenet	\N	2026-09-08 15:50:53.639205+00	97	\N	\N	\N	\N
2564	2	33	2026-09-14	16:00-17:00	1	VN	pincon parents	\N	2026-09-08 15:51:46.440179+00	97	\N	\N	\N	\N
2534	2	67	2026-09-10	18:00-19:00	1	VN	BAILLON / R5	\N	2026-09-08 15:35:00.625005+00	8	2026-09-08 15:52:26.374539+00	8	2026-09-08 15:52:24.909+00	8
2566	2	53	2026-09-11	14:00-15:00	2	VN	.	\N	2026-09-08 15:52:02.488625+00	9	2026-09-08 15:54:00.111925+00	9	2026-09-08 15:53:28.556+00	9
2558	2	10	2026-09-12	11:00-12:00	1	VN	SAINT JOANNIS	\N	2026-09-08 15:49:04.539672+00	3	2026-09-08 15:55:00.624149+00	3	2026-09-08 15:54:59.004+00	3
2549	2	75	2026-09-13	10:00-11:00	2	VN	LAPARRA	\N	2026-09-08 15:45:06.18621+00	1778	2026-09-08 16:14:54.105008+00	1778	2026-09-08 16:14:52.783+00	1778
2550	2	75	2026-09-13	10:00-11:00	2	VN	LAPARRA	\N	2026-09-08 15:45:42.890054+00	1778	2026-09-08 16:15:37.828699+00	1778	2026-09-08 16:15:36.538+00	1778
2552	2	75	2026-09-13	10:00-11:00	2	VN	LAPPARA	\N	2026-09-08 15:46:10.361866+00	1778	2026-09-08 16:15:42.935987+00	1778	2026-09-08 16:15:41.24+00	1778
2553	2	75	2026-09-13	10:00-11:00	2	VN	LAPPARA	\N	2026-09-08 15:46:10.398136+00	1778	2026-09-08 16:15:48.090489+00	1778	2026-09-08 16:15:46.764+00	1778
2554	2	75	2026-09-13	10:00-11:00	2	VN	LAPARRA	\N	2026-09-08 15:46:23.171546+00	1778	2026-09-08 16:15:51.089578+00	1778	2026-09-08 16:15:49.748+00	1778
2559	2	10	2026-09-12	10:00-11:00	1	VN	SAINT JOANNIS	\N	2026-09-08 15:49:04.506941+00	3	\N	\N	\N	\N
2562	2	53	2026-09-12	14:00-15:00	2	VN	FERRAPIE	\N	2026-09-08 15:51:21.192821+00	9	\N	\N	\N	\N
2563	2	33	2026-09-10	16:00-17:00	1	VN	pincon	\N	2026-09-08 15:51:22.488723+00	97	\N	\N	\N	\N
2568	2	43	2026-09-10	14:00-15:00	1	VN	GUILLOU CAPTUR	\N	2026-09-08 15:53:47.784907+00	1782	\N	\N	\N	\N
2569	2	41	2026-09-10	10:00-11:00	\N	VO	warot	\N	2026-09-08 15:53:51.964911+00	97	\N	\N	\N	\N
2570	2	43	2026-09-13	14:00-15:00	1	VN	CLAVEL R5 TWINGO	\N	2026-09-08 15:53:56.214373+00	1782	\N	\N	\N	\N
2571	2	35	2026-09-14	17:00-18:00	1	VN	vergne	\N	2026-09-08 15:53:59.50261+00	97	\N	\N	\N	\N
2572	2	43	2026-09-10	09:00-10:00	1	VN	LEVIEUX MEGANE E TECH	\N	2026-09-08 15:54:00.214644+00	1782	\N	\N	\N	\N
2576	2	43	2026-09-14	10:00-11:00	1	VN	DEGUELLE MEGANE TECH	\N	2026-09-08 15:54:16.041604+00	1782	\N	\N	\N	\N
2565	2	60	2026-09-11	12:00-13:00	1	VN	nnn	\N	2026-09-08 15:52:02.304829+00	7	2026-09-08 15:54:19.865425+00	7	2026-09-08 15:54:19.612+00	7
2577	2	65	2026-09-11	11:00-12:00	2	VN	RUISE	\N	2026-09-08 15:54:20.475609+00	9	\N	\N	\N	\N
2573	2	67	2026-09-10	09:00-10:00	1	VN	LARAT / R5	\N	2026-09-08 15:54:03.278747+00	8	2026-09-08 15:54:27.729049+00	8	2026-09-08 15:54:27.747+00	8
2575	2	67	2026-09-10	09:00-10:00	1	VN	LARAT / R5	\N	2026-09-08 15:54:15.857473+00	8	2026-09-08 15:54:48.816405+00	8	2026-09-08 15:54:43.792+00	8
2578	2	47	2026-09-10	09:00-10:00	\N	VO	ROSETTE	\N	2026-09-08 15:55:10.505658+00	1782	\N	\N	\N	\N
2579	2	47	2026-09-13	16:00-17:00	\N	VO	MME NICOLAS	\N	2026-09-08 15:55:14.716468+00	1782	\N	\N	\N	\N
2580	2	80	2026-09-10	12:00-13:00	1	VN	DELTOR TW3	\N	2026-09-08 15:55:18.112077+00	1776	2026-09-08 15:55:44.352972+00	1776	\N	\N
2581	2	69	2026-09-12	10:00-11:00	\N	VO	FOLTIER	\N	2026-09-08 15:56:04.354519+00	7	\N	\N	\N	\N
2582	2	1886	2026-09-12	11:00-12:00	2	VN	MUNERATTO SANDERO	\N	2026-09-08 15:56:13.134355+00	1776	2026-09-08 15:56:18.864403+00	1776	2026-09-08 15:56:19.277+00	1776
2583	2	68	2026-09-11	11:00-12:00	\N	VO	SANNIER	\N	2026-09-08 15:56:21.415318+00	9	\N	\N	\N	\N
2584	2	1886	2026-09-12	14:00-15:00	2	VN	GUALANO BIGSTER	\N	2026-09-08 15:56:37.157677+00	1776	2026-09-08 15:56:46.783714+00	1776	2026-09-08 15:56:46.991+00	1776
2586	2	1886	2026-09-12	16:00-17:00	2	VN	GARRIGUES SPRING	\N	2026-09-08 15:56:48.803905+00	1776	\N	\N	\N	\N
2587	2	61	2026-09-14	09:00-10:00	\N	VO	POUGET	\N	2026-09-08 15:56:52.205709+00	9	\N	\N	\N	\N
2589	2	1886	2026-09-12	14:00-15:00	2	VN	GUALANO BIGSTER	\N	2026-09-08 15:57:29.066295+00	1776	2026-09-08 15:57:35.822482+00	1776	2026-09-08 15:57:36.019+00	1776
2588	2	1887	2026-09-10	08:00-09:00	\N	VO	test	\N	2026-09-08 15:57:16.575322+00	92	2026-09-08 15:57:48.971452+00	92	2026-09-08 15:57:48.343+00	92
2590	2	1886	2026-09-12	15:00-16:00	2	VN	GUALANO BIGSTER	\N	2026-09-08 15:58:15.376876+00	1776	\N	\N	\N	\N
2591	2	3	2026-09-10	09:00-10:00	1	VN	TEST	\N	2026-09-08 15:58:27.060015+00	4	2026-09-08 15:58:35.768301+00	4	2026-09-08 15:58:35.834+00	4
2592	2	1886	2026-09-12	11:00-12:00	2	VN	MUNERATO SANDERO	\N	2026-09-08 15:58:43.555328+00	1776	\N	\N	\N	\N
2593	2	82	2026-09-11	09:00-10:00	1	VN	VANOUCHY TW3	\N	2026-09-08 15:59:21.62647+00	1776	2026-09-08 15:59:24.564132+00	1776	2026-09-08 15:59:24.977+00	1776
2594	2	82	2026-09-11	09:00-10:00	1	VN	VANOUCHY	\N	2026-09-08 15:59:45.431642+00	1776	\N	\N	\N	\N
2595	2	82	2026-09-11	16:00-17:00	2	VN	CAMI SANDERO	\N	2026-09-08 16:00:13.369962+00	1776	\N	\N	\N	\N
2557	2	10	2026-09-12	10:00-11:00	1	VN	SAINT JOANNIS	\N	2026-09-08 15:49:04.494758+00	3	2026-09-08 16:00:15.768408+00	3	2026-09-08 16:00:15.688+00	3
2596	2	70	2026-09-13	15:00-16:00	\N	VO	RAMOINEAU / TWINGO	\N	2026-09-08 16:00:27.392087+00	8	\N	\N	\N	\N
2598	2	82	2026-09-12	14:00-15:00	2	VN	BOKKER SPRING	\N	2026-09-08 16:00:38.536407+00	1776	\N	\N	\N	\N
2599	2	70	2026-09-11	14:00-15:00	\N	VO	BOUAOULI / CLIO	\N	2026-09-08 16:00:52.710672+00	8	\N	\N	\N	\N
2600	2	23	2026-09-12	11:00-12:00	\N	VO	ANDRE	\N	2026-09-08 16:00:55.266267+00	3	\N	\N	\N	\N
2601	2	23	2026-09-13	15:00-16:00	\N	VO	DONNAT	\N	2026-09-08 16:01:39.283482+00	3	\N	\N	\N	\N
2602	2	67	2026-09-10	09:00-10:00	1	VN	LARA / R5	\N	2026-09-08 16:01:39.102537+00	8	\N	\N	\N	\N
2606	2	213	2026-09-11	09:00-10:00	\N	VO	lioret	\N	2026-09-08 16:01:56.306405+00	6	\N	\N	\N	\N
2603	2	213	2026-09-11	09:00-10:00	\N	VO	4	\N	2026-09-08 16:01:39.609206+00	6	2026-09-08 16:02:00.645761+00	6	2026-09-08 16:02:00.46+00	6
2604	2	213	2026-09-11	09:00-10:00	\N	VO	lioret	\N	2026-09-08 16:01:44.202733+00	6	2026-09-08 16:02:08.27005+00	6	2026-09-08 16:02:06.756+00	6
2607	1	53	2026-06-11	13:00-14:00	1	VN	GAGNAIRE	\N	2026-09-08 16:02:13.273281+00	9	\N	\N	\N	\N
2605	2	213	2026-09-11	09:00-10:00	\N	VO	lioret	\N	2026-09-08 16:01:54.137697+00	6	2026-09-08 16:02:18.373242+00	6	2026-09-08 16:02:16.729+00	6
2608	2	67	2026-09-10	18:00-19:00	1	VN	BAILLON / R5	\N	2026-09-08 16:02:18.580712+00	8	\N	\N	\N	\N
2609	2	9	2026-09-11	10:00-11:00	\N	VO	vedrine	\N	2026-09-08 16:02:49.296902+00	6	\N	\N	\N	\N
2610	2	67	2026-09-12	10:00-11:00	1	VN	GRIMA / CLIO	\N	2026-09-08 16:02:51.013762+00	8	\N	\N	\N	\N
2611	2	11	2026-09-11	13:00-14:00	1	VN	BULAND  ELECTRIQUE	\N	2026-09-08 16:03:04.315159+00	2	\N	\N	\N	\N
2612	2	67	2026-09-13	10:00-11:00	1	VN	ESTOC / TWINGO	\N	2026-09-08 16:03:27.288932+00	8	\N	\N	\N	\N
2613	2	18	2026-09-11	15:00-16:00	1	VN	BONNET JOGGER	\N	2026-09-08 16:03:28.318911+00	4	\N	\N	\N	\N
2614	2	11	2026-09-14	14:00-15:00	1	VN	BALLET	\N	2026-09-08 16:03:31.355634+00	2	\N	\N	\N	\N
2616	2	67	2026-09-13	11:00-12:00	1	VN	DUMAS / TWINGO	\N	2026-09-08 16:03:41.344163+00	8	\N	\N	\N	\N
2617	2	18	2026-09-12	11:00-12:00	1	VN	TEYSSIER CLIO	\N	2026-09-08 16:04:02.51077+00	4	\N	\N	\N	\N
2618	2	66	2026-09-13	13:00-14:00	1	VN	DESVAUX / TWINGO	\N	2026-09-08 16:04:07.337783+00	8	\N	\N	\N	\N
2619	2	2	2026-09-10	14:00-15:00	1	VN	BOURDUGE	\N	2026-09-08 16:04:09.919879+00	3	\N	\N	\N	\N
2620	2	66	2026-09-14	14:00-15:00	1	VN	ROUVEAU / R5	\N	2026-09-08 16:04:24.429125+00	8	\N	\N	\N	\N
2621	2	18	2026-09-12	15:00-16:00	1	VN	CLAVEROL  CAPTUR	\N	2026-09-08 16:04:25.449844+00	4	\N	\N	\N	\N
2622	2	66	2026-09-14	16:00-17:00	1	VN	VEISSEYRE / TWINGO	\N	2026-09-08 16:04:50.170991+00	8	\N	\N	\N	\N
2623	2	19	2026-09-12	16:00-17:00	1	VN	GAREIL R5	\N	2026-09-08 16:05:08.78938+00	2	\N	\N	\N	\N
2624	2	66	2026-09-13	10:00-11:00	1	VN	ROBERTS / R5	\N	2026-09-08 16:05:12.056382+00	8	\N	\N	\N	\N
2625	2	19	2026-09-12	17:00-18:00	1	VN	BASPERAS CLIO6	\N	2026-09-08 16:05:25.202208+00	2	\N	\N	\N	\N
2626	2	66	2026-09-12	14:00-15:00	2	VN	BRINON / DUSTER	\N	2026-09-08 16:05:26.880933+00	8	\N	\N	\N	\N
2628	1	65	2026-06-11	18:00-19:00	1	VN	CN CHAUFFAGE	\N	2026-09-08 16:05:39.996923+00	9	\N	\N	\N	\N
2585	2	44	2026-09-11	17:00-18:00	1	VN	JOLDAIN VO	\N	2026-09-08 15:56:47.21141+00	1782	2026-09-08 16:57:07.514513+00	1782	2026-09-08 16:57:06.988+00	1782
2615	2	2	2026-09-12	10:00-11:00	1	VN	MABRUT	\N	2026-09-08 16:03:41.254942+00	3	2026-09-08 16:58:24.193283+00	3	2026-09-08 16:58:23.915+00	3
2627	2	2	2026-09-13	08:00-09:00	1	VN	VILLENEUVE	\N	2026-09-08 16:05:27.089619+00	3	2026-09-08 16:05:34.389495+00	3	2026-09-08 16:05:34.241+00	3
2629	2	10	2026-09-13	08:00-09:00	1	VN	VILLENEUVE	\N	2026-09-08 16:05:51.259139+00	3	\N	\N	\N	\N
2630	2	66	2026-09-14	15:00-16:00	1	VN	LE CLEUYOUR / CLIO	\N	2026-09-08 16:05:54.584904+00	8	\N	\N	\N	\N
2631	2	19	2026-09-13	08:00-09:00	1	VN	MIGLIAWACCA SCENIC	\N	2026-09-08 16:05:58.871039+00	2	\N	\N	\N	\N
2632	2	10	2026-09-13	11:00-12:00	1	VN	VEGAS	\N	2026-09-08 16:06:04.138096+00	3	\N	\N	\N	\N
2636	2	19	2026-09-13	10:00-11:00	1	VN	BRUNEL R5	\N	2026-09-08 16:06:21.579866+00	2	\N	\N	\N	\N
2650	2	10	2026-09-13	15:00-16:00	1	VN	MEUNIER	\N	2026-09-08 16:06:34.013473+00	3	\N	\N	\N	\N
2651	2	59	2026-09-14	18:00-19:00	1	VN	ROUQUETTE / R5	\N	2026-09-08 16:06:36.074411+00	8	\N	\N	\N	\N
2656	2	211	2026-09-14	14:00-15:00	\N	VO	MASSEBOEUF KUGA	\N	2026-09-08 16:06:58.927517+00	2	\N	\N	\N	\N
2657	2	36	2026-09-10	11:00-12:00	1	VN	jouve	\N	2026-09-08 16:07:00.475098+00	97	\N	\N	\N	\N
2658	2	59	2026-09-12	15:00-16:00	1	VN	TUNA / SYMBIOZ	\N	2026-09-08 16:07:05.150563+00	8	\N	\N	\N	\N
2675	2	94	2026-09-14	16:00-17:00	1	VN	CRANTELLE	\N	2026-09-08 16:07:22.704801+00	1780	\N	\N	\N	\N
2678	2	36	2026-09-11	17:00-18:00	1	VN	jardino	\N	2026-09-08 16:07:40.05874+00	97	\N	\N	\N	\N
2680	2	92	2026-09-11	14:00-15:00	1	VN	ANESA	\N	2026-09-08 16:08:01.181056+00	1780	\N	\N	\N	\N
2690	2	49	2026-09-13	10:00-11:00	1	VN	M LAHMRY	\N	2026-09-08 16:09:46.282609+00	1783	\N	\N	\N	\N
2691	2	49	2026-09-14	09:00-10:00	1	VN	M MARC	\N	2026-09-08 16:09:53.785026+00	1783	\N	\N	\N	\N
2694	2	49	2026-09-10	16:00-17:00	1	VN	M PUISSANT	\N	2026-09-08 16:10:32.023526+00	1783	\N	\N	\N	\N
2633	2	59	2026-09-13	11:00-12:00	1	VN	AMAT / CLIO	\N	2026-09-08 16:06:18.475911+00	8	\N	\N	\N	\N
2659	2	2	2026-09-10	16:00-17:00	1	VN	SOULARD	\N	2026-09-08 16:07:06.541296+00	3	\N	\N	\N	\N
2660	2	36	2026-09-10	14:00-15:00	1	VN	escudero	\N	2026-09-08 16:07:10.412978+00	97	\N	\N	\N	\N
2671	2	94	2026-09-14	10:00-11:00	1	VN	COUDERC	\N	2026-09-08 16:07:19.089332+00	1780	\N	\N	\N	\N
2677	2	59	2026-09-10	17:00-18:00	1	VN	NURIT / R5	\N	2026-09-08 16:07:30.06259+00	8	\N	\N	\N	\N
2679	2	92	2026-09-12	15:00-16:00	2	VN	BENECH	\N	2026-09-08 16:07:54.38646+00	1780	\N	\N	\N	\N
2681	2	36	2026-09-12	10:00-11:00	1	VN	mariller	\N	2026-09-08 16:08:02.687819+00	97	\N	\N	\N	\N
2683	2	36	2026-09-13	11:00-12:00	1	VN	franchesco alu	\N	2026-09-08 16:08:28.053587+00	97	\N	\N	\N	\N
2376	2	882	2026-09-13	11:00-12:00	\N	VO	DARDELET / SCENIC VO	\N	2026-09-08 14:58:01.817019+00	8	2026-09-08 16:08:35.062315+00	8	2026-09-08 16:08:35.159+00	8
2685	2	50	2026-09-12	17:00-18:00	1	VN	M MARSON	\N	2026-09-08 16:08:48.779076+00	1783	\N	\N	\N	\N
2692	2	48	2026-09-12	10:00-11:00	1	VN	M MANRESA	\N	2026-09-08 16:10:19.557017+00	1783	\N	\N	\N	\N
2693	2	81	2026-09-14	16:00-17:00	1	VN	SIGNOVIA TW3	\N	2026-09-08 16:10:29.620519+00	1776	\N	\N	\N	\N
2695	2	50	2026-09-11	10:00-11:00	1	VN	M BRUNET	\N	2026-09-08 16:11:29.49365+00	1783	\N	\N	\N	\N
2696	2	50	2026-09-13	16:00-17:00	1	VN	M VORILHON	\N	2026-09-08 16:11:58.56974+00	1783	\N	\N	\N	\N
2697	2	50	2026-09-14	10:00-11:00	1	VN	M ARTHAUD	\N	2026-09-08 16:12:12.826236+00	1783	\N	\N	\N	\N
2682	2	36	2026-09-12	11:00-12:00	1	VN	bosse	\N	2026-09-08 16:08:07.20824+00	97	\N	\N	\N	\N
2686	2	882	2026-09-12	14:00-15:00	\N	VO	CHAPUIS / ZOE	\N	2026-09-08 16:08:52.824134+00	8	\N	\N	\N	\N
2687	2	50	2026-09-13	15:00-16:00	1	VN	M POUGHEON	\N	2026-09-08 16:09:03.649805+00	1783	\N	\N	\N	\N
2688	2	49	2026-09-13	09:00-10:00	1	VN	M IMBERT	\N	2026-09-08 16:09:13.145932+00	1783	\N	\N	\N	\N
2684	2	92	2026-09-13	10:00-11:00	1	VN	RAYNAL	\N	2026-09-08 16:08:28.077179+00	1780	\N	\N	\N	\N
2689	2	1887	2026-09-11	16:00-17:00	\N	VO	M PELLISON	\N	2026-09-08 16:09:32.503679+00	1783	\N	\N	\N	\N
2698	2	1887	2026-09-11	15:00-16:00	\N	VO	M BRUN	\N	2026-09-08 16:12:25.118485+00	1783	\N	\N	\N	\N
2699	2	33	2026-09-11	11:00-12:00	1	VN	morance	\N	2026-09-08 16:12:28.324973+00	97	\N	\N	\N	\N
2701	2	96	2026-09-10	10:00-11:00	2	VN	MANIC SPRING	\N	2026-09-08 16:12:47.391872+00	1775	\N	\N	\N	\N
2703	2	96	2026-09-10	14:00-15:00	1	VN	ALCOUFFE	\N	2026-09-08 16:13:06.566169+00	1775	\N	\N	\N	\N
2705	2	54	2026-09-13	10:00-11:00	1	VN	AGRAIN / RAFALE	\N	2026-09-08 16:13:14.777679+00	8	\N	\N	\N	\N
2706	2	96	2026-09-10	15:00-16:00	1	VN	MORIN	\N	2026-09-08 16:13:17.2816+00	1775	\N	\N	\N	\N
2709	1	68	2026-06-12	17:00-18:00	\N	VO	QUBELKO	\N	2026-09-08 16:13:35.275717+00	9	\N	\N	\N	\N
2710	2	96	2026-09-11	14:00-15:00	1	VN	BRICARD	\N	2026-09-08 16:13:37.875555+00	1775	\N	\N	\N	\N
2712	2	96	2026-09-12	09:00-10:00	1	VN	COPO CLIO	\N	2026-09-08 16:13:55.500623+00	1775	2026-09-08 16:13:58.50124+00	1775	2026-09-08 16:13:58.935+00	1775
2713	2	12	2026-09-13	14:00-15:00	1	VN	GORAND SANDERO	\N	2026-09-08 16:14:12.372391+00	4	2026-09-09 16:22:13.456452+00	92	2026-09-09 16:22:13.09+00	92
2702	2	12	2026-09-12	17:00-18:00	1	VN	DUFAURE  SANDERO	\N	2026-09-08 16:12:50.688215+00	4	2026-09-09 16:22:43.062296+00	92	2026-09-09 16:22:42.731+00	92
2714	2	23	2026-09-11	18:00-19:00	\N	VO	LOPES	\N	2026-09-08 16:14:32.365778+00	3	\N	\N	\N	\N
2718	2	97	2026-09-14	15:00-16:00	1	VN	BEN ABI	\N	2026-09-08 16:15:29.550754+00	1775	\N	\N	\N	\N
2719	2	97	2026-09-10	16:00-17:00	1	VN	COLONGES	\N	2026-09-08 16:15:51.128414+00	1775	\N	\N	\N	\N
2720	2	78	2026-09-11	11:00-12:00	1	VN	ASSIE	\N	2026-09-08 16:16:25.590171+00	1778	\N	\N	\N	\N
2721	2	84	2026-09-14	09:00-10:00	\N	VO	DERIEN CLIO	\N	2026-09-08 16:16:38.593538+00	1776	\N	\N	\N	\N
2722	2	1890	2026-09-10	17:00-18:00	\N	VO	BELMOKTAR - VO LOA	\N	2026-09-08 16:17:16.168749+00	1777	\N	\N	\N	\N
2723	2	1890	2026-09-11	10:00-11:00	\N	VO	VERGUES - SCENIC VN	\N	2026-09-08 16:17:26.679071+00	1777	\N	\N	\N	\N
2724	2	84	2026-09-12	12:00-13:00	\N	VO	GUIGNO CLIO	\N	2026-09-08 16:17:26.754107+00	1776	\N	\N	\N	\N
2725	2	84	2026-09-12	14:00-15:00	\N	VO	CANTAGREL	\N	2026-09-08 16:17:46.918532+00	1776	\N	\N	\N	\N
2726	2	84	2026-09-11	15:00-16:00	\N	VO	HANESS CAPTUR	\N	2026-09-08 16:18:04.931325+00	1776	\N	\N	\N	\N
2727	2	15	2026-09-13	10:00-11:00	1	VN	GUILLOT R5	\N	2026-09-08 16:18:12.016246+00	2	\N	\N	\N	\N
2728	2	69	2026-09-14	09:00-10:00	\N	VO	VERICENE	\N	2026-09-08 16:18:35.652645+00	7	\N	\N	\N	\N
2729	2	23	2026-09-13	10:00-11:00	\N	VO	BARD	\N	2026-09-08 16:20:05.35418+00	3	\N	\N	\N	\N
2730	2	99	2026-09-10	10:00-11:00	2	VN	BONNAFOUS	\N	2026-09-08 16:20:07.802817+00	1778	\N	\N	\N	\N
2731	2	99	2026-09-14	13:00-14:00	1	VN	FABRICE	\N	2026-09-08 16:20:18.873202+00	1778	\N	\N	\N	\N
2732	2	71	2026-09-12	16:00-17:00	1	VN	VIGUIE	\N	2026-09-08 16:20:47.455843+00	1778	\N	\N	\N	\N
2733	2	74	2026-09-12	17:00-18:00	2	VN	FESTA	\N	2026-09-08 16:21:05.287465+00	1778	\N	\N	\N	\N
2366	2	14	2026-09-10	11:00-12:00	1	VN	CHOLLER SANDERO	\N	2026-09-08 14:55:25.096519+00	5	2026-09-08 16:21:30.558875+00	5	2026-09-08 16:21:30.655+00	5
2735	2	27	2026-09-13	15:00-16:00	1	VN	SANDONA AUSTRAL	\N	2026-09-08 16:22:40.899925+00	5	\N	\N	\N	\N
2736	2	27	2026-09-10	18:00-19:00	1	VN	GUILLER DUSTER	\N	2026-09-08 16:22:59.315857+00	5	\N	\N	\N	\N
2737	2	34	2026-09-14	17:00-18:00	1	VN	meyrial lagrange	\N	2026-09-08 16:23:49.425773+00	97	\N	\N	\N	\N
2738	2	34	2026-09-12	17:00-18:00	1	VN	bletery	\N	2026-09-08 16:24:04.897176+00	97	\N	\N	\N	\N
2739	2	34	2026-09-12	15:00-16:00	1	VN	fradin	\N	2026-09-08 16:24:11.373373+00	97	\N	\N	\N	\N
2740	2	34	2026-09-11	11:00-12:00	1	VN	devillard	\N	2026-09-08 16:24:26.406531+00	97	\N	\N	\N	\N
2741	2	87	2026-09-12	16:00-17:00	2	VN	BOYER - KEX VU	\N	2026-09-08 16:25:01.154306+00	1777	\N	\N	\N	\N
2742	2	43	2026-09-13	15:00-16:00	1	VN	ROBERT TWINGO	\N	2026-09-08 16:25:29.117921+00	1782	\N	\N	\N	\N
2743	2	43	2026-09-10	10:00-11:00	1	VN	AUCLAIR KANGOO	\N	2026-09-08 16:26:10.125015+00	1782	\N	\N	\N	\N
2744	2	79	2026-09-12	14:00-15:00	1	VN	MIHALOCHI	\N	2026-09-08 16:26:27.664545+00	1776	\N	\N	\N	\N
2745	2	5	2026-09-12	09:00-10:00	1	VN	CARTIER SANDERO	\N	2026-09-08 16:26:58.424889+00	5	\N	\N	\N	\N
2746	2	5	2026-09-12	11:00-12:00	1	VN	MOSSANG DUSTER	\N	2026-09-08 16:27:11.607754+00	5	\N	\N	\N	\N
2747	2	5	2026-09-11	17:00-18:00	1	VN	TAILLANDIER TRAFFIC	\N	2026-09-08 16:27:29.479029+00	5	\N	\N	\N	\N
2748	2	62	2026-09-11	15:00-16:00	1	VN	BAYLOT	\N	2026-09-08 16:28:17.085816+00	7	\N	\N	\N	\N
2749	2	53	2026-09-10	13:00-14:00	1	VN	GAGNAIRE	\N	2026-09-08 16:28:22.089406+00	9	\N	\N	\N	\N
2750	2	16	2026-09-12	16:00-17:00	1	VN	LACOTE	\N	2026-09-08 16:28:39.53964+00	3	\N	\N	\N	\N
2751	2	53	2026-09-10	14:00-15:00	1	VN	LABROSSE	\N	2026-09-08 16:28:47.363423+00	9	\N	\N	\N	\N
2574	2	53	2026-09-11	14:00-15:00	2	VN	.	\N	2026-09-08 15:54:03.847471+00	9	2026-09-08 16:28:52.291906+00	9	2026-09-08 16:28:51.905+00	9
2752	2	16	2026-09-11	16:00-17:00	1	VN	SCHULTZ	\N	2026-09-08 16:28:54.296507+00	3	\N	\N	\N	\N
2753	2	16	2026-09-14	10:00-11:00	1	VN	BLE	\N	2026-09-08 16:29:07.190104+00	3	\N	\N	\N	\N
2754	2	60	2026-09-14	16:00-17:00	2	VN	NACIVERA	\N	2026-09-08 16:29:16.372599+00	7	\N	\N	\N	\N
2755	2	55	2026-09-10	16:00-17:00	1	VN	BARBIERI	\N	2026-09-08 16:30:07.869077+00	9	\N	\N	\N	\N
2756	2	48	2026-09-12	15:00-16:00	1	VN	M BOURRE	\N	2026-09-08 16:30:35.186084+00	1783	\N	\N	\N	\N
2757	2	65	2026-09-10	18:00-19:00	1	VN	CN CHAUFFAGE	\N	2026-09-08 16:30:50.597478+00	9	\N	\N	\N	\N
2758	2	65	2026-09-12	09:00-10:00	1	VN	BERTRAND	\N	2026-09-08 16:31:11.58706+00	9	\N	\N	\N	\N
2759	2	18	2026-09-10	15:00-16:00	1	VN	COURAEL  R5	\N	2026-09-08 16:31:11.636194+00	4	\N	\N	\N	\N
2760	2	66	2026-09-10	15:00-16:00	2	VN	THIEBAULD / SANDERO	\N	2026-09-08 16:31:32.569301+00	8	\N	\N	\N	\N
2761	2	54	2026-09-13	14:00-15:00	1	VN	MARSOLAT /	\N	2026-09-08 16:32:19.5321+00	8	\N	\N	\N	\N
2704	2	12	2026-09-13	09:00-10:00	1	VN	MOUGIN SANDERO	\N	2026-09-08 16:13:12.935555+00	4	2026-09-09 16:21:09.402951+00	92	2026-09-09 16:21:09.045+00	92
2707	2	12	2026-09-13	10:00-11:00	1	VN	ROUX  DUSTER	\N	2026-09-08 16:13:19.640703+00	4	2026-09-09 16:21:25.275772+00	92	2026-09-09 16:21:24.934+00	92
2716	2	12	2026-09-14	10:00-11:00	1	VN	BEYNEIX  SPRING	\N	2026-09-08 16:14:57.736035+00	4	2026-09-09 16:21:28.164214+00	92	2026-09-09 16:21:27.779+00	92
2708	2	12	2026-09-13	11:00-12:00	1	VN	REVENU SANDERO	\N	2026-09-08 16:13:27.744461+00	4	2026-09-09 16:21:41.805544+00	92	2026-09-09 16:21:41.454+00	92
2717	2	12	2026-09-14	11:00-12:00	1	VN	TRONCHE  DUSTER	\N	2026-09-08 16:15:09.276671+00	4	2026-09-09 16:21:44.597012+00	92	2026-09-09 16:21:44.254+00	92
2734	2	14	2026-09-14	14:00-15:00	1	VN	GIRONDE SANDERO	\N	2026-09-08 16:21:49.46526+00	5	2026-09-09 16:23:51.955219+00	92	2026-09-09 16:23:51.613+00	92
2762	2	31	2026-09-12	10:00-11:00	2	VN	lebars	\N	2026-09-08 16:32:44.263008+00	97	\N	\N	\N	\N
2765	2	70	2026-09-10	15:00-16:00	\N	VO	MARVILLON / KADJAR	\N	2026-09-08 16:34:02.226842+00	8	\N	\N	\N	\N
2763	2	31	2026-09-10	15:00-16:00	2	VN	laurent	\N	2026-09-08 16:32:59.07676+00	97	\N	\N	\N	\N
2764	2	68	2026-09-11	17:00-18:00	\N	VO	KUBELKO	\N	2026-09-08 16:33:10.662634+00	9	\N	\N	\N	\N
2767	2	66	2026-09-12	16:00-17:00	1	VN	PIRSCH / RAFALE	\N	2026-09-08 16:35:41.834023+00	8	\N	\N	\N	\N
2769	2	47	2026-09-10	14:00-15:00	\N	VO	MORGADOT SPRING MP	\N	2026-09-08 16:36:23.300575+00	1782	\N	\N	\N	\N
2766	2	44	2026-09-10	13:00-14:00	1	VN	MORGADOT SPRING VO	\N	2026-09-08 16:35:40.443379+00	1782	2026-09-08 16:36:34.619028+00	1782	2026-09-08 16:36:34.088+00	1782
2770	2	96	2026-09-14	16:00-17:00	1	VN	MOULY AUSTRAL	\N	2026-09-08 16:36:41.287504+00	1775	\N	\N	\N	\N
2768	2	44	2026-09-10	17:00-18:00	2	VN	ABSELAM SANDERO VO	\N	2026-09-08 16:36:04.559711+00	1782	2026-09-08 16:36:50.217918+00	1782	2026-09-08 16:36:49.722+00	1782
2772	2	27	2026-09-12	15:00-16:00	1	VN	PLANE DUSTER	\N	2026-09-08 16:37:09.907875+00	5	\N	\N	\N	\N
2773	2	35	2026-09-11	11:00-12:00	1	VN	dayriat	\N	2026-09-08 16:37:15.219753+00	97	\N	\N	\N	\N
2771	2	47	2026-09-10	17:00-18:00	\N	VO	ABSELAM SANDERO VO MP	\N	2026-09-08 16:37:08.580607+00	1782	2026-09-08 16:37:16.890111+00	1782	\N	\N
2774	2	53	2026-09-13	10:00-11:00	2	VN	DUMONT	\N	2026-09-08 16:38:04.338727+00	9	\N	\N	\N	\N
2777	2	15	2026-09-10	14:00-15:00	2	VN	PIGOT SANDERO	\N	2026-09-08 16:43:13.139935+00	2	\N	\N	\N	\N
2776	2	15	2026-09-10	14:00-15:00	1	VN	PIGOT	\N	2026-09-08 16:43:06.036817+00	2	2026-09-08 16:43:17.094892+00	2	2026-09-08 16:43:17.91+00	2
2778	2	57	2026-09-13	09:00-10:00	\N	VO	SOEIRO	\N	2026-09-08 16:43:58.005138+00	7	\N	\N	\N	\N
2779	2	75	2026-09-10	18:00-19:00	2	VN	CABRADJOUZ	\N	2026-09-08 16:44:53.736324+00	1778	\N	\N	\N	\N
2780	2	42	2026-09-11	17:00-18:00	2	VN	MANSARD SANDERO	\N	2026-09-08 16:45:08.887979+00	1782	2026-09-08 16:45:18.989389+00	1782	\N	\N
2781	2	73	2026-09-10	17:00-18:00	1	VN	PELISSIER	\N	2026-09-08 16:47:58.489375+00	1778	\N	\N	\N	\N
2782	2	40	2026-09-10	15:00-16:00	\N	VO	dedey	\N	2026-09-08 16:48:38.34605+00	97	\N	\N	\N	\N
2783	2	40	2026-09-11	11:00-12:00	\N	VO	kibaki	\N	2026-09-08 16:48:58.563561+00	97	\N	\N	\N	\N
2784	2	32	2026-09-13	16:00-17:00	2	VN	fournier	\N	2026-09-08 16:49:18.493018+00	97	\N	\N	\N	\N
2785	2	67	2026-09-11	10:00-11:00	1	VN	TOURNEVIS / R5	\N	2026-09-08 16:49:59.078946+00	8	\N	\N	\N	\N
2786	2	41	2026-09-13	15:00-16:00	\N	VO	brigand	\N	2026-09-08 16:51:58.630172+00	97	\N	\N	\N	\N
2787	2	62	2026-09-11	14:00-15:00	1	VN	BUDINEK	\N	2026-09-08 16:52:12.023798+00	7	\N	\N	\N	\N
2788	2	62	2026-09-14	16:00-17:00	2	VN	CROCOMBETTE	\N	2026-09-08 16:53:32.346943+00	7	\N	\N	\N	\N
2789	2	65	2026-09-11	18:00-19:00	1	VN	LAFITE	\N	2026-09-08 16:54:06.674375+00	9	\N	\N	\N	\N
2775	2	65	2026-09-14	16:00-17:00	1	VN	LAFITE	\N	2026-09-08 16:41:26.689619+00	9	2026-09-08 16:54:09.636734+00	9	2026-09-08 16:54:09.178+00	9
2790	2	69	2026-09-13	11:00-12:00	\N	VO	PARISSEAUX	\N	2026-09-08 16:54:16.06864+00	7	\N	\N	\N	\N
2792	2	23	2026-09-13	11:00-12:00	\N	VO	TIVEYRAT	\N	2026-09-08 16:55:03.174126+00	3	\N	\N	\N	\N
2793	2	44	2026-09-10	11:00-12:00	1	VN	FISCHER RENAULTMER	\N	2026-09-08 16:56:09.429361+00	1782	2026-09-08 16:56:23.659903+00	1782	\N	\N
2794	2	44	2026-09-10	17:00-18:00	1	VN	DUPERET R5 CHAUVIN	\N	2026-09-08 16:56:48.148529+00	1782	\N	\N	\N	\N
2795	2	47	2026-09-11	17:00-18:00	\N	VO	JOLDAIN MP	\N	2026-09-08 16:57:19.375849+00	1782	\N	\N	\N	\N
2796	2	215	2026-09-14	11:00-12:00	\N	VO	GRANIER	\N	2026-09-08 16:57:46.230382+00	3	\N	\N	\N	\N
2797	2	2	2026-09-11	15:00-16:00	1	VN	CLAUSS	\N	2026-09-08 16:58:07.761731+00	3	\N	\N	\N	\N
2798	2	2	2026-09-12	09:00-10:00	1	VN	DUGAT	\N	2026-09-08 16:58:18.554771+00	3	\N	\N	\N	\N
2799	2	2	2026-09-13	10:00-11:00	1	VN	MABRUT	\N	2026-09-08 16:58:38.467855+00	3	\N	\N	\N	\N
2800	2	2	2026-09-12	11:00-12:00	1	VN	ARNAUD	\N	2026-09-08 16:58:46.047841+00	3	\N	\N	\N	\N
2801	2	2	2026-09-12	15:00-16:00	1	VN	SERRE	\N	2026-09-08 16:59:01.493903+00	3	\N	\N	\N	\N
2802	2	2	2026-09-13	15:00-16:00	1	VN	MESURE	\N	2026-09-08 16:59:05.887043+00	3	\N	\N	\N	\N
2803	2	17	2026-09-13	16:00-17:00	1	VN	BONGEAN CLIO	\N	2026-09-08 17:00:09.878058+00	5	\N	\N	\N	\N
2804	2	17	2026-09-14	09:00-10:00	1	VN	RIGOULET R5	\N	2026-09-08 17:00:38.75501+00	5	\N	\N	\N	\N
2805	2	17	2026-09-14	14:00-15:00	1	VN	VAYSSAD R5	\N	2026-09-08 17:01:00.778591+00	5	\N	\N	\N	\N
2806	2	17	2026-09-14	15:00-16:00	1	VN	GAUTHIER TWINGO	\N	2026-09-08 17:01:19.957837+00	5	\N	\N	\N	\N
2807	2	65	2026-09-11	12:00-13:00	1	VN	MUTZENBERG	\N	2026-09-08 17:01:28.188519+00	9	\N	\N	\N	\N
2808	2	49	2026-09-12	14:00-15:00	1	VN	M PACHE	\N	2026-09-08 17:01:54.20169+00	1783	\N	\N	\N	\N
2809	2	68	2026-09-13	16:00-17:00	\N	VO	GIROUX	\N	2026-09-08 17:02:20.233985+00	9	\N	\N	\N	\N
2810	2	67	2026-09-12	15:00-16:00	1	VN	DUCHET / R5	\N	2026-09-08 17:03:03.817497+00	8	\N	\N	\N	\N
2791	2	69	2026-09-10	11:00-12:00	\N	VO	²	\N	2026-09-08 16:54:32.435874+00	7	2026-09-08 17:04:40.950755+00	7	\N	\N
2811	2	57	2026-09-13	14:00-15:00	\N	VO	POUZOL	\N	2026-09-08 17:04:54.044046+00	7	\N	\N	\N	\N
2812	2	213	2026-09-12	08:00-09:00	\N	VO	Dalet	\N	2026-09-08 17:05:06.734654+00	6	\N	\N	\N	\N
2813	2	43	2026-09-11	11:00-12:00	1	VN	BECQUE AUSTRAL	\N	2026-09-08 17:05:17.267473+00	1782	\N	\N	\N	\N
2814	2	213	2026-09-11	16:00-17:00	\N	VO	Chanony	\N	2026-09-08 17:05:18.07161+00	6	\N	\N	\N	\N
2815	2	213	2026-09-12	10:00-11:00	\N	VO	Guiot	\N	2026-09-08 17:05:24.700377+00	6	\N	\N	\N	\N
2816	2	23	2026-09-13	17:00-18:00	\N	VO	SANTINI	\N	2026-09-08 17:05:49.119174+00	3	\N	\N	\N	\N
2817	2	69	2026-09-10	15:00-16:00	\N	VO	DOME	\N	2026-09-08 17:06:01.91514+00	7	\N	\N	\N	\N
2818	2	23	2026-09-13	18:00-19:00	\N	VO	GUILLY	\N	2026-09-08 17:06:02.728499+00	3	\N	\N	\N	\N
2819	2	62	2026-09-14	18:00-19:00	1	VN	CROUZET	\N	2026-09-08 17:06:26.737573+00	7	\N	\N	\N	\N
2820	2	60	2026-09-13	15:00-16:00	1	VN	CHAUDESAIGUES	\N	2026-09-08 17:07:24.909532+00	7	\N	\N	\N	\N
2821	2	16	2026-09-11	15:00-16:00	1	VN	FOURNERON	\N	2026-09-08 17:07:38.612562+00	3	\N	\N	\N	\N
2822	2	10	2026-09-13	09:00-10:00	1	VN	PERNET	\N	2026-09-08 17:07:50.236811+00	3	\N	\N	\N	\N
2823	2	34	2026-09-11	10:00-11:00	1	VN	chatelier	\N	2026-09-08 17:08:02.755154+00	97	\N	\N	\N	\N
2824	2	19	2026-09-13	16:00-17:00	1	VN	BARRIER CAPTUR	\N	2026-09-08 17:09:20.141277+00	2	\N	\N	\N	\N
2825	2	19	2026-09-14	09:00-10:00	1	VN	AIMOT SYMBIOZ	\N	2026-09-08 17:09:47.069507+00	2	\N	\N	\N	\N
2826	2	882	2026-09-12	10:00-11:00	\N	VO	VALENTIN	\N	2026-09-08 17:10:30.271799+00	8	\N	\N	\N	\N
2827	2	60	2026-09-13	09:00-10:00	1	VN	DE-JESUS ANDRAD ECT	\N	2026-09-08 17:12:53.290435+00	7	\N	\N	\N	\N
2828	2	9	2026-09-10	09:00-10:00	\N	VO	sagne	\N	2026-09-08 17:14:11.809207+00	6	\N	\N	\N	\N
2829	2	26	2026-09-11	17:00-18:00	1	VN	FOURCHON	\N	2026-09-08 17:14:43.62713+00	3	\N	\N	\N	\N
2830	2	26	2026-09-12	18:00-19:00	1	VN	SONET	\N	2026-09-08 17:14:57.428081+00	3	\N	\N	\N	\N
2836	2	19	2026-09-14	15:00-16:00	1	VN	BESQUENT TWINGO	\N	2026-09-08 17:17:23.695187+00	2	\N	\N	\N	\N
2831	2	26	2026-09-13	17:00-18:00	1	VN	COUDERC	\N	2026-09-08 17:15:09.635398+00	3	2026-09-08 17:15:25.96289+00	3	\N	\N
2832	2	66	2026-09-11	15:00-16:00	1	VN	BAYGUES / R5	\N	2026-09-08 17:15:32.924565+00	8	\N	\N	\N	\N
2833	2	66	2026-09-12	15:00-16:00	1	VN	VIZCAILO / TWINGO	\N	2026-09-08 17:15:50.213468+00	8	\N	\N	\N	\N
2834	2	67	2026-09-11	11:00-12:00	2	VN	LAUNAY / SANDERO	\N	2026-09-08 17:16:16.074216+00	8	\N	\N	\N	\N
2835	2	65	2026-09-10	17:00-18:00	1	VN	LAURENT	\N	2026-09-08 17:17:21.94802+00	9	\N	\N	\N	\N
2837	2	59	2026-09-12	17:00-18:00	1	VN	JOULIE / KANGOO ELEC	\N	2026-09-08 17:18:37.79584+00	8	\N	\N	\N	\N
2838	2	67	2026-09-10	15:00-16:00	1	VN	COUDOUEL / CAPTUR	\N	2026-09-08 17:19:16.402183+00	8	\N	\N	\N	\N
2839	2	882	2026-09-12	17:00-18:00	\N	VO	PICHELLE / ELEC	\N	2026-09-08 17:21:22.981996+00	8	\N	\N	\N	\N
2840	2	54	2026-09-13	11:00-12:00	1	VN	AURELLE / R4 INFO VE	\N	2026-09-08 17:27:05.16565+00	8	\N	\N	\N	\N
2841	2	55	2026-09-11	16:00-17:00	1	VN	SOUIGNON	\N	2026-09-08 17:31:25.269865+00	9	\N	\N	\N	\N
2597	2	10	2026-09-10	09:00-10:00	1	VN	PLANTELIGNE	\N	2026-09-08 16:00:29.351311+00	3	2026-09-09 06:38:59.918382+00	5	2026-09-09 06:39:00.622+00	5
2842	2	99	2026-09-14	17:00-18:00	1	VN	BUREL	\N	2026-09-09 08:16:18.21286+00	1778	\N	\N	\N	\N
2843	2	96	2026-09-12	10:00-11:00	1	VN	LARGE R5	\N	2026-09-09 08:41:47.368407+00	1775	\N	\N	\N	\N
2844	2	96	2026-09-12	14:00-15:00	1	VN	FAIVRE	\N	2026-09-09 08:41:59.405192+00	1775	\N	\N	\N	\N
2845	2	96	2026-09-10	10:00-11:00	1	VN	BENOIST R5	\N	2026-09-09 08:42:17.575836+00	1775	\N	\N	\N	\N
2846	2	75	2026-09-11	15:00-16:00	2	VN	FERNANDEZ	\N	2026-09-09 08:52:34.431499+00	1778	\N	\N	\N	\N
2847	2	75	2026-09-12	09:00-10:00	1	VN	LAJOIE	\N	2026-09-09 08:54:55.605013+00	1778	\N	\N	\N	\N
2848	2	50	2026-09-11	11:00-12:00	1	VN	MME BARGEON	\N	2026-09-09 12:53:10.564561+00	1783	\N	\N	\N	\N
2700	2	12	2026-09-12	08:00-09:00	1	VN	VESCO  SANDERO	\N	2026-09-08 16:12:29.689546+00	4	2026-09-09 16:20:57.629279+00	92	2026-09-09 16:20:57.213+00	92
2849	2	12	2026-09-12	08:00-09:00	2	VN	VESCO  SANDERO	\N	2026-09-09 16:20:59.294028+00	92	\N	\N	\N	\N
1756	2	12	2026-09-10	09:00-10:00	1	VN	BOUTINON  DUSTER	\N	2026-09-08 09:36:53.420101+00	4	2026-09-09 16:21:01.873194+00	92	2026-09-09 16:21:01.525+00	92
2850	2	12	2026-09-10	09:00-10:00	2	VN	BOUTINON  DUSTER	\N	2026-09-09 16:21:02.768573+00	92	\N	\N	\N	\N
2851	2	12	2026-09-11	09:00-10:00	2	VN	MIOCHE SPRING	\N	2026-09-09 16:21:05.370757+00	92	\N	\N	\N	\N
2245	2	12	2026-09-12	09:00-10:00	1	VN	BOULANGER DUSTER	\N	2026-09-08 14:28:10.490571+00	4	2026-09-09 16:21:06.926657+00	92	2026-09-09 16:21:06.498+00	92
2852	2	12	2026-09-12	09:00-10:00	2	VN	BOULANGER DUSTER	\N	2026-09-09 16:21:07.869236+00	92	\N	\N	\N	\N
2853	2	12	2026-09-13	09:00-10:00	2	VN	MOUGIN SANDERO	\N	2026-09-09 16:21:10.373178+00	92	\N	\N	\N	\N
2715	2	12	2026-09-14	09:00-10:00	1	VN	BARDOTTI JOGGER	\N	2026-09-08 16:14:42.12816+00	4	2026-09-09 16:21:12.349574+00	92	2026-09-09 16:21:11.979+00	92
2854	2	12	2026-09-14	09:00-10:00	2	VN	BARDOTTI JOGGER	\N	2026-09-09 16:21:13.282609+00	92	\N	\N	\N	\N
2855	2	12	2026-09-10	10:00-11:00	2	VN	CHEVALLET DUSTER	\N	2026-09-09 16:21:17.737664+00	92	\N	\N	\N	\N
2856	2	12	2026-09-11	10:00-11:00	2	VN	DA SILVA SPRING	\N	2026-09-09 16:21:20.328143+00	92	\N	\N	\N	\N
2133	2	12	2026-09-12	10:00-11:00	1	VN	GONINET SANDERO	\N	2026-09-08 10:40:30.277514+00	4	2026-09-09 16:21:21.888182+00	92	2026-09-09 16:21:21.517+00	92
2857	2	12	2026-09-12	10:00-11:00	2	VN	GONINET SANDERO	\N	2026-09-09 16:21:22.897798+00	92	\N	\N	\N	\N
2858	2	12	2026-09-13	10:00-11:00	2	VN	ROUX  DUSTER	\N	2026-09-09 16:21:26.427173+00	92	\N	\N	\N	\N
2859	2	12	2026-09-14	10:00-11:00	2	VN	BEYNEIX  SPRING	\N	2026-09-09 16:21:29.653115+00	92	\N	\N	\N	\N
2860	2	12	2026-09-10	11:00-12:00	2	VN	ALEDO DUSTER	\N	2026-09-09 16:21:32.426926+00	92	\N	\N	\N	\N
2861	2	12	2026-09-11	11:00-12:00	2	VN	GAILLARD SANDERO	\N	2026-09-09 16:21:37.101245+00	92	\N	\N	\N	\N
2862	2	12	2026-09-12	11:00-12:00	2	VN	BOGTOB BIGSTER	\N	2026-09-09 16:21:40.071412+00	92	\N	\N	\N	\N
2863	2	12	2026-09-13	11:00-12:00	2	VN	REVENU SANDERO	\N	2026-09-09 16:21:42.7431+00	92	\N	\N	\N	\N
2864	2	12	2026-09-14	11:00-12:00	2	VN	TRONCHE  DUSTER	\N	2026-09-09 16:21:46.258116+00	92	\N	\N	\N	\N
2865	2	12	2026-09-10	13:00-14:00	2	VN	JORDA DUSTER	\N	2026-09-09 16:21:53.412385+00	92	\N	\N	\N	\N
2866	2	12	2026-09-12	13:00-14:00	2	VN	NAULT SANDERO	\N	2026-09-09 16:21:57.132111+00	92	\N	\N	\N	\N
2711	2	12	2026-09-13	13:00-14:00	1	VN	DAMAS SPRING	\N	2026-09-08 16:13:47.110165+00	4	2026-09-09 16:21:58.718084+00	92	2026-09-09 16:21:58.376+00	92
2867	2	12	2026-09-13	13:00-14:00	2	VN	DAMAS SPRING	\N	2026-09-09 16:22:00.820714+00	92	\N	\N	\N	\N
2868	2	12	2026-09-10	14:00-15:00	2	VN	TRONCHERE JOGGER	\N	2026-09-09 16:22:03.437757+00	92	\N	\N	\N	\N
2869	2	12	2026-09-11	14:00-15:00	2	VN	FLORY CLIO	\N	2026-09-09 16:22:09.999375+00	92	\N	\N	\N	\N
2870	2	12	2026-09-13	14:00-15:00	2	VN	GORAND SANDERO	\N	2026-09-09 16:22:15.497563+00	92	\N	\N	\N	\N
2871	2	12	2026-09-11	15:00-16:00	2	VN	ROBERT SANDERO	\N	2026-09-09 16:22:20.725785+00	92	\N	\N	\N	\N
2109	2	12	2026-09-10	16:00-17:00	1	VN	ENJARY SANDERO	\N	2026-09-08 10:36:21.779102+00	4	2026-09-09 16:22:23.207107+00	92	2026-09-09 16:22:22.852+00	92
2872	2	12	2026-09-10	16:00-17:00	2	VN	ENJARY SANDERO	\N	2026-09-09 16:22:30.145197+00	92	\N	\N	\N	\N
2873	2	12	2026-09-10	17:00-18:00	2	VN	CAILLE SANDERO	\N	2026-09-09 16:22:34.093757+00	92	\N	\N	\N	\N
2874	2	12	2026-09-10	18:00-19:00	2	VN	AUBERT SANDERO	\N	2026-09-09 16:22:37.759906+00	92	\N	\N	\N	\N
2875	2	12	2026-09-11	17:00-18:00	2	VN	LAFEUILLE SANDERO	\N	2026-09-09 16:22:41.221937+00	92	\N	\N	\N	\N
2876	2	12	2026-09-12	17:00-18:00	2	VN	DUFAURE  SANDERO	\N	2026-09-09 16:22:44.540781+00	92	\N	\N	\N	\N
2877	2	12	2026-09-12	16:00-17:00	2	VN	FERNANDES SANDERO	\N	2026-09-09 16:22:47.511251+00	92	\N	\N	\N	\N
2878	2	14	2026-09-10	09:00-10:00	2	VN	SCATOLIN DUSTER	\N	2026-09-09 16:23:15.535508+00	92	\N	\N	\N	\N
2450	2	14	2026-09-12	09:00-10:00	1	VN	GURRIER CLIO	\N	2026-09-08 15:16:38.691982+00	5	2026-09-09 16:23:18.062939+00	92	2026-09-09 16:23:17.711+00	92
2879	2	14	2026-09-12	09:00-10:00	2	VN	GURRIER CLIO	\N	2026-09-09 16:23:18.954593+00	92	\N	\N	\N	\N
2880	2	14	2026-09-13	09:00-10:00	2	VN	JIMENEZ DUSTER	\N	2026-09-09 16:23:21.939106+00	92	\N	\N	\N	\N
2881	2	14	2026-09-14	09:00-10:00	2	VN	GAMBIER SANDERO	\N	2026-09-09 16:23:25.447777+00	92	\N	\N	\N	\N
2455	2	14	2026-09-12	10:00-11:00	1	VN	PAILLOU SANDERO	\N	2026-09-08 15:17:15.703954+00	5	2026-09-09 16:23:31.195828+00	92	2026-09-09 16:23:30.86+00	92
2882	2	14	2026-09-12	10:00-11:00	2	VN	PAILLOU SANDERO	\N	2026-09-09 16:23:32.311072+00	92	\N	\N	\N	\N
2883	2	14	2026-09-13	10:00-11:00	2	VN	GUILLO SANDERO	\N	2026-09-09 16:23:36.273446+00	92	\N	\N	\N	\N
2884	2	14	2026-09-11	11:00-12:00	2	VN	MARTIN SANDERO	\N	2026-09-09 16:23:41.699776+00	92	\N	\N	\N	\N
2885	2	14	2026-09-10	14:00-15:00	2	VN	DIOUGAN DUSTER	\N	2026-09-09 16:23:47.381989+00	92	\N	\N	\N	\N
2886	2	14	2026-09-11	14:00-15:00	2	VN	SAURIN DUSTER	\N	2026-09-09 16:23:50.309961+00	92	\N	\N	\N	\N
2894	2	6	2026-09-10	10:00-11:00	2	VN	MR SAGNE SANDERO	\N	2026-09-09 16:25:09.792088+00	92	\N	\N	\N	\N
2887	2	14	2026-09-14	14:00-15:00	2	VN	GIRONDE SANDERO	\N	2026-09-09 16:23:53.379051+00	92	\N	\N	\N	\N
2888	2	14	2026-09-10	16:00-17:00	2	VN	BESSERVE TWINGO	\N	2026-09-09 16:23:56.206627+00	92	\N	\N	\N	\N
2890	2	14	2026-09-11	17:00-18:00	2	VN	DELPRAT JOGGER	\N	2026-09-09 16:24:01.320254+00	92	\N	\N	\N	\N
2892	2	14	2026-09-14	17:00-18:00	2	VN	CHANTENAIS SANDERO	\N	2026-09-09 16:24:07.137094+00	92	\N	\N	\N	\N
2895	2	6	2026-09-11	10:00-11:00	2	VN	CHOMILLER DUSTER	\N	2026-09-09 16:25:13.64093+00	92	\N	\N	\N	\N
2889	2	14	2026-09-10	17:00-18:00	2	VN	MEGRESIF BIGSTER	\N	2026-09-09 16:23:58.630413+00	92	\N	\N	\N	\N
2891	2	14	2026-09-13	17:00-18:00	2	VN	DUCHE DUSTER	\N	2026-09-09 16:24:04.773073+00	92	\N	\N	\N	\N
2893	2	6	2026-09-10	08:00-09:00	2	VN	MR FOLLEAS SANDERO	\N	2026-09-09 16:25:05.660207+00	92	\N	\N	\N	\N
1784	2	6	2026-09-10	10:00-11:00	1	VN	MR SAGNE SANDERO	\N	2026-09-08 09:43:16.656852+00	5	2026-09-09 16:25:08.339087+00	92	2026-09-09 16:25:07.979+00	92
2896	2	6	2026-09-10	15:00-16:00	2	VN	DUTUEL SANDERO	\N	2026-09-09 16:25:28.459936+00	92	\N	\N	\N	\N
2897	2	6	2026-09-10	17:00-18:00	2	VN	KALINSKI DUSTER	\N	2026-09-09 16:25:33.839863+00	92	\N	\N	\N	\N
2340	2	6	2026-09-11	18:00-19:00	1	VN	CAMPOS JOGGER	\N	2026-09-08 14:51:45.919978+00	5	2026-09-09 16:28:46.963762+00	92	2026-09-09 16:28:46.629+00	92
2898	2	6	2026-09-11	18:00-19:00	2	VN	CAMPOS JOGGER	\N	2026-09-09 16:28:51.544247+00	92	\N	\N	\N	\N
2899	2	6	2026-09-12	10:00-11:00	2	VN	FOURNER SPRING	\N	2026-09-09 16:28:55.794369+00	92	\N	\N	\N	\N
2900	2	6	2026-09-13	10:00-11:00	2	VN	JEANJEAN SANDERO	\N	2026-09-09 16:29:02.335379+00	92	\N	\N	\N	\N
2901	2	6	2026-09-14	09:00-10:00	2	VN	BONABRI SPRING	\N	2026-09-09 16:29:07.826536+00	92	\N	\N	\N	\N
2360	2	6	2026-09-14	14:00-15:00	1	VN	ROYER SANDERO	\N	2026-09-08 14:54:14.608313+00	5	2026-09-09 16:29:13.404883+00	92	2026-09-09 16:29:12.999+00	92
2902	2	6	2026-09-14	14:00-15:00	2	VN	ROYER SANDERO	\N	2026-09-09 16:29:18.179494+00	92	\N	\N	\N	\N
2903	2	6	2026-09-14	15:00-16:00	2	VN	EVENO SANDERO	\N	2026-09-09 16:29:21.106521+00	92	\N	\N	\N	\N
2904	2	6	2026-09-14	16:00-17:00	2	VN	ASTAIX AUSTRAL	\N	2026-09-09 16:29:24.306761+00	92	\N	\N	\N	\N
2905	2	49	2026-09-14	10:00-11:00	1	VN	M MAROLLE	\N	2026-09-10 06:46:15.401472+00	1783	\N	\N	\N	\N
2906	2	49	2026-09-10	18:00-19:00	1	VN	M BARGEON	\N	2026-09-10 06:46:40.350185+00	1783	\N	\N	\N	\N
2150	2	17	2026-09-11	11:00-12:00	1	VN	TOURNADRE TWINGO	\N	2026-09-08 10:47:37.136126+00	5	2026-09-10 15:11:29.731671+00	92	2026-09-10 15:11:29.095+00	92
2907	2	17	2026-09-10	09:00-10:00	1	VN	MR COURET R5	\N	2026-09-10 15:24:43.15346+00	5	\N	\N	\N	\N
2908	2	17	2026-09-10	11:00-12:00	1	VN	TOURNADRE TWINGO	\N	2026-09-10 15:25:02.617462+00	5	\N	\N	\N	\N
2909	2	17	2026-09-11	14:00-15:00	1	VN	MR PLAGNE DUSTER	\N	2026-09-10 15:25:44.255867+00	5	\N	\N	\N	\N
\.


--
-- Data for Name: role_campagne; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.role_campagne (id, campagne_id, utilisateur_id, role, plaque_id, site_id, cree_le, cree_par, archive_le) FROM stdin;
4	2	13	chef_plaque	1	\N	2026-08-31 20:53:19.106+00	\N	\N
5	2	14	chef_site	\N	3	2026-08-31 20:53:19.987+00	\N	\N
\.


--
-- Data for Name: role_global; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.role_global (utilisateur_id, role, cree_le, cree_par) FROM stdin;
2116	direction	2026-09-09 09:47:46.135772+00	\N
10	admin	2026-08-31 20:53:15.78+00	\N
11	direction	2026-08-31 20:53:17.147+00	\N
1784	admin	2026-09-07 14:40:27.730194+00	\N
1785	admin	2026-09-08 10:31:23.661828+00	\N
787	admin	2026-09-01 16:43:20.447858+00	\N
92	admin	2026-09-01 12:45:20.746852+00	\N
93	admin	2026-09-01 12:58:40.915832+00	\N
94	direction	2026-09-01 12:59:44.615288+00	\N
95	direction	2026-09-01 13:01:37.569948+00	\N
96	direction	2026-09-01 13:01:52.884959+00	\N
98	admin	2026-09-01 15:11:18.605526+00	\N
1779	direction	2026-09-04 09:48:52.997933+00	\N
1	direction	2026-09-08 07:44:07.655897+00	92
1786	admin	2026-09-08 13:22:16.105933+00	\N
\.


--
-- Data for Name: session_plaque; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.session_plaque (id, campagne_id, plaque_id, mode, effectif_cible_table, cree_le, cree_par, archive_le) FROM stdin;
1	1	1	par_table	6	2026-08-31 20:50:18.397+00	\N	\N
2	1	2	par_site	\N	2026-08-31 20:50:18.808+00	\N	\N
3	1	3	par_table	6	2026-08-31 20:50:19.045+00	\N	\N
4	1	4	par_site	\N	2026-08-31 20:50:19.279+00	\N	\N
5	2	1	par_table	6	2026-08-31 20:50:20.458+00	\N	\N
6	2	2	par_site	\N	2026-08-31 20:50:20.716+00	\N	\N
7	2	3	par_table	6	2026-08-31 20:50:21.29+00	\N	\N
8	2	4	par_site	\N	2026-08-31 20:50:21.539+00	\N	\N
\.


--
-- Data for Name: site; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.site (id, code, libelle, plaque_id, cree_le, cree_par, archive_le) FROM stdin;
1	MASS	Massagettes	1	2026-08-31 20:49:25.453+00	\N	\N
2	MOZ	Mozac	1	2026-08-31 20:49:25.569+00	\N	\N
3	CLF	Clermont-Ferrand	1	2026-08-31 20:49:25.61+00	\N	\N
4	USS	Ussel	1	2026-08-31 20:49:25.658+00	\N	\N
5	ALPINE	Alpine	1	2026-08-31 20:49:25.702+00	\N	\N
6	VI	Vichy	2	2026-08-31 20:49:25.745+00	\N	\N
7	MOU	Moulins	2	2026-08-31 20:49:25.793+00	\N	\N
8	TH	Thiers	2	2026-08-31 20:49:25.83+00	\N	\N
9	PUY	Le Puy	3	2026-08-31 20:49:25.871+00	\N	\N
10	MEN	Mende	3	2026-08-31 20:49:25.942+00	\N	\N
11	ISS	Issoire	3	2026-08-31 20:49:25.992+00	\N	\N
12	GAILL	Gaillac	4	2026-08-31 20:49:26.025+00	\N	\N
13	ALBI	Albi	4	2026-08-31 20:49:26.066+00	\N	\N
14	RDZ	Rodez	4	2026-08-31 20:49:26.11+00	\N	\N
15	MILL	Millau	4	2026-08-31 20:49:26.149+00	\N	\N
16	FIGEAC	Figeac	4	2026-08-31 20:49:26.19+00	\N	\N
17	AUR	Aurillac	4	2026-08-31 20:49:26.232+00	\N	\N
18	VDR	Villefranche	4	2026-08-31 20:49:26.28+00	\N	\N
19	CARM	Carmaux	4	2026-08-31 20:49:26.33+00	\N	\N
710	LAV	Lavaur	4	2026-09-04 13:11:11.762874+00	\N	\N
\.


--
-- Data for Name: table_phoning; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.table_phoning (id, session_plaque_id, libelle, chef_utilisateur_id, ordre, cree_le, cree_par, archive_le, marque_id) FROM stdin;
1	1	Table 1	2	1	2026-08-31 20:50:21.882+00	\N	\N	\N
2	1	Table 2	3	2	2026-08-31 20:50:22.039+00	\N	\N	\N
3	1	Table 3	4	3	2026-08-31 20:50:22.124+00	\N	\N	\N
4	1	Table 4	5	4	2026-08-31 20:50:22.226+00	\N	\N	\N
5	1	Table 5	6	5	2026-08-31 20:50:22.346+00	\N	\N	\N
6	3	Table 1	7	1	2026-08-31 20:50:22.461+00	\N	\N	\N
7	3	Table 2	8	2	2026-08-31 20:50:22.59+00	\N	\N	\N
8	3	Table 3	9	3	2026-08-31 20:50:22.709+00	\N	\N	\N
145	7	PLAQUE SUD - 2	8	2	2026-09-02 09:30:35.062701+00	787	\N	\N
9	5	TABLE 1 - EAA	5	1	2026-09-01 15:28:59.817474+00	92	\N	\N
10	5	TABLE 2 - EAA	6	2	2026-09-01 15:29:31.677519+00	92	\N	\N
11	5	TABLE 3 - EAA	4	3	2026-09-01 15:29:37.085727+00	92	\N	\N
12	5	TABLE 4 - EAA	2	4	2026-09-01 15:29:42.158952+00	92	\N	\N
13	5	TABLE 5 - EAA	3	5	2026-09-01 15:29:49.251706+00	92	\N	\N
144	7	Plaque SUD -1	7	1	2026-09-01 16:46:55.487315+00	787	\N	\N
146	7	PLAQUE SUD - 3	9	3	2026-09-02 09:36:45.359915+00	787	\N	\N
\.


--
-- Data for Name: utilisateur; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.utilisateur (id, login_id, password_hash, nom, actif, cree_le, cree_par, archive_le, auth_uid) FROM stdin;
10	admin.test	$2b$10$jf1LfAOZSMgiQLYsVflYL.q0dRv8ocSlzR9ZpBjoTQNojIXHN9CJa	ADMIN — test	f	2026-08-31 20:53:15.597+00	\N	\N	37d1c8d1-6efb-41d9-84ad-1f5978acc0ce
1	admin	$2b$10$jf1LfAOZSMgiQLYsVflYL.q0dRv8ocSlzR9ZpBjoTQNojIXHN9CJa	Administrateur	t	2026-08-31 20:50:14.806+00	\N	\N	2e6f4109-a9ae-4975-9077-757592869249
13	chef.plaque.test	$2b$10$jf1LfAOZSMgiQLYsVflYL.q0dRv8ocSlzR9ZpBjoTQNojIXHN9CJa	CHEF DE PLAQUE — test	f	2026-08-31 20:53:18.693+00	\N	\N	\N
14	chef.site.test	$2b$10$jf1LfAOZSMgiQLYsVflYL.q0dRv8ocSlzR9ZpBjoTQNojIXHN9CJa	CHEF DE SITE — test	f	2026-08-31 20:53:19.683+00	\N	\N	\N
11	direction.test	$2b$10$jf1LfAOZSMgiQLYsVflYL.q0dRv8ocSlzR9ZpBjoTQNojIXHN9CJa	DIRECTION — test	f	2026-08-31 20:53:16.85+00	\N	\N	986a6c38-99b3-4ad6-8d71-501a04ca0c23
12	encadrant.test	$2b$10$jf1LfAOZSMgiQLYsVflYL.q0dRv8ocSlzR9ZpBjoTQNojIXHN9CJa	ENCADRANT — test	f	2026-08-31 20:53:17.728+00	\N	\N	d39e1b71-0b03-4d78-902f-02d50d3fa1ab
1775	cfabre	(supabase-auth)	Caroline FABRE	t	2026-09-04 09:45:14.793567+00	\N	\N	7fcb205f-7f0d-4136-baec-a7a34f9d1b8e
787	lroux	(supabase-auth)	LUDIVINE ROUX	t	2026-09-01 16:43:20.353208+00	\N	\N	303b0dd3-4ada-4f53-958b-29825fef98f3
92	tlabonne	(supabase-auth)	THEO LABONNE	t	2026-09-01 12:45:20.618531+00	\N	\N	9467b496-2b42-4663-9254-76454c9ae544
3	tcoignac	$2b$10$gYMOmKic9qsqxHud2dyZ0.RjSMQpPXWKzzZpZJj7CBvkSggU6bevK	THIERRY COIGNAC	t	2026-08-31 20:50:15.729+00	\N	\N	c4f2a711-917f-4158-adab-74a71c34527e
4	lmarchetti	$2b$10$gYMOmKic9qsqxHud2dyZ0.RjSMQpPXWKzzZpZJj7CBvkSggU6bevK	LUCIEN MARCHETTI	t	2026-08-31 20:50:15.98+00	\N	\N	6d61ac3b-1cad-42ce-ae94-963421dd4fb1
5	jlarget	$2b$10$gYMOmKic9qsqxHud2dyZ0.RjSMQpPXWKzzZpZJj7CBvkSggU6bevK	JF LARGET	t	2026-08-31 20:50:16.198+00	\N	\N	5a637024-b12e-47b9-b3f1-25631c049fdd
1776	smarty	(supabase-auth)	Stéphanie MARTY	t	2026-09-04 09:46:25.290645+00	\N	\N	0d437d07-4ce1-4368-8c7e-bb9dc0017c1a
6	mmasson	$2b$10$gYMOmKic9qsqxHud2dyZ0.RjSMQpPXWKzzZpZJj7CBvkSggU6bevK	MICKAEL MASSON	t	2026-08-31 20:50:16.394+00	\N	\N	bfc0adb8-889d-482e-a45c-17ca5ac56805
2	sbesson	$2b$10$jf1LfAOZSMgiQLYsVflYL.q0dRv8ocSlzR9ZpBjoTQNojIXHN9CJa	SÉVERINE BESSON	t	2026-08-31 20:50:15.467+00	\N	\N	323bc1ec-515e-4676-913a-50b39e43d18c
7	fnogues	$2b$10$gYMOmKic9qsqxHud2dyZ0.RjSMQpPXWKzzZpZJj7CBvkSggU6bevK	FRANCK NOGUES	t	2026-08-31 20:50:16.599+00	\N	\N	79958d14-63ab-4f93-bbc6-f57e3bb5082d
8	jhebert	$2b$10$gYMOmKic9qsqxHud2dyZ0.RjSMQpPXWKzzZpZJj7CBvkSggU6bevK	JÉRÔME HÉBERT	t	2026-08-31 20:50:16.808+00	\N	\N	c0eb4ed3-3b70-4af4-98f1-9fbb01f55f97
9	gparrain	$2b$10$gYMOmKic9qsqxHud2dyZ0.RjSMQpPXWKzzZpZJj7CBvkSggU6bevK	GILLES PARRAIN	t	2026-08-31 20:50:17.083+00	\N	\N	104bb84c-e5c5-4201-85aa-bf8cbdad1fb9
1777	lbressan	(supabase-auth)	Laurent BRESSAN	t	2026-09-04 09:46:42.435072+00	\N	\N	42985b02-8b3b-4dd6-9163-a7e443132448
1778	rbouzat	(supabase-auth)	Renaud BOUZAT	t	2026-09-04 09:47:53.826403+00	\N	\N	734f38ca-fe79-417e-9e7b-9a287336436c
1779	dsarotti	(supabase-auth)	Didier SAROTTI	t	2026-09-04 09:48:52.932794+00	\N	\N	5a1145e6-a11b-43df-825f-ce23b5620782
1780	cdelpuech	(supabase-auth)	Cédric DELPUECH	t	2026-09-04 09:49:59.218837+00	\N	\N	e988aca4-d096-462e-ba0f-3f23fae0f037
1781	jcazes	(supabase-auth)	Jean-Philippe CAZES	t	2026-09-04 09:50:49.297013+00	\N	\N	2de97c97-7eda-4f79-8d07-ff68abaf4f21
93	rfuziol	(supabase-auth)	RAPHAÊL FUZIOL	t	2026-09-01 12:58:40.811244+00	\N	\N	28e3e42b-0162-49f0-a62c-c0b827534777
94	ftixier	(supabase-auth)	FRANCK TIXIER	t	2026-09-01 12:59:44.528474+00	\N	\N	5c3f5664-b44a-44ef-8683-79041d50ac78
96	sgaudon	(supabase-auth)	STÉPHANE GAUDON	t	2026-09-01 13:01:52.818469+00	\N	\N	da923fe6-593f-4f5a-9423-36ff8b088d03
97	pduverger	(supabase-auth)	PIERRE DUVERGER	t	2026-09-01 13:02:41.790628+00	\N	\N	d6837ce3-decd-41a9-b616-77c9b16791e2
98	perard	(supabase-auth)	PIERRE-MICHEL ERARD	t	2026-09-01 15:11:18.506033+00	\N	\N	14b3b621-42d9-4463-9baa-57b036c50a27
1782	rfradetal	(supabase-auth)	ROMAIN FRADETAL	t	2026-09-07 13:53:28.180092+00	\N	\N	e81e5e4c-3fe6-43fa-aec2-8f7a9864f813
1783	rzennouche	(supabase-auth)	Romain Zennouche	t	2026-09-07 13:54:39.696631+00	\N	\N	499a5468-d3f8-497b-81c3-e92b1f857dc2
1784	aperz	(supabase-auth)	Alexis PERZ	t	2026-09-07 14:40:27.651382+00	\N	\N	8834688a-bb11-4b05-ae55-bcb73ec6c7a3
95	bbourron	(supabase-auth)	BENJAMIN BOURRON	f	2026-09-01 13:01:37.432109+00	\N	\N	11da046f-dfd2-4216-890f-f97c3782fea8
1785	ccharlier	(supabase-auth)	CHRISTIAN CHARLIER	t	2026-09-08 10:31:23.485863+00	\N	\N	752f4494-9746-4075-a251-0a161f78e1ba
1786	crichard	(supabase-auth)	CLAIRE RICHARD	t	2026-09-08 13:22:16.020976+00	\N	\N	ce6dff67-d3ad-473f-9bc0-0e50634e08c4
2116	pyb	(supabase-auth)	PIERRE-YVES BEYRON	t	2026-09-09 09:47:45.998152+00	\N	\N	48cef650-a3d8-466c-b429-c01bff90f2a7
\.


--
-- Data for Name: vendeur; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.vendeur (id, nom, site_id, utilisateur_id, date_entree, date_sortie, cree_le, cree_par, capacites_confirmees_le, capacites_confirmees_par, type_vehicule, archive_le, archive_par) FROM stdin;
2	VIRGINIE CUMINAL	1	\N	\N	\N	2026-08-31 20:49:27.54+00	\N	\N	\N	VN	\N	\N
3	ANTHONY DONAS	2	\N	\N	\N	2026-08-31 20:49:28.084+00	\N	\N	\N	VN	\N	\N
4	JORDAN CALDEIRA	2	\N	\N	\N	2026-08-31 20:49:28.795+00	\N	\N	\N	VN	\N	\N
5	ROBIN RABOISSON	2	\N	\N	\N	2026-08-31 20:49:29.355+00	\N	\N	\N	VN	\N	\N
6	KEVIN DIJOUX	2	\N	\N	\N	2026-08-31 20:49:30.148+00	\N	\N	\N	VN	\N	\N
13	BLANDINE CLÉMENT	3	\N	\N	2026-07-31	2026-08-31 20:49:33.679+00	\N	2026-09-01 15:38:04.770842+00	92	VN	\N	\N
8	YANN DE OLIVEIRA	2	\N	\N	\N	2026-08-31 20:49:31.298+00	\N	\N	\N	VO	\N	\N
9	MATTHIAS VALLE	2	\N	\N	\N	2026-08-31 20:49:31.515+00	\N	\N	\N	VO	\N	\N
10	VALENTIN PARPINELLI	3	\N	\N	\N	2026-08-31 20:49:31.644+00	\N	\N	\N	VN	\N	\N
11	THIERRY DUBERNAT	3	\N	\N	\N	2026-08-31 20:49:32.17+00	\N	\N	\N	VN	\N	\N
12	OCEANE ESPINASSE	3	\N	\N	\N	2026-08-31 20:49:33.088+00	\N	\N	\N	VN	\N	\N
14	THOMAS SOULIER	3	\N	\N	\N	2026-08-31 20:49:34.277+00	\N	\N	\N	VN	\N	\N
15	CHRISTOPHE BROSSEAU	3	\N	\N	\N	2026-08-31 20:49:34.82+00	\N	\N	\N	VN	\N	\N
16	THÉO ROUSSET	3	\N	\N	\N	2026-08-31 20:49:35.392+00	\N	\N	\N	VN	\N	\N
17	QUENTIN BELLAIGUES	3	\N	\N	\N	2026-08-31 20:49:35.914+00	\N	\N	\N	VN	\N	\N
18	JEAN-PIERRE FERRIER	3	\N	\N	\N	2026-08-31 20:49:36.449+00	\N	\N	\N	VN	\N	\N
19	JULIEN BIASUTTI	3	\N	\N	\N	2026-08-31 20:49:37.08+00	\N	\N	\N	VN	\N	\N
21	ANTOINE BASTIEN	3	\N	\N	\N	2026-08-31 20:49:38.351+00	\N	\N	\N	VO	\N	\N
22	DYLAN GUERRET	3	\N	\N	\N	2026-08-31 20:49:38.482+00	\N	\N	\N	VO	\N	\N
23	JOAO TEIXEIRA	3	\N	\N	\N	2026-08-31 20:49:38.604+00	\N	\N	\N	VO	\N	\N
24	THIERRY MARTINEZ	3	\N	\N	\N	2026-08-31 20:49:38.777+00	\N	\N	\N	VO	\N	\N
25	JEROME SABIN	3	\N	\N	\N	2026-08-31 20:49:38.909+00	\N	\N	\N	VO	\N	\N
26	ROBIN GUERY	4	\N	\N	\N	2026-08-31 20:49:39.039+00	\N	\N	\N	VN	\N	\N
27	JULIEN SPADAT	4	\N	\N	\N	2026-08-31 20:49:39.636+00	\N	\N	\N	VN	\N	\N
28	STÉPHANE VANDAMME	4	\N	\N	\N	2026-08-31 20:49:40.281+00	\N	\N	\N	VO	\N	\N
29	SÉBASTIEN MIRA	5	\N	\N	\N	2026-08-31 20:49:40.399+00	\N	\N	\N	VN	\N	\N
30	EMILIEN SOLEILHAVOUP	5	\N	\N	\N	2026-08-31 20:49:40.727+00	\N	\N	\N	VN	\N	\N
31	ALEXANDRE CHAVIGNON	6	\N	\N	\N	2026-08-31 20:49:41.278+00	\N	\N	\N	VN	\N	\N
32	MICHEL GUILLERM	6	\N	\N	\N	2026-08-31 20:49:41.815+00	\N	\N	\N	VN	\N	\N
33	ALEXANDRE DIOT	6	\N	\N	\N	2026-08-31 20:49:42.493+00	\N	\N	\N	VN	\N	\N
34	DYLAN MEYRIAL	6	\N	\N	\N	2026-08-31 20:49:43.05+00	\N	\N	\N	VN	\N	\N
35	YOANN TRIBOULET	6	\N	\N	\N	2026-08-31 20:49:43.564+00	\N	\N	\N	VN	\N	\N
36	MATTIS BONNAMOUR	6	\N	\N	\N	2026-08-31 20:49:44.169+00	\N	\N	\N	VN	\N	\N
39	CLÉMENT JACQUET	6	\N	\N	\N	2026-08-31 20:49:45.484+00	\N	\N	\N	VO	\N	\N
40	ROMARIC RAMBERT	6	\N	\N	\N	2026-08-31 20:49:45.643+00	\N	\N	\N	VO	\N	\N
41	CLÉMENT RAYA	6	\N	\N	\N	2026-08-31 20:49:45.839+00	\N	\N	\N	VO	\N	\N
42	SYLVETTE ROGUE	7	\N	\N	\N	2026-08-31 20:49:45.97+00	\N	\N	\N	VN	\N	\N
43	SEBASTIEN DUBOST	7	\N	\N	\N	2026-08-31 20:49:46.529+00	\N	\N	\N	VN	\N	\N
44	MARC PALUMBO	7	\N	\N	\N	2026-08-31 20:49:47.037+00	\N	\N	\N	VN	\N	\N
47	ROMAIN DENIS	7	\N	\N	\N	2026-08-31 20:49:47.82+00	\N	\N	\N	VO	\N	\N
48	LOUIS DUBOST	8	\N	\N	\N	2026-08-31 20:49:47.952+00	\N	\N	\N	VN	\N	\N
49	CYNTHIA VALLIN	8	\N	\N	\N	2026-08-31 20:49:48.57+00	\N	\N	\N	VN	\N	\N
50	AXEL DUMONT	8	\N	\N	\N	2026-08-31 20:49:49.219+00	\N	\N	\N	VN	\N	\N
51	DAMIEN DAGOSTINO	8	\N	\N	\N	2026-08-31 20:49:49.754+00	\N	\N	\N	VO	\N	\N
53	ARNAUD GALLAND	9	\N	\N	\N	2026-08-31 20:49:50.054+00	\N	\N	\N	VN	\N	\N
54	GUILLAUME SAVINEL	9	\N	\N	\N	2026-08-31 20:49:50.598+00	\N	\N	\N	VN	\N	\N
55	JEAN-PAUL RANVOISE	9	\N	\N	\N	2026-08-31 20:49:51.171+00	\N	\N	\N	VN	\N	\N
56	ARTHUR DURANTON	9	\N	\N	\N	2026-08-31 20:49:51.736+00	\N	\N	\N	VN	\N	\N
57	VALENTIN MOLINES	9	\N	\N	\N	2026-08-31 20:49:52.381+00	\N	\N	\N	VO	\N	\N
58	RICHARD WEISSELDINGER	9	\N	\N	\N	2026-08-31 20:49:52.544+00	\N	\N	\N	VO	\N	\N
59	JÉRÉMY DA COSTA	10	\N	\N	\N	2026-08-31 20:49:52.699+00	\N	\N	\N	VN	\N	\N
60	DYLAN NOGUEIRA	10	\N	\N	\N	2026-08-31 20:49:53.289+00	\N	\N	\N	VN	\N	\N
61	WILLIAM PASCAL	10	\N	\N	\N	2026-08-31 20:49:53.893+00	\N	\N	\N	VO	\N	\N
62	YOANN PICARD	11	\N	\N	\N	2026-08-31 20:49:54.046+00	\N	\N	\N	VN	\N	\N
63	STANISLAS RODAMEL	11	\N	\N	\N	2026-08-31 20:49:54.607+00	\N	\N	\N	VN	\N	\N
65	MAGALI MICHEL	11	\N	\N	\N	2026-08-31 20:49:55.883+00	\N	\N	\N	VN	\N	\N
66	AMÉLIE HERVÉ	11	\N	\N	\N	2026-08-31 20:49:56.498+00	\N	\N	\N	VN	\N	\N
67	SÉBASTIEN DUMONT	11	\N	\N	\N	2026-08-31 20:49:57.277+00	\N	\N	\N	VN	\N	\N
68	REDWANE TOULOUSE	11	\N	\N	\N	2026-08-31 20:49:57.884+00	\N	\N	\N	VO	\N	\N
69	STÉPHANE DALLO-BELLESSA	11	\N	\N	\N	2026-08-31 20:49:58.037+00	\N	\N	\N	VO	\N	\N
72	JULIEN SEBE	12	\N	\N	\N	2026-08-31 20:49:59.003+00	\N	\N	\N	VN	\N	\N
73	GUILLAUME SEGUI	12	\N	\N	\N	2026-08-31 20:49:59.657+00	\N	\N	\N	VN	\N	\N
74	FLAVIEN MILLON	12	\N	\N	\N	2026-08-31 20:50:00.271+00	\N	\N	\N	VN	\N	\N
75	DANIEL DIAS FERNANDES	13	\N	\N	\N	2026-08-31 20:50:00.978+00	\N	\N	\N	VN	\N	\N
76	AURÉLIE BOMPART	13	\N	\N	\N	2026-08-31 20:50:01.551+00	\N	\N	\N	VN	\N	\N
78	FLORENT THOMASSIN	13	\N	\N	\N	2026-08-31 20:50:02.833+00	\N	\N	\N	VN	\N	\N
79	ROMAIN BOISSONNADE	14	\N	\N	\N	2026-08-31 20:50:03.448+00	\N	\N	\N	VN	\N	\N
81	ALEXIS COMPANS	14	\N	\N	\N	2026-08-31 20:50:04.58+00	\N	\N	\N	VN	\N	\N
82	RÉMI DEGAND	14	\N	\N	\N	2026-08-31 20:50:05.428+00	\N	\N	\N	VN	\N	\N
83	ARNAUD LOPEZ	14	\N	\N	\N	2026-08-31 20:50:05.981+00	\N	\N	\N	VO	\N	\N
84	DORIAN FRANCE	14	\N	\N	\N	2026-08-31 20:50:06.106+00	\N	\N	\N	VO	\N	\N
85	DAMIEN RULHE	14	\N	\N	\N	2026-08-31 20:50:06.263+00	\N	\N	\N	VO	\N	\N
89	DORIAN ALLEGRE	16	\N	\N	\N	2026-08-31 20:50:08.199+00	\N	\N	\N	VN	\N	\N
90	MATIS BRUNO	16	\N	\N	\N	2026-08-31 20:50:08.719+00	\N	\N	\N	VN	\N	\N
92	YOHAN BANYIK	17	\N	\N	\N	2026-08-31 20:50:09.915+00	\N	\N	\N	VN	\N	\N
93	ROMAIN COMBOURIEU	17	\N	\N	\N	2026-08-31 20:50:10.608+00	\N	\N	\N	VN	\N	\N
1	QUENTIN VANINI	1	\N	\N	2026-08-01	2026-08-31 20:49:26.552+00	\N	2026-09-01 16:15:23.629754+00	92	VN	\N	\N
64	JULIEN MONATTE	11	\N	\N	2026-07-01	2026-08-31 20:49:55.371+00	\N	2026-09-02 09:28:21.242777+00	787	VN	\N	\N
882	JULIEN RAYNAL	9	\N	2026-08-17	\N	2026-09-02 09:29:00.167354+00	787	2026-09-02 09:29:00.167354+00	787	VO	\N	\N
88	ELSA AGRINIER	15	\N	\N	2026-09-01	2026-08-31 20:50:07.65+00	\N	2026-09-04 09:40:02.976243+00	1	VN	\N	\N
86	NICOLAS CAYRON	15	\N	\N	2026-09-01	2026-08-31 20:50:06.406+00	\N	2026-09-04 09:40:10.368376+00	1	VN	\N	\N
87	MATHIS FRANCOIS	15	\N	\N	\N	2026-08-31 20:50:06.987+00	\N	2026-09-04 09:40:53.277466+00	1	VN	\N	\N
46	JULIEN LE QUELLEC	7	\N	\N	2026-08-31	2026-08-31 20:49:47.699+00	\N	2026-09-07 16:51:38.951157+00	92	VO	\N	\N
45	PAULINE COIGNET	7	\N	\N	2026-08-31	2026-08-31 20:49:47.57+00	\N	2026-09-07 16:53:14.731361+00	92	VO	\N	\N
52	ALEXANDRE PINOT	8	\N	\N	2026-08-31	2026-08-31 20:49:49.924+00	\N	2026-09-08 09:44:12.07912+00	92	VO	\N	\N
37	VIKTORIIA BONDARENKO	6	\N	\N	2026-08-31	2026-08-31 20:49:44.723+00	\N	2026-09-07 16:54:36.73063+00	92	VN	\N	\N
71	CHRISTIAN CAUQUIL	12	\N	\N	\N	2026-08-31 20:49:58.351+00	\N	2026-09-08 14:14:01.710692+00	1784	VN	\N	\N
94	STÉPHANE SUC	17	\N	\N	\N	2026-08-31 20:50:11.145+00	\N	\N	\N	VN	\N	\N
95	ANTONIN LUC	17	\N	\N	\N	2026-08-31 20:50:11.84+00	\N	\N	\N	VN	\N	\N
96	MAGALI BRUGIER	18	\N	\N	\N	2026-08-31 20:50:12.458+00	\N	\N	\N	VN	\N	\N
97	THOMAS BERT	18	\N	\N	\N	2026-08-31 20:50:13.438+00	\N	\N	\N	VN	\N	\N
7	UGO FERVEL	2	\N	\N	2026-08-31	2026-08-31 20:49:30.651+00	\N	2026-09-01 15:39:00.971629+00	92	VN	\N	\N
70	LENAIC FRANCOIS	11	\N	\N	\N	2026-08-31 20:49:58.198+00	\N	2026-09-02 09:32:30.62226+00	787	VO	\N	\N
1886	Florian HELOIRE	14	\N	2026-09-01	\N	2026-09-04 09:41:48.853076+00	1	2026-09-04 09:41:48.853076+00	1	VN	\N	\N
80	MARINE FLAUJAGUET	14	\N	\N	\N	2026-08-31 20:50:03.969+00	\N	2026-09-04 09:41:57.153009+00	1	VN	\N	\N
98	AZIZ CHOUAY	18	\N	\N	\N	2026-08-31 20:50:14.021+00	\N	\N	\N	VO	2026-09-04 09:42:32.67308+00	1
38	NICOLAS BOUCHET	6	\N	\N	2026-08-31	2026-08-31 20:49:45.35+00	\N	2026-09-07 16:54:25.327233+00	92	VO	\N	\N
1887	ALEXANDRE  PINOT	8	\N	\N	\N	2026-09-08 09:44:52.268276+00	92	2026-09-08 09:44:52.268276+00	92	VO	\N	\N
211	PASCAL TABOULOT	3	\N	\N	\N	2026-09-01 16:12:42.508485+00	92	2026-09-01 16:12:42.508485+00	92	VO	\N	\N
212	DAMIEN TERRASSE	3	\N	\N	\N	2026-09-01 16:13:00.762443+00	92	2026-09-01 16:13:00.762443+00	92	VO	\N	\N
213	PIERRE PASSARELLI	3	\N	\N	\N	2026-09-01 16:13:19.46982+00	92	2026-09-01 16:13:19.46982+00	92	VO	\N	\N
214	QUENTIN OLIVO	3	\N	\N	\N	2026-09-01 16:13:43.970975+00	92	2026-09-01 16:13:43.970975+00	92	VO	\N	\N
215	FABIEN DELPUECH	3	\N	\N	\N	2026-09-01 16:14:02.900871+00	92	2026-09-01 16:14:02.900871+00	92	VO	\N	\N
1888	Aziz CHOUAY	710	\N	2026-09-08	\N	2026-09-08 10:06:53.168488+00	1784	2026-09-08 10:06:53.168488+00	1784	VO	2026-09-08 10:07:02.351077+00	1784
1889	Aziz CHOUAY	18	\N	2026-09-08	\N	2026-09-08 10:07:18.641531+00	1784	2026-09-08 10:07:18.641531+00	1784	VO	\N	\N
99	GEOFFREY SALGUES	13	\N	\N	\N	2026-08-31 20:50:14.173+00	\N	2026-09-08 14:13:31.024597+00	1784	VN	\N	\N
1890	Lolita ENGUIX	15	\N	\N	\N	2026-09-08 14:32:03.736085+00	1784	2026-09-08 14:32:03.736085+00	1784	VO	\N	\N
159	EMMA GUENGEN	13	\N	\N	2026-09-01	2026-09-01 08:36:23.102009+00	10	2026-09-04 09:30:54.305402+00	1	VN	\N	\N
160	BAPTISTE DUBOIS	2	\N	2026-09-01	\N	2026-09-01 15:35:17.590064+00	92	2026-09-01 15:35:17.590064+00	92	VN	\N	\N
881	ADRIEN BRISSARD	11	\N	2026-11-01	\N	2026-09-02 09:28:07.716215+00	787	2026-09-08 15:21:24.695076+00	787	VN	2026-09-08 15:41:15.60847+00	787
91	CLÉMENT MALGOUZOU	16	\N	\N	2026-09-01	2026-08-31 20:50:09.313+00	\N	2026-09-04 09:34:40.704556+00	1	VN	\N	\N
77	EMMA GUEGUEN	13	\N	\N	\N	2026-08-31 20:50:02.201+00	\N	\N	\N	VN	2026-09-01 08:35:38.146573+00	10
20	PIERRE-EDOUARD LAROCHE	3	\N	\N	2026-07-31	2026-08-31 20:49:37.667+00	\N	2026-09-01 15:33:51.776264+00	92	VN	\N	\N
1885	Clément CALVI	15	\N	2026-09-01	\N	2026-09-04 09:40:42.733882+00	1	2026-09-04 09:40:42.733882+00	1	VN	\N	\N
\.


--
-- Data for Name: vendeur_marque; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.vendeur_marque (vendeur_id, marque_id, cree_le, cree_par) FROM stdin;
2	1	2026-08-31 20:49:27.576+00	\N
2	2	2026-08-31 20:49:27.817+00	\N
3	1	2026-08-31 20:49:28.212+00	\N
3	2	2026-08-31 20:49:28.479+00	\N
4	1	2026-08-31 20:49:28.848+00	\N
4	2	2026-08-31 20:49:29.057+00	\N
5	1	2026-08-31 20:49:29.425+00	\N
5	2	2026-08-31 20:49:29.849+00	\N
6	1	2026-08-31 20:49:30.181+00	\N
6	2	2026-08-31 20:49:30.406+00	\N
10	1	2026-08-31 20:49:31.686+00	\N
10	2	2026-08-31 20:49:31.899+00	\N
11	1	2026-08-31 20:49:32.21+00	\N
11	2	2026-08-31 20:49:32.555+00	\N
12	1	2026-08-31 20:49:33.14+00	\N
12	2	2026-08-31 20:49:33.353+00	\N
14	1	2026-08-31 20:49:34.32+00	\N
14	2	2026-08-31 20:49:34.514+00	\N
15	1	2026-08-31 20:49:34.897+00	\N
15	2	2026-08-31 20:49:35.147+00	\N
16	1	2026-08-31 20:49:35.436+00	\N
16	2	2026-08-31 20:49:35.67+00	\N
17	1	2026-08-31 20:49:35.95+00	\N
17	2	2026-08-31 20:49:36.162+00	\N
18	1	2026-08-31 20:49:36.514+00	\N
18	2	2026-08-31 20:49:36.777+00	\N
19	1	2026-08-31 20:49:37.136+00	\N
19	2	2026-08-31 20:49:37.39+00	\N
26	1	2026-08-31 20:49:39.08+00	\N
26	2	2026-08-31 20:49:39.323+00	\N
27	1	2026-08-31 20:49:39.68+00	\N
27	2	2026-08-31 20:49:39.91+00	\N
29	3	2026-08-31 20:49:40.443+00	\N
30	3	2026-08-31 20:49:40.765+00	\N
31	1	2026-08-31 20:49:41.325+00	\N
31	2	2026-08-31 20:49:41.57+00	\N
32	1	2026-08-31 20:49:41.856+00	\N
32	2	2026-08-31 20:49:42.145+00	\N
33	1	2026-08-31 20:49:42.557+00	\N
33	2	2026-08-31 20:49:42.766+00	\N
34	1	2026-08-31 20:49:43.091+00	\N
34	2	2026-08-31 20:49:43.328+00	\N
35	1	2026-08-31 20:49:43.609+00	\N
35	2	2026-08-31 20:49:43.877+00	\N
36	1	2026-08-31 20:49:44.219+00	\N
36	2	2026-08-31 20:49:44.449+00	\N
42	1	2026-08-31 20:49:46.019+00	\N
42	2	2026-08-31 20:49:46.226+00	\N
43	1	2026-08-31 20:49:46.569+00	\N
43	2	2026-08-31 20:49:46.786+00	\N
44	1	2026-08-31 20:49:47.082+00	\N
44	2	2026-08-31 20:49:47.3+00	\N
48	1	2026-08-31 20:49:47.996+00	\N
48	2	2026-08-31 20:49:48.275+00	\N
49	1	2026-08-31 20:49:48.614+00	\N
49	2	2026-08-31 20:49:48.847+00	\N
50	1	2026-08-31 20:49:49.267+00	\N
50	2	2026-08-31 20:49:49.475+00	\N
53	1	2026-08-31 20:49:50.105+00	\N
53	2	2026-08-31 20:49:50.328+00	\N
54	1	2026-08-31 20:49:50.641+00	\N
54	2	2026-08-31 20:49:50.868+00	\N
55	1	2026-08-31 20:49:51.205+00	\N
55	2	2026-08-31 20:49:51.425+00	\N
56	1	2026-08-31 20:49:51.796+00	\N
56	2	2026-08-31 20:49:52.039+00	\N
59	1	2026-08-31 20:49:52.737+00	\N
59	2	2026-08-31 20:49:52.962+00	\N
60	1	2026-08-31 20:49:53.33+00	\N
60	2	2026-08-31 20:49:53.602+00	\N
62	1	2026-08-31 20:49:54.098+00	\N
62	2	2026-08-31 20:49:54.313+00	\N
63	1	2026-08-31 20:49:54.649+00	\N
63	2	2026-08-31 20:49:54.961+00	\N
65	1	2026-08-31 20:49:55.931+00	\N
65	2	2026-08-31 20:49:56.154+00	\N
66	1	2026-08-31 20:49:56.546+00	\N
66	2	2026-08-31 20:49:56.803+00	\N
67	1	2026-08-31 20:49:57.336+00	\N
67	2	2026-08-31 20:49:57.574+00	\N
72	1	2026-08-31 20:49:59.067+00	\N
72	2	2026-08-31 20:49:59.385+00	\N
73	1	2026-08-31 20:49:59.724+00	\N
73	2	2026-08-31 20:49:59.974+00	\N
74	1	2026-08-31 20:50:00.315+00	\N
74	2	2026-08-31 20:50:00.598+00	\N
75	1	2026-08-31 20:50:01.028+00	\N
75	2	2026-08-31 20:50:01.244+00	\N
76	1	2026-08-31 20:50:01.606+00	\N
76	2	2026-08-31 20:50:01.846+00	\N
77	1	2026-08-31 20:50:02.246+00	\N
77	2	2026-08-31 20:50:02.52+00	\N
78	1	2026-08-31 20:50:02.879+00	\N
78	2	2026-08-31 20:50:03.174+00	\N
79	1	2026-08-31 20:50:03.49+00	\N
79	2	2026-08-31 20:50:03.714+00	\N
81	1	2026-08-31 20:50:04.644+00	\N
81	2	2026-08-31 20:50:05.177+00	\N
82	1	2026-08-31 20:50:05.473+00	\N
82	2	2026-08-31 20:50:05.709+00	\N
89	1	2026-08-31 20:50:08.248+00	\N
89	2	2026-08-31 20:50:08.454+00	\N
90	1	2026-08-31 20:50:08.761+00	\N
90	2	2026-08-31 20:50:08.973+00	\N
92	1	2026-08-31 20:50:09.99+00	\N
92	2	2026-08-31 20:50:10.24+00	\N
93	1	2026-08-31 20:50:10.656+00	\N
93	2	2026-08-31 20:50:10.896+00	\N
94	1	2026-08-31 20:50:11.207+00	\N
94	2	2026-08-31 20:50:11.464+00	\N
95	1	2026-08-31 20:50:11.899+00	\N
95	2	2026-08-31 20:50:12.155+00	\N
96	1	2026-08-31 20:50:12.494+00	\N
96	2	2026-08-31 20:50:12.721+00	\N
97	1	2026-08-31 20:50:13.51+00	\N
97	2	2026-08-31 20:50:13.721+00	\N
20	1	2026-09-01 15:33:51.776264+00	92
20	2	2026-09-01 15:33:51.776264+00	92
160	1	2026-09-01 15:35:17.590064+00	92
160	2	2026-09-01 15:35:17.590064+00	92
13	1	2026-09-01 15:38:04.770842+00	92
13	2	2026-09-01 15:38:04.770842+00	92
7	1	2026-09-01 15:39:00.971629+00	92
7	2	2026-09-01 15:39:00.971629+00	92
1	1	2026-09-01 16:15:23.629754+00	92
1	2	2026-09-01 16:15:23.629754+00	92
64	1	2026-09-02 09:28:21.242777+00	787
64	2	2026-09-02 09:28:21.242777+00	787
159	1	2026-09-04 09:30:54.305402+00	1
159	2	2026-09-04 09:30:54.305402+00	1
91	1	2026-09-04 09:34:40.704556+00	1
91	2	2026-09-04 09:34:40.704556+00	1
88	1	2026-09-04 09:40:02.976243+00	1
88	2	2026-09-04 09:40:02.976243+00	1
86	1	2026-09-04 09:40:10.368376+00	1
86	2	2026-09-04 09:40:10.368376+00	1
1885	1	2026-09-04 09:40:42.733882+00	1
87	2	2026-09-04 09:40:53.277466+00	1
1886	2	2026-09-04 09:41:48.853076+00	1
80	1	2026-09-04 09:41:57.153009+00	1
37	1	2026-09-07 16:54:36.73063+00	92
37	2	2026-09-07 16:54:36.73063+00	92
99	1	2026-09-08 14:13:31.024597+00	1784
99	2	2026-09-08 14:13:31.024597+00	1784
71	1	2026-09-08 14:14:01.710692+00	1784
71	2	2026-09-08 14:14:01.710692+00	1784
881	1	2026-09-08 15:21:24.695076+00	787
881	2	2026-09-08 15:21:24.695076+00	787
\.


--
-- Name: affectation_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.affectation_id_seq', 1637, true);


--
-- Name: campagne_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.campagne_id_seq', 782, true);


--
-- Name: encadrement_site_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.encadrement_site_id_seq', 632, true);


--
-- Name: marque_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.marque_id_seq', 54, true);


--
-- Name: plaque_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.plaque_id_seq', 394, true);


--
-- Name: rdv_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.rdv_id_seq', 2909, true);


--
-- Name: role_campagne_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.role_campagne_id_seq', 21, true);


--
-- Name: session_plaque_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.session_plaque_id_seq', 398, true);


--
-- Name: site_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.site_id_seq', 848, true);


--
-- Name: table_phoning_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.table_phoning_id_seq', 406, true);


--
-- Name: utilisateur_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.utilisateur_id_seq', 2116, true);


--
-- Name: vendeur_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.vendeur_id_seq', 2227, true);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: affectation affectation_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.affectation
    ADD CONSTRAINT affectation_pkey PRIMARY KEY (id);


--
-- Name: campagne_creneau campagne_creneau_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.campagne_creneau
    ADD CONSTRAINT campagne_creneau_pkey PRIMARY KEY (campagne_id, code);


--
-- Name: campagne_jour campagne_jour_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.campagne_jour
    ADD CONSTRAINT campagne_jour_pkey PRIMARY KEY (campagne_id, jour);


--
-- Name: campagne campagne_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.campagne
    ADD CONSTRAINT campagne_pkey PRIMARY KEY (id);


--
-- Name: encadrement_site encadrement_site_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.encadrement_site
    ADD CONSTRAINT encadrement_site_pkey PRIMARY KEY (id);


--
-- Name: marque marque_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.marque
    ADD CONSTRAINT marque_pkey PRIMARY KEY (id);


--
-- Name: plaque plaque_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.plaque
    ADD CONSTRAINT plaque_pkey PRIMARY KEY (id);


--
-- Name: rdv rdv_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.rdv
    ADD CONSTRAINT rdv_pkey PRIMARY KEY (id);


--
-- Name: role_campagne role_campagne_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.role_campagne
    ADD CONSTRAINT role_campagne_pkey PRIMARY KEY (id);


--
-- Name: role_global role_global_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.role_global
    ADD CONSTRAINT role_global_pkey PRIMARY KEY (utilisateur_id, role);


--
-- Name: session_plaque session_plaque_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.session_plaque
    ADD CONSTRAINT session_plaque_pkey PRIMARY KEY (id);


--
-- Name: site site_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.site
    ADD CONSTRAINT site_pkey PRIMARY KEY (id);


--
-- Name: table_phoning table_phoning_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.table_phoning
    ADD CONSTRAINT table_phoning_pkey PRIMARY KEY (id);


--
-- Name: utilisateur utilisateur_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.utilisateur
    ADD CONSTRAINT utilisateur_pkey PRIMARY KEY (id);


--
-- Name: vendeur_marque vendeur_marque_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.vendeur_marque
    ADD CONSTRAINT vendeur_marque_pkey PRIMARY KEY (vendeur_id, marque_id);


--
-- Name: vendeur vendeur_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.vendeur
    ADD CONSTRAINT vendeur_pkey PRIMARY KEY (id);


--
-- Name: affectation_table_id_vendeur_id_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX affectation_table_id_vendeur_id_key ON relance.affectation USING btree (table_id, vendeur_id);


--
-- Name: affectation_vendeur_id_idx; Type: INDEX; Schema: relance; Owner: -
--

CREATE INDEX affectation_vendeur_id_idx ON relance.affectation USING btree (vendeur_id);


--
-- Name: campagne_libelle_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX campagne_libelle_key ON relance.campagne USING btree (libelle);


--
-- Name: encadrement_site_site_role_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX encadrement_site_site_role_key ON relance.encadrement_site USING btree (site_id, role);


--
-- Name: encadrement_site_utilisateur_id_idx; Type: INDEX; Schema: relance; Owner: -
--

CREATE INDEX encadrement_site_utilisateur_id_idx ON relance.encadrement_site USING btree (utilisateur_id);


--
-- Name: marque_code_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX marque_code_key ON relance.marque USING btree (code);


--
-- Name: plaque_libelle_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX plaque_libelle_key ON relance.plaque USING btree (libelle);


--
-- Name: rdv_campagne_id_jour_creneau_code_idx; Type: INDEX; Schema: relance; Owner: -
--

CREATE INDEX rdv_campagne_id_jour_creneau_code_idx ON relance.rdv USING btree (campagne_id, jour, creneau_code);


--
-- Name: rdv_campagne_id_vendeur_id_idx; Type: INDEX; Schema: relance; Owner: -
--

CREATE INDEX rdv_campagne_id_vendeur_id_idx ON relance.rdv USING btree (campagne_id, vendeur_id);


--
-- Name: role_campagne_campagne_id_utilisateur_id_idx; Type: INDEX; Schema: relance; Owner: -
--

CREATE INDEX role_campagne_campagne_id_utilisateur_id_idx ON relance.role_campagne USING btree (campagne_id, utilisateur_id);


--
-- Name: session_plaque_campagne_id_plaque_id_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX session_plaque_campagne_id_plaque_id_key ON relance.session_plaque USING btree (campagne_id, plaque_id);


--
-- Name: site_code_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX site_code_key ON relance.site USING btree (code);


--
-- Name: table_phoning_marque_id_idx; Type: INDEX; Schema: relance; Owner: -
--

CREATE INDEX table_phoning_marque_id_idx ON relance.table_phoning USING btree (marque_id);


--
-- Name: table_phoning_session_plaque_id_libelle_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX table_phoning_session_plaque_id_libelle_key ON relance.table_phoning USING btree (session_plaque_id, libelle);


--
-- Name: utilisateur_auth_uid_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX utilisateur_auth_uid_key ON relance.utilisateur USING btree (auth_uid);


--
-- Name: utilisateur_login_id_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX utilisateur_login_id_key ON relance.utilisateur USING btree (login_id);


--
-- Name: vendeur_site_id_idx; Type: INDEX; Schema: relance; Owner: -
--

CREATE INDEX vendeur_site_id_idx ON relance.vendeur USING btree (site_id);


--
-- Name: vendeur_utilisateur_id_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX vendeur_utilisateur_id_key ON relance.vendeur USING btree (utilisateur_id);


--
-- Name: affectation affectation_marque_table; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER affectation_marque_table BEFORE INSERT OR UPDATE ON relance.affectation FOR EACH ROW EXECUTE FUNCTION relance.verifier_affectation_marque_table();


--
-- Name: affectation affectation_meme_plaque; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER affectation_meme_plaque BEFORE INSERT OR UPDATE ON relance.affectation FOR EACH ROW EXECUTE FUNCTION relance.verifier_affectation_meme_plaque();


--
-- Name: affectation affectation_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER affectation_pas_de_delete BEFORE DELETE ON relance.affectation FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: affectation affectation_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER affectation_tracabilite BEFORE INSERT ON relance.affectation FOR EACH ROW EXECUTE FUNCTION relance.tracer_creation();


--
-- Name: affectation affectation_unique_par_campagne; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER affectation_unique_par_campagne BEFORE INSERT OR UPDATE ON relance.affectation FOR EACH ROW EXECUTE FUNCTION relance.verifier_affectation_unique();


--
-- Name: affectation affectation_vendeur_present; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER affectation_vendeur_present BEFORE INSERT OR UPDATE ON relance.affectation FOR EACH ROW EXECUTE FUNCTION relance.verifier_affectation_presence();


--
-- Name: campagne campagne_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER campagne_pas_de_delete BEFORE DELETE ON relance.campagne FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: campagne campagne_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER campagne_tracabilite BEFORE INSERT ON relance.campagne FOR EACH ROW EXECUTE FUNCTION relance.tracer_creation();


--
-- Name: encadrement_site encadrement_site_compte_actif; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER encadrement_site_compte_actif BEFORE INSERT OR UPDATE ON relance.encadrement_site FOR EACH ROW EXECUTE FUNCTION relance.verifier_encadrant_actif();


--
-- Name: encadrement_site encadrement_site_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER encadrement_site_pas_de_delete BEFORE DELETE ON relance.encadrement_site FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: encadrement_site encadrement_site_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER encadrement_site_tracabilite BEFORE INSERT ON relance.encadrement_site FOR EACH ROW EXECUTE FUNCTION relance.tracer_creation();


--
-- Name: marque marque_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER marque_pas_de_delete BEFORE DELETE ON relance.marque FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: plaque plaque_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER plaque_pas_de_delete BEFORE DELETE ON relance.plaque FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: rdv rdv_campagne_ouverte; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER rdv_campagne_ouverte BEFORE INSERT OR DELETE OR UPDATE ON relance.rdv FOR EACH ROW EXECUTE FUNCTION relance.verifier_campagne_ouverte();


--
-- Name: rdv rdv_diffusion; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER rdv_diffusion AFTER INSERT OR UPDATE ON relance.rdv FOR EACH ROW EXECUTE FUNCTION relance.diffuser_rdv();


--
-- Name: rdv rdv_marque_autorisee; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER rdv_marque_autorisee BEFORE INSERT OR UPDATE OF vendeur_id, marque_id ON relance.rdv FOR EACH ROW EXECUTE FUNCTION relance.verifier_marque_autorisee();


--
-- Name: rdv rdv_marque_selon_metier; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER rdv_marque_selon_metier BEFORE INSERT OR UPDATE OF vendeur_id, marque_id ON relance.rdv FOR EACH ROW EXECUTE FUNCTION relance.verifier_marque_selon_metier();


--
-- Name: rdv rdv_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER rdv_pas_de_delete BEFORE DELETE ON relance.rdv FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: rdv rdv_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER rdv_tracabilite BEFORE INSERT OR UPDATE ON relance.rdv FOR EACH ROW EXECUTE FUNCTION relance.tracer_modification_rdv();


--
-- Name: rdv rdv_type_coherent; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER rdv_type_coherent BEFORE INSERT OR UPDATE OF vendeur_id, type_vehicule ON relance.rdv FOR EACH ROW EXECUTE FUNCTION relance.verifier_type_coherent();


--
-- Name: role_campagne role_campagne_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER role_campagne_tracabilite BEFORE INSERT ON relance.role_campagne FOR EACH ROW EXECUTE FUNCTION relance.tracer_creation();


--
-- Name: role_global role_global_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER role_global_tracabilite BEFORE INSERT ON relance.role_global FOR EACH ROW EXECUTE FUNCTION relance.tracer_creation();


--
-- Name: session_plaque session_plaque_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER session_plaque_pas_de_delete BEFORE DELETE ON relance.session_plaque FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: session_plaque session_plaque_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER session_plaque_tracabilite BEFORE INSERT ON relance.session_plaque FOR EACH ROW EXECUTE FUNCTION relance.tracer_creation();


--
-- Name: site site_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER site_pas_de_delete BEFORE DELETE ON relance.site FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: table_phoning table_phoning_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER table_phoning_pas_de_delete BEFORE DELETE ON relance.table_phoning FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: table_phoning table_phoning_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER table_phoning_tracabilite BEFORE INSERT ON relance.table_phoning FOR EACH ROW EXECUTE FUNCTION relance.tracer_creation();


--
-- Name: utilisateur utilisateur_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER utilisateur_pas_de_delete BEFORE DELETE ON relance.utilisateur FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: vendeur vendeur_dates_contre_rdv; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER vendeur_dates_contre_rdv BEFORE INSERT OR UPDATE ON relance.vendeur FOR EACH ROW EXECUTE FUNCTION relance.verifier_vendeur_dates_contre_rdv();


--
-- Name: vendeur vendeur_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER vendeur_pas_de_delete BEFORE DELETE ON relance.vendeur FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: vendeur vendeur_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER vendeur_tracabilite BEFORE INSERT ON relance.vendeur FOR EACH ROW EXECUTE FUNCTION relance.tracer_creation();


--
-- Name: affectation affectation_table_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.affectation
    ADD CONSTRAINT affectation_table_id_fkey FOREIGN KEY (table_id) REFERENCES relance.table_phoning(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: affectation affectation_vendeur_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.affectation
    ADD CONSTRAINT affectation_vendeur_id_fkey FOREIGN KEY (vendeur_id) REFERENCES relance.vendeur(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: campagne_creneau campagne_creneau_campagne_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.campagne_creneau
    ADD CONSTRAINT campagne_creneau_campagne_id_fkey FOREIGN KEY (campagne_id) REFERENCES relance.campagne(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: campagne_jour campagne_jour_campagne_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.campagne_jour
    ADD CONSTRAINT campagne_jour_campagne_id_fkey FOREIGN KEY (campagne_id) REFERENCES relance.campagne(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: encadrement_site encadrement_site_site_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.encadrement_site
    ADD CONSTRAINT encadrement_site_site_id_fkey FOREIGN KEY (site_id) REFERENCES relance.site(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: encadrement_site encadrement_site_utilisateur_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.encadrement_site
    ADD CONSTRAINT encadrement_site_utilisateur_id_fkey FOREIGN KEY (utilisateur_id) REFERENCES relance.utilisateur(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: rdv rdv_campagne_id_creneau_code_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.rdv
    ADD CONSTRAINT rdv_campagne_id_creneau_code_fkey FOREIGN KEY (campagne_id, creneau_code) REFERENCES relance.campagne_creneau(campagne_id, code) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: rdv rdv_campagne_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.rdv
    ADD CONSTRAINT rdv_campagne_id_fkey FOREIGN KEY (campagne_id) REFERENCES relance.campagne(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: rdv rdv_campagne_id_jour_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.rdv
    ADD CONSTRAINT rdv_campagne_id_jour_fkey FOREIGN KEY (campagne_id, jour) REFERENCES relance.campagne_jour(campagne_id, jour) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: rdv rdv_marque_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.rdv
    ADD CONSTRAINT rdv_marque_id_fkey FOREIGN KEY (marque_id) REFERENCES relance.marque(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: rdv rdv_vendeur_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.rdv
    ADD CONSTRAINT rdv_vendeur_id_fkey FOREIGN KEY (vendeur_id) REFERENCES relance.vendeur(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: role_campagne role_campagne_campagne_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.role_campagne
    ADD CONSTRAINT role_campagne_campagne_id_fkey FOREIGN KEY (campagne_id) REFERENCES relance.campagne(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: role_campagne role_campagne_plaque_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.role_campagne
    ADD CONSTRAINT role_campagne_plaque_id_fkey FOREIGN KEY (plaque_id) REFERENCES relance.plaque(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: role_campagne role_campagne_site_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.role_campagne
    ADD CONSTRAINT role_campagne_site_id_fkey FOREIGN KEY (site_id) REFERENCES relance.site(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: role_campagne role_campagne_utilisateur_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.role_campagne
    ADD CONSTRAINT role_campagne_utilisateur_id_fkey FOREIGN KEY (utilisateur_id) REFERENCES relance.utilisateur(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: role_global role_global_utilisateur_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.role_global
    ADD CONSTRAINT role_global_utilisateur_id_fkey FOREIGN KEY (utilisateur_id) REFERENCES relance.utilisateur(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: session_plaque session_plaque_campagne_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.session_plaque
    ADD CONSTRAINT session_plaque_campagne_id_fkey FOREIGN KEY (campagne_id) REFERENCES relance.campagne(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: session_plaque session_plaque_plaque_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.session_plaque
    ADD CONSTRAINT session_plaque_plaque_id_fkey FOREIGN KEY (plaque_id) REFERENCES relance.plaque(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: site site_plaque_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.site
    ADD CONSTRAINT site_plaque_id_fkey FOREIGN KEY (plaque_id) REFERENCES relance.plaque(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: table_phoning table_phoning_chef_utilisateur_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.table_phoning
    ADD CONSTRAINT table_phoning_chef_utilisateur_id_fkey FOREIGN KEY (chef_utilisateur_id) REFERENCES relance.utilisateur(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: table_phoning table_phoning_marque_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.table_phoning
    ADD CONSTRAINT table_phoning_marque_id_fkey FOREIGN KEY (marque_id) REFERENCES relance.marque(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: table_phoning table_phoning_session_plaque_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.table_phoning
    ADD CONSTRAINT table_phoning_session_plaque_id_fkey FOREIGN KEY (session_plaque_id) REFERENCES relance.session_plaque(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vendeur_marque vendeur_marque_marque_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.vendeur_marque
    ADD CONSTRAINT vendeur_marque_marque_id_fkey FOREIGN KEY (marque_id) REFERENCES relance.marque(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: vendeur_marque vendeur_marque_vendeur_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.vendeur_marque
    ADD CONSTRAINT vendeur_marque_vendeur_id_fkey FOREIGN KEY (vendeur_id) REFERENCES relance.vendeur(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: vendeur vendeur_site_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.vendeur
    ADD CONSTRAINT vendeur_site_id_fkey FOREIGN KEY (site_id) REFERENCES relance.site(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: vendeur vendeur_utilisateur_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.vendeur
    ADD CONSTRAINT vendeur_utilisateur_id_fkey FOREIGN KEY (utilisateur_id) REFERENCES relance.utilisateur(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: _prisma_migrations; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance._prisma_migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: affectation; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.affectation ENABLE ROW LEVEL SECURITY;

--
-- Name: affectation affectation_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY affectation_creation ON relance.affectation FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: affectation affectation_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY affectation_lecture ON relance.affectation FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: affectation affectation_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY affectation_modification ON relance.affectation FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: campagne; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.campagne ENABLE ROW LEVEL SECURITY;

--
-- Name: campagne campagne_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_creation ON relance.campagne FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: campagne_creneau; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.campagne_creneau ENABLE ROW LEVEL SECURITY;

--
-- Name: campagne_creneau campagne_creneau_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_creneau_creation ON relance.campagne_creneau FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: campagne_creneau campagne_creneau_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_creneau_lecture ON relance.campagne_creneau FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: campagne_creneau campagne_creneau_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_creneau_modification ON relance.campagne_creneau FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: campagne_jour; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.campagne_jour ENABLE ROW LEVEL SECURITY;

--
-- Name: campagne_jour campagne_jour_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_jour_creation ON relance.campagne_jour FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: campagne_jour campagne_jour_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_jour_lecture ON relance.campagne_jour FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: campagne_jour campagne_jour_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_jour_modification ON relance.campagne_jour FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: campagne campagne_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_lecture ON relance.campagne FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: campagne campagne_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_modification ON relance.campagne FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: encadrement_site; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.encadrement_site ENABLE ROW LEVEL SECURITY;

--
-- Name: encadrement_site encadrement_site_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY encadrement_site_creation ON relance.encadrement_site FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs));


--
-- Name: encadrement_site encadrement_site_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY encadrement_site_lecture ON relance.encadrement_site FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: encadrement_site encadrement_site_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY encadrement_site_modification ON relance.encadrement_site FOR UPDATE TO authenticated USING (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs)) WITH CHECK (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs));


--
-- Name: marque; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.marque ENABLE ROW LEVEL SECURITY;

--
-- Name: marque marque_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY marque_creation ON relance.marque FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: marque marque_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY marque_lecture ON relance.marque FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: marque marque_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY marque_modification ON relance.marque FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: plaque; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.plaque ENABLE ROW LEVEL SECURITY;

--
-- Name: plaque plaque_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY plaque_creation ON relance.plaque FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: plaque plaque_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY plaque_lecture ON relance.plaque FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: plaque plaque_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY plaque_modification ON relance.plaque FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: rdv; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.rdv ENABLE ROW LEVEL SECURITY;

--
-- Name: rdv rdv_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY rdv_creation ON relance.rdv FOR INSERT TO authenticated WITH CHECK ((( SELECT relance.peut_saisir(rdv.vendeur_id, rdv.campagne_id) AS peut_saisir) AND ( SELECT relance.campagne_ouverte(rdv.campagne_id) AS campagne_ouverte)));


--
-- Name: rdv rdv_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY rdv_lecture ON relance.rdv FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM relance.perimetre_saisie ps
  WHERE ((ps.campagne_id = rdv.campagne_id) AND (ps.vendeur_id = rdv.vendeur_id)))));


--
-- Name: rdv rdv_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY rdv_modification ON relance.rdv FOR UPDATE TO authenticated USING ((( SELECT relance.peut_saisir(rdv.vendeur_id, rdv.campagne_id) AS peut_saisir) AND ( SELECT relance.campagne_ouverte(rdv.campagne_id) AS campagne_ouverte))) WITH CHECK ((( SELECT relance.peut_saisir(rdv.vendeur_id, rdv.campagne_id) AS peut_saisir) AND ( SELECT relance.campagne_ouverte(rdv.campagne_id) AS campagne_ouverte)));


--
-- Name: role_campagne; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.role_campagne ENABLE ROW LEVEL SECURITY;

--
-- Name: role_campagne role_campagne_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY role_campagne_creation ON relance.role_campagne FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs));


--
-- Name: role_campagne role_campagne_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY role_campagne_lecture ON relance.role_campagne FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: role_campagne role_campagne_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY role_campagne_modification ON relance.role_campagne FOR UPDATE TO authenticated USING (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs)) WITH CHECK (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs));


--
-- Name: role_global; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.role_global ENABLE ROW LEVEL SECURITY;

--
-- Name: role_global role_global_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY role_global_creation ON relance.role_global FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs));


--
-- Name: role_global role_global_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY role_global_lecture ON relance.role_global FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: role_global role_global_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY role_global_modification ON relance.role_global FOR UPDATE TO authenticated USING (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs)) WITH CHECK (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs));


--
-- Name: session_plaque; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.session_plaque ENABLE ROW LEVEL SECURITY;

--
-- Name: session_plaque session_plaque_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY session_plaque_creation ON relance.session_plaque FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: session_plaque session_plaque_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY session_plaque_lecture ON relance.session_plaque FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: session_plaque session_plaque_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY session_plaque_modification ON relance.session_plaque FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: site; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.site ENABLE ROW LEVEL SECURITY;

--
-- Name: site site_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY site_creation ON relance.site FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: site site_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY site_lecture ON relance.site FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: site site_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY site_modification ON relance.site FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: table_phoning; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.table_phoning ENABLE ROW LEVEL SECURITY;

--
-- Name: table_phoning table_phoning_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY table_phoning_creation ON relance.table_phoning FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: table_phoning table_phoning_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY table_phoning_lecture ON relance.table_phoning FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: table_phoning table_phoning_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY table_phoning_modification ON relance.table_phoning FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: utilisateur; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.utilisateur ENABLE ROW LEVEL SECURITY;

--
-- Name: utilisateur utilisateur_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY utilisateur_creation ON relance.utilisateur FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs));


--
-- Name: utilisateur utilisateur_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY utilisateur_lecture ON relance.utilisateur FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: utilisateur utilisateur_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY utilisateur_modification ON relance.utilisateur FOR UPDATE TO authenticated USING (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs)) WITH CHECK (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs));


--
-- Name: vendeur; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.vendeur ENABLE ROW LEVEL SECURITY;

--
-- Name: vendeur vendeur_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY vendeur_creation ON relance.vendeur FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: vendeur vendeur_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY vendeur_lecture ON relance.vendeur FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: vendeur_marque; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.vendeur_marque ENABLE ROW LEVEL SECURITY;

--
-- Name: vendeur_marque vendeur_marque_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY vendeur_marque_creation ON relance.vendeur_marque FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: vendeur_marque vendeur_marque_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY vendeur_marque_lecture ON relance.vendeur_marque FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: vendeur_marque vendeur_marque_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY vendeur_marque_modification ON relance.vendeur_marque FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: vendeur vendeur_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY vendeur_modification ON relance.vendeur FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- PostgreSQL database dump complete
--

\unrestrict aZlU4rEymOlcoWVkgqzCuW0uYVcIc7whZhkVCYfMyLA2TEn0HQMRVAyTGc2RtQP

