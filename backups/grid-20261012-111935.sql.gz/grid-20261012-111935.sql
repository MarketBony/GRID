--
-- PostgreSQL database dump
--

\restrict W6A2mJtYwqpnHLYDn1ol8fKXB80vKsCvULUdREaIWpfkBLshStbJ0ffl1SHaezm

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.11 (Ubuntu 17.11-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: relance; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA relance;


--
-- Name: a_role_global(text); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.a_role_global(p_role text) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
  SELECT EXISTS (
    SELECT 1 FROM relance.role_global rg
    WHERE rg.utilisateur_id = relance.utilisateur_courant()
      AND rg.role = p_role
  )
$$;


--
-- Name: campagne_creer(text, date, date, bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.campagne_creer(p_libelle text, p_debut date, p_fin date, p_modele_id bigint) RETURNS bigint
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_administration();
  v_libelle text := btrim(coalesce(p_libelle, ''));
  nouvelle bigint;
BEGIN
  IF v_libelle = '' THEN
    RAISE EXCEPTION 'RELANCE: le libelle de la campagne est requis.';
  END IF;
  IF p_debut IS NULL OR p_fin IS NULL THEN
    RAISE EXCEPTION 'RELANCE: les dates de debut et de fin sont requises.';
  END IF;
  IF p_fin < p_debut THEN
    RAISE EXCEPTION 'RELANCE: la date de fin precede la date de debut.';
  END IF;
  -- Une borne, pas une regle metier : une faute de frappe sur l'annee
  -- (2026 -> 2027) poserait 366 jours, donc 366 colonnes dans la grille.
  IF p_fin - p_debut > 30 THEN
    RAISE EXCEPTION 'RELANCE: une campagne couvre au plus 31 jours (% jours demandes).',
      p_fin - p_debut + 1;
  END IF;
  -- Le libelle est UNIQUE (le seed resout une campagne par son libelle). Le
  -- verifier ici donne un message lisible au lieu d'une violation de contrainte.
  IF EXISTS (SELECT 1 FROM relance.campagne c WHERE c.libelle = v_libelle) THEN
    RAISE EXCEPTION 'RELANCE: une campagne s''appelle deja « % ».', v_libelle;
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM relance.campagne c WHERE c.id = p_modele_id AND c.archive_le IS NULL
  ) THEN
    RAISE EXCEPTION 'RELANCE: campagne modele introuvable.';
  END IF;
  -- Un modele sans creneau donnerait une grille sans ligne.
  IF NOT EXISTS (SELECT 1 FROM relance.campagne_creneau cc WHERE cc.campagne_id = p_modele_id) THEN
    RAISE EXCEPTION 'RELANCE: la campagne modele n''a aucun creneau a reprendre.';
  END IF;

  INSERT INTO relance.campagne (libelle, date_debut, date_fin, cree_par)
  VALUES (v_libelle, p_debut, p_fin, moi)
  RETURNING id INTO nouvelle;

  INSERT INTO relance.campagne_jour (campagne_id, jour, ordre, cree_par)
  SELECT nouvelle, j::date, row_number() OVER (ORDER BY j)::int, moi
    FROM generate_series(p_debut, p_fin, interval '1 day') AS j;

  INSERT INTO relance.campagne_creneau (campagne_id, code, libelle, ordre, cree_par)
  SELECT nouvelle, cc.code, cc.libelle, cc.ordre, moi
    FROM relance.campagne_creneau cc
   WHERE cc.campagne_id = p_modele_id;

  INSERT INTO relance.session_plaque (campagne_id, plaque_id, mode, effectif_cible_table, cree_par)
  SELECT nouvelle, p.id,
         coalesce(sm.mode, 'par_site'),
         sm.effectif_cible_table,
         moi
    FROM relance.plaque p
    LEFT JOIN relance.session_plaque sm
      ON sm.campagne_id = p_modele_id
     AND sm.plaque_id = p.id
     AND sm.archive_le IS NULL
   WHERE p.archive_le IS NULL;

  RETURN nouvelle;
END $$;


--
-- Name: campagne_definir_creneaux(bigint, text[], text[], text, text); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.campagne_definir_creneaux(p_campagne_id bigint, p_codes text[], p_libelles text[], p_mode text DEFAULT NULL::text, p_vers text DEFAULT NULL::text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_administration();
  retires text[];
  ajoutes text[];
  impactes int;
  detail jsonb;
  i int;
BEGIN
  IF p_codes IS NULL OR array_length(p_codes, 1) IS NULL THEN
    RAISE EXCEPTION 'RELANCE: au moins un creneau est requis.';
  END IF;
  IF array_length(p_codes, 1) <> array_length(p_libelles, 1) THEN
    RAISE EXCEPTION 'RELANCE: chaque creneau doit porter un libelle.';
  END IF;
  IF (SELECT count(DISTINCT c) FROM unnest(p_codes) c) <> array_length(p_codes, 1) THEN
    RAISE EXCEPTION 'RELANCE: un creneau est present deux fois.';
  END IF;
  IF NOT relance.campagne_ouverte(p_campagne_id) THEN
    RAISE EXCEPTION 'RELANCE: campagne cloturee, ses creneaux ne sont plus modifiables.';
  END IF;

  SELECT coalesce(array_agg(cc.code ORDER BY cc.ordre), '{}')
    INTO retires
    FROM relance.campagne_creneau cc
   WHERE cc.campagne_id = p_campagne_id AND NOT (cc.code = ANY (p_codes));

  SELECT coalesce(array_agg(c), '{}')
    INTO ajoutes
    FROM unnest(p_codes) c
   WHERE NOT EXISTS (
     SELECT 1 FROM relance.campagne_creneau cc
      WHERE cc.campagne_id = p_campagne_id AND cc.code = c
   );

  SELECT count(*)::int,
         coalesce(jsonb_agg(jsonb_build_object('creneau', s.code, 'actifs', s.actifs, 'archives', s.archives)), '[]'::jsonb)
    INTO impactes, detail
    FROM (
      SELECT r.creneau_code AS code,
             count(*) FILTER (WHERE r.archive_le IS NULL) AS actifs,
             count(*) FILTER (WHERE r.archive_le IS NOT NULL) AS archives
        FROM relance.rdv r
       WHERE r.campagne_id = p_campagne_id AND r.creneau_code = ANY (retires)
       GROUP BY r.creneau_code
    ) s;

  SELECT coalesce(sum((x->>'actifs')::int + (x->>'archives')::int), 0)::int
    INTO impactes FROM jsonb_array_elements(detail) x;

  IF impactes > 0 AND coalesce(p_mode, '') <> 'deplacer' THEN
    RETURN jsonb_build_object(
      'applique', false, 'code', 'RDV_IMPACTES',
      'retires', to_jsonb(retires), 'ajoutes', to_jsonb(ajoutes),
      'impacts', detail, 'creneauxConserves', to_jsonb(p_codes),
      'message', format('Retirer ces creneaux supprimerait le rattachement de %s RDV. Choisir : annuler, ou deplacer ces RDV vers un creneau conserve.', impactes)
    );
  END IF;

  IF impactes > 0 AND (p_vers IS NULL OR NOT (p_vers = ANY (p_codes))) THEN
    RAISE EXCEPTION 'RELANCE: le creneau de destination doit faire partie des creneaux conserves.';
  END IF;

  FOR i IN 1 .. array_length(p_codes, 1) LOOP
    INSERT INTO relance.campagne_creneau (campagne_id, code, libelle, ordre, cree_par)
    VALUES (p_campagne_id, p_codes[i], p_libelles[i], i, moi)
    ON CONFLICT (campagne_id, code) DO UPDATE SET libelle = EXCLUDED.libelle, ordre = EXCLUDED.ordre;
  END LOOP;

  IF impactes > 0 THEN
    UPDATE relance.rdv r
       SET creneau_code = p_vers, modifie_le = now(), modifie_par = moi
     WHERE r.campagne_id = p_campagne_id AND r.creneau_code = ANY (retires);
  END IF;

  IF array_length(retires, 1) IS NOT NULL THEN
    DELETE FROM relance.campagne_creneau cc
     WHERE cc.campagne_id = p_campagne_id AND cc.code = ANY (retires);
  END IF;

  RETURN jsonb_build_object(
    'applique', true, 'retires', to_jsonb(retires), 'ajoutes', to_jsonb(ajoutes),
    'rdvDeplaces', impactes, 'versCreneau', to_jsonb(p_vers),
    'creneaux', (SELECT coalesce(jsonb_agg(jsonb_build_object('code', cc.code, 'libelle', cc.libelle, 'ordre', cc.ordre) ORDER BY cc.ordre), '[]'::jsonb)
                   FROM relance.campagne_creneau cc WHERE cc.campagne_id = p_campagne_id)
  );
END $$;


--
-- Name: campagne_definir_jours(bigint, date[], text, date); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.campagne_definir_jours(p_campagne_id bigint, p_jours date[], p_mode text DEFAULT NULL::text, p_vers date DEFAULT NULL::date) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_administration();
  retires date[];
  ajoutes date[];
  impactes int;
  detail jsonb;
  i int;
BEGIN
  IF p_jours IS NULL OR array_length(p_jours, 1) IS NULL THEN
    RAISE EXCEPTION 'RELANCE: au moins un jour est requis.';
  END IF;
  IF (SELECT count(DISTINCT j) FROM unnest(p_jours) j) <> array_length(p_jours, 1) THEN
    RAISE EXCEPTION 'RELANCE: un jour est present deux fois.';
  END IF;
  IF NOT relance.campagne_ouverte(p_campagne_id) THEN
    RAISE EXCEPTION 'RELANCE: campagne cloturee, ses jours ne sont plus modifiables.';
  END IF;

  SELECT coalesce(array_agg(cj.jour ORDER BY cj.jour), '{}')
    INTO retires
    FROM relance.campagne_jour cj
   WHERE cj.campagne_id = p_campagne_id
     AND NOT (cj.jour = ANY (p_jours));

  SELECT coalesce(array_agg(j ORDER BY j), '{}')
    INTO ajoutes
    FROM unnest(p_jours) j
   WHERE NOT EXISTS (
     SELECT 1 FROM relance.campagne_jour cj
      WHERE cj.campagne_id = p_campagne_id AND cj.jour = j
   );

  -- Les RDV impactes, ARCHIVES COMPRIS : un RDV archive reste rattache a son jour
  -- par la cle etrangere, donc il bloque le retrait exactement comme un actif.
  SELECT count(*)::int,
         coalesce(jsonb_agg(x ORDER BY x->>'jour'), '[]'::jsonb)
    INTO impactes, detail
    FROM (
      SELECT jsonb_build_object(
               'jour', r.jour,
               'actifs', count(*) FILTER (WHERE r.archive_le IS NULL),
               'archives', count(*) FILTER (WHERE r.archive_le IS NOT NULL),
               'vendeurs', coalesce(jsonb_agg(DISTINCT v.nom) FILTER (WHERE r.archive_le IS NULL), '[]'::jsonb)
             ) AS x,
             count(*) AS n
        FROM relance.rdv r
        JOIN relance.vendeur v ON v.id = r.vendeur_id
       WHERE r.campagne_id = p_campagne_id
         AND r.jour = ANY (retires)
       GROUP BY r.jour
    ) s;

  SELECT coalesce(sum((x->>'actifs')::int + (x->>'archives')::int), 0)::int
    INTO impactes
    FROM jsonb_array_elements(detail) x;

  -- SONDAGE : on rend l'impact sans rien modifier. L'interface s'en sert pour
  -- proposer le choix « annuler ou deplacer ».
  IF impactes > 0 AND coalesce(p_mode, '') <> 'deplacer' THEN
    RETURN jsonb_build_object(
      'applique', false,
      'code', 'RDV_IMPACTES',
      'retires', to_jsonb(retires),
      'ajoutes', to_jsonb(ajoutes),
      'impacts', detail,
      'joursConserves', to_jsonb(p_jours),
      'message', format(
        'Retirer %s supprimerait le rattachement de %s RDV. Choisir : annuler la modification, ou deplacer ces RDV vers un jour conserve.',
        CASE WHEN array_length(retires, 1) > 1 THEN 'ces jours' ELSE 'ce jour' END,
        impactes)
    );
  END IF;

  IF impactes > 0 THEN
    IF p_vers IS NULL OR NOT (p_vers = ANY (p_jours)) THEN
      RAISE EXCEPTION 'RELANCE: le jour de destination doit faire partie des jours conserves.';
    END IF;
  END IF;

  -- 1. les jours demandes, crees ou renumerotes
  FOR i IN 1 .. array_length(p_jours, 1) LOOP
    INSERT INTO relance.campagne_jour (campagne_id, jour, ordre, cree_par)
    VALUES (p_campagne_id, p_jours[i], i, moi)
    ON CONFLICT (campagne_id, jour) DO UPDATE SET ordre = EXCLUDED.ordre;
  END LOOP;

  -- 2. les RDV deplaces, APRES la creation des jours de destination
  IF impactes > 0 THEN
    UPDATE relance.rdv r
       SET jour = p_vers, modifie_le = now(), modifie_par = moi
     WHERE r.campagne_id = p_campagne_id
       AND r.jour = ANY (retires);
  END IF;

  -- 3. les jours retires, une fois vides
  IF array_length(retires, 1) IS NOT NULL THEN
    DELETE FROM relance.campagne_jour cj
     WHERE cj.campagne_id = p_campagne_id AND cj.jour = ANY (retires);
  END IF;

  RETURN jsonb_build_object(
    'applique', true,
    'retires', to_jsonb(retires),
    'ajoutes', to_jsonb(ajoutes),
    'rdvDeplaces', impactes,
    'versJour', to_jsonb(p_vers),
    'jours', (SELECT coalesce(jsonb_agg(jsonb_build_object('jour', cj.jour, 'ordre', cj.ordre) ORDER BY cj.ordre), '[]'::jsonb)
                FROM relance.campagne_jour cj WHERE cj.campagne_id = p_campagne_id)
  );
END $$;


--
-- Name: campagne_ouverte(bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.campagne_ouverte(p_campagne_id bigint) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
  SELECT EXISTS (
    SELECT 1 FROM relance.campagne c
    WHERE c.id = p_campagne_id
      AND NOT c.cloturee
      AND c.archive_le IS NULL
  )
$$;


--
-- Name: charger_saisie(bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.charger_saisie(p_campagne_id bigint) RETURNS jsonb
    LANGUAGE sql STABLE
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
  WITH moi AS (SELECT relance.utilisateur_courant() AS id),
  ids AS (
    SELECT ps.vendeur_id FROM relance.perimetre_saisie ps WHERE ps.campagne_id = p_campagne_id
  )
  SELECT jsonb_build_object(
    'campagne', (SELECT jsonb_build_object('id', c.id, 'libelle', c.libelle, 'cloturee', c.cloturee)
                   FROM relance.campagne c WHERE c.id = p_campagne_id),
    'jours', coalesce((SELECT jsonb_agg(jsonb_build_object('jour', j.jour, 'ordre', j.ordre) ORDER BY j.ordre)
                         FROM relance.campagne_jour j WHERE j.campagne_id = p_campagne_id), '[]'::jsonb),
    'creneaux', coalesce((SELECT jsonb_agg(jsonb_build_object('code', cr.code, 'libelle', cr.libelle, 'ordre', cr.ordre) ORDER BY cr.ordre)
                            FROM relance.campagne_creneau cr WHERE cr.campagne_id = p_campagne_id), '[]'::jsonb),
    'vendeurs', coalesce((SELECT jsonb_agg(jsonb_build_object(
        'id', v.id, 'nom', v.nom, 'type_vehicule', v.type_vehicule,
        'site', jsonb_build_object('id', s.id, 'code', s.code, 'libelle', s.libelle, 'plaque_id', s.plaque_id),
        'vendeur_marque', coalesce((SELECT jsonb_agg(jsonb_build_object('marque',
              jsonb_build_object('id', m.id, 'libelle', m.libelle, 'ordre', m.ordre)))
            FROM relance.vendeur_marque vm JOIN relance.marque m ON m.id = vm.marque_id
           WHERE vm.vendeur_id = v.id), '[]'::jsonb)) ORDER BY v.id)
        FROM relance.vendeur v LEFT JOIN relance.site s ON s.id = v.site_id
       WHERE v.id IN (SELECT vendeur_id FROM ids)), '[]'::jsonb),
    'rdvs', coalesce((SELECT jsonb_agg(jsonb_build_object(
        'id', r.id, 'vendeur_id', r.vendeur_id, 'jour', r.jour, 'creneau_code', r.creneau_code,
        'marque_id', r.marque_id, 'type_vehicule', r.type_vehicule, 'client', r.client,
        'commentaire', r.commentaire, 'source', r.source) ORDER BY r.id)
        FROM relance.rdv r
       WHERE r.campagne_id = p_campagne_id AND r.archive_le IS NULL
         AND r.vendeur_id IN (SELECT vendeur_id FROM ids)), '[]'::jsonb),
    'tables', coalesce((SELECT jsonb_agg(jsonb_build_object(
        'id', t.id, 'libelle', t.libelle,
        'session_plaque', jsonb_build_object('campagne_id', sp.campagne_id,
            'plaque', jsonb_build_object('id', p.id, 'libelle', p.libelle)),
        'affectation', coalesce((SELECT jsonb_agg(jsonb_build_object('vendeur_id', a.vendeur_id, 'archive_le', a.archive_le))
                                   FROM relance.affectation a WHERE a.table_id = t.id), '[]'::jsonb)) ORDER BY t.id)
        FROM relance.table_phoning t
        JOIN relance.session_plaque sp ON sp.id = t.session_plaque_id
        LEFT JOIN relance.plaque p ON p.id = sp.plaque_id
       WHERE t.chef_utilisateur_id = (SELECT id FROM moi)
         AND sp.campagne_id = p_campagne_id AND t.archive_le IS NULL), '[]'::jsonb),
    'encadrements', coalesce((SELECT jsonb_agg(jsonb_build_object('site_id', e.site_id))
        FROM relance.encadrement_site e
       WHERE e.utilisateur_id = (SELECT id FROM moi) AND e.archive_le IS NULL), '[]'::jsonb),
    'roles_campagne', coalesce((SELECT jsonb_agg(jsonb_build_object('role', rc.role, 'site_id', rc.site_id, 'plaque_id', rc.plaque_id))
        FROM relance.role_campagne rc
       WHERE rc.utilisateur_id = (SELECT id FROM moi) AND rc.campagne_id = p_campagne_id
         AND rc.archive_le IS NULL), '[]'::jsonb),
    -- D11 : un vendeur declare ABSENT a l'ecran Effectifs sort de la grille de
    -- saisie (il reste accessible par un filtre). Seules les exceptions sont rendues.
    'mobilisations', coalesce((SELECT jsonb_agg(jsonb_build_object('vendeur_id', mo.vendeur_id, 'mobilise', mo.mobilise))
        FROM relance.mobilisation mo
       WHERE mo.campagne_id = p_campagne_id AND mo.vendeur_id IN (SELECT vendeur_id FROM ids)), '[]'::jsonb)
  );
$$;


--
-- Name: charger_suivi(bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.charger_suivi(p_campagne_id bigint) RETURNS jsonb
    LANGUAGE sql STABLE
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
  SELECT coalesce(jsonb_agg(jsonb_build_object(
      'id', r.id, 'vendeur_id', r.vendeur_id, 'vendeur', v.nom,
      'site_id', s.id, 'site', s.libelle, 'site_code', s.code,
      'jour', r.jour, 'creneau_code', r.creneau_code, 'creneau', cr.libelle, 'creneau_ordre', cr.ordre,
      'marque_id', r.marque_id, 'marque', m.libelle,
      'type_vehicule', r.type_vehicule, 'client', r.client, 'source', r.source,
      'issue', su.issue, 'diac', coalesce(su.diac, false), 'stock', coalesce(su.stock, false),
      'cs', coalesce(su.cs, false), 'vd', coalesce(su.vd, false), 'modele', su.modele,
      'commentaire', su.commentaire, 'maj_le', coalesce(su.modifie_le, su.cree_le))
      ORDER BY r.jour, cr.ordre, v.nom, r.id), '[]'::jsonb)
    FROM relance.rdv r
    JOIN relance.vendeur v ON v.id = r.vendeur_id
    LEFT JOIN relance.site s ON s.id = v.site_id
    LEFT JOIN relance.campagne_creneau cr ON cr.campagne_id = r.campagne_id AND cr.code = r.creneau_code
    LEFT JOIN relance.marque m ON m.id = r.marque_id
    LEFT JOIN relance.rdv_suivi su ON su.rdv_id = r.id
   WHERE r.campagne_id = p_campagne_id AND r.archive_le IS NULL
     AND r.vendeur_id IN (SELECT ps.vendeur_id FROM relance.perimetre_suivi ps WHERE ps.campagne_id = p_campagne_id);
$$;


--
-- Name: charger_tableau(bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.charger_tableau(p_campagne_id bigint) RETURNS jsonb
    LANGUAGE sql STABLE
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
  SELECT jsonb_build_object(
    'campagne', (SELECT jsonb_build_object('id', c.id, 'libelle', c.libelle, 'date_debut', c.date_debut,
                                           'date_fin', c.date_fin, 'cloturee', c.cloturee)
                   FROM relance.campagne c WHERE c.id = p_campagne_id),
    'jours', coalesce((SELECT jsonb_agg(j.jour ORDER BY j.ordre)
                         FROM relance.campagne_jour j WHERE j.campagne_id = p_campagne_id), '[]'::jsonb),
    'sessions', coalesce((SELECT jsonb_agg(jsonb_build_object('id', sp.id, 'mode', sp.mode,
          'effectif_cible_table', sp.effectif_cible_table,
          'plaque', jsonb_build_object('id', p.id, 'libelle', p.libelle, 'ordre', p.ordre)) ORDER BY sp.id)
        FROM relance.session_plaque sp LEFT JOIN relance.plaque p ON p.id = sp.plaque_id
       WHERE sp.campagne_id = p_campagne_id AND sp.archive_le IS NULL), '[]'::jsonb),
    'vendeurs', coalesce((SELECT jsonb_agg(jsonb_build_object('id', v.id, 'nom', v.nom,
          'type_vehicule', v.type_vehicule, 'date_entree', v.date_entree, 'date_sortie', v.date_sortie,
          'site', CASE WHEN s.id IS NULL THEN NULL ELSE jsonb_build_object('id', s.id, 'libelle', s.libelle,
                    'plaque', CASE WHEN p.id IS NULL THEN NULL ELSE jsonb_build_object('id', p.id, 'libelle', p.libelle) END) END)
          ORDER BY v.id)
        FROM relance.vendeur v
        LEFT JOIN relance.site s ON s.id = v.site_id
        LEFT JOIN relance.plaque p ON p.id = s.plaque_id
       WHERE v.archive_le IS NULL), '[]'::jsonb),
    'affectations', coalesce((SELECT jsonb_agg(jsonb_build_object('vendeur_id', a.vendeur_id,
          'table_phoning', jsonb_build_object('id', t.id, 'libelle', t.libelle,
            'session_plaque', jsonb_build_object('campagne_id', sp.campagne_id, 'plaque_id', sp.plaque_id)))
          ORDER BY a.id)
        FROM relance.affectation a
        JOIN relance.table_phoning t ON t.id = a.table_id
        JOIN relance.session_plaque sp ON sp.id = t.session_plaque_id
       WHERE a.archive_le IS NULL AND t.archive_le IS NULL AND sp.campagne_id = p_campagne_id), '[]'::jsonb),
    'mobilisations', coalesce((SELECT jsonb_agg(jsonb_build_object('vendeur_id', mo.vendeur_id,
          'mobilise', mo.mobilise, 'motif', mo.motif) ORDER BY mo.id)
        FROM relance.mobilisation mo WHERE mo.campagne_id = p_campagne_id), '[]'::jsonb),
    'rdvs', coalesce((SELECT jsonb_agg(jsonb_build_object('id', r.id, 'vendeur_id', r.vendeur_id,
          'type_vehicule', r.type_vehicule, 'marque_id', r.marque_id, 'jour', r.jour,
          'creneau_code', r.creneau_code, 'source', r.source) ORDER BY r.id)
        FROM relance.rdv_agrege r
       WHERE r.campagne_id = p_campagne_id AND r.archive_le IS NULL), '[]'::jsonb),
    'nb_rdvs', (SELECT count(*) FROM relance.rdv_agrege r
                 WHERE r.campagne_id = p_campagne_id AND r.archive_le IS NULL)
  );
$$;


--
-- Name: compte_reinitialise(bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.compte_reinitialise(p_utilisateur_id bigint) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_gestion_comptes();
BEGIN
  UPDATE relance.utilisateur SET doit_changer_mdp = true WHERE id = p_utilisateur_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'RELANCE: compte introuvable.';
  END IF;
  INSERT INTO relance.journal_compte (cree_par, cible_id, action) VALUES (moi, p_utilisateur_id, 'reinitialisation');
END $$;


--
-- Name: diffuser_rdv(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.diffuser_rdv() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
BEGIN
  PERFORM realtime.send(
    -- Ni `client` ni `commentaire`, structurellement : il n'y a pas de champ a
    -- oublier de retirer.
    jsonb_build_object(
      'id', NEW.id::text,
      'vendeurId', NEW.vendeur_id::text,
      'jour', NEW.jour,
      'creneauCode', NEW.creneau_code,
      'marqueId', NEW.marque_id::text,
      'typeVehicule', NEW.type_vehicule,
      'source', NEW.source,
      'archive', NEW.archive_le IS NOT NULL,
      'auteur', coalesce(NEW.modifie_par, NEW.cree_par)::text
    ),
    'rdv',
    'campagne-' || NEW.campagne_id::text,
    true
  );
  RETURN NULL;
END $$;


--
-- Name: diffuser_tables(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.diffuser_tables() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  c bigint;
BEGIN
  IF TG_TABLE_NAME = 'affectation' THEN
    FOR c IN SELECT DISTINCT sp.campagne_id
               FROM nouveaux n
               JOIN relance.table_phoning t ON t.id = n.table_id
               JOIN relance.session_plaque sp ON sp.id = t.session_plaque_id
    LOOP
      PERFORM realtime.send(jsonb_build_object('campagneId', c::text), 'tables', 'campagne-' || c::text, true);
    END LOOP;
  ELSE
    FOR c IN SELECT DISTINCT sp.campagne_id
               FROM nouveaux n
               JOIN relance.session_plaque sp ON sp.id = n.session_plaque_id
    LOOP
      PERFORM realtime.send(jsonb_build_object('campagneId', c::text), 'tables', 'campagne-' || c::text, true);
    END LOOP;
  END IF;
  RETURN NULL;
END $$;


--
-- Name: exiger_administration(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.exiger_administration() RETURNS bigint
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE moi bigint := relance.utilisateur_courant();
BEGIN
  IF moi IS NULL THEN
    RAISE EXCEPTION 'RELANCE: authentification requise.';
  END IF;
  IF NOT relance.peut_administrer() THEN
    RAISE EXCEPTION 'RELANCE: cette action demande le niveau administrateur ou direction.';
  END IF;
  RETURN moi;
END $$;


--
-- Name: exiger_gestion_comptes(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.exiger_gestion_comptes() RETURNS bigint
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE moi bigint := relance.utilisateur_courant();
BEGIN
  IF moi IS NULL THEN
    RAISE EXCEPTION 'RELANCE: authentification requise.';
  END IF;
  -- `admin` SEUL. C'est la frontiere qui empeche `direction` de se promouvoir,
  -- et elle ne doit jamais etre elargie « pour simplifier ».
  IF NOT relance.peut_gerer_utilisateurs() THEN
    RAISE EXCEPTION 'RELANCE: la gestion des comptes est reservee aux administrateurs.';
  END IF;
  RETURN moi;
END $$;


--
-- Name: exiger_session(bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.exiger_session(p_session_id bigint) RETURNS bigint
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.utilisateur_courant();
  campagne bigint;
BEGIN
  IF moi IS NULL THEN
    RAISE EXCEPTION 'RELANCE: authentification requise.';
  END IF;
  SELECT sp.campagne_id INTO campagne FROM relance.session_plaque sp WHERE sp.id = p_session_id;
  IF campagne IS NULL THEN
    RAISE EXCEPTION 'RELANCE: session introuvable.';
  END IF;
  IF NOT relance.peut_administrer_session(p_session_id) THEN
    RAISE EXCEPTION 'RELANCE: vous n''administrez pas cette plaque sur cette campagne.';
  END IF;
  -- R-C.3. Repete ici parce qu'une session close ne doit pas non plus voir sa
  -- composition changer — le trigger sur `rdv` ne couvre que les RDV.
  IF NOT relance.campagne_ouverte(campagne) THEN
    RAISE EXCEPTION 'RELANCE: cette campagne est cloturee, sa composition n''est plus modifiable.';
  END IF;
  RETURN moi;
END $$;


--
-- Name: horodater_mobilisation(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.horodater_mobilisation() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
BEGIN
  NEW.modifie_le := now();
  NEW.cree_par := OLD.cree_par;
  NEW.cree_le := OLD.cree_le;
  RETURN NEW;
END $$;


--
-- Name: interdire_suppression(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.interdire_suppression() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'relance', 'public'
    AS $$
BEGIN
  -- La porte : ouverte pour la duree d'UNE transaction, par la route de purge et
  -- par elle seule. `current_setting(..., true)` rend NULL si le parametre n'a
  -- jamais ete pose — donc le refus est bien le defaut, y compris sur une
  -- connexion neuve.
  IF coalesce(current_setting('relance.purge_autorisee', true), '') = 'oui' THEN
    RETURN NULL; -- trigger STATEMENT : la valeur de retour est ignoree
  END IF;

  RAISE EXCEPTION
    'RELANCE: suppression interdite sur %. Utiliser l''archivage (archive_le ou date_sortie). La purge definitive passe par l''ecran Archivage.',
    TG_TABLE_NAME;
END $$;


--
-- Name: journaliser_actif(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.journaliser_actif() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
BEGIN
  IF NEW.actif IS DISTINCT FROM OLD.actif THEN
    INSERT INTO relance.journal_compte (cree_par, cible_id, action)
    VALUES (relance.utilisateur_courant(), NEW.id, CASE WHEN NEW.actif THEN 'reactivation' ELSE 'desactivation' END);
  END IF;
  RETURN NULL;
END $$;


--
-- Name: mot_de_passe_choisi(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.mot_de_passe_choisi() RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.utilisateur_courant();
BEGIN
  IF moi IS NULL THEN
    RAISE EXCEPTION 'RELANCE: aucun compte actif.';
  END IF;
  UPDATE relance.utilisateur SET doit_changer_mdp = false WHERE id = moi;
  INSERT INTO relance.journal_compte (cree_par, cible_id, action) VALUES (moi, moi, 'changement_mot_de_passe');
END $$;


--
-- Name: peut_administrer(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.peut_administrer() RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
  SELECT relance.a_role_global('admin') OR relance.a_role_global('direction')
$$;


--
-- Name: peut_administrer_session(bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.peut_administrer_session(p_session_id bigint) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
  SELECT relance.peut_administrer()
      OR EXISTS (
        SELECT 1
        FROM relance.session_plaque sp
        JOIN relance.role_campagne rc
          ON rc.campagne_id = sp.campagne_id
         AND rc.plaque_id = sp.plaque_id
         AND rc.role = 'chef_plaque'
         AND rc.archive_le IS NULL
         AND rc.utilisateur_id = relance.utilisateur_courant()
        WHERE sp.id = p_session_id
      )
$$;


--
-- Name: peut_gerer_utilisateurs(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.peut_gerer_utilisateurs() RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
  SELECT relance.a_role_global('admin')
$$;


--
-- Name: peut_saisir(bigint, bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.peut_saisir(p_vendeur_id bigint, p_campagne_id bigint) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
  SELECT EXISTS (
    SELECT 1 FROM relance.perimetre_saisie ps
    WHERE ps.vendeur_id = p_vendeur_id
      AND ps.campagne_id = p_campagne_id
  )
$$;


--
-- Name: poser_capacites(bigint, bigint[], text, bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.poser_capacites(p_vendeur_id bigint, p_marque_ids bigint[], p_type_vehicule text, p_par bigint) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE m bigint;
BEGIN
  DELETE FROM relance.vendeur_marque WHERE vendeur_id = p_vendeur_id;
  IF p_type_vehicule <> 'VO' AND p_marque_ids IS NOT NULL THEN
    FOREACH m IN ARRAY p_marque_ids LOOP
      INSERT INTO relance.vendeur_marque (vendeur_id, marque_id, cree_par)
      VALUES (p_vendeur_id, m, p_par)
      ON CONFLICT DO NOTHING;
    END LOOP;
  END IF;

  -- PROVENANCE, pas un statut : qui a change les capacites et quand. La notion de
  -- « confirme / placeholder » a ete retiree — un vendeur en base est valide. Ces
  -- deux colonnes servent le jour ou un RDV est refuse sans que personne comprenne.
  UPDATE relance.vendeur
     SET type_vehicule = p_type_vehicule,
         capacites_confirmees_le = now(),
         capacites_confirmees_par = p_par
   WHERE id = p_vendeur_id;
END $$;


--
-- Name: rdv_poser(bigint, bigint, date, text, bigint, text, text, uuid); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.rdv_poser(p_campagne_id bigint, p_vendeur_id bigint, p_jour date, p_creneau_code text, p_marque_id bigint, p_type_vehicule text, p_client text, p_cle uuid) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  resultat jsonb;
BEGIN
  IF p_cle IS NULL THEN
    RAISE EXCEPTION 'RELANCE: cle d''idempotence manquante.';
  END IF;

  INSERT INTO relance.rdv (campagne_id, vendeur_id, jour, creneau_code, marque_id, type_vehicule, client, cle_client)
  VALUES (p_campagne_id, p_vendeur_id, p_jour, p_creneau_code, p_marque_id, p_type_vehicule, p_client, p_cle)
  ON CONFLICT (cle_client) DO NOTHING;

  SELECT jsonb_build_object('id', r.id, 'vendeur_id', r.vendeur_id, 'jour', r.jour,
           'creneau_code', r.creneau_code, 'marque_id', r.marque_id,
           'type_vehicule', r.type_vehicule, 'client', r.client, 'commentaire', r.commentaire,
           'archive_le', r.archive_le)
    INTO resultat
    FROM relance.rdv r
   WHERE r.cle_client = p_cle;

  IF resultat IS NULL THEN
    -- La cle existe mais la ligne n'est pas lisible : elle appartient a un autre
    -- perimetre. On n'en dit pas plus : la RLS ne se contourne pas par un message.
    RAISE EXCEPTION 'RELANCE: ce rendez-vous ne peut pas etre enregistre sur votre perimetre.';
  END IF;
  RETURN resultat;
END
$$;


--
-- Name: rdv_poser_showroom(bigint, bigint, date, text, bigint, text, text, uuid); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.rdv_poser_showroom(p_campagne_id bigint, p_vendeur_id bigint, p_jour date, p_creneau_code text, p_marque_id bigint, p_type_vehicule text, p_client text, p_cle uuid) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  resultat jsonb;
BEGIN
  IF p_cle IS NULL THEN
    RAISE EXCEPTION 'RELANCE: cle d''idempotence manquante.';
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM relance.perimetre_suivi ps
     WHERE ps.campagne_id = p_campagne_id AND ps.vendeur_id = p_vendeur_id
  ) THEN
    RAISE EXCEPTION 'RELANCE: ce vendeur n''est pas sur un de vos sites.';
  END IF;
  INSERT INTO relance.rdv (campagne_id, vendeur_id, jour, creneau_code, marque_id, type_vehicule, client, cle_client, source)
  VALUES (p_campagne_id, p_vendeur_id, p_jour, p_creneau_code, p_marque_id, p_type_vehicule, p_client, p_cle, 'showroom')
  ON CONFLICT (cle_client) DO NOTHING;
  SELECT jsonb_build_object('id', r.id, 'vendeur_id', r.vendeur_id, 'jour', r.jour,
           'creneau_code', r.creneau_code, 'marque_id', r.marque_id, 'type_vehicule', r.type_vehicule,
           'client', r.client, 'source', r.source)
    INTO resultat FROM relance.rdv r WHERE r.cle_client = p_cle;
  IF resultat IS NULL THEN
    RAISE EXCEPTION 'RELANCE: ce rendez-vous ne peut pas etre enregistre sur votre perimetre.';
  END IF;
  RETURN resultat;
END $$;


--
-- Name: sante(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.sante() RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'RELANCE: connexion requise' USING ERRCODE = '42501';
  END IF;
  RETURN jsonb_build_object(
    'ok', true,
    'heure', to_char(now() AT TIME ZONE 'Europe/Paris', 'HH24:MI:SS'),
    'rdv_10min', (SELECT count(*) FROM relance.rdv WHERE cree_le > now() - interval '10 minutes'));
END;
$$;


--
-- Name: sante_detail(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.sante_detail() RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  v_ouvertes integer;
  v_actives  integer;
  v_verrous  integer;
  v_bloquees integer;
  v_max      integer;
  v_derniere timestamptz;
BEGIN
  IF NOT relance.peut_administrer() THEN
    RAISE EXCEPTION 'RELANCE: reserve a l''administration' USING ERRCODE = '42501';
  END IF;

  -- `authenticator` est le role par lequel PostgREST se connecte. On ne rend
  -- que des COMPTEURS : jamais un texte de requete ni un nom d'utilisateur.
  SELECT count(*) FILTER (WHERE usename = 'authenticator'),
         count(*) FILTER (WHERE usename = 'authenticator' AND state = 'active'),
         count(*) FILTER (WHERE wait_event_type = 'Lock'),
         count(*) FILTER (WHERE state = 'idle in transaction')
    INTO v_ouvertes, v_actives, v_verrous, v_bloquees
    FROM pg_stat_activity;

  SELECT setting::int INTO v_max FROM pg_settings WHERE name = 'max_connections';

  SELECT greatest(max(cree_le), max(modifie_le), max(archive_le)) INTO v_derniere FROM relance.rdv;

  RETURN jsonb_build_object(
    -- La sonde elle-meme occupe une connexion active : on la retire.
    'pool',            greatest(v_actives - 1, 0),
    'pool_ouvertes',   v_ouvertes,
    -- Plafond du pool PostgREST de l'offre gratuite, mesure sur le Forum
    -- (meme offre). Il n'est lisible nulle part depuis la base.
    'pool_max',        11,
    'connexions_max',  v_max,
    'verrous',         v_verrous,
    'bloquees',        v_bloquees,
    'rdv_min',         (SELECT count(*) FROM relance.rdv WHERE cree_le > now() - interval '1 minute'),
    'rdv_10min',       (SELECT count(*) FROM relance.rdv WHERE cree_le > now() - interval '10 minutes'),
    'taille_mo',       round(pg_database_size(current_database()) / 1048576.0, 1),
    'taille_max_mo',   500,
    'derniere_activite', v_derniere,
    'heure',           to_char(now() AT TIME ZONE 'Europe/Paris', 'HH24:MI:SS'));
END;
$$;


--
-- Name: session_appliquer_repartition(bigint, jsonb, boolean); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.session_appliquer_repartition(p_session_id bigint, p_placements jsonb, p_remplacer boolean DEFAULT false) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_session(p_session_id);
  place int := 0;
  p jsonb;
  v jsonb;
  t bigint;
BEGIN
  -- `remplacer` REFAIT la composition entiere : toutes les affectations actives de
  -- la session sont archivees avant de replacer. Derriere une confirmation dans
  -- l'interface, jamais par defaut.
  IF p_remplacer THEN
    UPDATE relance.affectation a SET archive_le = now()
      FROM relance.table_phoning t
     WHERE t.id = a.table_id
       AND t.session_plaque_id = p_session_id
       AND a.archive_le IS NULL;
  END IF;

  FOR p IN SELECT jsonb_array_elements(coalesce(p_placements, '[]'::jsonb)) LOOP
    t := (p->>'tableId')::bigint;

    -- La table doit appartenir A CETTE session : sans ce controle, un appelant
    -- autorise sur sa plaque pourrait ecrire dans les tables d'une autre.
    IF NOT EXISTS (
      SELECT 1 FROM relance.table_phoning tp
       WHERE tp.id = t AND tp.session_plaque_id = p_session_id AND tp.archive_le IS NULL
    ) THEN
      RAISE EXCEPTION 'RELANCE: la table % n''appartient pas a cette session.', t;
    END IF;

    FOR v IN SELECT jsonb_array_elements(coalesce(p->'vendeurIdsAjoutes', '[]'::jsonb)) LOOP
      INSERT INTO relance.affectation (table_id, vendeur_id, origine, cree_par)
      VALUES (t, (v#>>'{}')::bigint, 'auto', moi)
      ON CONFLICT (table_id, vendeur_id) DO UPDATE SET archive_le = NULL, origine = 'auto';
      place := place + 1;
    END LOOP;
  END LOOP;

  RETURN jsonb_build_object('graine', 42, 'remplacer', p_remplacer, 'affectations', place);
END $$;


--
-- Name: session_reprendre(bigint, bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.session_reprendre(p_session_id bigint, p_depuis_campagne_id bigint) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_session(p_session_id);
  plaque bigint;
  campagne bigint;
  source bigint;
  tables_creees int := 0;
  reprises int := 0;
  reportes jsonb := '[]'::jsonb;
  t record;
  a record;
  cible bigint;
  existait boolean;
BEGIN
  SELECT sp.plaque_id, sp.campagne_id INTO plaque, campagne
    FROM relance.session_plaque sp WHERE sp.id = p_session_id;

  IF p_depuis_campagne_id = campagne THEN
    RAISE EXCEPTION 'RELANCE: la campagne source doit etre une AUTRE campagne.';
  END IF;

  SELECT sp.id INTO source
    FROM relance.session_plaque sp
   WHERE sp.campagne_id = p_depuis_campagne_id
     AND sp.plaque_id = plaque
     AND sp.archive_le IS NULL;
  IF source IS NULL THEN
    RAISE EXCEPTION 'RELANCE: cette plaque n''avait aucune session sur la campagne demandee.';
  END IF;

  FOR t IN
    SELECT tp.id, tp.libelle, tp.ordre, tp.chef_utilisateur_id, tp.marque_id
      FROM relance.table_phoning tp
     WHERE tp.session_plaque_id = source AND tp.archive_le IS NULL
     ORDER BY tp.ordre
  LOOP
    SELECT tp.id INTO cible
      FROM relance.table_phoning tp
     WHERE tp.session_plaque_id = p_session_id AND tp.libelle = t.libelle;
    existait := cible IS NOT NULL;

    IF existait THEN
      UPDATE relance.table_phoning
         SET archive_le = NULL, ordre = t.ordre,
             chef_utilisateur_id = t.chef_utilisateur_id, marque_id = t.marque_id
       WHERE id = cible;
    ELSE
      INSERT INTO relance.table_phoning (session_plaque_id, libelle, ordre, chef_utilisateur_id, marque_id, cree_par)
      VALUES (p_session_id, t.libelle, t.ordre, t.chef_utilisateur_id, t.marque_id, moi)
      RETURNING id INTO cible;
      tables_creees := tables_creees + 1;
    END IF;

    FOR a IN
      SELECT v.id, v.nom, v.site_id
        FROM relance.affectation af
        JOIN relance.vendeur v ON v.id = af.vendeur_id
       WHERE af.table_id = t.id AND af.archive_le IS NULL
    LOOP
      -- ELIGIBILITE : present pendant LA NOUVELLE campagne, et toujours de cette
      -- plaque. Les deux conditions sont verifiees ici EN PLUS du trigger, pour
      -- pouvoir NOMMER ceux qu'on laisse de cote plutot que d'echouer en bloc.
      IF NOT EXISTS (
        SELECT 1
          FROM relance.vendeur vv
          JOIN relance.site s ON s.id = vv.site_id
          JOIN relance.campagne c ON c.id = campagne
         WHERE vv.id = a.id
           AND s.plaque_id = plaque
           AND vv.archive_le IS NULL
           AND (vv.date_entree IS NULL OR vv.date_entree <= c.date_fin)
           AND (vv.date_sortie IS NULL OR vv.date_sortie >= c.date_debut)
      ) THEN
        reportes := reportes || jsonb_build_object(
          'nom', a.nom,
          'raison', 'absent de cette campagne, ou rattache a une autre plaque');
        CONTINUE;
      END IF;

      INSERT INTO relance.affectation (table_id, vendeur_id, origine, cree_par)
      VALUES (cible, a.id, 'manuel', moi)
      ON CONFLICT (table_id, vendeur_id) DO UPDATE SET archive_le = NULL;
      reprises := reprises + 1;
    END LOOP;
  END LOOP;

  RETURN jsonb_build_object(
    'tablesCreees', tables_creees,
    'affectationsReprises', reprises,
    'reportes', reportes
  );
END $$;


--
-- Name: suivi_enregistrer(bigint, text, boolean, boolean, boolean, text, text, boolean); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.suivi_enregistrer(p_rdv_id bigint, p_issue text, p_diac boolean, p_stock boolean, p_cs boolean, p_modele text, p_commentaire text, p_vd boolean DEFAULT false) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  resultat jsonb;
BEGIN
  IF coalesce(p_vd, false) AND NOT EXISTS (
    SELECT 1 FROM relance.rdv r WHERE r.id = p_rdv_id AND r.type_vehicule = 'VN'
  ) THEN
    RAISE EXCEPTION 'RELANCE: un vehicule de demonstration ne se vend que sur un RDV VN.';
  END IF;

  INSERT INTO relance.rdv_suivi (rdv_id, issue, diac, stock, cs, vd, modele, commentaire)
  VALUES (p_rdv_id, p_issue, coalesce(p_diac, false), coalesce(p_stock, false), coalesce(p_cs, false),
          coalesce(p_vd, false), nullif(btrim(p_modele), ''), nullif(btrim(p_commentaire), ''))
  ON CONFLICT (rdv_id) DO UPDATE
     SET issue = EXCLUDED.issue, diac = EXCLUDED.diac, stock = EXCLUDED.stock, cs = EXCLUDED.cs,
         vd = EXCLUDED.vd, modele = EXCLUDED.modele, commentaire = EXCLUDED.commentaire;

  SELECT jsonb_build_object('rdv_id', su.rdv_id, 'issue', su.issue, 'diac', su.diac, 'stock', su.stock,
           'cs', su.cs, 'vd', su.vd, 'modele', su.modele, 'commentaire', su.commentaire,
           'maj_le', coalesce(su.modifie_le, su.cree_le))
    INTO resultat FROM relance.rdv_suivi su WHERE su.rdv_id = p_rdv_id;
  RETURN resultat;
END $$;


--
-- Name: table_archiver(bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.table_archiver(p_table_id bigint) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  session_id bigint;
  libelle text;
  n int;
BEGIN
  SELECT t.session_plaque_id, t.libelle INTO session_id, libelle
    FROM relance.table_phoning t WHERE t.id = p_table_id;
  IF session_id IS NULL THEN
    RAISE EXCEPTION 'RELANCE: table introuvable.';
  END IF;
  PERFORM relance.exiger_session(session_id);

  UPDATE relance.table_phoning SET archive_le = now() WHERE id = p_table_id;
  UPDATE relance.affectation SET archive_le = now()
   WHERE table_id = p_table_id AND archive_le IS NULL;
  GET DIAGNOSTICS n = ROW_COUNT;

  RETURN jsonb_build_object(
    'archivee', libelle,
    'affectationsArchivees', n,
    'sessionId', session_id::text,
    'message', format(
      '« %s » est archivee, pas supprimee : sa composition reste consultable. %s vendeur(s) reviennent en reserve et restent saisissables par leur chef de site.',
      libelle, n)
  );
END $$;


--
-- Name: table_definir_vendeurs(bigint, bigint[]); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.table_definir_vendeurs(p_table_id bigint, p_vendeur_ids bigint[]) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint;
  session_id bigint;
  ids bigint[] := coalesce(p_vendeur_ids, '{}');
  retires int;
  v bigint;
BEGIN
  SELECT t.session_plaque_id INTO session_id
    FROM relance.table_phoning t WHERE t.id = p_table_id AND t.archive_le IS NULL;
  IF session_id IS NULL THEN
    RAISE EXCEPTION 'RELANCE: table introuvable ou archivee.';
  END IF;
  moi := relance.exiger_session(session_id);

  UPDATE relance.affectation SET archive_le = now()
   WHERE table_id = p_table_id AND archive_le IS NULL AND NOT (vendeur_id = ANY (ids));
  GET DIAGNOSTICS retires = ROW_COUNT;

  -- Un a un, et non en bloc : les triggers R-B.1 (meme plaque), R-B.4 (une seule
  -- table par campagne) et R-B.5 (marque de la table) sont `FOR EACH ROW`. Leurs
  -- messages, deja ecrits pour un humain, remontent tels quels a l'appelant.
  FOREACH v IN ARRAY ids LOOP
    INSERT INTO relance.affectation (table_id, vendeur_id, origine, cree_par)
    VALUES (p_table_id, v, 'manuel', moi)
    ON CONFLICT (table_id, vendeur_id)
      DO UPDATE SET archive_le = NULL, origine = 'manuel';
  END LOOP;

  RETURN jsonb_build_object(
    'retires', retires,
    'effectif', coalesce(array_length(ids, 1), 0),
    'sessionId', session_id::text
  );
END $$;


--
-- Name: tracer_creation(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.tracer_creation() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.utilisateur_courant();
BEGIN
  IF moi IS NOT NULL THEN
    NEW.cree_par := moi;
  END IF;
  RETURN NEW;
END $$;


--
-- Name: tracer_modification_rdv(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.tracer_modification_rdv() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.utilisateur_courant();
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF moi IS NOT NULL THEN NEW.cree_par := moi; END IF;
    RETURN NEW;
  END IF;

  IF moi IS NOT NULL THEN
    NEW.modifie_par := moi;
    -- L'ARCHIVAGE EST UN UPDATE, c'est la seule facon de retirer un RDV. On veut
    -- donc savoir qui l'a retire, et pas seulement qui l'a modifie en dernier.
    IF NEW.archive_le IS NOT NULL AND OLD.archive_le IS NULL THEN
      NEW.archive_par := moi;
    END IF;
  END IF;
  NEW.modifie_le := now();

  -- `cree_par` et `cree_le` ne se reecrivent jamais. Sans cette ligne, un client
  -- pourrait se declarer auteur d'un RDV saisi par quelqu'un d'autre en le
  -- modifiant — l'attribution serait alors reecrivable a volonte.
  NEW.cree_par := OLD.cree_par;
  NEW.cree_le := OLD.cree_le;
  RETURN NEW;
END $$;


--
-- Name: tracer_suivi(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.tracer_suivi() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.utilisateur_courant();
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF moi IS NOT NULL THEN NEW.cree_par := moi; END IF;
    RETURN NEW;
  END IF;
  NEW.modifie_le := now();
  IF moi IS NOT NULL THEN NEW.modifie_par := moi; END IF;
  NEW.cree_par := OLD.cree_par;
  NEW.cree_le := OLD.cree_le;
  RETURN NEW;
END $$;


--
-- Name: utilisateur_courant(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.utilisateur_courant() RETURNS bigint
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
  SELECT u.id
  FROM relance.utilisateur u
  WHERE u.auth_uid = auth.uid()
    AND u.actif
    AND u.archive_le IS NULL
$$;


--
-- Name: utilisateur_definir_encadrement(bigint, text, bigint); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.utilisateur_definir_encadrement(p_site_id bigint, p_role text, p_utilisateur_id bigint DEFAULT NULL::bigint) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_gestion_comptes();
BEGIN
  IF p_role NOT IN ('chef_de_site', 'chef_de_vente_vn', 'chef_de_vente_vo') THEN
    RAISE EXCEPTION 'RELANCE: role invalide : chef_de_site, chef_de_vente_vn ou chef_de_vente_vo.';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM relance.site WHERE id = p_site_id AND archive_le IS NULL) THEN
    RAISE EXCEPTION 'RELANCE: site introuvable ou archive.';
  END IF;

  IF p_utilisateur_id IS NULL THEN
    UPDATE relance.encadrement_site SET archive_le = now()
     WHERE site_id = p_site_id AND role = p_role AND archive_le IS NULL;
    RETURN jsonb_build_object('libere', true, 'siteId', p_site_id::text, 'role', p_role);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM relance.utilisateur
     WHERE id = p_utilisateur_id AND actif AND archive_le IS NULL
  ) THEN
    RAISE EXCEPTION 'RELANCE: ce compte est introuvable ou desactive.';
  END IF;

  -- ON LIBERE LE ROLE AVANT DE LE DONNER. L'unique `(site, role)` refuse deux
  -- titulaires : l'ordre inverse echouerait. Meme piege que sur l'ecran des
  -- encadrants, ou deux requetes lancees en parallele se marchaient dessus.
  UPDATE relance.encadrement_site SET archive_le = now()
   WHERE site_id = p_site_id AND role = p_role AND archive_le IS NULL
     AND utilisateur_id <> p_utilisateur_id;

  INSERT INTO relance.encadrement_site (site_id, role, utilisateur_id, cree_par)
  VALUES (p_site_id, p_role, p_utilisateur_id, moi)
  ON CONFLICT (site_id, role) DO UPDATE
    SET utilisateur_id = EXCLUDED.utilisateur_id, archive_le = NULL;

  RETURN jsonb_build_object('siteId', p_site_id::text, 'role', p_role,
                            'utilisateurId', p_utilisateur_id::text);
END $$;


--
-- Name: utilisateur_definir_roles(bigint, text); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.utilisateur_definir_roles(p_utilisateur_id bigint, p_role text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_gestion_comptes();
  etait_admin boolean;
  autres_admins int;
BEGIN
  IF p_role IS NOT NULL AND p_role NOT IN ('admin', 'direction', 'lecteur') THEN
    RAISE EXCEPTION 'RELANCE: role inconnu : admin, direction ou lecteur.';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM relance.utilisateur WHERE id = p_utilisateur_id) THEN
    RAISE EXCEPTION 'RELANCE: compte introuvable.';
  END IF;

  -- LE DERNIER ADMINISTRATEUR NE PEUT PAS ETRE DEGRADE. Sans ce controle,
  -- l'application devient inadministrable et plus personne ne peut creer de compte
  -- — y compris pour se redonner le role.
  SELECT EXISTS (
    SELECT 1 FROM relance.role_global WHERE utilisateur_id = p_utilisateur_id AND role = 'admin'
  ) INTO etait_admin;

  IF etait_admin AND coalesce(p_role, '') <> 'admin' THEN
    SELECT count(*)::int INTO autres_admins
      FROM relance.role_global rg
      JOIN relance.utilisateur u ON u.id = rg.utilisateur_id
     WHERE rg.role = 'admin' AND rg.utilisateur_id <> p_utilisateur_id
       AND u.actif AND u.archive_le IS NULL;
    IF autres_admins = 0 THEN
      RAISE EXCEPTION 'RELANCE: c''est le dernier administrateur actif : le degrader rendrait l''application inadministrable. Nommer un autre administrateur d''abord.';
    END IF;
  END IF;

  DELETE FROM relance.role_global WHERE utilisateur_id = p_utilisateur_id;
  IF p_role IS NOT NULL THEN
    INSERT INTO relance.role_global (utilisateur_id, role, cree_par)
    VALUES (p_utilisateur_id, p_role, moi);
  END IF;

  RETURN jsonb_build_object('utilisateurId', p_utilisateur_id::text, 'role', to_jsonb(p_role));
END $$;


--
-- Name: utilisateur_purger(bigint, text); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.utilisateur_purger(p_utilisateur_id bigint, p_confirmation text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_gestion_comptes();
  nom_exact text;
  attaches text[] := '{}';
BEGIN
  SELECT u.nom INTO nom_exact FROM relance.utilisateur u WHERE u.id = p_utilisateur_id;
  IF nom_exact IS NULL THEN
    RAISE EXCEPTION 'RELANCE: compte introuvable.';
  END IF;
  IF p_utilisateur_id = moi THEN
    RAISE EXCEPTION 'RELANCE: on ne supprime pas son propre compte.';
  END IF;

  IF EXISTS (SELECT 1 FROM relance.table_phoning WHERE chef_utilisateur_id = p_utilisateur_id) THEN
    attaches := attaches || 'des tables de phoning';
  END IF;
  IF EXISTS (SELECT 1 FROM relance.rdv WHERE cree_par = p_utilisateur_id OR modifie_par = p_utilisateur_id) THEN
    attaches := attaches || 'des RDV saisis';
  END IF;
  IF EXISTS (SELECT 1 FROM relance.rdv_suivi WHERE cree_par = p_utilisateur_id OR modifie_par = p_utilisateur_id) THEN
    attaches := attaches || 'des RDV suivis';
  END IF;
  IF EXISTS (SELECT 1 FROM relance.vendeur WHERE utilisateur_id = p_utilisateur_id) THEN
    attaches := attaches || 'une fiche vendeur';
  END IF;
  IF array_length(attaches, 1) IS NOT NULL THEN
    RAISE EXCEPTION 'RELANCE: % ne peut pas etre supprime : son compte explique encore %. Le laisser desactive conserve cette trace sans lui donner aucun acces.',
      nom_exact, array_to_string(attaches, ', ');
  END IF;

  IF p_confirmation IS DISTINCT FROM nom_exact THEN
    RAISE EXCEPTION 'RELANCE: pour supprimer definitivement, retaper le nom exact. Attendu : « % ».', nom_exact;
  END IF;

  PERFORM set_config('relance.purge_autorisee', 'oui', true);
  -- Le journal DONT CE COMPTE EST LA CIBLE part avec lui ; celui qu'il a ecrit
  -- sur d'autres reste (`cree_par` n'est pas une cle etrangere).
  DELETE FROM relance.journal_compte WHERE cible_id = p_utilisateur_id;
  DELETE FROM relance.encadrement_site WHERE utilisateur_id = p_utilisateur_id;
  DELETE FROM relance.role_global WHERE utilisateur_id = p_utilisateur_id;
  DELETE FROM relance.role_campagne WHERE utilisateur_id = p_utilisateur_id;
  DELETE FROM relance.utilisateur WHERE id = p_utilisateur_id;

  RETURN jsonb_build_object('supprime', nom_exact);
END $$;


--
-- Name: vendeur_appliquer_import_marques(jsonb); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.vendeur_appliquer_import_marques(p_lignes jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_administration();
  l jsonb;
  n int := 0;
  marques bigint[];
BEGIN
  FOR l IN SELECT jsonb_array_elements(coalesce(p_lignes, '[]'::jsonb)) LOOP
    SELECT coalesce(array_agg((m#>>'{}')::bigint), '{}')
      INTO marques
      FROM jsonb_array_elements(coalesce(l->'marqueIds', '[]'::jsonb)) m;

    PERFORM relance.poser_capacites(
      (l->>'vendeurId')::bigint, marques, l->>'typeVehicule', moi);
    n := n + 1;
  END LOOP;

  RETURN jsonb_build_object('appliquees', n);
END $$;


--
-- Name: vendeur_creer(text, bigint, text, bigint[], date); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.vendeur_creer(p_nom text, p_site_id bigint, p_type_vehicule text, p_marque_ids bigint[] DEFAULT '{}'::bigint[], p_date_entree date DEFAULT NULL::date) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_administration();
  nouveau bigint;
  nom text := btrim(coalesce(p_nom, ''));
BEGIN
  IF nom = '' THEN
    RAISE EXCEPTION 'RELANCE: le nom du vendeur est requis.';
  END IF;
  IF p_type_vehicule NOT IN ('VN', 'VO') THEN
    RAISE EXCEPTION 'RELANCE: le metier doit etre VN ou VO.';
  END IF;
  IF p_type_vehicule = 'VN' AND coalesce(array_length(p_marque_ids, 1), 0) = 0 THEN
    RAISE EXCEPTION 'RELANCE: un vendeur VN doit porter au moins une marque, sinon sa grille de saisie serait vide.';
  END IF;

  INSERT INTO relance.vendeur (nom, site_id, type_vehicule, date_entree, cree_par)
  VALUES (nom, p_site_id, p_type_vehicule, p_date_entree, moi)
  RETURNING id INTO nouveau;

  PERFORM relance.poser_capacites(nouveau, p_marque_ids, p_type_vehicule, moi);

  RETURN jsonb_build_object('id', nouveau::text, 'nom', nom);
END $$;


--
-- Name: vendeur_modifier(bigint, text, bigint, date, date, boolean, boolean, text, bigint[]); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.vendeur_modifier(p_vendeur_id bigint, p_nom text DEFAULT NULL::text, p_site_id bigint DEFAULT NULL::bigint, p_date_entree date DEFAULT NULL::date, p_date_sortie date DEFAULT NULL::date, p_archiver boolean DEFAULT NULL::boolean, p_changer_capacites boolean DEFAULT false, p_type_vehicule text DEFAULT NULL::text, p_marque_ids bigint[] DEFAULT NULL::bigint[]) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_administration();
BEGIN
  IF NOT EXISTS (SELECT 1 FROM relance.vendeur WHERE id = p_vendeur_id) THEN
    RAISE EXCEPTION 'RELANCE: vendeur introuvable.';
  END IF;

  UPDATE relance.vendeur
     SET nom = coalesce(btrim(p_nom), nom),
         site_id = coalesce(p_site_id, site_id),
         date_entree = CASE WHEN p_date_entree IS NOT NULL THEN p_date_entree ELSE date_entree END,
         date_sortie = CASE WHEN p_date_sortie IS NOT NULL THEN p_date_sortie ELSE date_sortie END,
         archive_le = CASE
                        WHEN p_archiver IS NULL THEN archive_le
                        WHEN p_archiver THEN coalesce(archive_le, now())
                        ELSE NULL
                      END,
         archive_par = CASE
                         WHEN p_archiver IS TRUE THEN moi
                         WHEN p_archiver IS FALSE THEN NULL
                         ELSE archive_par
                       END
   WHERE id = p_vendeur_id;

  IF p_changer_capacites THEN
    IF p_type_vehicule NOT IN ('VN', 'VO') THEN
      RAISE EXCEPTION 'RELANCE: le metier doit etre VN ou VO.';
    END IF;
    IF p_type_vehicule = 'VN' AND coalesce(array_length(p_marque_ids, 1), 0) = 0 THEN
      RAISE EXCEPTION 'RELANCE: un vendeur VN doit porter au moins une marque.';
    END IF;
    PERFORM relance.poser_capacites(p_vendeur_id, p_marque_ids, p_type_vehicule, moi);
  END IF;

  RETURN jsonb_build_object('id', p_vendeur_id::text);
END $$;


--
-- Name: vendeur_purger(bigint, text); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.vendeur_purger(p_vendeur_id bigint, p_confirmation text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  moi bigint := relance.exiger_administration();
  nom_exact text;
  archive timestamptz;
  nb_rdv int;
  nb_aff int;
BEGIN
  SELECT v.nom, v.archive_le INTO nom_exact, archive
    FROM relance.vendeur v WHERE v.id = p_vendeur_id;
  IF nom_exact IS NULL THEN
    RAISE EXCEPTION 'RELANCE: vendeur introuvable.';
  END IF;

  IF archive IS NULL THEN
    RAISE EXCEPTION 'RELANCE: ce vendeur doit d''abord etre archive. La purge ne s''applique qu''a une fiche deja retiree.';
  END IF;
  IF p_confirmation IS DISTINCT FROM nom_exact THEN
    RAISE EXCEPTION 'RELANCE: pour purger definitivement, retaper le nom exact du vendeur. Attendu : « % ».', nom_exact;
  END IF;

  SELECT count(*)::int INTO nb_rdv FROM relance.rdv WHERE vendeur_id = p_vendeur_id;
  SELECT count(*)::int INTO nb_aff FROM relance.affectation WHERE vendeur_id = p_vendeur_id;

  PERFORM set_config('relance.purge_autorisee', 'oui', true);
  DELETE FROM relance.rdv_suivi WHERE rdv_id IN (SELECT id FROM relance.rdv WHERE vendeur_id = p_vendeur_id);
  DELETE FROM relance.rdv WHERE vendeur_id = p_vendeur_id;
  DELETE FROM relance.mobilisation WHERE vendeur_id = p_vendeur_id;
  DELETE FROM relance.affectation WHERE vendeur_id = p_vendeur_id;
  DELETE FROM relance.vendeur_marque WHERE vendeur_id = p_vendeur_id;
  DELETE FROM relance.vendeur WHERE id = p_vendeur_id;

  RETURN jsonb_build_object(
    'purge', nom_exact, 'nbRdv', nb_rdv, 'nbAffectations', nb_aff,
    'message', format(
      '%s est definitivement supprime, avec %s RDV et %s affectation(s). Les totaux des campagnes concernees ont change. C''est irreversible.',
      nom_exact, nb_rdv, nb_aff)
  );
END $$;


--
-- Name: verifier_affectation_marque_table(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_affectation_marque_table() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public'
    AS $$
DECLARE
  marque_table   bigint;
  libelle_marque text;
  libelle_table  text;
  type_vendeur   text;
  nom_vendeur    text;
  autorise       boolean;
BEGIN
  -- Une ligne archivee ne rattache plus personne.
  IF NEW.archive_le IS NOT NULL THEN
    RETURN NEW;
  END IF;

  SELECT t.marque_id, t.libelle INTO marque_table, libelle_table
  FROM table_phoning t WHERE t.id = NEW.table_id;

  -- Table mixte : aucune contrainte. Cas normal.
  IF marque_table IS NULL THEN
    RETURN NEW;
  END IF;

  SELECT v.type_vehicule, v.nom INTO type_vendeur, nom_vendeur
  FROM vendeur v WHERE v.id = NEW.vendeur_id;

  IF type_vendeur IS NULL THEN
    -- Vendeur inexistant : la cle etrangere s'en charge, on ne masque pas son
    -- message par le notre.
    RETURN NEW;
  END IF;

  SELECT m.libelle INTO libelle_marque FROM marque m WHERE m.id = marque_table;

  IF type_vendeur = 'VO' THEN
    RAISE EXCEPTION
      'RELANCE: % est un vendeur VO et n''a aucune ventilation par marque : il ne peut pas rejoindre la table "%", specialisee %.',
      nom_vendeur, libelle_table, libelle_marque;
  END IF;

  SELECT EXISTS (
    SELECT 1 FROM vendeur_marque vm
    WHERE vm.vendeur_id = NEW.vendeur_id AND vm.marque_id = marque_table
  ) INTO autorise;

  IF NOT autorise THEN
    RAISE EXCEPTION
      'RELANCE: % n''est pas autorise a vendre % : il ne peut pas rejoindre la table "%", specialisee sur cette marque.',
      nom_vendeur, libelle_marque, libelle_table;
  END IF;

  RETURN NEW;
END $$;


--
-- Name: verifier_affectation_meme_plaque(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_affectation_meme_plaque() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public'
    AS $$
DECLARE
  plaque_table   bigint;
  plaque_vendeur bigint;
  libelle_table  text;
  nom_vendeur    text;
BEGIN
  -- Une ligne archivee ne rattache plus personne : inutile de la contraindre, et
  -- la contraindre empecherait d'archiver une affectation devenue invalide apres
  -- un changement de plaque d'un site.
  IF NEW.archive_le IS NOT NULL THEN
    RETURN NEW;
  END IF;

  SELECT s.plaque_id, t.libelle
    INTO plaque_table, libelle_table
  FROM table_phoning  t
  JOIN session_plaque s ON s.id = t.session_plaque_id
  WHERE t.id = NEW.table_id;

  SELECT si.plaque_id, v.nom
    INTO plaque_vendeur, nom_vendeur
  FROM vendeur v
  JOIN site si ON si.id = v.site_id
  WHERE v.id = NEW.vendeur_id;

  IF plaque_table IS NULL OR plaque_vendeur IS NULL THEN
    -- Table ou vendeur inexistant : les cles etrangeres s'en chargent, on ne
    -- masque pas leur message par le notre.
    RETURN NEW;
  END IF;

  IF plaque_table <> plaque_vendeur THEN
    RAISE EXCEPTION
      'RELANCE: % appartient a une autre plaque que la table "%". Une table ne peut contenir que des vendeurs de sa propre plaque.',
      nom_vendeur, libelle_table;
  END IF;

  RETURN NEW;
END $$;


--
-- Name: verifier_affectation_presence(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_affectation_presence() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  v      record;
  c      record;
BEGIN
  -- ARCHIVER RESTE TOUJOURS POSSIBLE. Sans cette sortie, retirer de sa table un
  -- vendeur qui vient de partir serait refuse par le controle cense l'empecher
  -- d'y etre : on ne pourrait plus corriger la situation qu'on denonce.
  IF NEW.archive_le IS NOT NULL THEN
    RETURN NEW;
  END IF;

  SELECT ve.nom, ve.date_entree, ve.date_sortie, ve.archive_le
    INTO v
    FROM relance.vendeur ve
   WHERE ve.id = NEW.vendeur_id;

  SELECT ca.libelle, ca.date_debut, ca.date_fin
    INTO c
    FROM relance.table_phoning tp
    JOIN relance.session_plaque sp ON sp.id = tp.session_plaque_id
    JOIN relance.campagne ca       ON ca.id = sp.campagne_id
   WHERE tp.id = NEW.table_id;

  IF v IS NULL OR c IS NULL THEN
    RETURN NEW; -- les cles etrangeres s'en chargeront, ce n'est pas notre role
  END IF;

  IF v.archive_le IS NOT NULL THEN
    RAISE EXCEPTION 'RELANCE: % est archive : il ne peut etre affecte a aucune table.', v.nom;
  END IF;

  -- MEME REGLE, MOT POUR MOT, QUE `relance.perimetre_saisie`. Une date nulle
  -- signifie << depuis toujours >> ou << pour toujours >> : le fichier source
  -- n'a pas les dates d'entree des 99 vendeurs importes.
  IF v.date_entree IS NOT NULL AND v.date_entree > c.date_fin THEN
    RAISE EXCEPTION
      'RELANCE: % entre le % : il n''etait pas encore la pendant « % » (% au %).',
      v.nom, to_char(v.date_entree, 'DD/MM/YYYY'), c.libelle,
      to_char(c.date_debut, 'DD/MM/YYYY'), to_char(c.date_fin, 'DD/MM/YYYY');
  END IF;

  IF v.date_sortie IS NOT NULL AND v.date_sortie < c.date_debut THEN
    RAISE EXCEPTION
      'RELANCE: % est sorti le % : il n''etait plus la pendant « % » (% au %).',
      v.nom, to_char(v.date_sortie, 'DD/MM/YYYY'), c.libelle,
      to_char(c.date_debut, 'DD/MM/YYYY'), to_char(c.date_fin, 'DD/MM/YYYY');
  END IF;

  RETURN NEW;
END
$$;


--
-- Name: verifier_affectation_unique(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_affectation_unique() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public'
    AS $$
DECLARE
  autre_table text;
BEGIN
  -- Une ligne archivee ne reserve pas la place du vendeur.
  IF NEW.archive_le IS NOT NULL THEN
    RETURN NEW;
  END IF;

  SELECT t_autre.libelle INTO autre_table
  FROM affectation a
  JOIN table_phoning  t_autre ON t_autre.id = a.table_id
  JOIN session_plaque s_autre ON s_autre.id = t_autre.session_plaque_id
  JOIN table_phoning  t_new   ON t_new.id   = NEW.table_id
  JOIN session_plaque s_new   ON s_new.id   = t_new.session_plaque_id
  WHERE a.vendeur_id = NEW.vendeur_id
    AND a.archive_le IS NULL
    -- Cle METIER, pas identite technique : voir l'explication ci-dessus.
    AND a.table_id <> NEW.table_id
    AND s_autre.campagne_id = s_new.campagne_id
  LIMIT 1;

  IF autre_table IS NOT NULL THEN
    RAISE EXCEPTION 'RELANCE: ce vendeur est deja affecte a la table "%" pour cette campagne.', autre_table;
  END IF;

  RETURN NEW;
END $$;


--
-- Name: verifier_campagne_ouverte(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_campagne_ouverte() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public'
    AS $$
DECLARE
  c record;
BEGIN
  SELECT libelle, cloturee, archive_le INTO c
  FROM campagne
  WHERE id = COALESCE(NEW.campagne_id, OLD.campagne_id);

  IF c.cloturee THEN
    RAISE EXCEPTION 'RELANCE: la campagne "%" est cloturee, plus aucune saisie n''est possible.', c.libelle;
  END IF;

  IF c.archive_le IS NOT NULL THEN
    RAISE EXCEPTION 'RELANCE: la campagne "%" est archivee.', c.libelle;
  END IF;

  RETURN COALESCE(NEW, OLD);
END $$;


--
-- Name: verifier_encadrant_actif(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_encadrant_actif() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public'
    AS $$
DECLARE
  nom_compte text;
  compte_actif boolean;
  compte_archive timestamptz;
BEGIN
  IF NEW.archive_le IS NOT NULL THEN
    RETURN NEW;
  END IF;

  SELECT u.nom, u.actif, u.archive_le
    INTO nom_compte, compte_actif, compte_archive
  FROM utilisateur u WHERE u.id = NEW.utilisateur_id;

  IF nom_compte IS NULL THEN
    RETURN NEW; -- la cle etrangere s'en charge
  END IF;

  IF NOT compte_actif OR compte_archive IS NOT NULL THEN
    RAISE EXCEPTION
      'RELANCE: le compte de % est desactive : il ne peut pas encadrer un site. Le reactiver dans la gestion des comptes.',
      nom_compte;
  END IF;

  RETURN NEW;
END $$;


--
-- Name: verifier_marque_autorisee(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_marque_autorisee() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public'
    AS $$
DECLARE
  nom_vendeur text;
  nom_marque  text;
BEGIN
  IF NEW.marque_id IS NULL THEN
    RETURN NEW;
  END IF;

  IF EXISTS (
    SELECT 1 FROM vendeur_marque vm
    WHERE vm.vendeur_id = NEW.vendeur_id AND vm.marque_id = NEW.marque_id
  ) THEN
    RETURN NEW;
  END IF;

  SELECT v.nom INTO nom_vendeur FROM vendeur v WHERE v.id = NEW.vendeur_id;
  SELECT m.libelle INTO nom_marque FROM marque  m WHERE m.id = NEW.marque_id;

  RAISE EXCEPTION 'RELANCE: % n''est pas autorise a vendre %.',
    COALESCE(nom_vendeur, 'ce vendeur'), COALESCE(nom_marque, 'cette marque');
END $$;


--
-- Name: verifier_marque_selon_metier(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_marque_selon_metier() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public'
    AS $$
DECLARE
  v record;
BEGIN
  SELECT nom, type_vehicule INTO v FROM vendeur WHERE id = NEW.vendeur_id;

  IF v.type_vehicule = 'VO' AND NEW.marque_id IS NOT NULL THEN
    RAISE EXCEPTION 'RELANCE: % est un vendeur VO, ses RDV ne portent pas de marque.', v.nom;
  END IF;

  IF v.type_vehicule = 'VN' AND NEW.marque_id IS NULL THEN
    RAISE EXCEPTION 'RELANCE: % est un vendeur VN, la marque du RDV est obligatoire.', v.nom;
  END IF;

  RETURN NEW;
END $$;


--
-- Name: verifier_type_coherent(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_type_coherent() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public'
    AS $$
DECLARE
  v record;
BEGIN
  SELECT nom, type_vehicule INTO v FROM vendeur WHERE id = NEW.vendeur_id;

  IF v.type_vehicule <> NEW.type_vehicule THEN
    RAISE EXCEPTION 'RELANCE: % est un vendeur %, il ne peut pas recevoir un RDV %.',
      v.nom, v.type_vehicule, NEW.type_vehicule;
  END IF;

  RETURN NEW;
END $$;


--
-- Name: verifier_vendeur_dates_contre_rdv(); Type: FUNCTION; Schema: relance; Owner: -
--

CREATE FUNCTION relance.verifier_vendeur_dates_contre_rdv() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'relance', 'public', 'pg_temp'
    AS $$
DECLARE
  conflit record;
BEGIN
  -- Rien a verifier si les deux dates sont inchangees. Un vendeur se modifie
  -- souvent (nom, marques, site) et cette requete n'a pas a tourner pour rien.
  IF TG_OP = 'UPDATE'
     AND NEW.date_entree IS NOT DISTINCT FROM OLD.date_entree
     AND NEW.date_sortie IS NOT DISTINCT FROM OLD.date_sortie THEN
    RETURN NEW;
  END IF;

  IF NEW.date_entree IS NULL AND NEW.date_sortie IS NULL THEN
    RETURN NEW; -- present depuis toujours et pour toujours : rien ne peut clocher
  END IF;

  SELECT c.libelle, c.date_debut, c.date_fin, count(*) AS n
    INTO conflit
    FROM relance.rdv r
    JOIN relance.campagne c ON c.id = r.campagne_id
   WHERE r.vendeur_id = NEW.id
     AND r.archive_le IS NULL
     AND (
       (NEW.date_entree IS NOT NULL AND NEW.date_entree > c.date_fin)
       OR (NEW.date_sortie IS NOT NULL AND NEW.date_sortie < c.date_debut)
     )
   GROUP BY c.id, c.libelle, c.date_debut, c.date_fin
   ORDER BY c.date_debut
   LIMIT 1;

  IF conflit IS NOT NULL THEN
    RAISE EXCEPTION
      'RELANCE: % a % RDV sur « % » (% au %). Ces dates l''en excluraient, et ses RDV disparaitraient des totaux. Archiver ces RDV d''abord si c''est bien voulu.',
      NEW.nom, conflit.n, conflit.libelle,
      to_char(conflit.date_debut, 'DD/MM/YYYY'), to_char(conflit.date_fin, 'DD/MM/YYYY');
  END IF;

  RETURN NEW;
END
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: affectation; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.affectation (
    id bigint NOT NULL,
    table_id bigint NOT NULL,
    vendeur_id bigint NOT NULL,
    origine text DEFAULT 'manuel'::text NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone,
    CONSTRAINT affectation_origine_check CHECK ((origine = ANY (ARRAY['auto'::text, 'manuel'::text])))
);


--
-- Name: affectation_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.affectation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: affectation_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.affectation_id_seq OWNED BY relance.affectation.id;


--
-- Name: campagne; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.campagne (
    id bigint NOT NULL,
    libelle text NOT NULL,
    date_debut date NOT NULL,
    date_fin date NOT NULL,
    cloturee boolean DEFAULT false NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone,
    CONSTRAINT campagne_dates_coherentes_check CHECK ((date_fin >= date_debut))
);


--
-- Name: campagne_creneau; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.campagne_creneau (
    campagne_id bigint NOT NULL,
    code text NOT NULL,
    libelle text NOT NULL,
    ordre integer NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint
);


--
-- Name: campagne_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.campagne_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: campagne_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.campagne_id_seq OWNED BY relance.campagne.id;


--
-- Name: campagne_jour; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.campagne_jour (
    campagne_id bigint NOT NULL,
    jour date NOT NULL,
    ordre integer NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint
);


--
-- Name: encadrement_site; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.encadrement_site (
    id bigint NOT NULL,
    site_id bigint NOT NULL,
    role text NOT NULL,
    utilisateur_id bigint NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT now() NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone,
    CONSTRAINT encadrement_site_role_check CHECK ((role = ANY (ARRAY['chef_de_site'::text, 'chef_de_vente_vn'::text, 'chef_de_vente_vo'::text])))
);


--
-- Name: encadrement_site_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.encadrement_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: encadrement_site_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.encadrement_site_id_seq OWNED BY relance.encadrement_site.id;


--
-- Name: journal_compte; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.journal_compte (
    id bigint NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    cible_id bigint NOT NULL,
    action text NOT NULL,
    detail text,
    CONSTRAINT journal_compte_action_check CHECK ((action = ANY (ARRAY['reinitialisation'::text, 'changement_mot_de_passe'::text, 'desactivation'::text, 'reactivation'::text])))
);


--
-- Name: journal_compte_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.journal_compte_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: journal_compte_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.journal_compte_id_seq OWNED BY relance.journal_compte.id;


--
-- Name: marque; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.marque (
    id bigint NOT NULL,
    code text NOT NULL,
    libelle text NOT NULL,
    ordre integer DEFAULT 0 NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone,
    tableau_ventes boolean DEFAULT true NOT NULL
);


--
-- Name: marque_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.marque_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: marque_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.marque_id_seq OWNED BY relance.marque.id;


--
-- Name: mobilisation; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.mobilisation (
    id bigint NOT NULL,
    campagne_id bigint NOT NULL,
    vendeur_id bigint NOT NULL,
    mobilise boolean DEFAULT false NOT NULL,
    motif text,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    modifie_le timestamp(6) with time zone
);


--
-- Name: mobilisation_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.mobilisation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: mobilisation_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.mobilisation_id_seq OWNED BY relance.mobilisation.id;


--
-- Name: objectif_vente; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.objectif_vente (
    id bigint NOT NULL,
    campagne_id bigint NOT NULL,
    site_id bigint NOT NULL,
    marque_id bigint NOT NULL,
    ventes integer,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    modifie_le timestamp(6) with time zone,
    CONSTRAINT objectif_vente_ventes_check CHECK (((ventes IS NULL) OR (ventes >= 0)))
);


--
-- Name: objectif_vente_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.objectif_vente_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: objectif_vente_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.objectif_vente_id_seq OWNED BY relance.objectif_vente.id;


--
-- Name: role_campagne; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.role_campagne (
    id bigint NOT NULL,
    campagne_id bigint NOT NULL,
    utilisateur_id bigint NOT NULL,
    role text NOT NULL,
    plaque_id bigint,
    site_id bigint,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone,
    CONSTRAINT role_campagne_portee_check CHECK ((((role = 'chef_plaque'::text) AND (plaque_id IS NOT NULL) AND (site_id IS NULL)) OR ((role = 'chef_site'::text) AND (site_id IS NOT NULL) AND (plaque_id IS NULL)))),
    CONSTRAINT role_campagne_role_check CHECK ((role = ANY (ARRAY['chef_plaque'::text, 'chef_site'::text])))
);


--
-- Name: site; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.site (
    id bigint NOT NULL,
    code text NOT NULL,
    libelle text NOT NULL,
    plaque_id bigint NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone,
    tableau_ventes boolean DEFAULT true NOT NULL
);


--
-- Name: vendeur; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.vendeur (
    id bigint NOT NULL,
    nom text NOT NULL,
    site_id bigint NOT NULL,
    utilisateur_id bigint,
    date_entree date,
    date_sortie date,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    capacites_confirmees_le timestamp(6) with time zone,
    capacites_confirmees_par bigint,
    type_vehicule text NOT NULL,
    archive_le timestamp(6) with time zone,
    archive_par bigint,
    CONSTRAINT vendeur_dates_coherentes_check CHECK (((date_sortie IS NULL) OR (date_entree IS NULL) OR (date_sortie >= date_entree))),
    CONSTRAINT vendeur_type_check CHECK ((type_vehicule = ANY (ARRAY['VN'::text, 'VO'::text])))
);


--
-- Name: perimetre_suivi; Type: VIEW; Schema: relance; Owner: -
--

CREATE VIEW relance.perimetre_suivi AS
 SELECT c.id AS campagne_id,
    v.id AS vendeur_id
   FROM (relance.campagne c
     CROSS JOIN relance.vendeur v)
  WHERE ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL) AND (v.archive_le IS NULL) AND ((v.date_entree IS NULL) OR (v.date_entree <= c.date_fin)) AND ((v.date_sortie IS NULL) OR (v.date_sortie >= c.date_debut)) AND (( SELECT relance.peut_administrer() AS peut_administrer) OR (EXISTS ( SELECT 1
           FROM (relance.role_campagne rc
             JOIN relance.site s ON ((s.id = v.site_id)))
          WHERE ((rc.utilisateur_id = ( SELECT relance.utilisateur_courant() AS utilisateur_courant)) AND (rc.campagne_id = c.id) AND (rc.role = 'chef_plaque'::text) AND (rc.plaque_id = s.plaque_id) AND (rc.archive_le IS NULL)))) OR (EXISTS ( SELECT 1
           FROM relance.role_campagne rc
          WHERE ((rc.utilisateur_id = ( SELECT relance.utilisateur_courant() AS utilisateur_courant)) AND (rc.campagne_id = c.id) AND (rc.role = 'chef_site'::text) AND (rc.site_id = v.site_id) AND (rc.archive_le IS NULL)))) OR (EXISTS ( SELECT 1
           FROM relance.encadrement_site es
          WHERE ((es.utilisateur_id = ( SELECT relance.utilisateur_courant() AS utilisateur_courant)) AND (es.site_id = v.site_id) AND (es.archive_le IS NULL))))));


--
-- Name: session_plaque; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.session_plaque (
    id bigint NOT NULL,
    campagne_id bigint NOT NULL,
    plaque_id bigint NOT NULL,
    mode text DEFAULT 'par_site'::text NOT NULL,
    effectif_cible_table integer,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone,
    CONSTRAINT session_plaque_mode_check CHECK ((mode = ANY (ARRAY['par_site'::text, 'par_table'::text])))
);


--
-- Name: table_phoning; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.table_phoning (
    id bigint NOT NULL,
    session_plaque_id bigint NOT NULL,
    libelle text NOT NULL,
    chef_utilisateur_id bigint,
    ordre integer DEFAULT 0 NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone,
    marque_id bigint
);


--
-- Name: perimetre_saisie; Type: VIEW; Schema: relance; Owner: -
--

CREATE VIEW relance.perimetre_saisie AS
 SELECT ps.campagne_id,
    ps.vendeur_id
   FROM relance.perimetre_suivi ps
UNION
 SELECT c.id AS campagne_id,
    v.id AS vendeur_id
   FROM (relance.campagne c
     CROSS JOIN relance.vendeur v)
  WHERE ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL) AND (v.archive_le IS NULL) AND ((v.date_entree IS NULL) OR (v.date_entree <= c.date_fin)) AND ((v.date_sortie IS NULL) OR (v.date_sortie >= c.date_debut)) AND (EXISTS ( SELECT 1
           FROM ((relance.affectation a
             JOIN relance.table_phoning t ON ((t.id = a.table_id)))
             JOIN relance.session_plaque sp ON ((sp.id = t.session_plaque_id)))
          WHERE ((a.vendeur_id = v.id) AND (a.archive_le IS NULL) AND (t.archive_le IS NULL) AND (t.chef_utilisateur_id = ( SELECT relance.utilisateur_courant() AS utilisateur_courant)) AND (sp.campagne_id = c.id) AND (sp.archive_le IS NULL)))));


--
-- Name: plaque; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.plaque (
    id bigint NOT NULL,
    libelle text NOT NULL,
    alias text,
    ordre integer DEFAULT 0 NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone
);


--
-- Name: plaque_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.plaque_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: plaque_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.plaque_id_seq OWNED BY relance.plaque.id;


--
-- Name: rdv; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.rdv (
    id bigint NOT NULL,
    campagne_id bigint NOT NULL,
    vendeur_id bigint NOT NULL,
    jour date NOT NULL,
    creneau_code text NOT NULL,
    marque_id bigint,
    type_vehicule text NOT NULL,
    client text NOT NULL,
    commentaire text,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    modifie_le timestamp(6) with time zone,
    modifie_par bigint,
    archive_le timestamp(6) with time zone,
    archive_par bigint,
    cle_client uuid,
    source text DEFAULT 'relance'::text NOT NULL,
    CONSTRAINT rdv_client_non_vide_check CHECK ((length(btrim(client)) > 0)),
    CONSTRAINT rdv_source_check CHECK ((source = ANY (ARRAY['relance'::text, 'showroom'::text]))),
    CONSTRAINT rdv_type_vehicule_check CHECK ((type_vehicule = ANY (ARRAY['VN'::text, 'VO'::text])))
);


--
-- Name: rdv_agrege; Type: VIEW; Schema: relance; Owner: -
--

CREATE VIEW relance.rdv_agrege AS
 SELECT id,
    campagne_id,
    vendeur_id,
    jour,
    creneau_code,
    marque_id,
    type_vehicule,
    cree_le,
    archive_le,
    source
   FROM relance.rdv r
  WHERE (( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL);


--
-- Name: rdv_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.rdv_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rdv_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.rdv_id_seq OWNED BY relance.rdv.id;


--
-- Name: rdv_suivi; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.rdv_suivi (
    rdv_id bigint NOT NULL,
    issue text,
    diac boolean DEFAULT false NOT NULL,
    stock boolean DEFAULT false NOT NULL,
    cs boolean DEFAULT false NOT NULL,
    modele text,
    commentaire text,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    modifie_le timestamp(6) with time zone,
    modifie_par bigint,
    vd boolean DEFAULT false NOT NULL,
    CONSTRAINT rdv_suivi_avantages_check CHECK (((issue = 'commande'::text) OR ((NOT diac) AND (NOT stock) AND (NOT cs)))),
    CONSTRAINT rdv_suivi_issue_check CHECK (((issue IS NULL) OR (issue = ANY (ARRAY['commande'::text, 'offre_en_cours'::text, 'annule'::text, 'no_show'::text, 'clos_sans_suite'::text])))),
    CONSTRAINT rdv_suivi_vd_check CHECK (((NOT vd) OR stock))
);


--
-- Name: role_campagne_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.role_campagne_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: role_campagne_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.role_campagne_id_seq OWNED BY relance.role_campagne.id;


--
-- Name: role_global; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.role_global (
    utilisateur_id bigint NOT NULL,
    role text NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    CONSTRAINT role_global_role_check CHECK ((role = ANY (ARRAY['admin'::text, 'direction'::text, 'lecteur'::text])))
);


--
-- Name: session_plaque_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.session_plaque_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: session_plaque_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.session_plaque_id_seq OWNED BY relance.session_plaque.id;


--
-- Name: site_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: site_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.site_id_seq OWNED BY relance.site.id;


--
-- Name: table_phoning_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.table_phoning_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: table_phoning_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.table_phoning_id_seq OWNED BY relance.table_phoning.id;


--
-- Name: utilisateur; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.utilisateur (
    id bigint NOT NULL,
    login_id text NOT NULL,
    password_hash text NOT NULL,
    nom text NOT NULL,
    actif boolean DEFAULT true NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint,
    archive_le timestamp(6) with time zone,
    auth_uid uuid,
    doit_changer_mdp boolean DEFAULT false NOT NULL
);


--
-- Name: COLUMN utilisateur.auth_uid; Type: COMMENT; Schema: relance; Owner: -
--

COMMENT ON COLUMN relance.utilisateur.auth_uid IS 'Identifiant Supabase Auth (auth.users.id). NULL tant que le compte n''a pas ete relie. Aucune FK : voir la migration 20260831200000.';


--
-- Name: utilisateur_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.utilisateur_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: utilisateur_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.utilisateur_id_seq OWNED BY relance.utilisateur.id;


--
-- Name: vendeur_id_seq; Type: SEQUENCE; Schema: relance; Owner: -
--

CREATE SEQUENCE relance.vendeur_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vendeur_id_seq; Type: SEQUENCE OWNED BY; Schema: relance; Owner: -
--

ALTER SEQUENCE relance.vendeur_id_seq OWNED BY relance.vendeur.id;


--
-- Name: vendeur_marque; Type: TABLE; Schema: relance; Owner: -
--

CREATE TABLE relance.vendeur_marque (
    vendeur_id bigint NOT NULL,
    marque_id bigint NOT NULL,
    cree_le timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cree_par bigint
);


--
-- Name: vente; Type: VIEW; Schema: relance; Owner: -
--

CREATE VIEW relance.vente AS
 SELECT r.id AS rdv_id,
    r.campagne_id,
    v.site_id,
    r.marque_id,
    r.jour,
    r.type_vehicule,
    r.source,
    su.diac,
    su.stock,
    su.cs,
    su.vd
   FROM ((relance.rdv r
     JOIN relance.rdv_suivi su ON (((su.rdv_id = r.id) AND (su.issue = 'commande'::text))))
     JOIN relance.vendeur v ON ((v.id = r.vendeur_id)))
  WHERE ((r.archive_le IS NULL) AND (( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: affectation id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.affectation ALTER COLUMN id SET DEFAULT nextval('relance.affectation_id_seq'::regclass);


--
-- Name: campagne id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.campagne ALTER COLUMN id SET DEFAULT nextval('relance.campagne_id_seq'::regclass);


--
-- Name: encadrement_site id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.encadrement_site ALTER COLUMN id SET DEFAULT nextval('relance.encadrement_site_id_seq'::regclass);


--
-- Name: journal_compte id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.journal_compte ALTER COLUMN id SET DEFAULT nextval('relance.journal_compte_id_seq'::regclass);


--
-- Name: marque id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.marque ALTER COLUMN id SET DEFAULT nextval('relance.marque_id_seq'::regclass);


--
-- Name: mobilisation id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.mobilisation ALTER COLUMN id SET DEFAULT nextval('relance.mobilisation_id_seq'::regclass);


--
-- Name: objectif_vente id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.objectif_vente ALTER COLUMN id SET DEFAULT nextval('relance.objectif_vente_id_seq'::regclass);


--
-- Name: plaque id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.plaque ALTER COLUMN id SET DEFAULT nextval('relance.plaque_id_seq'::regclass);


--
-- Name: rdv id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.rdv ALTER COLUMN id SET DEFAULT nextval('relance.rdv_id_seq'::regclass);


--
-- Name: role_campagne id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.role_campagne ALTER COLUMN id SET DEFAULT nextval('relance.role_campagne_id_seq'::regclass);


--
-- Name: session_plaque id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.session_plaque ALTER COLUMN id SET DEFAULT nextval('relance.session_plaque_id_seq'::regclass);


--
-- Name: site id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.site ALTER COLUMN id SET DEFAULT nextval('relance.site_id_seq'::regclass);


--
-- Name: table_phoning id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.table_phoning ALTER COLUMN id SET DEFAULT nextval('relance.table_phoning_id_seq'::regclass);


--
-- Name: utilisateur id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.utilisateur ALTER COLUMN id SET DEFAULT nextval('relance.utilisateur_id_seq'::regclass);


--
-- Name: vendeur id; Type: DEFAULT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.vendeur ALTER COLUMN id SET DEFAULT nextval('relance.vendeur_id_seq'::regclass);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
c3320f35-1cb1-48d3-b154-011a8cfaf156	663bc3222aca5b5f031a3e92f31e1c27d71100c01dd878528b10f6668995fd12	2026-09-01 16:00:01.666769+00	20260901160000_vendeur_dates_contre_rdv	\N	\N	2026-09-01 16:00:01.339588+00	1
034c6337-8f5f-4cc4-bb2c-b0a47266601f	f91fef5197f9ce6f31beb50a6c1cd616ff2e1a0658fcec8952e970f903516ff6	2026-08-31 20:48:17.187601+00	20260828083906_init	\N	\N	2026-08-31 20:48:16.84487+00	1
7e21ca07-0a16-4b73-8f43-e2627375601e	a8435a7dd2f4a6ec9ab7caded693d28463f28a31374df732081b7270e75b5706	2026-08-31 20:48:22.175806+00	20260831201000_rls_portail	\N	\N	2026-08-31 20:48:21.816726+00	1
21ebccf8-3bd5-49c5-a141-e839326a990e	726e168a5281c8963e0ee703fcc9262701c3834d78357c29f95d8147be34a65b	2026-08-31 20:48:17.518104+00	20260828084443_table_phoning_unique	\N	\N	2026-08-31 20:48:17.276477+00	1
f7dd0868-33b8-43e0-a180-6bfa509c20ad	79aafe37634a24daf6351b054e78b9db3cd0d5a7121660e598caedb5aa03240b	2026-08-31 20:48:17.855516+00	20260828084642_marque_code_unique	\N	\N	2026-08-31 20:48:17.608949+00	1
99eae4f4-3ee6-4891-9cfc-18e509016f89	e7873192844e9ad922fdf6d70142b21984b587780f0b30bd7452ea807202651c	2026-08-31 20:48:18.340105+00	20260828090000_invariants	\N	\N	2026-08-31 20:48:17.982293+00	1
d85e8a26-c0b2-465b-be9a-0a0d4cfa03fc	bb7aa8e6c7e08b6ed80c3b0a89ba1a792cc8e9549373777c8e46ce2ddb51f729	2026-08-31 20:48:22.501309+00	20260831202000_triggers_hors_rls	\N	\N	2026-08-31 20:48:22.270654+00	1
a0a1e28b-b64d-4354-ba11-12bef5adf224	48b9288ceed6ca51d370a90c74acda08e77d832ac1014e71eb8bbc6e1f1e6e47	2026-08-31 20:48:18.696869+00	20260828091000_fix_affectation_unique	\N	\N	2026-08-31 20:48:18.452815+00	1
3b5dc4f8-e316-451a-ab05-b74573b23408	08c5fe8ea9d6cb607235f8a64e26fab12d280d0621d17e30d87edd3560417e92	2026-08-31 20:48:19.040117+00	20260828092952_marques_confirmees	\N	\N	2026-08-31 20:48:18.792129+00	1
9a7d8fbc-e799-4c8c-a7f3-29e7633c32ff	4ef1fe153c9bd997429985c5a63f1dae534f2c907fb975cefd10ff2bb9fca77a	2026-08-31 20:48:19.476783+00	20260828121219_vendeur_types_vehicule	\N	\N	2026-08-31 20:48:19.153909+00	1
5eb12b05-cf20-4f66-a0e5-3d9319656d4b	35f523c5ed80dc674eec7bcf015877273434687ab542191724d90c43c3ddaf03	2026-08-31 20:48:22.873781+00	20260831203000_rdv_agrege_compte_actif	\N	\N	2026-08-31 20:48:22.603913+00	1
5b310058-b12b-4151-9848-f467b0bcafbe	906125bc6e4ff14a63a707496d670e8c52ee5eef41be21ee430980b6862d7cfb	2026-08-31 20:48:19.883913+00	20260828140000_vendeur_type_scalaire	\N	\N	2026-08-31 20:48:19.603046+00	1
687baad8-4669-4546-aea8-74e8e6866700	6782c4a8e1c582798e7ab8ef8657cd69725ef1a7e2496aa33025895cdd5a3e05	2026-08-31 20:48:20.230605+00	20260828160000_affectation_meme_plaque	\N	\N	2026-08-31 20:48:19.961444+00	1
7f71923a-d1dd-4f78-a801-5394e5d1f3e2	e2fc62aeae4fdf8ab3f2b3b0ba2d595874fae0203ce025d4c0d3b83dd8e0de50	2026-09-03 08:15:13.054569+00	20260903065812_revoquer_execute_public	\N	\N	2026-09-03 08:15:12.730081+00	1
0b998f60-c78e-47a9-9aea-01e5f0bc24bf	b246a47f533735c55fe3f82fda03bbb0e51ca7e1b2b07d49edd908da7cbbebaa	2026-08-31 20:48:20.594508+00	20260831090000_table_specialisation	\N	\N	2026-08-31 20:48:20.335715+00	1
4fa87ad9-c2fd-4986-8536-7a85f67d65f2	1324cfd0f87dd0599a85c63ba2621853cae0fd29a20500bbc1897ff832abfc1b	2026-08-31 21:08:48.58242+00	20260831210000_rpc_privilegies	\N	\N	2026-08-31 21:08:48.148814+00	1
5ecabbc8-906f-4025-b3d0-51143e3ce56e	b9bc25688197a550d562cefbe3f58cb46e4db8861bbe30070e99ecd933798be0	2026-08-31 20:48:20.995261+00	20260831140000_encadrement_et_purge	\N	\N	2026-08-31 20:48:20.702141+00	1
0b9543be-ee5c-424b-8618-f760e5afb69d	4b915a14c0e99774f99d3cd91e3a544cf77db6fb37b171ace4ff3a2edd22c211	2026-08-31 20:48:21.387548+00	20260831180000_encadrants_comptes	\N	\N	2026-08-31 20:48:21.093345+00	1
a4cbbf19-ca40-438e-98ae-cba138c30915	80d560b4b705f634e6e539b55f834fa8300025c544398a9720839e5fe8a9c530	2026-08-31 20:48:21.71838+00	20260831200000_auth_uid	\N	\N	2026-08-31 20:48:21.486458+00	1
af3ddc2b-6923-4c38-a2d4-2443cae856c0	ed8b975bc704873bf4b3afc146e4176f398a2ead2d3a7c65cf59e167cd9349c6	2026-08-31 21:42:17.980581+00	20260831220000_diffusion_realtime	\N	\N	2026-08-31 21:42:17.649765+00	1
f636e087-8005-42d6-bee4-4fadb331046f	94424ab8d41e81cde13e738c3aa9449c585b3978c5bf2702cca2376aa938a11e	2026-10-05 12:09:45.909163+00	20261005120818_ventes_tableau_ventes	\N	\N	2026-10-05 12:09:45.321576+00	1
6e95a6cc-d076-49dd-95a6-4e6f2af3e834	cd06454f8dc43f8dac50b3c8220beeb492691d374f495b107fbdffae4758b6fa	2026-08-31 21:59:32.501785+00	20260831230000_canal_sans_deux_points	\N	\N	2026-08-31 21:59:32.192017+00	1
7e1d19d5-af24-4a13-96bc-521473b4fba5	6dc4f8ee43885303e7750b25037c47f3301e4ddb1276cae8302af6bdb6bcc634	2026-09-08 16:05:07.786914+00	20260908160000_perimetre_saisie_appel_unique	\N	\N	2026-09-08 16:05:07.359938+00	1
28aa5e09-b1e9-4c3b-a2c5-a56dc0f1e2d8	8d88252bc75fa3bc6ebb0954d538d4d65d23f7f2527b092ac6f89390f533fd2e	2026-08-31 22:35:04.542758+00	20260901090000_droits_service_role	\N	\N	2026-08-31 22:35:04.201542+00	1
2910245a-bde1-452f-bf19-84b49fb01ed6	03ce6c39b993d79520a474350abe48c953e9a2993ecd95c30a44776447bfeb5a	2026-09-01 15:46:46.856505+00	20260901120000_affectation_vendeur_present	\N	\N	2026-09-01 15:46:46.481453+00	1
e8f1d103-19ff-4f4f-9c3a-47cef1d3f2ba	e2f2082ecbb1fd8d6970ac75fd2bc782474dcedda8069ea427c98da0affeab61	2026-10-03 12:14:33.079288+00	20261003180000_sante_base	\N	\N	2026-10-03 12:14:32.825478+00	1
41a6b73b-ec31-4daf-bf58-418ad6db6777	f6ed63755e308b9f691cf8844f1e7590313ac394e2032395c5513087c792621f	2026-10-02 08:57:58.269801+00	20261002090000_campagne_creer	\N	\N	2026-10-02 08:57:57.890069+00	1
4fa0fa29-3252-406e-bd96-da8ee97b5e6e	1edad7ca4f37e40fcc8cb93349036281c9d6778d5fc92e0f78c834d78efa0cfc	2026-10-02 22:04:19.786022+00	20261002204318_robustesse_seance	\N	\N	2026-10-02 22:04:19.439722+00	1
82bb9c51-c21e-4426-be6d-d11e43c80345	f92c90d5ee9508728346ba2f9e70c0e4bc6c02587d3ac1cfd72bcd1687dd6ef5	2026-10-05 10:03:57.092962+00	20261005090000_suivi_no_show	\N	\N	2026-10-05 10:03:56.74726+00	1
3d6ae618-4a22-4d83-8b3c-2e042de6d0fc	d7b177c9a2476d172862a68beadd9a62434938de94ed61b6d4316cec05f8b0a0	2026-10-02 22:04:20.138376+00	20261002213103_suivi_effectifs_comptes	\N	\N	2026-10-02 22:04:19.852981+00	1
4864570e-5015-475a-a910-d9af9be8597c	0a990ae985521834c807a99078b9467a3920a1a1dd91d96ae9e52be3369c9358	2026-10-05 11:56:02.925293+00	20261005114344_ventes_vd_objectifs	\N	\N	2026-10-05 11:56:02.401664+00	1
fa69ac98-18c7-4a57-b891-32b7fd7993a5	e84b853800fa3a62be7a1a61eaf69531da2d11c5745a80cb915e620264e1f24c	2026-10-08 12:33:04.651867+00	20261008090000_suivi_perimetre_sites	\N	\N	2026-10-08 12:33:04.168478+00	1
75969ffb-59dd-4cb6-98d5-48f19c3c40ed	e42609aeec0b14758b7db4df7ead758168eeeef62855ce99ef90038f4e55b0c2	2026-10-08 12:33:05.074776+00	20261008090100_showroom_perimetre_suivi	\N	\N	2026-10-08 12:33:04.772689+00	1
\.


--
-- Data for Name: affectation; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.affectation (id, table_id, vendeur_id, origine, cree_le, cree_par, archive_le) FROM stdin;
1	1	20	manuel	2026-08-31 20:50:22.754+00	\N	\N
2	1	21	manuel	2026-08-31 20:50:22.841+00	\N	\N
3	1	10	manuel	2026-08-31 20:50:22.891+00	\N	\N
4	1	11	manuel	2026-08-31 20:50:22.931+00	\N	\N
5	1	27	manuel	2026-08-31 20:50:22.966+00	\N	\N
6	1	5	manuel	2026-08-31 20:50:23.066+00	\N	\N
7	2	25	manuel	2026-08-31 20:50:23.103+00	\N	\N
8	2	22	manuel	2026-08-31 20:50:23.146+00	\N	\N
9	2	29	manuel	2026-08-31 20:50:23.182+00	\N	\N
10	2	15	manuel	2026-08-31 20:50:23.224+00	\N	\N
11	2	3	manuel	2026-08-31 20:50:23.27+00	\N	\N
12	2	4	manuel	2026-08-31 20:50:23.32+00	\N	\N
13	3	13	manuel	2026-08-31 20:50:23.362+00	\N	\N
14	3	23	manuel	2026-08-31 20:50:23.421+00	\N	\N
15	3	16	manuel	2026-08-31 20:50:23.47+00	\N	\N
16	3	17	manuel	2026-08-31 20:50:23.523+00	\N	\N
17	3	26	manuel	2026-08-31 20:50:23.602+00	\N	\N
18	3	30	manuel	2026-08-31 20:50:23.671+00	\N	\N
19	4	24	manuel	2026-08-31 20:50:23.725+00	\N	\N
20	4	12	manuel	2026-08-31 20:50:23.775+00	\N	\N
21	4	18	manuel	2026-08-31 20:50:23.824+00	\N	\N
22	4	2	manuel	2026-08-31 20:50:23.881+00	\N	\N
23	4	6	manuel	2026-08-31 20:50:23.92+00	\N	\N
24	4	7	manuel	2026-08-31 20:50:23.98+00	\N	\N
25	5	28	manuel	2026-08-31 20:50:24.017+00	\N	\N
26	5	8	manuel	2026-08-31 20:50:24.061+00	\N	\N
27	5	9	manuel	2026-08-31 20:50:24.102+00	\N	\N
28	5	1	manuel	2026-08-31 20:50:24.162+00	\N	\N
29	5	19	manuel	2026-08-31 20:50:24.295+00	\N	\N
30	5	14	manuel	2026-08-31 20:50:24.34+00	\N	\N
31	6	62	manuel	2026-08-31 20:50:24.383+00	\N	\N
32	6	60	manuel	2026-08-31 20:50:24.444+00	\N	\N
33	6	57	manuel	2026-08-31 20:50:24.5+00	\N	\N
34	6	54	manuel	2026-08-31 20:50:24.54+00	\N	\N
35	6	68	manuel	2026-08-31 20:50:24.583+00	\N	\N
36	6	65	manuel	2026-08-31 20:50:24.628+00	\N	\N
37	7	55	manuel	2026-08-31 20:50:24.674+00	\N	\N
38	7	56	manuel	2026-08-31 20:50:24.723+00	\N	\N
39	7	66	manuel	2026-08-31 20:50:24.782+00	\N	\N
40	7	67	manuel	2026-08-31 20:50:24.84+00	\N	\N
41	7	61	manuel	2026-08-31 20:50:24.885+00	\N	\N
42	7	70	manuel	2026-08-31 20:50:24.943+00	\N	\N
43	8	53	manuel	2026-08-31 20:50:24.99+00	\N	\N
44	8	58	manuel	2026-08-31 20:50:25.031+00	\N	\N
45	8	59	manuel	2026-08-31 20:50:25.089+00	\N	\N
46	8	69	manuel	2026-08-31 20:50:25.127+00	\N	\N
47	8	63	manuel	2026-08-31 20:50:25.168+00	\N	\N
48	8	64	manuel	2026-08-31 20:50:25.247+00	\N	\N
2469	574	4	manuel	2026-10-03 15:35:57.26025+00	92	\N
1486	12	160	manuel	2026-09-08 07:30:14.119778+00	92	\N
961	146	63	manuel	2026-09-02 09:36:56.215824+00	787	2026-09-08 08:00:51.080661+00
503	9	27	manuel	2026-09-01 16:24:32.369555+00	92	\N
975	146	55	manuel	2026-09-02 09:37:18.5654+00	787	\N
122	9	17	manuel	2026-09-01 15:36:17.114882+00	92	\N
123	9	160	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:28:00.741819+00
966	146	68	manuel	2026-09-02 09:37:08.756176+00	787	\N
921	144	881	manuel	2026-09-02 09:29:26.909987+00	787	2026-09-08 08:00:58.958651+00
933	144	57	manuel	2026-09-02 09:30:07.304445+00	787	\N
1003	10	212	manuel	2026-09-02 12:33:32.457659+00	92	2026-09-08 07:27:36.404195+00
514	10	213	manuel	2026-09-01 16:24:34.424935+00	92	\N
527	10	25	manuel	2026-09-01 16:25:56.052063+00	92	2026-09-01 16:26:12.847571+00
120	9	11	auto	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
121	9	16	auto	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
2024	573	8	manuel	2026-10-03 09:45:53.068862+00	92	2026-10-03 15:37:57.145305+00
126	9	25	auto	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
404	9	213	manuel	2026-09-01 16:18:22.397405+00	92	2026-09-01 16:24:34.330589+00
2037	575	3215	manuel	2026-10-03 09:46:51.827285+00	92	\N
2496	573	18	manuel	2026-10-03 15:36:47.617171+00	92	2026-10-05 07:46:56.920874+00
380	10	15	manuel	2026-09-01 16:15:50.843134+00	92	2026-09-01 16:29:39.236415+00
2026	574	5	manuel	2026-10-03 09:46:08.720705+00	92	\N
398	13	18	manuel	2026-09-01 16:17:49.152953+00	92	2026-09-01 16:22:39.790055+00
118	12	27	manuel	2026-09-01 15:33:01.648281+00	92	2026-09-01 15:36:17.114882+00
2502	575	3216	manuel	2026-10-03 15:37:03.60572+00	92	\N
940	145	66	manuel	2026-09-02 09:31:49.297693+00	787	\N
2050	574	18	manuel	2026-10-03 09:47:33.219649+00	92	2026-10-03 15:36:47.488208+00
954	145	882	manuel	2026-09-02 09:36:22.618244+00	787	\N
945	145	70	manuel	2026-09-02 09:32:11.551854+00	787	\N
634	10	8	manuel	2026-09-01 16:26:49.055013+00	92	2026-09-02 12:32:25.575309+00
420	12	28	manuel	2026-09-01 16:19:11.844782+00	92	2026-09-01 16:26:10.134249+00
377	13	3	manuel	2026-09-01 16:14:54.37136+00	92	2026-09-01 16:27:58.053286+00
492	9	212	manuel	2026-09-01 16:24:29.121256+00	92	2026-09-02 12:33:32.338735+00
2043	573	160	manuel	2026-10-03 09:47:20.684394+00	92	\N
2014	572	6	manuel	2026-10-03 09:45:08.638528+00	92	\N
2021	572	26	manuel	2026-10-03 09:45:33.968497+00	92	\N
2525	575	18	manuel	2026-10-05 07:46:57.025402+00	92	\N
2029	573	2	manuel	2026-10-03 09:46:18.676372+00	92	\N
3166	1082	55	manuel	2026-10-05 12:14:38.683084+00	787	\N
386	10	17	manuel	2026-09-01 16:17:01.059119+00	92	2026-09-01 16:26:47.012437+00
2060	575	10	manuel	2026-10-03 09:48:00.514024+00	92	\N
125	9	8	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:26:48.967169+00
918	144	56	manuel	2026-09-01 16:49:47.200314+00	787	2026-09-04 15:10:50.024022+00
3175	1082	65	manuel	2026-10-05 12:14:51.519568+00	787	\N
542	10	28	manuel	2026-09-01 16:26:10.237926+00	92	\N
557	12	25	manuel	2026-09-01 16:26:12.935278+00	92	2026-09-08 07:28:53.386443+00
3181	1083	53	manuel	2026-10-05 12:15:10.099771+00	787	\N
480	12	211	manuel	2026-09-01 16:24:10.226691+00	92	\N
458	11	18	manuel	2026-09-01 16:22:39.942687+00	92	\N
119	11	12	manuel	2026-09-01 15:33:24.773285+00	92	\N
355	11	29	manuel	2026-09-01 16:10:29.873494+00	92	\N
445	12	4	manuel	2026-09-01 16:21:19.493923+00	92	2026-09-08 07:26:54.04251+00
3185	1083	57	manuel	2026-10-05 12:15:13.076862+00	787	\N
3161	1082	61	manuel	2026-10-05 12:14:18.704629+00	787	2026-10-05 15:01:28.927787+00
3196	1084	56	manuel	2026-10-05 12:15:34.632086+00	787	\N
3205	1084	70	manuel	2026-10-05 12:15:48.561241+00	787	\N
295	13	9	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:09:58.492635+00
284	11	8	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:42.573896+00
416	10	160	manuel	2026-09-01 16:19:00.878121+00	92	2026-09-01 16:26:31.851005+00
289	12	17	auto	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:04.929551+00
143	12	21	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:29:36.691409+00
917	144	66	manuel	2026-09-01 16:47:05.541155+00	787	2026-09-01 16:47:07.940102+00
133	11	7	auto	2026-09-01 15:36:17.114882+00	92	2026-09-01 15:54:28.676692+00
278	10	16	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:44.395376+00
271	9	2	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:20.23679+00
132	10	13	auto	2026-09-01 15:36:17.114882+00	92	2026-09-01 15:38:19.167368+00
277	10	23	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:46.005143+00
287	12	5	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:06.932049+00
269	9	12	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:21.546654+00
150	13	20	auto	2026-09-01 15:36:17.114882+00	92	2026-09-01 15:45:32.849189+00
2039	574	15	manuel	2026-10-03 09:47:03.88407+00	92	\N
131	10	18	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:10:24.634513+00
290	12	14	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:10.728207+00
286	12	10	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:12.65505+00
282	11	3	auto	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:14.313187+00
139	12	23	auto	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
141	12	22	auto	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
142	12	3	auto	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
144	12	30	auto	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
134	11	6	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
135	11	1	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
130	10	12	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
127	10	5	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
128	10	10	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
149	13	15	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
145	13	4	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
148	13	24	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
376	11	214	manuel	2026-09-01 16:14:31.621838+00	92	2026-09-08 07:25:59.093525+00
136	11	27	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
393	10	9	manuel	2026-09-01 16:17:30.068762+00	92	\N
138	11	9	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:41.773837+00
2055	572	4	manuel	2026-10-03 09:47:49.620465+00	92	2026-10-03 15:35:56.92601+00
147	13	28	auto	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:09:52.678846+00
2022	573	16	manuel	2026-10-03 09:45:44.343057+00	92	\N
294	13	26	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:09:54.677259+00
2017	572	19	manuel	2026-10-03 09:45:16.466954+00	92	\N
292	13	1	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:09:56.738521+00
146	13	2	manuel	2026-09-01 15:36:17.114882+00	92	\N
834	12	15	manuel	2026-09-01 16:29:39.331892+00	92	\N
268	9	15	auto	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:16.655365+00
140	12	19	manuel	2026-09-01 15:36:17.114882+00	92	\N
717	9	3	manuel	2026-09-01 16:27:58.173895+00	92	2026-09-02 12:32:03.585855+00
129	10	29	manuel	2026-09-01 15:36:17.114882+00	92	2026-09-01 16:10:29.738855+00
288	12	11	manuel	2026-09-01 16:09:41.773837+00	92	\N
970	146	53	manuel	2026-09-02 09:37:16.501982+00	787	\N
272	9	22	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:17.83428+00
137	11	26	manuel	2026-09-01 15:36:17.114882+00	92	\N
963	146	65	manuel	2026-09-02 09:37:01.762322+00	787	\N
981	146	61	manuel	2026-09-02 09:37:22.936546+00	787	\N
273	9	30	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:18.959226+00
2031	574	17	manuel	2026-10-03 09:46:36.094327+00	92	2026-10-03 09:46:43.098585+00
2025	575	14	manuel	2026-10-03 09:45:59.927644+00	92	2026-10-03 15:37:23.636153+00
283	11	4	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:32.613245+00
280	11	24	manuel	2026-09-01 16:09:41.773837+00	92	\N
281	11	19	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:35.611782+00
291	13	160	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-08 07:30:14.023231+00
378	9	26	manuel	2026-09-01 16:15:05.564154+00	92	2026-09-01 16:20:50.469134+00
285	11	25	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:10:38.518255+00
486	13	215	manuel	2026-09-01 16:24:16.765847+00	92	\N
384	13	23	manuel	2026-09-01 16:16:51.960836+00	92	\N
949	145	54	manuel	2026-09-02 09:36:14.095636+00	787	\N
942	145	67	manuel	2026-09-02 09:31:53.883002+00	787	\N
960	145	59	manuel	2026-09-02 09:36:30.814978+00	787	\N
276	10	27	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-01 16:24:32.298307+00
279	10	21	manuel	2026-09-01 16:09:41.773837+00	92	2026-09-08 07:27:31.76096+00
463	13	16	manuel	2026-09-01 16:22:44.394464+00	92	\N
428	13	10	manuel	2026-09-01 16:19:37.585581+00	92	\N
270	9	6	manuel	2026-09-01 16:09:41.773837+00	92	\N
449	9	5	manuel	2026-09-01 16:21:31.222739+00	92	\N
124	9	14	manuel	2026-09-01 15:36:17.114882+00	92	\N
939	144	60	manuel	2026-09-02 09:30:15.856488+00	787	\N
924	144	69	manuel	2026-09-02 09:29:36.971986+00	787	\N
520	10	22	manuel	2026-09-01 16:24:40.341832+00	92	\N
1466	12	2	manuel	2026-09-08 07:29:49.235401+00	92	2026-09-08 07:29:58.854265+00
919	144	62	manuel	2026-09-02 09:27:24.480863+00	787	\N
2034	575	17	manuel	2026-10-03 09:46:43.285538+00	92	2026-10-05 07:46:59.707384+00
2012	572	12	manuel	2026-10-03 09:44:59.909807+00	92	\N
2512	572	14	manuel	2026-10-03 15:37:23.776052+00	92	\N
2064	574	11	manuel	2026-10-03 09:48:04.294396+00	92	\N
2478	572	3215	manuel	2026-10-03 15:36:21.121395+00	92	2026-10-03 15:36:27.666911+00
2534	573	17	manuel	2026-10-05 07:46:59.785084+00	92	\N
2047	575	3217	manuel	2026-10-03 09:47:26.948149+00	92	\N
3170	1082	67	manuel	2026-10-05 12:14:41.279703+00	787	\N
3163	1082	69	manuel	2026-10-05 12:14:24.980158+00	787	\N
3176	1083	882	manuel	2026-10-05 12:14:58.952755+00	787	\N
3178	1083	62	manuel	2026-10-05 12:15:01.471319+00	787	\N
3190	1083	60	manuel	2026-10-05 12:15:19.166281+00	787	\N
3191	1084	54	manuel	2026-10-05 12:15:27.79133+00	787	\N
3200	1084	59	manuel	2026-10-05 12:15:41.230797+00	787	\N
3193	1084	68	manuel	2026-10-05 12:15:31.43238+00	787	\N
3214	1082	5766	manuel	2026-10-05 15:01:30.44444+00	787	\N
\.


--
-- Data for Name: campagne; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.campagne (id, libelle, date_debut, date_fin, cloturee, cree_le, cree_par, archive_le) FROM stdin;
2	Septembre 2026	2026-09-10	2026-09-14	t	2026-08-31 20:50:19.52+00	\N	\N
1	Juin 2026	2026-06-11	2026-06-15	t	2026-08-31 20:50:17.444+00	\N	\N
933	Octobre 2026	2026-10-08	2026-10-12	f	2026-10-02 09:06:05.777418+00	92	\N
\.


--
-- Data for Name: campagne_creneau; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.campagne_creneau (campagne_id, code, libelle, ordre, cree_le, cree_par) FROM stdin;
1	08:00-09:00	8h-9h	1	2026-08-31 20:50:17.821+00	\N
1	09:00-10:00	9h-10h	2	2026-08-31 20:50:17.921+00	\N
1	10:00-11:00	10h-11h	3	2026-08-31 20:50:17.96+00	\N
1	11:00-12:00	11h-12h	4	2026-08-31 20:50:18.014+00	\N
1	12:00-13:00	12h-13h	5	2026-08-31 20:50:18.058+00	\N
1	13:00-14:00	13h-14h	6	2026-08-31 20:50:18.099+00	\N
1	14:00-15:00	14h-15h	7	2026-08-31 20:50:18.149+00	\N
1	15:00-16:00	15h-16h	8	2026-08-31 20:50:18.19+00	\N
1	16:00-17:00	16h-17h	9	2026-08-31 20:50:18.23+00	\N
1	17:00-18:00	17h-18h	10	2026-08-31 20:50:18.273+00	\N
1	18:00-19:00	18h-19h	11	2026-08-31 20:50:18.323+00	\N
2	08:00-09:00	8h-9h	1	2026-08-31 20:50:19.849+00	\N
2	09:00-10:00	9h-10h	2	2026-08-31 20:50:19.889+00	\N
2	10:00-11:00	10h-11h	3	2026-08-31 20:50:19.934+00	\N
2	11:00-12:00	11h-12h	4	2026-08-31 20:50:19.987+00	\N
2	12:00-13:00	12h-13h	5	2026-08-31 20:50:20.044+00	\N
2	13:00-14:00	13h-14h	6	2026-08-31 20:50:20.085+00	\N
2	14:00-15:00	14h-15h	7	2026-08-31 20:50:20.161+00	\N
2	15:00-16:00	15h-16h	8	2026-08-31 20:50:20.199+00	\N
2	16:00-17:00	16h-17h	9	2026-08-31 20:50:20.243+00	\N
2	17:00-18:00	17h-18h	10	2026-08-31 20:50:20.284+00	\N
2	18:00-19:00	18h-19h	11	2026-08-31 20:50:20.408+00	\N
933	08:00-09:00	8h-9h	1	2026-10-02 09:06:05.777418+00	92
933	09:00-10:00	9h-10h	2	2026-10-02 09:06:05.777418+00	92
933	10:00-11:00	10h-11h	3	2026-10-02 09:06:05.777418+00	92
933	11:00-12:00	11h-12h	4	2026-10-02 09:06:05.777418+00	92
933	12:00-13:00	12h-13h	5	2026-10-02 09:06:05.777418+00	92
933	13:00-14:00	13h-14h	6	2026-10-02 09:06:05.777418+00	92
933	14:00-15:00	14h-15h	7	2026-10-02 09:06:05.777418+00	92
933	15:00-16:00	15h-16h	8	2026-10-02 09:06:05.777418+00	92
933	16:00-17:00	16h-17h	9	2026-10-02 09:06:05.777418+00	92
933	17:00-18:00	17h-18h	10	2026-10-02 09:06:05.777418+00	92
933	18:00-19:00	18h-19h	11	2026-10-02 09:06:05.777418+00	92
\.


--
-- Data for Name: campagne_jour; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.campagne_jour (campagne_id, jour, ordre, cree_le, cree_par) FROM stdin;
1	2026-06-11	1	2026-08-31 20:50:17.546+00	\N
1	2026-06-12	2	2026-08-31 20:50:17.644+00	\N
1	2026-06-13	3	2026-08-31 20:50:17.691+00	\N
1	2026-06-14	4	2026-08-31 20:50:17.737+00	\N
1	2026-06-15	5	2026-08-31 20:50:17.78+00	\N
2	2026-09-10	1	2026-08-31 20:50:19.56+00	\N
2	2026-09-11	2	2026-08-31 20:50:19.607+00	\N
2	2026-09-12	3	2026-08-31 20:50:19.649+00	\N
2	2026-09-13	4	2026-08-31 20:50:19.713+00	\N
2	2026-09-14	5	2026-08-31 20:50:19.779+00	\N
933	2026-10-08	1	2026-10-02 09:07:03.028566+00	92
933	2026-10-09	2	2026-10-02 09:07:14.311605+00	92
933	2026-10-10	3	2026-10-02 09:07:17.772836+00	92
933	2026-10-11	4	2026-10-02 09:07:21.213957+00	92
933	2026-10-12	5	2026-10-02 09:07:24.35537+00	92
\.


--
-- Data for Name: encadrement_site; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.encadrement_site (id, site_id, role, utilisateur_id, cree_le, cree_par, archive_le) FROM stdin;
552	12	chef_de_vente_vn	5501	2026-09-04 09:53:41.284847+00	1	\N
1357	12	chef_de_vente_vo	5501	2026-10-07 07:49:04.485232+00	1784	\N
1358	5	chef_de_vente_vn	5502	2026-10-07 08:45:40.415238+00	92	\N
544	15	chef_de_site	1777	2026-09-04 09:47:04.446432+00	1	\N
545	14	chef_de_site	1776	2026-09-04 09:47:15.417471+00	1	\N
546	18	chef_de_site	1775	2026-09-04 09:47:25.190832+00	1	\N
547	13	chef_de_site	1778	2026-09-04 09:48:03.668553+00	1	\N
549	12	chef_de_site	1779	2026-09-04 09:49:33.361849+00	1	\N
550	17	chef_de_site	1780	2026-09-04 09:51:20.89576+00	1	\N
551	16	chef_de_site	1781	2026-09-04 09:51:31.002306+00	1	\N
119	7	chef_de_vente_vn	1782	2026-09-01 13:03:08.910207+00	92	\N
554	8	chef_de_vente_vn	1783	2026-09-07 13:55:54.0902+00	92	\N
123	9	chef_de_site	95	2026-09-01 13:04:32.927457+00	92	2026-09-08 07:37:50.305+00
548	19	chef_de_site	1778	2026-09-04 09:48:16.272587+00	1	2026-09-08 14:13:41.30356+00
35	2	chef_de_vente_vn	12	2026-08-31 20:53:18.168+00	\N	2026-09-01 16:28:32.236+00
110	3	chef_de_vente_vn	5	2026-09-01 12:01:04.526057+00	10	\N
555	710	chef_de_site	1778	2026-09-08 08:19:21.964003+00	1784	2026-09-08 14:14:05.474919+00
111	5	chef_de_site	94	2026-09-01 13:00:01.411095+00	92	\N
34	3	chef_de_site	94	2026-08-31 20:53:17.946+00	\N	\N
113	3	chef_de_vente_vo	6	2026-09-01 13:00:15.179147+00	92	\N
114	1	chef_de_site	2	2026-09-01 13:00:21.513463+00	92	\N
115	2	chef_de_site	4	2026-09-01 13:00:34.781521+00	92	\N
116	4	chef_de_site	3	2026-09-01 13:00:56.770605+00	92	\N
117	7	chef_de_site	96	2026-09-01 13:02:03.428751+00	92	\N
118	8	chef_de_site	96	2026-09-01 13:03:01.351951+00	92	\N
120	6	chef_de_site	96	2026-09-01 13:03:21.300404+00	92	\N
121	6	chef_de_vente_vn	97	2026-09-01 13:03:43.943745+00	92	\N
122	11	chef_de_site	9	2026-09-01 13:04:10.655272+00	92	\N
124	9	chef_de_vente_vn	8	2026-09-01 13:04:38.333952+00	92	\N
125	9	chef_de_vente_vo	8	2026-09-01 13:04:44.588092+00	92	\N
126	10	chef_de_site	7	2026-09-01 13:04:53.644516+00	92	\N
729	19	chef_de_vente_vn	12	2026-10-02 20:02:46.725158+00	\N	2026-10-03 07:56:12.495083+00
\.


--
-- Data for Name: journal_compte; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.journal_compte (id, cree_le, cree_par, cible_id, action, detail) FROM stdin;
10	2026-10-02 22:06:09.784478+00	\N	10	reactivation	\N
11	2026-10-02 22:06:09.784478+00	\N	11	reactivation	\N
12	2026-10-02 22:06:09.784478+00	\N	12	reactivation	\N
13	2026-10-02 22:08:11.75962+00	\N	10	desactivation	\N
14	2026-10-02 22:08:11.75962+00	\N	11	desactivation	\N
15	2026-10-02 22:08:11.75962+00	\N	12	desactivation	\N
16	2026-10-02 22:08:24.70538+00	\N	10	reactivation	\N
17	2026-10-02 22:08:24.70538+00	\N	11	reactivation	\N
18	2026-10-02 22:08:24.70538+00	\N	12	reactivation	\N
19	2026-10-03 07:07:16.450274+00	\N	10	desactivation	\N
20	2026-10-03 07:07:16.450274+00	\N	11	desactivation	\N
21	2026-10-03 07:07:16.450274+00	\N	12	desactivation	\N
22	2026-10-03 07:08:14.450023+00	\N	10	reactivation	\N
23	2026-10-03 07:08:14.450023+00	\N	11	reactivation	\N
24	2026-10-03 07:08:14.450023+00	\N	12	reactivation	\N
25	2026-10-03 07:34:34.115419+00	\N	10	desactivation	\N
26	2026-10-03 07:34:34.115419+00	\N	11	desactivation	\N
27	2026-10-03 07:34:34.115419+00	\N	12	desactivation	\N
28	2026-10-03 07:52:40.665446+00	\N	10	reactivation	\N
29	2026-10-03 07:52:40.665446+00	\N	11	reactivation	\N
30	2026-10-03 07:52:40.665446+00	\N	12	reactivation	\N
31	2026-10-03 07:56:12.495083+00	\N	10	desactivation	\N
32	2026-10-03 07:56:12.495083+00	\N	11	desactivation	\N
33	2026-10-03 07:56:12.495083+00	\N	12	desactivation	\N
48	2026-10-03 12:58:44.227516+00	98	95	reactivation	\N
49	2026-10-03 12:59:08.376679+00	98	2116	reactivation	\N
50	2026-10-05 08:02:52.867143+00	92	95	reinitialisation	\N
51	2026-10-05 08:10:02.093646+00	92	95	reinitialisation	\N
52	2026-10-05 08:22:30.272448+00	95	95	changement_mot_de_passe	\N
53	2026-10-05 09:42:11.718962+00	92	1785	desactivation	\N
54	2026-10-05 09:54:56.454266+00	92	2116	desactivation	\N
76	2026-10-06 06:57:25.417523+00	92	1785	reactivation	\N
77	2026-10-06 06:57:31.252336+00	92	1785	reinitialisation	\N
78	2026-10-06 07:31:23.147801+00	92	4	reinitialisation	\N
79	2026-10-06 07:33:43.550245+00	4	4	changement_mot_de_passe	\N
80	2026-10-06 09:37:47.635469+00	1784	1780	reinitialisation	\N
81	2026-10-06 09:39:05.855492+00	1784	1781	reinitialisation	\N
82	2026-10-06 09:41:00.966946+00	1784	1776	reinitialisation	\N
83	2026-10-06 09:42:17.75845+00	1784	1775	reinitialisation	\N
84	2026-10-06 09:57:53.974878+00	1776	1776	changement_mot_de_passe	\N
85	2026-10-06 10:00:50.803016+00	1775	1775	changement_mot_de_passe	\N
86	2026-10-06 11:47:55.197752+00	1780	1780	changement_mot_de_passe	\N
87	2026-10-06 13:01:03.370777+00	1784	1781	reinitialisation	\N
88	2026-10-06 13:21:51.388815+00	1781	1781	changement_mot_de_passe	\N
89	2026-10-06 15:03:39.369005+00	92	1785	reinitialisation	\N
90	2026-10-06 15:47:18.407636+00	1785	1785	changement_mot_de_passe	\N
91	2026-10-07 07:20:56.860167+00	1784	1779	reinitialisation	\N
92	2026-10-07 07:28:43.396095+00	1784	1777	reinitialisation	\N
93	2026-10-07 09:39:40.523388+00	1777	1777	changement_mot_de_passe	\N
94	2026-10-07 14:29:58.815658+00	1779	1779	changement_mot_de_passe	\N
\.


--
-- Data for Name: marque; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.marque (id, code, libelle, ordre, cree_le, cree_par, archive_le, tableau_ventes) FROM stdin;
1	RENAULT	Renault	1	2026-08-31 20:49:25.026+00	\N	\N	t
2	DACIA	Dacia	2	2026-08-31 20:49:25.128+00	\N	\N	t
3	ALPINE	Alpine	3	2026-08-31 20:49:25.174+00	\N	\N	f
\.


--
-- Data for Name: mobilisation; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.mobilisation (id, campagne_id, vendeur_id, mobilise, motif, cree_le, cree_par, modifie_le) FROM stdin;
13	933	1885	f	\N	2026-10-07 07:39:24.297867+00	1784	\N
14	933	76	f	\N	2026-10-07 07:39:48.011811+00	1784	\N
15	933	75	f	\N	2026-10-07 07:39:48.291448+00	1784	\N
16	933	78	f	\N	2026-10-07 07:39:48.625687+00	1784	\N
17	933	99	f	\N	2026-10-07 07:39:48.888615+00	1784	\N
18	933	81	f	\N	2026-10-07 07:41:21.514856+00	1784	2026-10-07 09:14:51.26108+00
\.


--
-- Data for Name: objectif_vente; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.objectif_vente (id, campagne_id, site_id, marque_id, ventes, cree_le, cree_par, modifie_le) FROM stdin;
\.


--
-- Data for Name: plaque; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.plaque (id, libelle, alias, ordre, cree_le, cree_par, archive_le) FROM stdin;
1	CENTRE	EAA	1	2026-08-31 20:49:25.236+00	\N	\N
2	NORD	\N	2	2026-08-31 20:49:25.332+00	\N	\N
3	SUD	\N	3	2026-08-31 20:49:25.371+00	\N	\N
4	SUD-OUEST	\N	4	2026-08-31 20:49:25.41+00	\N	\N
\.


--
-- Data for Name: rdv; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.rdv (id, campagne_id, vendeur_id, jour, creneau_code, marque_id, type_vehicule, client, commentaire, cree_le, cree_par, modifie_le, modifie_par, archive_le, archive_par, cle_client, source) FROM stdin;
8471	933	1887	2026-10-08	08:00-09:00	\N	VO	Eric	\N	2026-10-03 07:57:39.940763+00	98	2026-10-03 07:57:51.494466+00	98	2026-10-03 07:57:51.729+00	98	0a54ed91-cc3a-48b0-a86b-2a57b6944229	relance
8746	933	79	2026-10-09	16:00-17:00	2	VN	CARRIER RENAULT	\N	2026-10-06 09:58:57.956511+00	1776	2026-10-06 09:59:08.233206+00	1776	\N	\N	f8bc9c88-8858-49e1-b38a-885e8dac9c16	relance
8975	933	41	2026-10-10	16:00-17:00	\N	VO	MAGNAN	\N	2026-10-06 10:44:56.16079+00	97	\N	\N	\N	\N	d4953fe3-4328-46d0-9170-7dee422fa1c1	relance
161	2	3	2026-09-10	08:00-09:00	1	VN	CONTROLE NAVIGATEURSAISIE ECRAN	\N	2026-08-31 21:50:44.921383+00	12	2026-08-31 22:00:23.239731+00	12	2026-08-31 22:00:22.212+00	\N	\N	relance
162	2	3	2026-09-10	09:00-10:00	1	VN	CLIENT DEPUIS LA GRILLE	\N	2026-08-31 21:51:54.608775+00	12	2026-08-31 22:00:23.239731+00	\N	2026-08-31 22:00:22.212+00	\N	\N	relance
194	2	1	2026-09-10	18:00-19:00	1	VN	DEPUIS LE TERMINAL	\N	2026-08-31 22:00:00.426+00	\N	2026-08-31 22:00:23.239731+00	\N	2026-08-31 22:00:22.212+00	\N	\N	relance
262	1	10	2026-06-11	09:00-10:00	1	VN	DELATOURAS	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
263	1	10	2026-06-12	09:00-10:00	1	VN	CHARDON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
264	1	10	2026-06-13	09:00-10:00	1	VN	TERON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
265	1	10	2026-06-14	09:00-10:00	1	VN	PERNET	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
266	1	10	2026-06-11	10:00-11:00	1	VN	CREMIEUX	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
267	1	10	2026-06-13	10:00-11:00	1	VN	MARI	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
268	1	10	2026-06-14	10:00-11:00	1	VN	FORMENTI	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
269	1	10	2026-06-11	11:00-12:00	1	VN	PICOT	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
270	1	10	2026-06-14	11:00-12:00	1	VN	CHAMBRE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
271	1	10	2026-06-12	12:00-13:00	1	VN	CHOMEILLE*	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
272	1	10	2026-06-12	14:00-15:00	1	VN	ZAMORA	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
273	1	10	2026-06-13	14:00-15:00	1	VN	VIALTAIX	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
274	1	10	2026-06-14	14:00-15:00	1	VN	ALVES	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
275	1	10	2026-06-11	16:00-17:00	1	VN	MARTIN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
276	1	10	2026-06-13	16:00-17:00	1	VN	BRETTE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
277	1	10	2026-06-14	16:00-17:00	1	VN	RAGOT 208	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
278	1	11	2026-06-12	09:00-10:00	1	VN	JELADE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
279	1	11	2026-06-13	09:00-10:00	1	VN	DEBLOIS	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
280	1	11	2026-06-11	10:00-11:00	1	VN	CHILE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
281	1	11	2026-06-15	10:00-11:00	1	VN	THEVENET	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
282	1	11	2026-06-12	11:00-12:00	1	VN	TARTRY	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
283	1	11	2026-06-15	11:00-12:00	1	VN	MESTRE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
284	1	11	2026-06-11	12:00-13:00	1	VN	VASSET	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
285	1	11	2026-06-12	12:00-13:00	1	VN	DE LA COTARDIERE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
286	1	11	2026-06-15	13:00-14:00	1	VN	ABEL	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
287	1	11	2026-06-12	14:00-15:00	1	VN	GUITTARD	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
288	1	11	2026-06-15	14:00-15:00	1	VN	BONNET	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
289	1	11	2026-06-15	16:00-17:00	1	VN	DELODDE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
290	1	11	2026-06-11	14:00-15:00	2	VN	CABANAC	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
291	1	11	2026-06-12	15:00-16:00	2	VN	MONNERON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
292	1	11	2026-06-11	16:00-17:00	2	VN	GOUTAIN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
293	1	11	2026-06-12	16:00-17:00	2	VN	POSSON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
294	1	11	2026-06-11	18:00-19:00	2	VN	GOUTEFANGEAT	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
295	1	12	2026-06-11	08:00-09:00	2	VN	RICCARDELLI (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
296	1	12	2026-06-12	09:00-10:00	2	VN	DELORME (BIGSTER)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
297	1	12	2026-06-13	09:00-10:00	2	VN	SCHAMPERS (JOGGER)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
298	1	12	2026-06-14	09:00-10:00	2	VN	DUREL (DUSTER)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
299	1	12	2026-06-11	10:00-11:00	2	VN	BERNIGAUD (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
300	1	12	2026-06-12	10:00-11:00	2	VN	DAMIANI (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
301	1	12	2026-06-13	10:00-11:00	2	VN	TROUCAS (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
302	1	12	2026-06-14	10:00-11:00	2	VN	PAILHE (SANDERO STEPWAY)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
303	1	12	2026-06-15	10:00-11:00	2	VN	VAGNE (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
304	1	12	2026-06-11	11:00-12:00	2	VN	CHAVAROCHE  (DUSTER)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
305	1	12	2026-06-12	11:00-12:00	2	VN	AMBLARD (BIGSTER)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
306	1	12	2026-06-11	14:00-15:00	2	VN	LEMONIER (STEPWAY)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
307	1	12	2026-06-12	14:00-15:00	2	VN	LEMOINE (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
308	1	12	2026-06-14	14:00-15:00	2	VN	FRANCES (DUSTER)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
309	1	12	2026-06-15	15:00-16:00	2	VN	BEAL (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
310	1	12	2026-06-14	16:00-17:00	2	VN	DUMAS (JOGGER)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
311	1	12	2026-06-11	17:00-18:00	2	VN	QUERART (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
312	1	12	2026-06-12	17:00-18:00	2	VN	MAILLET (BIGSTER)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
313	1	12	2026-06-13	17:00-18:00	2	VN	NUGER (JOGGER)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
314	1	12	2026-06-11	18:00-19:00	2	VN	JACQUIER (sandero)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
315	1	13	2026-06-11	09:00-10:00	1	VN	ARTAUD	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
316	1	13	2026-06-14	09:00-10:00	1	VN	BERKOUN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
317	1	13	2026-06-12	09:00-10:00	2	VN	NORE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
318	1	13	2026-06-13	09:00-10:00	2	VN	ALBERT	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
319	1	13	2026-06-11	10:00-11:00	2	VN	COUESNON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
320	1	13	2026-06-13	10:00-11:00	2	VN	OUDARD	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
321	1	13	2026-06-14	10:00-11:00	2	VN	VERNIERE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
322	1	13	2026-06-11	11:00-12:00	2	VN	CLAVELOU	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
323	1	13	2026-06-12	11:00-12:00	2	VN	DEGRANGE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
324	1	13	2026-06-11	13:00-14:00	2	VN	SAINTE ARROMAN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
325	1	13	2026-06-14	14:00-15:00	2	VN	DREUX	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
326	1	13	2026-06-14	15:00-16:00	2	VN	GORALSKI	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
327	1	13	2026-06-15	15:00-16:00	2	VN	GUIENNE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
328	1	14	2026-06-11	16:00-17:00	1	VN	LECHARPENTIER (Twingo ou Spring)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
329	1	14	2026-06-11	08:00-09:00	2	VN	GUERINO (Sandero)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
330	1	14	2026-06-12	09:00-10:00	2	VN	MUCIENTES (Sandero)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
331	1	14	2026-06-14	09:00-10:00	2	VN	CHANTELAUZE (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
332	1	14	2026-06-13	10:00-11:00	2	VN	RADINI (Duster 4x4 diesel reprise)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
333	1	14	2026-06-13	13:00-14:00	2	VN	GENINO (Sandero)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
334	1	14	2026-06-11	14:00-15:00	2	VN	LEMAIRE (DUster)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
335	1	14	2026-06-14	14:00-15:00	2	VN	FAURIOL (Bigster)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
336	1	14	2026-06-13	15:00-16:00	2	VN	GULF (jogger 7 places)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
337	1	14	2026-06-14	16:00-17:00	2	VN	ESCURE (Duster, reprise DUstuer diesel 4x4)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
338	1	14	2026-06-11	17:00-18:00	2	VN	ASTARI (Sandero)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
339	1	14	2026-06-12	18:00-19:00	2	VN	COL (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
340	1	15	2026-06-13	09:00-10:00	1	VN	SARDIER	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
341	1	15	2026-06-14	09:00-10:00	1	VN	JUNG	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
342	1	15	2026-06-15	09:00-10:00	1	VN	TISON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
343	1	15	2026-06-13	10:00-11:00	1	VN	JAMOT	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
344	1	15	2026-06-15	10:00-11:00	1	VN	GODARD	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
345	1	15	2026-06-11	14:00-15:00	1	VN	FAYARD	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
346	1	15	2026-06-15	14:00-15:00	1	VN	MARCHAND	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
347	1	15	2026-06-11	09:00-10:00	2	VN	NEGRONIE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
348	1	15	2026-06-12	09:00-10:00	2	VN	NAULT	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
349	1	15	2026-06-11	11:00-12:00	2	VN	MIAUX	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
350	1	15	2026-06-12	11:00-12:00	2	VN	FAURE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
351	1	15	2026-06-12	14:00-15:00	2	VN	DARTOIS	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
352	1	15	2026-06-13	14:00-15:00	2	VN	DUBOIS	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
353	1	15	2026-06-12	16:00-17:00	2	VN	MONTOLOY	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
354	1	15	2026-06-12	17:00-18:00	2	VN	EYDIEUX	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
355	1	16	2026-06-11	09:00-10:00	1	VN	JALAN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
356	1	16	2026-06-15	09:00-10:00	1	VN	RAMBEAU	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
357	1	16	2026-06-12	10:00-11:00	1	VN	STRADY	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
358	1	16	2026-06-14	10:00-11:00	1	VN	RAMBAUD	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
359	1	16	2026-06-15	10:00-11:00	1	VN	BAYDE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
360	1	16	2026-06-11	11:00-12:00	1	VN	MEUNIER	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
361	1	16	2026-06-12	11:00-12:00	1	VN	VOLDOIRE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
362	1	16	2026-06-12	12:00-13:00	1	VN	LAGACHE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
363	1	16	2026-06-13	12:00-13:00	1	VN	MONTOUTON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
364	1	16	2026-06-12	14:00-15:00	1	VN	ROUX	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
365	1	16	2026-06-13	14:00-15:00	1	VN	COUDERT	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
366	1	16	2026-06-14	14:00-15:00	1	VN	JOURNIAC	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
367	1	16	2026-06-12	16:00-17:00	1	VN	CHEVALIER	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
368	1	16	2026-06-11	17:00-18:00	1	VN	ZAKARIA	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
369	1	16	2026-06-15	17:00-18:00	1	VN	BARRA	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
370	1	17	2026-06-11	09:00-10:00	1	VN	SIGURET	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
371	1	17	2026-06-13	09:00-10:00	1	VN	CEYRAS	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
372	1	17	2026-06-14	09:00-10:00	1	VN	HABRIAL	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
373	1	17	2026-06-15	09:00-10:00	1	VN	LECOIN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
374	1	17	2026-06-11	10:00-11:00	1	VN	GAUDICHON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
375	1	17	2026-06-14	10:00-11:00	1	VN	SAUSSAC	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
376	1	17	2026-06-15	11:00-12:00	1	VN	DEKEYSER	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
377	1	17	2026-06-11	13:00-14:00	1	VN	KANIT	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
378	1	17	2026-06-12	13:00-14:00	1	VN	CORDIESE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
379	1	17	2026-06-11	14:00-15:00	1	VN	MAILHOT	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
380	1	17	2026-06-12	14:00-15:00	1	VN	BONNIN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
381	1	17	2026-06-13	14:00-15:00	1	VN	BERTIN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
382	1	17	2026-06-14	14:00-15:00	1	VN	VAYSSADE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
383	1	17	2026-06-13	15:00-16:00	1	VN	MONTBOISSE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
384	1	17	2026-06-15	15:00-16:00	1	VN	CURADO	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
385	1	17	2026-06-11	16:00-17:00	1	VN	FOZEN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
386	1	17	2026-06-13	17:00-18:00	1	VN	CHALLET	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
387	1	17	2026-06-15	17:00-18:00	1	VN	FLORES	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
388	1	18	2026-06-12	09:00-10:00	1	VN	LAON (R4)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
389	1	18	2026-06-13	09:00-10:00	1	VN	MR BAYARD	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
390	1	18	2026-06-11	10:00-11:00	1	VN	ABRANTES (TWINGO ETECH)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
391	1	18	2026-06-12	10:00-11:00	1	VN	HOUZEAU (AUSTRAl)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
392	1	18	2026-06-15	10:00-11:00	1	VN	GLAIZE (R4 E TECH)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
393	1	18	2026-06-11	14:00-15:00	1	VN	MARTINEZ (CLIO 6)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
394	1	18	2026-06-12	14:00-15:00	1	VN	MARQUES (CAPTUR)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
395	1	18	2026-06-13	14:00-15:00	1	VN	GAILLER (CLIO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
396	1	18	2026-06-14	14:00-15:00	1	VN	CHANUDET (R5)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
397	1	18	2026-06-15	14:00-15:00	1	VN	MEAUGER (TWINGO ETECH)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
398	1	18	2026-06-12	15:00-16:00	1	VN	ROUGIER (CLIO 6 ECO G)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
399	1	18	2026-06-13	15:00-16:00	1	VN	CHAPER (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
400	1	18	2026-06-11	16:00-17:00	1	VN	DUMONT (R5 ETECH)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
401	1	18	2026-06-11	17:00-18:00	1	VN	DAGUNA (TWINGO etech)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
402	1	18	2026-06-15	18:00-19:00	1	VN	DAULAT	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
403	1	19	2026-06-11	08:00-09:00	1	VN	MIGLIAVACCA (Clio)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
404	1	19	2026-06-12	08:00-09:00	1	VN	BELOT (R5)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
405	1	19	2026-06-11	09:00-10:00	1	VN	TARDIVAT (Captur)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
406	1	19	2026-06-13	09:00-10:00	1	VN	PENOT (Twingo electrique)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
407	1	19	2026-06-14	09:00-10:00	1	VN	MISSONIER (R5)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
408	1	19	2026-06-15	09:00-10:00	1	VN	RODIER (Clio)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
409	1	19	2026-06-11	10:00-11:00	1	VN	GROSSE (Twingo)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
410	1	19	2026-06-12	10:00-11:00	1	VN	LOUIS Isabelle (R5)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
411	1	19	2026-06-13	10:00-11:00	1	VN	SAHUC (reprise Twingo)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
412	1	19	2026-06-14	10:00-11:00	1	VN	HEALY (fin solde)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
413	1	19	2026-06-13	11:00-12:00	1	VN	PIRONNET (Captur)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
414	1	19	2026-06-11	14:00-15:00	1	VN	SALGADO (Twingo)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
415	1	19	2026-06-14	14:00-15:00	1	VN	DALLOUBEIX (reprise Captur)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
416	1	19	2026-06-12	15:00-16:00	1	VN	SEVAILLE (R5 Megane elec)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
417	1	19	2026-06-11	16:00-17:00	1	VN	DEBONNO (Captur)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
418	1	19	2026-06-12	16:00-17:00	1	VN	DEPRESLE (SANDERO)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
419	1	19	2026-06-13	16:00-17:00	1	VN	LAPORTE (reprise Captur)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
420	1	19	2026-06-12	17:00-18:00	1	VN	CLAVEL (Clio)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
421	1	19	2026-06-13	17:00-18:00	1	VN	GUILLON COTARD (Captur)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
422	1	19	2026-06-15	17:00-18:00	1	VN	PETIT (CLio)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
423	1	20	2026-06-12	11:00-12:00	2	VN	ROUX	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
424	1	20	2026-06-13	11:00-12:00	2	VN	NICODEME	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
425	1	20	2026-06-15	11:00-12:00	2	VN	BARDOTTI	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
426	1	20	2026-06-12	14:00-15:00	2	VN	MOULY	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
427	1	20	2026-06-15	14:00-15:00	2	VN	PLANE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
428	1	20	2026-06-13	16:00-17:00	2	VN	SERRE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
429	1	20	2026-06-14	16:00-17:00	2	VN	GOGEOUR	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
430	1	20	2026-06-15	16:00-17:00	2	VN	BRUSTEL	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
431	1	20	2026-06-12	17:00-18:00	2	VN	JARNIAL	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
432	1	20	2026-06-15	18:00-19:00	2	VN	PEDRINI	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
433	1	21	2026-06-15	09:00-10:00	\N	VO	ESPOSITO	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
434	1	21	2026-06-13	10:00-11:00	\N	VO	PERETON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
435	1	21	2026-06-15	10:00-11:00	\N	VO	FERREIRA	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
436	1	21	2026-06-15	11:00-12:00	\N	VO	COURAGEOT	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
437	1	21	2026-06-13	14:00-15:00	\N	VO	JAFFEUX	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
438	1	21	2026-06-14	14:00-15:00	\N	VO	SOUCHER	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
439	1	21	2026-06-14	16:00-17:00	\N	VO	LARVOL	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
440	1	21	2026-06-12	17:00-18:00	\N	VO	VANDEVILLE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
441	1	21	2026-06-14	17:00-18:00	\N	VO	PLANCHER	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
442	1	21	2026-06-15	18:00-19:00	\N	VO	PETIT	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
443	1	22	2026-06-11	10:00-11:00	\N	VO	SEBASTIEN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
444	1	22	2026-06-13	10:00-11:00	\N	VO	BONIN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
445	1	22	2026-06-13	11:00-12:00	\N	VO	TERKIHADJ	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
446	1	22	2026-06-14	14:00-15:00	\N	VO	FRANCK	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
447	1	22	2026-06-11	15:00-16:00	\N	VO	MARTIN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
448	1	22	2026-06-13	15:00-16:00	\N	VO	MARET	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
449	1	22	2026-06-14	16:00-17:00	\N	VO	FAURE	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
450	1	22	2026-06-15	16:00-17:00	\N	VO	BOULANGER	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
451	1	22	2026-06-11	17:00-18:00	\N	VO	PERREIRA	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
452	1	23	2026-06-11	09:00-10:00	\N	VO	SOYDARI	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
453	1	23	2026-06-14	09:00-10:00	\N	VO	COLON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
454	1	23	2026-06-12	10:00-11:00	\N	VO	HANNARD	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
455	1	23	2026-06-11	11:00-12:00	\N	VO	DAMON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
456	1	23	2026-06-11	13:00-14:00	\N	VO	GENESTIER	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
457	1	23	2026-06-12	14:00-15:00	\N	VO	LANDILLON	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
458	1	23	2026-06-11	17:00-18:00	\N	VO	PAYET	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
459	1	24	2026-06-12	09:00-10:00	\N	VO	LAMBAIN	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
460	1	24	2026-06-14	09:00-10:00	\N	VO	ROUFFET	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
461	1	24	2026-06-14	10:00-11:00	\N	VO	BENIER (CAPTUR)	\N	2026-09-01 09:37:22.585237+00	1	\N	\N	\N	\N	\N	relance
462	1	24	2026-06-13	11:00-12:00	\N	VO	RICHARD	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
463	1	24	2026-06-12	14:00-15:00	\N	VO	ROUDIER (CLIO DIESEL)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
464	1	24	2026-06-13	14:00-15:00	\N	VO	CHEREL (CLIO 5 hev)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
465	1	24	2026-06-14	16:00-17:00	\N	VO	FRUQUIERE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
466	1	24	2026-06-15	16:00-17:00	\N	VO	MALLET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
467	1	24	2026-06-12	17:00-18:00	\N	VO	ADDEO (CLIO)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
468	1	24	2026-06-15	17:00-18:00	\N	VO	GATIGNOL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
469	1	25	2026-06-13	09:00-10:00	\N	VO	EHMIG	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
470	1	25	2026-06-14	09:00-10:00	\N	VO	ROUFFET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
471	1	25	2026-06-11	14:00-15:00	\N	VO	ROUVET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
472	1	25	2026-06-13	14:00-15:00	\N	VO	GORY	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
473	1	25	2026-06-15	14:00-15:00	\N	VO	DEVERNOIS	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
474	1	25	2026-06-14	16:00-17:00	\N	VO	FRUQUIERE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
475	1	25	2026-06-11	17:00-18:00	\N	VO	GHIAB	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
476	1	25	2026-06-12	17:00-18:00	\N	VO	MAUME	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
477	1	25	2026-06-13	17:00-18:00	\N	VO	BONNET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
478	1	25	2026-06-15	17:00-18:00	\N	VO	ANADON LUIS	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
479	1	25	2026-06-15	14:00-15:00	\N	VO	DE SOUSA	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
480	1	3	2026-06-12	09:00-10:00	1	VN	GIAMPRETIE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
481	1	3	2026-06-13	09:00-10:00	1	VN	ALLENDE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
482	1	3	2026-06-14	10:00-11:00	1	VN	BELKADI	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
483	1	3	2026-06-13	11:00-12:00	1	VN	SEMA	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
484	1	3	2026-06-13	14:00-15:00	1	VN	GUYONNET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
485	1	3	2026-06-14	14:00-15:00	1	VN	BERTRAND	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
486	1	3	2026-06-12	15:00-16:00	1	VN	FUZET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
487	1	3	2026-06-15	15:00-16:00	1	VN	LASTIQUE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
488	1	3	2026-06-13	16:00-17:00	1	VN	MUNOZ	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
489	1	3	2026-06-15	16:00-17:00	1	VN	CLEMENT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
490	1	3	2026-06-12	17:00-18:00	1	VN	BRONGNIART	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
491	1	3	2026-06-13	17:00-18:00	1	VN	VERGNE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
492	1	3	2026-06-14	17:00-18:00	1	VN	CHONAL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
493	1	3	2026-06-15	10:00-11:00	2	VN	CHELLES	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
494	1	3	2026-06-12	14:00-15:00	2	VN	PINET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
495	1	3	2026-06-14	14:00-15:00	2	VN	GIUSIANO	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
496	1	3	2026-06-12	16:00-17:00	2	VN	MORIOL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
497	1	4	2026-06-12	08:00-09:00	1	VN	THOMAS	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
498	1	4	2026-06-11	09:00-10:00	1	VN	KUNTZ	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
499	1	4	2026-06-12	09:00-10:00	1	VN	FRADETAL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
500	1	4	2026-06-11	10:00-11:00	1	VN	SEGUIN	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
501	1	4	2026-06-14	10:00-11:00	1	VN	MARTINET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
502	1	4	2026-06-13	11:00-12:00	1	VN	PERONNET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
503	1	4	2026-06-12	14:00-15:00	1	VN	GRAVIL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
504	1	4	2026-06-13	14:00-15:00	1	VN	ARNAUD	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
505	1	4	2026-06-14	14:00-15:00	1	VN	GRENIER	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
506	1	4	2026-06-12	15:00-16:00	1	VN	IMBERT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
507	1	4	2026-06-13	15:00-16:00	1	VN	DECLOUX	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
508	1	4	2026-06-11	17:00-18:00	1	VN	PETITCOLLIN	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
509	1	4	2026-06-13	10:00-11:00	2	VN	ARDAILLON	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
510	1	4	2026-06-11	11:00-12:00	2	VN	COUDERT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
511	1	4	2026-06-11	14:00-15:00	2	VN	BONNOT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
512	1	4	2026-06-13	14:00-15:00	2	VN	ARCHAMBEAU	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
513	1	4	2026-06-11	16:00-17:00	2	VN	CHARVEL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
514	1	4	2026-06-12	17:00-18:00	2	VN	MENUGE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
515	1	5	2026-06-11	09:00-10:00	1	VN	GUERIOT ANNA	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
516	1	5	2026-06-12	09:00-10:00	1	VN	GONZALEZ	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
517	1	5	2026-06-14	09:00-10:00	1	VN	PEROL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
518	1	5	2026-06-14	10:00-11:00	1	VN	TINEL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
519	1	5	2026-06-11	11:00-12:00	1	VN	DUMAS	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
520	1	5	2026-06-11	14:00-15:00	1	VN	PREVOT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
521	1	5	2026-06-12	14:00-15:00	1	VN	PETIT CLEMENT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
522	1	5	2026-06-15	14:00-15:00	1	VN	DEGUIS	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
523	1	5	2026-06-11	15:00-16:00	1	VN	SCHANK	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
524	1	5	2026-06-13	17:00-18:00	1	VN	MARION GILLES	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
525	1	5	2026-06-13	18:00-19:00	1	VN	SCANDELLA	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
526	1	5	2026-06-12	09:00-10:00	2	VN	MORLIN	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
527	1	5	2026-06-11	10:00-11:00	2	VN	SAUVADET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
528	1	5	2026-06-13	11:00-12:00	2	VN	GOUT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
529	1	5	2026-06-11	17:00-18:00	2	VN	GILON	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
530	1	6	2026-06-12	09:00-10:00	1	VN	ROULLEAU (CLIO)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
531	1	6	2026-06-14	09:00-10:00	1	VN	GIRAUD (CAPTUR)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
532	1	6	2026-06-13	10:00-11:00	1	VN	THEUIL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
533	1	6	2026-06-14	10:00-11:00	1	VN	AMBLARD (ESPACE)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
534	1	6	2026-06-15	10:00-11:00	1	VN	DIOGON (AUSTRAL OU RAFALE)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
535	1	6	2026-06-14	11:00-12:00	1	VN	VACHER ( CAPTUR)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
536	1	6	2026-06-13	14:00-15:00	1	VN	DEVILLARD (R5 E TECH)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
537	1	6	2026-06-14	14:00-15:00	1	VN	ESSARD (R5 E TYECH)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
538	1	6	2026-06-14	15:00-16:00	1	VN	CHARMETON (AUSTRAL)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
539	1	6	2026-06-11	16:00-17:00	1	VN	ROAESTER (CLIO)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
540	1	6	2026-06-13	16:00-17:00	1	VN	BOUSSEARE (R5)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
541	1	6	2026-06-11	17:00-18:00	1	VN	BASQUE (R5)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
542	1	6	2026-06-12	18:00-19:00	1	VN	CALDEIRA (CLIO 5 OU 6)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
543	1	6	2026-06-12	08:00-09:00	2	VN	HEMAR (JOGGER)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
544	1	6	2026-06-11	09:00-10:00	2	VN	Thors (Stepway)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
545	1	6	2026-06-11	10:00-11:00	2	VN	FOUCAUD (STEPWAY)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
546	1	6	2026-06-13	11:00-12:00	2	VN	MALARD (SPRING)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
547	1	6	2026-06-11	15:00-16:00	2	VN	PELLET (DUSTER)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
548	1	6	2026-06-11	18:00-19:00	2	VN	FRESCENAUNAI (JOGGER)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
549	1	7	2026-06-13	09:00-10:00	1	VN	MONIER (SCENIC E TECH)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
550	1	7	2026-06-11	10:00-11:00	1	VN	DEBAIN (R5)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
551	1	7	2026-06-12	10:00-11:00	1	VN	BOLLATON (R5)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
552	1	7	2026-06-11	14:00-15:00	1	VN	BRASSIER (CAPTUR)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
553	1	7	2026-06-12	14:00-15:00	1	VN	RASTERO (scenic etech)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
554	1	7	2026-06-13	14:00-15:00	1	VN	PIROIRE MEGANE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
555	1	7	2026-06-15	14:00-15:00	1	VN	RM	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
556	1	7	2026-06-13	15:00-16:00	1	VN	MAGUIGNOU (CLIO 6)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
557	1	7	2026-06-12	16:00-17:00	1	VN	BELLET (R5 ETECH)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
558	1	7	2026-06-13	16:00-17:00	1	VN	FAURE (R4 ETECH)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
559	1	7	2026-06-11	17:00-18:00	1	VN	COURTIAL CLIO 6	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
560	1	7	2026-06-13	10:00-11:00	2	VN	DEBEZ(sandero)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
561	1	7	2026-06-11	11:00-12:00	2	VN	MARTINS (jOGGER)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
562	1	7	2026-06-13	11:00-12:00	2	VN	BELLE SANDERO OU DUSTER	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
563	1	7	2026-06-15	15:00-16:00	2	VN	PONNA SANDERO	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
564	1	7	2026-06-14	17:00-18:00	2	VN	POUILLY (SCENIC)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
565	1	8	2026-06-11	08:00-09:00	\N	VO	THIALLET (Espace 6)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
566	1	8	2026-06-12	08:00-09:00	\N	VO	BIDET (DUSTER)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
567	1	8	2026-06-11	09:00-10:00	\N	VO	PLANCHAT (CLio 5)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
568	1	8	2026-06-13	09:00-10:00	\N	VO	MALESTROIT (DUster)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
569	1	8	2026-06-11	10:00-11:00	\N	VO	SUGERE (ARKANA)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
570	1	8	2026-06-13	10:00-11:00	\N	VO	MORGAN (Clio)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
571	1	8	2026-06-14	10:00-11:00	\N	VO	ABDALAH (reprise clio)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
572	1	8	2026-06-11	11:00-12:00	\N	VO	BOUAJAY (Sandero)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
573	1	8	2026-06-13	11:00-12:00	\N	VO	FIGUERIDO (Megane)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
574	1	8	2026-06-14	11:00-12:00	\N	VO	LIGIER (DOkker)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
575	1	8	2026-06-11	14:00-15:00	\N	VO	ROLLIN (Captur)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
576	1	8	2026-06-13	14:00-15:00	\N	VO	BAUDOIN (Austral)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
577	1	8	2026-06-14	14:00-15:00	\N	VO	DA SILVA (CLio)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
578	1	8	2026-06-15	14:00-15:00	\N	VO	CLEMENT (Captur)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
579	1	8	2026-06-14	15:00-16:00	\N	VO	TESSANDIER (CAPTUR)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
580	1	8	2026-06-13	16:00-17:00	\N	VO	MAZZOLINI (reprise Zoé)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
581	1	8	2026-06-12	17:00-18:00	\N	VO	FOURNIER (Arkana)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
582	1	8	2026-06-15	18:00-19:00	\N	VO	LANDRO (Sandero)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
583	1	9	2026-06-12	08:00-09:00	\N	VO	CORNOT (Austral?)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
584	1	9	2026-06-14	10:00-11:00	\N	VO	PERTIN (CLio)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
585	1	9	2026-06-11	11:00-12:00	\N	VO	AVRIL (Jogger)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
586	1	9	2026-06-13	11:00-12:00	\N	VO	Mairie de BORNES les MIMOSA (Master benne)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
587	1	9	2026-06-14	11:00-12:00	\N	VO	PERTIN (Captur)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
588	1	9	2026-06-11	14:00-15:00	\N	VO	PRADA (Sandero)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
589	1	9	2026-06-12	14:00-15:00	\N	VO	GARDON (Renouvellement elec)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
590	1	9	2026-06-13	14:00-15:00	\N	VO	LAMBERT (Clio hybride 145)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
591	1	9	2026-06-14	14:00-15:00	\N	VO	BAFOURD (Clio)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
592	1	9	2026-06-11	15:00-16:00	\N	VO	VAURE - DENIS (LOA elec)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
593	1	9	2026-06-14	15:00-16:00	\N	VO	MAZE (CLio)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
594	1	9	2026-06-11	16:00-17:00	\N	VO	DEVEAUX (Sandero)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
595	1	9	2026-06-11	17:00-18:00	\N	VO	BOURJIS (Zoé ?)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
596	1	26	2026-06-11	11:00-12:00	1	VN	SIMMONOT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
597	1	26	2026-06-12	14:00-15:00	1	VN	REDONDY	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
598	1	26	2026-06-13	14:00-15:00	1	VN	SULTAN	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
599	1	26	2026-06-13	16:00-17:00	1	VN	CHABOT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
600	1	26	2026-06-11	10:00-11:00	2	VN	BELLEGUEULE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
601	1	26	2026-06-14	11:00-12:00	2	VN	MALAQUI	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
602	1	26	2026-06-12	16:00-17:00	2	VN	JACOB	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
603	1	27	2026-06-11	08:00-09:00	1	VN	¨GOIFFON	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
604	1	27	2026-06-13	10:00-11:00	1	VN	PAREL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
605	1	27	2026-06-14	10:00-11:00	1	VN	FAUGERAS	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
606	1	27	2026-06-13	11:00-12:00	1	VN	SCHOENMAKERS	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
607	1	27	2026-06-12	14:00-15:00	1	VN	NIN	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
608	1	27	2026-06-13	14:00-15:00	1	VN	ARNOULT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
609	1	27	2026-06-11	16:00-17:00	1	VN	GOUYO	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
610	1	27	2026-06-12	11:00-12:00	2	VN	TREUIL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
611	1	27	2026-06-12	15:00-16:00	2	VN	SABOURIN	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
612	1	27	2026-06-13	16:00-17:00	2	VN	JAKSIK	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
613	1	28	2026-06-13	08:00-09:00	\N	VO	GUGGER (DUSTER)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
614	1	28	2026-06-13	09:00-10:00	\N	VO	NOEL (Arkana)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
615	1	28	2026-06-14	10:00-11:00	\N	VO	PRELAT (Spring)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
616	1	28	2026-06-12	14:00-15:00	\N	VO	COSTERO (DUSTER)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
617	1	28	2026-06-13	15:00-16:00	\N	VO	CELERIER (Captur)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
618	1	28	2026-06-14	15:00-16:00	\N	VO	DUPONT (VO)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
619	1	28	2026-06-12	17:00-18:00	\N	VO	BARRAGE (Duster)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
620	1	29	2026-06-13	09:00-10:00	3	VN	MATHE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
621	1	29	2026-06-13	10:00-11:00	3	VN	DUMAZET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
622	1	29	2026-06-14	10:00-11:00	3	VN	DELENCLOS	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
623	1	29	2026-06-12	11:00-12:00	3	VN	BERGOGNE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
624	1	29	2026-06-13	11:00-12:00	3	VN	LEHMAN	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
625	1	29	2026-06-14	11:00-12:00	3	VN	BATISSON	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
626	1	29	2026-06-12	14:00-15:00	3	VN	MOREL	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
627	1	29	2026-06-13	14:00-15:00	3	VN	ZHAO	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
628	1	29	2026-06-14	14:00-15:00	3	VN	IERA	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
629	1	29	2026-06-13	15:00-16:00	3	VN	VALETTE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
630	1	29	2026-06-14	15:00-16:00	3	VN	MINET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
631	1	29	2026-06-12	16:00-17:00	3	VN	MEZIN	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
632	1	29	2026-06-13	16:00-17:00	3	VN	BILLEBAULT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
633	1	29	2026-06-13	17:00-18:00	3	VN	BILLEBAULT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
634	1	30	2026-06-12	09:00-10:00	3	VN	lacroix  (l,nore)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
635	1	30	2026-06-11	10:00-11:00	3	VN	THEVENET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
636	1	30	2026-06-12	10:00-11:00	3	VN	IZARD	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
637	1	30	2026-06-13	10:00-11:00	3	VN	CABANO	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
638	1	30	2026-06-14	10:00-11:00	3	VN	chevasson (l,nore)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
639	1	30	2026-06-12	11:00-12:00	3	VN	ramon (l,nore)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
640	1	30	2026-06-13	13:00-14:00	3	VN	garret (l,nore)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
641	1	30	2026-06-11	14:00-15:00	3	VN	PESTANA	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
642	1	30	2026-06-12	14:00-15:00	3	VN	DUCROT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
643	1	30	2026-06-13	14:00-15:00	3	VN	COMBETTES	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
644	1	30	2026-06-14	14:00-15:00	3	VN	gieze (l,nore)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
645	1	30	2026-06-13	15:00-16:00	3	VN	POUZET	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
646	1	30	2026-06-11	16:00-17:00	3	VN	SEVESTRE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
647	1	30	2026-06-12	16:00-17:00	3	VN	LAVERGNE	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
648	1	30	2026-06-12	17:00-18:00	3	VN	BERNAT	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
649	1	1	2026-06-11	09:00-10:00	1	VN	MOUSTEY (Megane VO)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
650	1	1	2026-06-13	09:00-10:00	1	VN	MOURTON (Scenic)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
651	1	1	2026-06-15	09:00-10:00	1	VN	CHEVALIER (CLio 6)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
652	1	1	2026-06-14	10:00-11:00	1	VN	BOUANET (R5)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
653	1	1	2026-06-13	11:00-12:00	1	VN	VIAL (Duster 4x4)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
654	1	1	2026-06-14	11:00-12:00	1	VN	PECOL (R4)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
655	1	1	2026-06-13	15:00-16:00	1	VN	PUERTAS (SANDERO)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
656	1	1	2026-06-12	12:00-13:00	2	VN	ENSMINGER (Spring ou Sandero)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
657	1	1	2026-06-12	15:00-16:00	2	VN	BRIGO (Sandero bleu)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
658	1	2	2026-06-11	09:00-10:00	1	VN	MERCIER (CLIO EVO)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
659	1	2	2026-06-14	09:00-10:00	1	VN	SOULE (GAMME EV)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
660	1	2	2026-06-15	09:00-10:00	1	VN	BOUCHERIE TAVES /VERNY	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
661	1	2	2026-06-12	10:00-11:00	1	VN	Esperaing (Twingo)	\N	2026-09-01 09:37:22.997802+00	1	\N	\N	\N	\N	\N	relance
662	1	2	2026-06-11	11:00-12:00	1	VN	DOME SANCY ARTENSE( KANGOO)	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
663	1	2	2026-06-13	11:00-12:00	1	VN	TERPENEAU (R5)	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
664	1	2	2026-06-11	14:00-15:00	1	VN	PETIT (R5 ETECH)	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
862	1	49	2026-06-12	15:00-16:00	1	VN	Derbias	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
665	1	2	2026-06-13	14:00-15:00	1	VN	MONIER (TWINGO OU R5)	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
666	1	2	2026-06-12	17:00-18:00	1	VN	DARPHIN (TWINGO)	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
667	1	2	2026-06-13	09:00-10:00	2	VN	BERGER SANDERO	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
668	1	2	2026-06-11	16:00-17:00	2	VN	Guillon Duster	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
669	1	42	2026-06-12	09:00-10:00	2	VN	Laustriat Jogger	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
670	1	42	2026-06-13	09:00-10:00	2	VN	Laborde Duster	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
671	1	42	2026-06-11	10:00-11:00	2	VN	Gaillard Sandero	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
672	1	42	2026-06-14	10:00-11:00	2	VN	Molle Sandero	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
673	1	42	2026-06-13	11:00-12:00	2	VN	Fardeau Sandero	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
674	1	42	2026-06-11	14:00-15:00	2	VN	Schmalzle Sandero	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
675	1	42	2026-06-13	14:00-15:00	2	VN	Hissler Sandero	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
676	1	42	2026-06-11	15:00-16:00	2	VN	Mousse Sandero	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
677	1	42	2026-06-12	15:00-16:00	2	VN	Caillavet	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
678	1	42	2026-06-14	15:00-16:00	2	VN	Ferret Sandero	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
679	1	42	2026-06-13	16:00-17:00	2	VN	Gauthier Bigster	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
680	1	42	2026-06-11	17:00-18:00	2	VN	Jonier Duster	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
681	1	42	2026-06-12	17:00-18:00	2	VN	Plet Sandero	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
682	1	43	2026-06-11	08:00-09:00	1	VN	Tourreau Symbioz	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
683	1	43	2026-06-12	08:00-09:00	1	VN	Coudrot Twingo/R5	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
684	1	43	2026-06-13	08:00-09:00	1	VN	Rouyer Clio 6	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
685	1	43	2026-06-14	08:00-09:00	1	VN	Bechonnet R5	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
686	1	43	2026-06-15	08:00-09:00	1	VN	Michon Twingo	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
687	1	43	2026-06-11	09:00-10:00	1	VN	Pontonier Rafale	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
688	1	43	2026-06-13	09:00-10:00	1	VN	Michon R4	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
689	1	43	2026-06-12	10:00-11:00	1	VN	Novac LC R5	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
690	1	43	2026-06-13	10:00-11:00	1	VN	Charpit R4	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
691	1	43	2026-06-13	11:00-12:00	1	VN	Raymond LC R5	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
692	1	43	2026-06-13	14:00-15:00	1	VN	Gammet Austral	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
693	1	43	2026-06-13	15:00-16:00	1	VN	Dumont LC Twingo	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
694	1	43	2026-06-12	16:00-17:00	1	VN	Gibert Symbioz	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
695	1	43	2026-06-15	17:00-18:00	1	VN	Pozzi LC Austral	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
696	1	43	2026-06-12	14:00-15:00	2	VN	Roux LC Duster	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
697	1	43	2026-06-14	14:00-15:00	2	VN	Chouchkaiev Duster	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
698	1	43	2026-06-13	15:00-16:00	2	VN	Gauthier duster	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
699	1	44	2026-06-11	08:00-09:00	1	VN	Bernard Megane E Tech	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
700	1	44	2026-06-11	09:00-10:00	1	VN	Fosse R5	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
701	1	44	2026-06-12	09:00-10:00	1	VN	Guilloux Symbioz	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
702	1	44	2026-06-11	10:00-11:00	1	VN	Danodier	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
703	1	44	2026-06-13	10:00-11:00	1	VN	Laborde R5	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
704	1	44	2026-06-15	10:00-11:00	1	VN	Berrat R5	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
705	1	44	2026-06-12	11:00-12:00	1	VN	Belland Master benne	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
706	1	44	2026-06-13	11:00-12:00	1	VN	Prudhomme R5	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
707	1	44	2026-06-14	11:00-12:00	1	VN	Normand R5	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
708	1	44	2026-06-12	14:00-15:00	1	VN	Singery Clio	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
709	1	44	2026-06-13	14:00-15:00	1	VN	Bertrand Twingo	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
710	1	44	2026-06-14	14:00-15:00	1	VN	Bostivois R5	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
711	1	44	2026-06-12	15:00-16:00	1	VN	Petitjean Twingo	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
712	1	44	2026-06-15	15:00-16:00	1	VN	Riollet Scenic	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
713	1	44	2026-06-12	16:00-17:00	1	VN	Sennepin Austral	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
714	1	44	2026-06-12	18:00-19:00	1	VN	Esnard Baillon clio 6	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
715	1	44	2026-06-11	15:00-16:00	2	VN	Moroy	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
716	1	45	2026-06-14	08:00-09:00	\N	VO	Repos	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
717	1	45	2026-06-13	11:00-12:00	\N	VO	Froliche Clio	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
718	1	45	2026-06-13	15:00-16:00	\N	VO	Lamouche	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
719	1	45	2026-06-11	16:00-17:00	\N	VO	Techer	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
720	1	46	2026-06-13	09:00-10:00	\N	VO	Maire André	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
721	1	46	2026-06-14	09:00-10:00	\N	VO	Da costa	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
722	1	46	2026-06-12	11:00-12:00	\N	VO	Delaye Gladys	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
723	1	46	2026-06-12	17:00-18:00	\N	VO	chapelet Romain	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
724	1	47	2026-06-14	10:00-11:00	\N	VO	El Asheb	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
725	1	47	2026-06-13	14:00-15:00	\N	VO	Auclair	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
726	1	47	2026-06-14	14:00-15:00	\N	VO	Peyrin	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
727	1	47	2026-06-14	15:00-16:00	\N	VO	Bordes	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
728	1	47	2026-06-12	15:00-16:00	\N	VO	Lopez-lage Sandero	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
729	1	31	2026-06-11	09:00-10:00	2	VN	DEPLACE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
730	1	31	2026-06-12	09:00-10:00	2	VN	OCTAVE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
731	1	31	2026-06-13	09:00-10:00	2	VN	MACE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
732	1	31	2026-06-14	09:00-10:00	2	VN	DIOT	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
733	1	31	2026-06-11	10:00-11:00	2	VN	NAJEAN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
734	1	31	2026-06-12	10:00-11:00	2	VN	PERROUX	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
735	1	31	2026-06-11	11:00-12:00	2	VN	RACAT	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
736	1	31	2026-06-11	14:00-15:00	2	VN	MECHIN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
737	1	31	2026-06-12	14:00-15:00	2	VN	M LORQUIN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
738	1	31	2026-06-13	14:00-15:00	2	VN	M BEAUDRON	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
739	1	31	2026-06-14	17:00-18:00	2	VN	MERCIER	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
740	1	32	2026-06-11	09:00-10:00	2	VN	BIGOT	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
741	1	32	2026-06-12	09:00-10:00	2	VN	BUTLER	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
742	1	32	2026-06-13	09:00-10:00	2	VN	RIBES PAPA	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
743	1	32	2026-06-14	09:00-10:00	2	VN	LECLERC	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
744	1	32	2026-06-15	09:00-10:00	2	VN	DESCHAMPS	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
745	1	32	2026-06-12	10:00-11:00	2	VN	STANITTA	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
746	1	32	2026-06-13	10:00-11:00	2	VN	RIBES MAMAN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
747	1	32	2026-06-11	11:00-12:00	2	VN	FERBOS	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
748	1	32	2026-06-13	11:00-12:00	2	VN	RIBES FILLE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
749	1	32	2026-06-11	14:00-15:00	2	VN	COULPIER	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
750	1	32	2026-06-12	14:00-15:00	2	VN	DUBUSSET	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
751	1	32	2026-06-13	14:00-15:00	2	VN	FERREIRA	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
752	1	32	2026-06-14	14:00-15:00	2	VN	MAYER	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
753	1	32	2026-06-11	16:00-17:00	2	VN	GUILLOT	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
754	1	32	2026-06-12	16:00-17:00	2	VN	VASSAL	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
755	1	32	2026-06-11	17:00-18:00	2	VN	LECOIN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
756	1	32	2026-06-12	17:00-18:00	2	VN	LAFONT GAGNIERE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
757	1	32	2026-06-12	18:00-19:00	2	VN	SIMONET	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
758	1	33	2026-06-11	09:00-10:00	1	VN	M ODIN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
759	1	33	2026-06-12	09:00-10:00	1	VN	M VILLE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
760	1	33	2026-06-13	09:00-10:00	1	VN	GARDETTE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
761	1	33	2026-06-14	09:00-10:00	1	VN	TRAFARSKI	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
762	1	33	2026-06-11	10:00-11:00	1	VN	MUYARD	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
763	1	33	2026-06-12	10:00-11:00	1	VN	RIGAUDIAS	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
764	1	33	2026-06-13	10:00-11:00	1	VN	THOUVENET	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
765	1	33	2026-06-14	10:00-11:00	1	VN	BAL	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
766	1	33	2026-06-15	10:00-11:00	1	VN	COURTOIS	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
767	1	33	2026-06-11	11:00-12:00	1	VN	PUCCPCCI	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
768	1	33	2026-06-12	11:00-12:00	1	VN	M TROTIN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
769	1	33	2026-06-13	11:00-12:00	1	VN	BUVAT	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
770	1	33	2026-06-14	11:00-12:00	1	VN	STONS	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
771	1	33	2026-06-11	12:00-13:00	1	VN	M GENESTE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
772	1	33	2026-06-11	14:00-15:00	1	VN	LOMBARD	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
773	1	33	2026-06-12	14:00-15:00	1	VN	GONCALVES	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
774	1	33	2026-06-13	14:00-15:00	1	VN	PAGES	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
775	1	33	2026-06-11	15:00-16:00	1	VN	DAVID	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
776	1	33	2026-06-13	15:00-16:00	1	VN	FARRET	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
777	1	33	2026-06-11	16:00-17:00	1	VN	DECORAY	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
778	1	33	2026-06-12	16:00-17:00	1	VN	M RIESEN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
779	1	33	2026-06-13	16:00-17:00	1	VN	JEUDI	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
780	1	33	2026-06-14	16:00-17:00	1	VN	M RIGAUDIAS	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
781	1	33	2026-06-11	17:00-18:00	1	VN	M HENRIOT	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
782	1	33	2026-06-12	17:00-18:00	1	VN	LE VAN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
783	1	33	2026-06-13	17:00-18:00	1	VN	BOUILLERAND	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
784	1	33	2026-06-15	17:00-18:00	1	VN	MAITRIAS	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
785	1	33	2026-06-11	18:00-19:00	1	VN	CHARLIEU	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
786	1	33	2026-06-12	18:00-19:00	1	VN	ALLIGIER	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
787	1	33	2026-06-13	18:00-19:00	1	VN	M ROUSSEL	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
788	1	34	2026-06-11	09:00-10:00	1	VN	DUJARDIN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
789	1	34	2026-06-13	09:00-10:00	1	VN	LEDOUX	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
790	1	34	2026-06-15	09:00-10:00	1	VN	BELVEDERE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
791	1	34	2026-06-11	10:00-11:00	1	VN	MOREL	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
792	1	34	2026-06-12	10:00-11:00	1	VN	WEIDELICH	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
793	1	34	2026-06-14	10:00-11:00	1	VN	BRANCHI	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
794	1	34	2026-06-11	11:00-12:00	1	VN	BERNARD ALPINE 290	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
795	1	34	2026-06-12	11:00-12:00	1	VN	DEBUSSY	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
796	1	34	2026-06-13	11:00-12:00	1	VN	TETU	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
797	1	34	2026-06-11	15:00-16:00	1	VN	LETIZIA	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
798	1	34	2026-06-12	15:00-16:00	1	VN	JOUFFRE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
799	1	34	2026-06-13	15:00-16:00	1	VN	EVEILLAU	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
800	1	34	2026-06-14	15:00-16:00	1	VN	BEAUDEAN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
801	1	34	2026-06-14	16:00-17:00	1	VN	KOUDOUGOU	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
802	1	34	2026-06-11	17:00-18:00	1	VN	BEAUMET	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
803	1	34	2026-06-12	17:00-18:00	1	VN	DUPRE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
804	1	34	2026-06-13	17:00-18:00	1	VN	MECHIN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
805	1	34	2026-06-15	17:00-18:00	1	VN	GUILLON	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
806	1	34	2026-06-12	18:00-19:00	1	VN	IMBERDIS PAPA	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
807	1	34	2026-06-12	08:00-09:00	2	VN	IMBERDI FILLE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
808	1	35	2026-06-11	08:00-09:00	1	VN	REGNY	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
809	1	35	2026-06-12	08:00-09:00	1	VN	DURANTET	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
810	1	35	2026-06-11	09:00-10:00	1	VN	AMIGO	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
811	1	35	2026-06-12	10:00-11:00	1	VN	GLADINE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
812	1	35	2026-06-13	10:00-11:00	1	VN	TALABARD	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
813	1	35	2026-06-14	10:00-11:00	1	VN	CARRICO	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
814	1	35	2026-06-11	11:00-12:00	1	VN	BUTEY	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
815	1	35	2026-06-11	14:00-15:00	1	VN	DOCHEZ	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
816	1	35	2026-06-13	14:00-15:00	1	VN	MARTIN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
817	1	35	2026-06-14	14:00-15:00	1	VN	SOPHIE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
818	1	35	2026-06-12	16:00-17:00	1	VN	GOUGAT	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
819	1	35	2026-06-11	17:00-18:00	1	VN	GUERET	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
820	1	35	2026-06-14	17:00-18:00	1	VN	REVENU	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
821	1	36	2026-06-11	09:00-10:00	1	VN	BERTHAULT	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
822	1	36	2026-06-11	10:00-11:00	1	VN	MEGE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
823	1	36	2026-06-13	10:00-11:00	1	VN	DURANTET	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
824	1	36	2026-06-12	11:00-12:00	1	VN	JANIQUE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
825	1	36	2026-06-13	15:00-16:00	1	VN	LEMAITRE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
826	1	36	2026-06-14	15:00-16:00	1	VN	PORTTIN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
827	1	36	2026-06-11	16:00-17:00	1	VN	VLACH	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
828	1	36	2026-06-12	16:00-17:00	1	VN	SOCOL	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
829	1	36	2026-06-13	17:00-18:00	1	VN	ROTTAT	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
830	1	39	2026-06-11	09:00-10:00	\N	VO	DAPZOL	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
831	1	39	2026-06-12	09:00-10:00	\N	VO	LABUSSIERE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
832	1	39	2026-06-14	09:00-10:00	\N	VO	DAMPURE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
833	1	39	2026-06-12	14:00-15:00	\N	VO	CASILE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
834	1	39	2026-06-15	14:00-15:00	\N	VO	PROVOST	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
835	1	39	2026-06-13	16:00-17:00	\N	VO	ALIGIER	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
836	1	39	2026-06-11	17:00-18:00	\N	VO	CHANTELOUP	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
837	1	39	2026-06-12	18:00-19:00	\N	VO	MILLER	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
838	1	40	2026-06-11	10:00-11:00	\N	VO	HEDOO	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
839	1	40	2026-06-13	10:00-11:00	\N	VO	LAGACHE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
840	1	40	2026-06-14	11:00-12:00	\N	VO	BONJEAN	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
841	1	40	2026-06-11	15:00-16:00	\N	VO	LEDENTU	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
842	1	40	2026-06-14	15:00-16:00	\N	VO	ETIENNE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
843	1	41	2026-06-13	09:00-10:00	\N	VO	GABARD	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
844	1	41	2026-06-14	10:00-11:00	\N	VO	DENNE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
845	1	41	2026-06-13	11:00-12:00	\N	VO	VEYNE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
846	1	41	2026-06-13	14:00-15:00	\N	VO	EYMARD	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
847	1	41	2026-06-14	15:00-16:00	\N	VO	HUSSAR	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
848	1	41	2026-06-12	16:00-17:00	\N	VO	TOUREAU	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
849	1	41	2026-06-13	16:00-17:00	\N	VO	BELOT	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
850	1	41	2026-06-15	16:00-17:00	\N	VO	NAVARRE	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
851	1	41	2026-06-11	17:00-18:00	\N	VO	PATON	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
852	1	48	2026-06-13	08:00-09:00	1	VN	Absent	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
853	1	48	2026-06-11	09:00-10:00	1	VN	M Languedoc	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
854	1	48	2026-06-12	11:00-12:00	1	VN	M Crohas	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
855	1	48	2026-06-11	18:00-19:00	1	VN	M Massimino	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
856	1	48	2026-06-12	09:00-10:00	2	VN	M Legay	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
857	1	49	2026-06-11	09:00-10:00	1	VN	M Gardes	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
858	1	49	2026-06-13	09:00-10:00	1	VN	Thiers	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
859	1	49	2026-06-15	09:00-10:00	1	VN	M Pasquet	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
860	1	49	2026-06-11	10:00-11:00	1	VN	M Fayolle	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
861	1	49	2026-06-12	11:00-12:00	1	VN	Fouillot	\N	2026-09-01 09:37:23.39591+00	1	\N	\N	\N	\N	\N	relance
8472	933	1887	2026-10-08	08:00-09:00	\N	VO	test	\N	2026-10-03 08:53:22.042801+00	98	2026-10-03 08:53:42.478763+00	98	2026-10-03 08:53:42.83+00	98	eb059baa-fef8-4356-8c7d-8ccbc9164301	relance
8747	933	79	2026-10-10	09:00-10:00	1	VN	PANEC RENAULT	\N	2026-10-06 09:59:21.567915+00	1776	\N	\N	\N	\N	753687de-b3d1-4c6e-9ab8-4c4a85412c2b	relance
8976	933	41	2026-10-12	17:00-18:00	\N	VO	AUMIOT	\N	2026-10-06 10:45:04.222622+00	97	\N	\N	\N	\N	821539e2-c93a-4f23-a8ab-313d934e8a01	relance
9000	933	4204	2026-10-12	15:00-16:00	2	VN	DEVAUX DUSTER	\N	2026-10-06 10:48:02.457197+00	1782	\N	\N	\N	\N	c6318298-d9c4-49d7-a934-34a5001c66aa	relance
9003	933	43	2026-10-08	10:00-11:00	1	VN	FONDARD CAPTUR	\N	2026-10-06 10:48:45.341078+00	1782	\N	\N	\N	\N	c6f9e214-df12-4338-9e58-4f2981a9a345	relance
9009	933	17	2026-10-09	18:00-19:00	1	VN	Coquery Twingo	\N	2026-10-06 10:49:16.349929+00	3	\N	\N	\N	\N	dc627a2f-30cf-4b18-be2d-6d6e57be25c1	relance
9012	933	43	2026-10-09	15:00-16:00	1	VN	OLIVIER R5 TWINGO	\N	2026-10-06 10:49:32.304549+00	1782	\N	\N	\N	\N	4540b0b3-4a3a-48d7-a330-327935c06681	relance
9018	933	17	2026-10-10	13:00-14:00	1	VN	Mouly Twingo/R5	\N	2026-10-06 10:50:23.936783+00	3	\N	\N	\N	\N	cd03a91c-61bb-4f3d-bcc4-734f0e0c538d	relance
9102	933	49	2026-10-09	18:00-19:00	1	VN	M BARGOIN (VP RODDIER)	\N	2026-10-06 14:07:17.228477+00	1783	\N	\N	\N	\N	4c2bd0b6-e419-4562-961c-25a01944130f	relance
9265	933	32	2026-10-11	14:00-15:00	1	VN	BATIGNY	\N	2026-10-06 15:20:05.466144+00	97	\N	\N	\N	\N	eadafb1f-7c3c-4ab9-9341-2d4941e4eddd	relance
863	1	49	2026-06-13	16:00-17:00	1	VN	Chouvel	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
864	1	49	2026-06-14	10:00-11:00	2	VN	Buvat	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
865	1	49	2026-06-12	11:00-12:00	2	VN	Chefdeville	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
866	1	49	2026-06-11	14:00-15:00	2	VN	M Gouttetoque	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
867	1	49	2026-06-13	14:00-15:00	2	VN	Culpo	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
868	1	50	2026-06-13	09:00-10:00	1	VN	M Roccetto	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
869	1	50	2026-06-14	09:00-10:00	1	VN	M Dartois	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
870	1	50	2026-06-11	10:00-11:00	1	VN	M Gentil	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
871	1	50	2026-06-12	10:00-11:00	1	VN	M Haverland	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
872	1	50	2026-06-13	10:00-11:00	1	VN	M Goutefangheas	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
873	1	50	2026-06-14	10:00-11:00	1	VN	M Mathe	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
874	1	50	2026-06-11	14:00-15:00	1	VN	M Arnaud	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
875	1	50	2026-06-12	14:00-15:00	1	VN	Mme Bonnal	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
876	1	50	2026-06-14	14:00-15:00	1	VN	M Raymond	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
877	1	50	2026-06-15	14:00-15:00	1	VN	M Privat	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
878	1	50	2026-06-11	15:00-16:00	1	VN	M Escailler	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
879	1	50	2026-06-12	15:00-16:00	1	VN	M Couturier	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
880	1	50	2026-06-14	15:00-16:00	1	VN	M Roche	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
881	1	50	2026-06-11	17:00-18:00	1	VN	M Ferrier	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
882	1	50	2026-06-12	18:00-19:00	1	VN	Mme Mazellier	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
883	1	51	2026-06-14	09:00-10:00	\N	VO	M Perrin	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
884	1	51	2026-06-11	10:00-11:00	\N	VO	M Monteilhet	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
885	1	51	2026-06-14	15:00-16:00	\N	VO	M Pousset	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
886	1	51	2026-06-11	18:00-19:00	\N	VO	M Gomez	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
887	1	52	2026-06-14	08:00-09:00	\N	VO	absent	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
888	1	52	2026-06-13	09:00-10:00	\N	VO	M Roussillon	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
889	1	52	2026-06-11	10:00-11:00	\N	VO	M Montpetroux	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
890	1	52	2026-06-12	10:00-11:00	\N	VO	M Delbege	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
891	1	52	2026-06-13	10:00-11:00	\N	VO	M Plazenet	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
892	1	52	2026-06-13	11:00-12:00	\N	VO	M Montereal	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
893	1	52	2026-06-11	14:00-15:00	\N	VO	M Leudir	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
894	1	52	2026-06-11	15:00-16:00	\N	VO	M Borel	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
895	1	52	2026-06-12	15:00-16:00	\N	VO	M Brugas	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
896	1	52	2026-06-11	16:00-17:00	\N	VO	M Nicolas	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
897	1	52	2026-06-11	17:00-18:00	\N	VO	M Barge	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
898	1	52	2026-06-12	17:00-18:00	\N	VO	M Poquet	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
899	1	62	2026-06-13	09:00-10:00	1	VN	Mr DOUIX	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
900	1	62	2026-06-14	10:00-11:00	1	VN	Mme DEGOUDE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
901	1	62	2026-06-13	11:00-12:00	1	VN	Mme PALKHIVALA	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
902	1	62	2026-06-13	14:00-15:00	1	VN	JEANNNOT	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
903	1	62	2026-06-14	14:00-15:00	1	VN	MmeTAMAGNI	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
904	1	62	2026-06-11	15:00-16:00	1	VN	Mme APTEL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
905	1	62	2026-06-13	15:00-16:00	1	VN	GROLIERE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
906	1	62	2026-06-14	16:00-17:00	1	VN	Mme MORVAN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
907	1	62	2026-06-11	17:00-18:00	1	VN	Mme VALENTE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
908	1	62	2026-06-14	15:00-16:00	2	VN	Mme RODIER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
909	1	63	2026-06-13	10:00-11:00	1	VN	ROBILLON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
910	1	63	2026-06-12	11:00-12:00	1	VN	PINET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
911	1	63	2026-06-12	15:00-16:00	1	VN	DUMAS	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
912	1	63	2026-06-13	15:00-16:00	1	VN	ABOU SAMRA	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
913	1	63	2026-06-14	15:00-16:00	1	VN	DELORME	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
914	1	63	2026-06-13	17:00-18:00	1	VN	GARTILLON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
915	1	63	2026-06-14	10:00-11:00	2	VN	DELBOS	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
916	1	63	2026-06-13	11:00-12:00	2	VN	SAUVESTRE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
917	1	63	2026-06-13	14:00-15:00	2	VN	FIORENTINO	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
918	1	63	2026-06-11	15:00-16:00	2	VN	HALLIROL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
919	1	63	2026-06-11	16:00-17:00	2	VN	COMPTE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
920	1	63	2026-06-12	16:00-17:00	2	VN	DALBE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
921	1	63	2026-06-13	16:00-17:00	2	VN	CONTOUX	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
922	1	63	2026-06-11	17:00-18:00	2	VN	BELLY	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
923	1	65	2026-06-11	08:00-09:00	1	VN	Mme BERTRAND	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
924	1	65	2026-06-11	09:00-10:00	1	VN	Mr MORAND	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
925	1	65	2026-06-14	11:00-12:00	1	VN	Mr FOURNIER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
926	1	65	2026-06-14	14:00-15:00	1	VN	BESSON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
927	1	65	2026-06-12	15:00-16:00	1	VN	DEAN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
928	1	65	2026-06-13	18:00-19:00	1	VN	Mr SELLIN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
929	1	65	2026-06-11	09:00-10:00	2	VN	DEMANGE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
930	1	65	2026-06-14	09:00-10:00	2	VN	M VIGANOTTI	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
931	1	65	2026-06-11	11:00-12:00	2	VN	M MOLLE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
932	1	65	2026-06-11	14:00-15:00	2	VN	Mme  CROS	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
933	1	66	2026-06-11	09:00-10:00	1	VN	MAHAUT	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
934	1	66	2026-06-11	11:00-12:00	1	VN	CAUTAL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
935	1	66	2026-06-13	11:00-12:00	1	VN	JEANNOT	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
936	1	66	2026-06-11	14:00-15:00	1	VN	LECOCALI	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
937	1	66	2026-06-12	14:00-15:00	1	VN	RAMEL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
938	1	66	2026-06-12	15:00-16:00	1	VN	BRAS	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
939	1	66	2026-06-12	16:00-17:00	1	VN	PILLON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
940	1	66	2026-06-11	10:00-11:00	2	VN	GIOAN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
941	1	66	2026-06-12	10:00-11:00	2	VN	DUPART	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
942	1	66	2026-06-13	10:00-11:00	2	VN	MEURIE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
943	1	66	2026-06-15	10:00-11:00	2	VN	BRUCIAMACCHIE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
944	1	66	2026-06-13	12:00-13:00	2	VN	GROLIERES	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
945	1	66	2026-06-13	13:00-14:00	2	VN	BACHAYTER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
946	1	66	2026-06-14	14:00-15:00	2	VN	BEABIN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
947	1	66	2026-06-14	15:00-16:00	2	VN	ESTRADE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
948	1	66	2026-06-11	16:00-17:00	2	VN	ZYMAN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
949	1	66	2026-06-11	17:00-18:00	2	VN	NARCE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
950	1	66	2026-06-11	18:00-19:00	2	VN	NARCE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
951	1	67	2026-06-15	09:00-10:00	1	VN	I	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
952	1	67	2026-06-11	10:00-11:00	1	VN	CROS	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
953	1	67	2026-06-14	10:00-11:00	1	VN	OUDOUL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
954	1	67	2026-06-14	11:00-12:00	1	VN	DUFEUTEULE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
955	1	67	2026-06-12	14:00-15:00	1	VN	CARBASSE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
956	1	67	2026-06-14	15:00-16:00	1	VN	ROCHES	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
957	1	67	2026-06-12	17:00-18:00	1	VN	BOUQUET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
958	1	67	2026-06-13	18:00-19:00	1	VN	BOURDON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
959	1	67	2026-06-11	09:00-10:00	2	VN	MEUNIER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
960	1	67	2026-06-12	09:00-10:00	2	VN	HERITIER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
961	1	67	2026-06-13	09:00-10:00	2	VN	ROBILLON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
962	1	67	2026-06-13	10:00-11:00	2	VN	PEDRONETTO	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
963	1	67	2026-06-13	11:00-12:00	2	VN	MAISONNEUVE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
964	1	67	2026-06-11	14:00-15:00	2	VN	TISSERAND	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
965	1	67	2026-06-12	16:00-17:00	2	VN	ROFFET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
966	1	67	2026-06-14	16:00-17:00	2	VN	ANSELLEME	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
967	1	68	2026-06-11	08:00-09:00	\N	VO	DAUBARD	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
968	1	68	2026-06-12	08:00-09:00	\N	VO	TRASSOUDAINE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
969	1	68	2026-06-11	09:00-10:00	\N	VO	Mme DELPAGNE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
970	1	68	2026-06-11	10:00-11:00	\N	VO	I	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
971	1	68	2026-06-13	10:00-11:00	\N	VO	Mme BICHERAY	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
972	1	68	2026-06-11	14:00-15:00	\N	VO	Mme SEMBEL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
973	1	68	2026-06-11	08:00-09:00	\N	VO	COSTON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
974	1	68	2026-06-12	10:00-11:00	\N	VO	MAZET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
975	1	68	2026-06-13	14:00-15:00	\N	VO	MMe PARDANAUD	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
976	1	68	2026-06-12	16:00-17:00	\N	VO	Mme GARINOT	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
977	1	69	2026-06-13	10:00-11:00	\N	VO	TALLOBRE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
978	1	69	2026-06-13	14:00-15:00	\N	VO	PORTEIX	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
979	1	69	2026-06-11	18:00-19:00	\N	VO	MONDILLON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
980	1	70	2026-06-11	09:00-10:00	\N	VO	NOUGUIER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
981	1	70	2026-06-13	09:00-10:00	\N	VO	PLANTIN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
982	1	70	2026-06-13	10:00-11:00	\N	VO	DIAS	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
983	1	70	2026-06-11	11:00-12:00	\N	VO	DUCHER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
984	1	70	2026-06-11	14:00-15:00	\N	VO	PERRIN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
985	1	70	2026-06-13	14:00-15:00	\N	VO	BENKEMOUN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
986	1	70	2026-06-11	15:00-16:00	\N	VO	PRANYES	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
987	1	70	2026-06-11	16:00-17:00	\N	VO	BREJAUD	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
988	1	70	2026-06-11	08:00-09:00	\N	VO	ANGLADE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
989	1	70	2026-06-11	10:00-11:00	\N	VO	LAPELEGERIE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
990	1	70	2026-06-12	10:00-11:00	\N	VO	BARD	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
991	1	70	2026-06-12	11:00-12:00	\N	VO	VANDERSUISSE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
992	1	53	2026-06-11	08:00-09:00	1	VN	DELALANDE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
993	1	53	2026-06-11	09:00-10:00	1	VN	CHABERT	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
994	1	53	2026-06-11	10:00-11:00	1	VN	VIGOUROUX	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
995	1	53	2026-06-13	10:00-11:00	1	VN	LYOTARD	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
996	1	53	2026-06-14	10:00-11:00	1	VN	VILLESECHE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
997	1	53	2026-06-13	11:00-12:00	1	VN	FAURE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
998	1	53	2026-06-11	14:00-15:00	1	VN	SAGNARD	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
999	1	53	2026-06-12	14:00-15:00	1	VN	BEGEY	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1000	1	53	2026-06-13	14:00-15:00	1	VN	CHARBONNEL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1001	1	53	2026-06-12	15:00-16:00	1	VN	CHABERT	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1002	1	53	2026-06-13	15:00-16:00	1	VN	OUILON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1003	1	53	2026-06-14	15:00-16:00	1	VN	ORFEUBRE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1004	1	53	2026-06-12	16:00-17:00	1	VN	DELUBAC	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1005	1	53	2026-06-13	16:00-17:00	1	VN	AURELLE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1006	1	53	2026-06-14	16:00-17:00	1	VN	MAUACI	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1007	1	53	2026-06-12	17:00-18:00	1	VN	SOUCHON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1008	1	53	2026-06-12	18:00-19:00	1	VN	MAGNE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1009	1	53	2026-06-12	13:00-14:00	2	VN	VALLET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1010	1	53	2026-06-11	15:00-16:00	2	VN	RAFFARD DE BRIENNE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1011	1	54	2026-06-11	09:00-10:00	1	VN	M GUILLON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1012	1	54	2026-06-12	10:00-11:00	1	VN	Mr PILlOT	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1013	1	54	2026-06-14	10:00-11:00	1	VN	Mr COURTIAL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1014	1	54	2026-06-11	11:00-12:00	1	VN	ART FLORAL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1015	1	54	2026-06-12	11:00-12:00	1	VN	MR LAUBUGE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1016	1	54	2026-06-12	14:00-15:00	1	VN	Mme TEYSSIER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1017	1	54	2026-06-12	17:00-18:00	1	VN	Mme VAUZELLE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1018	1	54	2026-06-13	09:00-10:00	2	VN	Mme ROCHETTE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1019	1	54	2026-06-11	13:00-14:00	2	VN	Mme PAQUIN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1020	1	55	2026-06-11	09:00-10:00	1	VN	DAVID / LANGEAC	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1021	1	55	2026-06-13	09:00-10:00	1	VN	DREYFUS	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1022	1	55	2026-06-11	10:00-11:00	1	VN	BESSON / LANGEAC	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1023	1	55	2026-06-15	14:00-15:00	1	VN	GERANTON / VOREY	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1024	1	55	2026-06-11	09:00-10:00	2	VN	GOBELET / LANGEAC	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1025	1	55	2026-06-11	14:00-15:00	2	VN	GIRARD / SERVEL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1026	1	55	2026-06-12	14:00-15:00	2	VN	BESSON	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1027	1	55	2026-06-11	17:00-18:00	2	VN	MARIN / BIGSTER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1028	1	56	2026-06-12	10:00-11:00	1	VN	DUPUIS	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1029	1	56	2026-06-13	10:00-11:00	1	VN	JOUANNY	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1030	1	56	2026-06-14	10:00-11:00	1	VN	PONTVIANNE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1031	1	56	2026-06-15	10:00-11:00	1	VN	BOUCHET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1032	1	56	2026-06-11	11:00-12:00	1	VN	BONNET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1033	1	56	2026-06-13	13:00-14:00	1	VN	BATTONET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1034	1	56	2026-06-15	14:00-15:00	1	VN	CROS	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1035	1	56	2026-06-13	15:00-16:00	1	VN	NOUVET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1036	1	56	2026-06-14	16:00-17:00	1	VN	AVOUAC	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1037	1	56	2026-06-15	16:00-17:00	1	VN	MAZET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1038	1	56	2026-06-11	10:00-11:00	2	VN	MULLER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1039	1	57	2026-06-13	09:00-10:00	\N	VO	M COURJAUD	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1040	1	57	2026-06-14	09:00-10:00	\N	VO	9h30 Berger	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1041	1	57	2026-06-13	11:00-12:00	\N	VO	Mr MEZIN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1042	1	57	2026-06-12	14:00-15:00	\N	VO	MMe BOSSAERT	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1043	1	58	2026-06-11	10:00-11:00	\N	VO	ROUSSET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1044	1	58	2026-06-14	10:00-11:00	\N	VO	TORRESAN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1045	1	58	2026-06-13	11:00-12:00	\N	VO	VIALVIELLE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1046	1	58	2026-06-13	13:00-14:00	\N	VO	DARBOUSSET	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1047	1	58	2026-06-11	14:00-15:00	\N	VO	DAMIEN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1048	1	58	2026-06-12	14:00-15:00	\N	VO	CIODOIU	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1049	1	58	2026-06-11	15:00-16:00	\N	VO	JEANNIN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1050	1	58	2026-06-11	16:00-17:00	\N	VO	CLUZEL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1051	1	58	2026-06-14	16:00-17:00	\N	VO	DUMOND	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1052	1	58	2026-06-12	17:00-18:00	\N	VO	RODRIGUES	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1053	1	58	2026-06-11	18:00-19:00	\N	VO	LIOGIER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1054	1	59	2026-06-12	09:00-10:00	1	VN	TAULAMESSE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1055	1	59	2026-06-13	09:00-10:00	1	VN	BADUEL	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1056	1	59	2026-06-11	10:00-11:00	1	VN	MARCU	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1057	1	59	2026-06-13	10:00-11:00	1	VN	BERNIER	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1058	1	59	2026-06-14	10:00-11:00	1	VN	HERME	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1059	1	59	2026-06-14	11:00-12:00	1	VN	CALANDRE	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1060	1	59	2026-06-13	14:00-15:00	1	VN	PEPIN	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1061	1	59	2026-06-11	16:00-17:00	1	VN	LEITAO	\N	2026-09-01 09:37:23.818844+00	1	\N	\N	\N	\N	\N	relance
1062	1	59	2026-06-15	16:00-17:00	1	VN	COLLET	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1063	1	59	2026-06-13	17:00-18:00	1	VN	BRUNET	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1064	1	59	2026-06-11	18:00-19:00	1	VN	OZIOL	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1065	1	59	2026-06-12	10:00-11:00	2	VN	PELOTHIER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1066	1	59	2026-06-12	14:00-15:00	2	VN	SEGOLA	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1067	1	59	2026-06-14	14:00-15:00	2	VN	POUDEVIGNE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1068	1	59	2026-06-12	15:00-16:00	2	VN	BROJAN	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1069	1	59	2026-06-12	16:00-17:00	2	VN	FOURNIER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1070	1	59	2026-06-12	17:00-18:00	2	VN	GAUGAIN	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1071	1	61	2026-06-12	10:00-11:00	\N	VO	REMISE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1072	1	61	2026-06-15	10:00-11:00	\N	VO	SOANE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1073	1	61	2026-06-11	14:00-15:00	\N	VO	JIMENEZ	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1074	1	61	2026-06-13	14:00-15:00	\N	VO	DELRIEU	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1075	1	61	2026-06-14	14:00-15:00	\N	VO	PORTAL	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1076	1	61	2026-06-12	09:00-10:00	\N	VO	DELON	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1077	1	61	2026-06-14	10:00-11:00	\N	VO	MONIEZ	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1078	1	61	2026-06-12	14:00-15:00	\N	VO	MONTESANI	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1079	1	61	2026-06-13	16:00-17:00	\N	VO	REMIZE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1080	1	61	2026-06-12	17:00-18:00	\N	VO	ASTIER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1081	1	61	2026-06-12	18:00-19:00	\N	VO	TROCELLIER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1082	1	79	2026-06-13	09:00-10:00	1	VN	BONAMI DUSTER CAPTUR	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1083	1	79	2026-06-11	10:00-11:00	1	VN	LEGRAND TWINGO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1084	1	79	2026-06-12	11:00-12:00	1	VN	BELLIERE R4	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1085	1	79	2026-06-13	15:00-16:00	1	VN	GARIN TW3 OU R5	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1086	1	79	2026-06-12	16:00-17:00	2	VN	DELOUS SANDERO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1087	1	79	2026-06-13	16:00-17:00	2	VN	DOMERGUES SPRING OU SANDERO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1088	1	79	2026-06-11	17:00-18:00	2	VN	BARBIER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1089	1	79	2026-06-13	17:00-18:00	2	VN	GARCIA CLIO 6	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1090	1	80	2026-06-11	08:00-09:00	1	VN	OLIVIER TWINGO VD	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1091	1	80	2026-06-11	09:00-10:00	1	VN	GUTFREND CLIO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1092	1	80	2026-06-12	09:00-10:00	1	VN	AURIOL TWINGO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1093	1	80	2026-06-13	09:00-10:00	1	VN	ESPINASSE RENOUV ZOE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1094	1	80	2026-06-11	10:00-11:00	1	VN	VASILIC TWINGO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1095	1	80	2026-06-12	10:00-11:00	1	VN	CROS CLIO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1096	1	80	2026-06-13	10:00-11:00	1	VN	CARRIERE RENOUV MEGANE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1097	1	80	2026-06-15	10:00-11:00	1	VN	BLANC	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1098	1	80	2026-06-11	11:00-12:00	1	VN	DUBAR CAPTUR	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1099	1	80	2026-06-15	11:00-12:00	1	VN	LACLEDE RENOUV MEGANE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1100	1	80	2026-06-11	12:00-13:00	1	VN	MOULY RENOUV ZOE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1101	1	80	2026-06-11	13:00-14:00	1	VN	MOLINIER CAPTUR	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1102	1	80	2026-06-11	14:00-15:00	1	VN	MAZARS	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1103	1	80	2026-06-12	14:00-15:00	1	VN	FLEURY SCENIC	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1104	1	80	2026-06-12	15:00-16:00	1	VN	DELOUS CLIO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1105	1	80	2026-06-11	16:00-17:00	1	VN	JOULIA	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1106	1	80	2026-06-11	17:00-18:00	1	VN	MERCIER A VOIR	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1107	1	80	2026-06-11	18:00-19:00	1	VN	ROUSSELLE RENOUV ZOE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1108	1	81	2026-06-14	14:00-15:00	1	VN	GRIBBAL TWINGO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1109	1	81	2026-06-11	18:00-19:00	1	VN	CHENE CHRISTOPHE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1110	1	81	2026-06-12	09:00-10:00	2	VN	BARRETTE SANDERO VD	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1111	1	81	2026-06-11	10:00-11:00	2	VN	QUENHE JOGGER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1112	1	81	2026-06-12	11:00-12:00	2	VN	GATIMEL DUSTER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1113	1	81	2026-06-14	12:00-13:00	2	VN	FOUCAT SANDERO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1114	1	81	2026-06-11	16:00-17:00	2	VN	FABIE SANDERO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1115	1	82	2026-06-11	09:00-10:00	1	VN	CARLES	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1116	1	82	2026-06-13	09:00-10:00	1	VN	ROGUET MEGANE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1117	1	82	2026-06-11	10:00-11:00	1	VN	FAGES	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1118	1	82	2026-06-12	10:00-11:00	1	VN	VERNES CLIO 6	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1119	1	82	2026-06-13	10:00-11:00	1	VN	MURAT SCENIC	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1120	1	82	2026-06-15	10:00-11:00	1	VN	PHOUMAN CLIO 5	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1121	1	82	2026-06-13	11:00-12:00	1	VN	DELMAS TWINGO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1122	1	82	2026-06-13	12:00-13:00	1	VN	NOWFOL R4	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1123	1	82	2026-06-13	14:00-15:00	1	VN	ALONZO CLIO 6	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1124	1	82	2026-06-13	16:00-17:00	1	VN	FRUNEAU TWINGO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1125	1	82	2026-06-11	17:00-18:00	1	VN	GEMARIN	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1126	1	82	2026-06-12	17:00-18:00	1	VN	ALBERT SCENIC	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1127	1	82	2026-06-12	09:00-10:00	2	VN	LERIDENT BIGSTER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1128	1	82	2026-06-11	14:00-15:00	2	VN	DEGUIRARD DUSTER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1129	1	82	2026-06-13	15:00-16:00	2	VN	DOMERGUES JOGGER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1130	1	82	2026-06-11	17:00-18:00	2	VN	BLANQUET SANDERO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1131	1	83	2026-06-13	10:00-11:00	\N	VO	HYGONET	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1132	1	83	2026-06-12	11:00-12:00	\N	VO	MER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1133	1	83	2026-06-14	11:00-12:00	\N	VO	REDOULES	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1134	1	83	2026-06-13	15:00-16:00	\N	VO	LADET TWINGO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1135	1	83	2026-06-14	15:00-16:00	\N	VO	MOUNIRAT	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1136	1	83	2026-06-11	16:00-17:00	\N	VO	COMBRET SPRING	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1137	1	83	2026-06-13	16:00-17:00	\N	VO	ALFONSO JOGGER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1138	1	83	2026-06-14	16:00-17:00	\N	VO	BEN DAOUD	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1139	1	84	2026-06-13	09:00-10:00	\N	VO	LEONNARD CLIO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1140	1	84	2026-06-12	15:00-16:00	\N	VO	THERON CLIO	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1141	1	84	2026-06-11	17:00-18:00	\N	VO	MAUME ZOE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1142	1	84	2026-06-12	17:00-18:00	\N	VO	LACAN MELANIE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1143	1	84	2026-06-13	17:00-18:00	\N	VO	ESTELLE CAVALERIE ZE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1144	1	85	2026-06-12	10:00-11:00	\N	VO	AGUERA AUDI A1	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1145	1	85	2026-06-15	11:00-12:00	\N	VO	PANOT	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1146	1	85	2026-06-12	14:00-15:00	\N	VO	BLANC CAPTUR	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1147	1	85	2026-06-12	15:00-16:00	\N	VO	RAYNAL CAPTUR	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1148	1	92	2026-06-11	10:00-11:00	1	VN	TOVAR	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1149	1	92	2026-06-12	10:00-11:00	1	VN	MERDRIGNAC	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1150	1	92	2026-06-11	11:00-12:00	1	VN	NOZIERES	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1151	1	92	2026-06-12	11:00-12:00	1	VN	GARD	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1152	1	92	2026-06-12	14:00-15:00	1	VN	OGLAZA	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1153	1	92	2026-06-13	14:00-15:00	1	VN	CONSTENSOU	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1154	1	92	2026-06-12	15:00-16:00	1	VN	SOULIER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1155	1	92	2026-06-13	15:00-16:00	1	VN	MEZGHANI	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1156	1	92	2026-06-11	16:00-17:00	1	VN	LUSSIER	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1157	1	92	2026-06-12	16:00-17:00	1	VN	PICARONNY	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1158	1	92	2026-06-11	17:00-18:00	1	VN	MESTRIES	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1159	1	92	2026-06-12	17:00-18:00	1	VN	THEATE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1160	1	92	2026-06-15	17:00-18:00	1	VN	DEGUIRARD	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1161	1	92	2026-06-11	18:00-19:00	1	VN	HEBRARD	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1162	1	92	2026-06-12	18:00-19:00	1	VN	BEDOUSSAC	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1163	1	92	2026-06-11	09:00-10:00	2	VN	GUILLERON	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1164	1	92	2026-06-13	09:00-10:00	2	VN	KAIQUE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1165	1	92	2026-06-13	17:00-18:00	2	VN	CHAILLOU	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1166	1	93	2026-06-11	09:00-10:00	1	VN	MOISSINAC	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1167	1	93	2026-06-13	09:00-10:00	1	VN	FALIES	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1168	1	93	2026-06-13	10:00-11:00	1	VN	BESSE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1169	1	93	2026-06-11	11:00-12:00	1	VN	LACROZE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1170	1	93	2026-06-11	14:00-15:00	1	VN	LIMBERTIE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1171	1	93	2026-06-12	14:00-15:00	1	VN	KIALA	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1172	1	93	2026-06-15	14:00-15:00	1	VN	LASFAUX	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1173	1	93	2026-06-12	15:00-16:00	1	VN	TRIN	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1174	1	93	2026-06-13	15:00-16:00	1	VN	LALOIS	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1175	1	93	2026-06-15	17:00-18:00	1	VN	NEY	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1176	1	93	2026-06-11	10:00-11:00	2	VN	PUECH	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1177	1	93	2026-06-13	17:00-18:00	2	VN	REUR	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1178	1	94	2026-06-13	09:00-10:00	1	VN	VEYRIERES	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1179	1	94	2026-06-15	09:00-10:00	1	VN	CHARMES	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1180	1	94	2026-06-12	10:00-11:00	1	VN	LORCY	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1181	1	94	2026-06-11	11:00-12:00	1	VN	PRUNIERES	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1182	1	94	2026-06-12	14:00-15:00	1	VN	LAJARRIGE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1183	1	94	2026-06-13	14:00-15:00	1	VN	COUET	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1184	1	94	2026-06-15	15:00-16:00	1	VN	ESPALIEU	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1185	1	94	2026-06-15	17:00-18:00	1	VN	VEILLY	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1186	1	94	2026-06-15	18:00-19:00	1	VN	RODDE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1187	1	94	2026-06-13	10:00-11:00	2	VN	ROCHE	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1188	1	94	2026-06-15	10:00-11:00	2	VN	CONSTANT	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1189	1	94	2026-06-13	11:00-12:00	2	VN	DANIS	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1190	1	94	2026-06-12	17:00-18:00	2	VN	FREYTET	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1191	1	86	2026-06-15	09:00-10:00	1	VN	GINESTET (Clio GPL)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1192	1	86	2026-06-11	10:00-11:00	1	VN	GUILLEMIN (Espace VD)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1193	1	86	2026-06-12	10:00-11:00	1	VN	BERNADMONT (Twingo)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1194	1	86	2026-06-13	10:00-11:00	1	VN	BLANC (Clio)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1195	1	86	2026-06-14	11:00-12:00	1	VN	GUIBBERT (Clio VI)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1196	1	86	2026-06-12	14:00-15:00	1	VN	MALLAT (Twingo)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1197	1	86	2026-06-13	14:00-15:00	1	VN	PERSEGOL (Captur)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1198	1	86	2026-06-14	14:00-15:00	1	VN	HURGON (Captur)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1199	1	86	2026-06-15	14:00-15:00	1	VN	BELMOTKAR  (Captur)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1200	1	86	2026-06-11	15:00-16:00	1	VN	GAVALDA (Clio)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1201	1	86	2026-06-13	16:00-17:00	1	VN	GALZIN (Rafale)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1202	1	86	2026-06-11	17:00-18:00	1	VN	CHEVALIER (Clio ou Captur)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1203	1	86	2026-06-12	18:00-19:00	1	VN	RAVELEAU (Clio)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1204	1	87	2026-06-11	09:00-10:00	2	VN	MAURY (Duster)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1205	1	87	2026-06-13	09:00-10:00	2	VN	RICHARD (Master VO)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1206	1	87	2026-06-12	10:00-11:00	2	VN	BOONEFOUS (duster)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1207	1	87	2026-06-11	11:00-12:00	2	VN	WILLERMACK (Duster LOA)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1208	1	87	2026-06-12	11:00-12:00	2	VN	GINESTE (Sandero)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1209	1	87	2026-06-13	11:00-12:00	2	VN	DANILL (Duster LOA)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1210	1	87	2026-06-15	11:00-12:00	2	VN	ROCHER (Sandero)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1211	1	87	2026-06-11	14:00-15:00	2	VN	VIALE (Jogger en LOA)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1212	1	87	2026-06-12	14:00-15:00	2	VN	LAMOTTE (Sandero)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1213	1	87	2026-06-13	14:00-15:00	2	VN	BOURDAIS (etech)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1214	1	87	2026-06-11	15:00-16:00	2	VN	GAL (Sandero LOA)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1215	1	87	2026-06-13	15:00-16:00	2	VN	AMDRAUD (Sandero)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1216	1	87	2026-06-13	16:00-17:00	2	VN	Carriere (Bigster)	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1217	1	71	2026-06-11	09:00-10:00	1	VN	JANIN Rafale	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1218	1	71	2026-06-12	09:00-10:00	1	VN	POMPIER Scenic	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1219	1	71	2026-06-13	10:00-11:00	1	VN	CARRE R5	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1220	1	71	2026-06-11	11:00-12:00	1	VN	RAFRE Scenic	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1221	1	71	2026-06-12	11:00-12:00	1	VN	DURIF R5	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1222	1	71	2026-06-11	14:00-15:00	1	VN	RICARDOU Twingo	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1223	1	71	2026-06-11	15:00-16:00	1	VN	CHEVILLER R5	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1224	1	71	2026-06-12	15:00-16:00	1	VN	PAILLASSA R5	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1225	1	71	2026-06-13	15:00-16:00	1	VN	DABLANC Kangoo	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1226	1	71	2026-06-11	17:00-18:00	1	VN	AUZAN R5	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1227	1	72	2026-06-11	09:00-10:00	1	VN	VARLET Megane	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1228	1	72	2026-06-12	09:00-10:00	1	VN	PATAQUI R5	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1229	1	72	2026-06-11	10:00-11:00	1	VN	LEVY Captur	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1230	1	72	2026-06-12	10:00-11:00	1	VN	CHAPLIN Clio	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1231	1	72	2026-06-11	11:00-12:00	1	VN	PEREZ Captur	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1232	1	72	2026-06-11	14:00-15:00	1	VN	PANADERO Twingo	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1233	1	72	2026-06-12	14:00-15:00	1	VN	MOSTARDI Twingo	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1234	1	72	2026-06-11	15:00-16:00	1	VN	MARIE Megane	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1235	1	72	2026-06-13	15:00-16:00	1	VN	PORTAL Clio	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1236	1	72	2026-06-11	16:00-17:00	1	VN	DEMEURE Espace	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1237	1	72	2026-06-12	16:00-17:00	1	VN	NAVARRO Twingo	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1238	1	72	2026-06-13	16:00-17:00	1	VN	FILLION E Tech	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1239	1	72	2026-06-11	17:00-18:00	1	VN	SALANDIN Austral	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1240	1	72	2026-06-13	17:00-18:00	1	VN	GOMEZ Twingo	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1241	1	72	2026-06-11	18:00-19:00	1	VN	LEFEVRE Scenic	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1242	1	73	2026-06-11	09:00-10:00	1	VN	BARRE Megane	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1243	1	73	2026-06-13	09:00-10:00	1	VN	BARTHE R5	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1244	1	73	2026-06-13	10:00-11:00	1	VN	BIBAL Clio	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1245	1	73	2026-06-12	11:00-12:00	1	VN	BELIERE Clio	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1246	1	73	2026-06-12	14:00-15:00	1	VN	FIGUIERE R5	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1247	1	73	2026-06-11	15:00-16:00	1	VN	BALKE Captur	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1248	1	73	2026-06-12	15:00-16:00	1	VN	PIBERNAT Twingo	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1249	1	73	2026-06-11	16:00-17:00	1	VN	BONNET Kangoo	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1250	1	73	2026-06-11	17:00-18:00	1	VN	SOULIE Twingo	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1251	1	73	2026-06-11	10:00-11:00	2	VN	DELMAS Sandero	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1252	1	73	2026-06-12	16:00-17:00	2	VN	MILLET Spring	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1253	1	74	2026-06-11	10:00-11:00	1	VN	GRANGE Twingo	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1254	1	74	2026-06-13	10:00-11:00	1	VN	DUBUY Clio	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1255	1	74	2026-06-13	11:00-12:00	1	VN	ANTERIEUR Kex	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1256	1	74	2026-06-11	14:00-15:00	1	VN	TRAPAS Twingo	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1257	1	74	2026-06-13	14:00-15:00	1	VN	BERNARDIN Clio	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1258	1	74	2026-06-12	16:00-17:00	1	VN	TAILLEFER Clio	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1259	1	74	2026-06-11	17:00-18:00	1	VN	SOULA Megane	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1260	1	74	2026-06-12	17:00-18:00	1	VN	ROBIN Clio	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1261	1	74	2026-06-12	18:00-19:00	1	VN	NAVARRO R5	\N	2026-09-01 09:37:24.258606+00	1	\N	\N	\N	\N	\N	relance
1262	1	74	2026-06-12	10:00-11:00	2	VN	RAHAL Jogger	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1263	1	75	2026-06-11	09:00-10:00	1	VN	DELEBECQUE Scenic	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1264	1	75	2026-06-11	11:00-12:00	1	VN	SAUVAGE Captur	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1265	1	75	2026-06-12	15:00-16:00	1	VN	CHALIEZ Clio	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1266	1	75	2026-06-11	17:00-18:00	1	VN	LIMOUZY Rafale	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1267	1	75	2026-06-11	10:00-11:00	2	VN	FORMAGE Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1268	1	75	2026-06-13	10:00-11:00	2	VN	TISSIER Spring	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1269	1	75	2026-06-12	11:00-12:00	2	VN	ABBES Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1270	1	75	2026-06-13	11:00-12:00	2	VN	MONCHAMP Spring	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1271	1	75	2026-06-15	12:00-13:00	2	VN	DELAIRE Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1272	1	75	2026-06-11	14:00-15:00	2	VN	MASSA Spring	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1273	1	75	2026-06-11	15:00-16:00	2	VN	LAUNAY Twingo	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1274	1	75	2026-06-11	16:00-17:00	2	VN	DRAGUTIN R5	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1275	1	76	2026-06-11	10:00-11:00	1	VN	PERRINE Kangoo	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1276	1	76	2026-06-13	10:00-11:00	1	VN	COUDOURNAC R4	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1277	1	76	2026-06-12	11:00-12:00	1	VN	DEFAUS Megane	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1278	1	76	2026-06-15	17:00-18:00	1	VN	MERCIER R5	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1279	1	76	2026-06-13	14:00-15:00	2	VN	ALBOUY Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1280	1	78	2026-06-11	08:00-09:00	1	VN	DELRIEU Arkana	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1281	1	78	2026-06-11	10:00-11:00	1	VN	DA SILVA Scenic	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1282	1	78	2026-06-12	10:00-11:00	1	VN	LAURENT Captur	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1283	1	78	2026-06-11	11:00-12:00	1	VN	CAUGUEZ R5	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1284	1	78	2026-06-12	11:00-12:00	1	VN	LEVIGUELOUX R5	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1285	1	78	2026-06-14	11:00-12:00	1	VN	TASSEL R5	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1286	1	78	2026-06-11	12:00-13:00	1	VN	GAVALDA TWINGO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1287	1	78	2026-06-11	14:00-15:00	1	VN	ORTHE Captur	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1288	1	78	2026-06-12	14:00-15:00	1	VN	SOUNGOULA Austral	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1289	1	78	2026-06-13	14:00-15:00	1	VN	THOUNANA Captur	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1290	1	78	2026-06-14	14:00-15:00	1	VN	VILLEDIEU CLIO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1291	1	78	2026-06-11	15:00-16:00	1	VN	MARTINAUD Twingo	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1292	1	78	2026-06-13	15:00-16:00	1	VN	CHARTROU Austral	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1293	1	78	2026-06-12	16:00-17:00	1	VN	CAZELLE Captur	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1294	1	78	2026-06-15	16:00-17:00	1	VN	DUCROS Twingo	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1295	1	78	2026-06-11	17:00-18:00	1	VN	RUDELLE Clio	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1296	1	78	2026-06-12	17:00-18:00	1	VN	BIAU Clio	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1297	1	78	2026-06-13	17:00-18:00	1	VN	BOURDON Clio	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1298	1	99	2026-06-12	10:00-11:00	1	VN	ROUSSILHES Clio	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1299	1	99	2026-06-13	10:00-11:00	1	VN	ASSIE Captur	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1300	1	99	2026-06-14	10:00-11:00	1	VN	DASTE Captur	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1301	1	99	2026-06-12	15:00-16:00	1	VN	BEAUGENDRE R4	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1302	1	99	2026-06-12	16:00-17:00	1	VN	RAYSSAC Megane	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1303	1	99	2026-06-13	16:00-17:00	1	VN	HERAIL Megane	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1304	1	99	2026-06-12	09:00-10:00	2	VN	CANTAGREL Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1305	1	99	2026-06-15	09:00-10:00	2	VN	BACHELERI Bigster	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1306	1	99	2026-06-11	10:00-11:00	2	VN	PICARD Duster	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1307	1	99	2026-06-15	10:00-11:00	2	VN	ISSALLI Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1308	1	99	2026-06-12	11:00-12:00	2	VN	GANGLOF Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1309	1	99	2026-06-11	14:00-15:00	2	VN	ALLEGRE Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1310	1	99	2026-06-13	14:00-15:00	2	VN	GEMAIN Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1311	1	99	2026-06-14	14:00-15:00	2	VN	PUTEAU Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1312	1	99	2026-06-15	14:00-15:00	2	VN	KOSTIL Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1313	1	99	2026-06-11	16:00-17:00	2	VN	MAURAISIN Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1314	1	99	2026-06-15	16:00-17:00	2	VN	VERDIS Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1315	1	99	2026-06-12	18:00-19:00	2	VN	VERDIN Duster	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1316	1	99	2026-06-15	18:00-19:00	2	VN	MUNOZ Sandero	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1317	1	96	2026-06-11	09:00-10:00	1	VN	BESSIERE TWINGO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1318	1	96	2026-06-12	09:00-10:00	1	VN	BONSANG CLIO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1319	1	96	2026-06-13	10:00-11:00	1	VN	ARTIGUES TWINGO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1320	1	96	2026-06-11	14:00-15:00	1	VN	LALOEUF TWINGO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1321	1	96	2026-06-12	14:00-15:00	1	VN	ROUZIES CAPTUR	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1322	1	96	2026-06-15	14:00-15:00	1	VN	LAGARRIGUE TWINGO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1323	1	96	2026-06-13	15:00-16:00	1	VN	CIPRIANO R5	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1324	1	96	2026-06-15	15:00-16:00	1	VN	AUDOUY R5	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1325	1	96	2026-06-11	16:00-17:00	1	VN	CAPABIDY TWINGO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1326	1	96	2026-06-12	17:00-18:00	1	VN	ESTIVAL CAPTUR	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1327	1	96	2026-06-13	17:00-18:00	1	VN	MARUEJOULS CLIO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1328	1	96	2026-06-15	17:00-18:00	1	VN	PACHIN CLIO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1329	1	96	2026-06-13	09:00-10:00	2	VN	TOUPENSE DUSTER	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1330	1	96	2026-06-11	10:00-11:00	2	VN	LATAPIE DUSTER	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1331	1	96	2026-06-12	10:00-11:00	2	VN	CHAMEROYS DUSTER	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1332	1	96	2026-06-15	10:00-11:00	2	VN	GINESTE SANDERO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1333	1	96	2026-06-13	14:00-15:00	2	VN	MOGADOR SPRING	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1334	1	97	2026-06-11	09:00-10:00	1	VN	DAENILKIT TRAFIC	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1335	1	97	2026-06-13	10:00-11:00	1	VN	BERT R5	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1336	1	97	2026-06-15	10:00-11:00	1	VN	POIGNANT MEGANE	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1337	1	97	2026-06-11	16:00-17:00	1	VN	CONTE CLIO 6	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1338	1	97	2026-06-11	10:00-11:00	2	VN	DEFOIS DUSTER BIGSTER	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1339	1	97	2026-06-12	10:00-11:00	2	VN	LEGRUE DUSTER	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1340	1	97	2026-06-11	14:00-15:00	2	VN	GILBERT	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1341	1	97	2026-06-13	14:00-15:00	2	VN	JORIS DUSTER	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1342	1	97	2026-06-12	15:00-16:00	2	VN	ROQUES SPRING	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1343	1	89	2026-06-13	09:00-10:00	1	VN	bagreo twingo	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1344	1	89	2026-06-14	09:00-10:00	1	VN	BOMBAISI CLIO 6	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1345	1	89	2026-06-12	11:00-12:00	1	VN	COSSARD CLIO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1346	1	89	2026-06-11	14:00-15:00	1	VN	calmels clio	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1347	1	89	2026-06-13	14:00-15:00	1	VN	ERVIE TWINGO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1348	1	89	2026-06-12	15:00-16:00	1	VN	chambon austral	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1349	1	89	2026-06-11	17:00-18:00	1	VN	CHANDELIER AUSTRAL	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1350	1	89	2026-06-12	10:00-11:00	2	VN	ARIES SANDERO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1351	1	89	2026-06-13	11:00-12:00	2	VN	SALLES SPRING	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1352	1	89	2026-06-13	16:00-17:00	2	VN	CIPIERE SPRING	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1353	1	89	2026-06-15	16:00-17:00	2	VN	mazard spring	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1354	1	89	2026-06-12	17:00-18:00	2	VN	LABRE SANDERO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1355	1	90	2026-06-12	09:00-10:00	1	VN	PEGOURIE R5	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1356	1	90	2026-06-13	09:00-10:00	1	VN	TEYSSEDOU CLIO6	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1357	1	90	2026-06-12	11:00-12:00	1	VN	GOACHET AUSTRAL	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1358	1	90	2026-06-13	11:00-12:00	1	VN	hotzalari clio 6	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1359	1	90	2026-06-11	14:00-15:00	1	VN	BERTHIN SCENIC	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1360	1	90	2026-06-12	14:00-15:00	1	VN	GUILIVERT CLIO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1361	1	90	2026-06-13	16:00-17:00	1	VN	AMIEL CLIO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1362	1	90	2026-06-11	17:00-18:00	1	VN	MARTY R5	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1363	1	90	2026-06-12	10:00-11:00	2	VN	BRUN SANDERO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1364	1	91	2026-06-11	10:00-11:00	1	VN	GALTHIER CAPTUR	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1365	1	91	2026-06-12	11:00-12:00	1	VN	COSTE SANDERO	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1366	1	91	2026-06-15	11:00-12:00	1	VN	FAURE CAPTUR	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1367	1	91	2026-06-12	18:00-19:00	1	VN	DEBORD SCENIC	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
1368	1	91	2026-06-11	18:00-19:00	2	VN	SENTIS BIGSTER SPRING	\N	2026-09-01 09:37:24.711349+00	1	\N	\N	\N	\N	\N	relance
8473	933	31	2026-10-08	08:00-09:00	1	VN	oui	\N	2026-10-03 08:53:50.335445+00	98	2026-10-03 08:53:56.531634+00	98	2026-10-03 08:53:56.754+00	98	3a6c6d9a-4971-4369-b3f3-2e4bd1b01a14	relance
8748	933	70	2026-10-11	09:00-10:00	\N	VO	CHAUVEL ELECTRIQUE	\N	2026-10-06 09:59:23.199943+00	7	\N	\N	\N	\N	5f86ff4b-d874-45a8-b1f9-52c3a3f20d3a	relance
8978	933	39	2026-10-08	14:00-15:00	\N	VO	MAZEL	\N	2026-10-06 10:45:32.294753+00	97	\N	\N	\N	\N	0da8d23e-f920-43ad-9ba9-5897f0371adf	relance
8984	933	39	2026-10-10	09:00-10:00	\N	VO	ZALDIAR	\N	2026-10-06 10:46:16.402223+00	97	\N	\N	\N	\N	b40c391c-7ba6-4b2c-be35-f8042639a632	relance
8986	933	4204	2026-10-09	14:00-15:00	1	VN	VEULE SCENIC E TECH	\N	2026-10-06 10:46:32.511313+00	1782	\N	\N	\N	\N	bb06fdea-0ab0-490e-89e9-e0f1ee71c02e	relance
9001	933	49	2026-10-08	10:00-11:00	1	VN	M FERRIER	\N	2026-10-06 10:48:12.240274+00	1783	\N	\N	\N	\N	77d2ad6a-4003-4879-9be6-8aaf1b3efc3d	relance
9019	933	17	2026-10-10	14:00-15:00	1	VN	Altozaro R5	\N	2026-10-06 10:50:37.08547+00	3	\N	\N	\N	\N	ccb16ce0-a0fa-466d-aa69-9c7602b74fc7	relance
9103	933	36	2026-10-08	15:00-16:00	1	VN	BACCUZAT	\N	2026-10-06 14:10:58.483543+00	97	\N	\N	\N	\N	8d7ffedf-e10f-486e-9e9a-7e3982277401	relance
9106	933	36	2026-10-10	17:00-18:00	1	VN	MAUGER	\N	2026-10-06 14:11:21.10485+00	97	\N	\N	\N	\N	6d4cc84f-1b9e-4268-bd36-2e3f7c798925	relance
9118	933	34	2026-10-12	16:00-17:00	1	VN	ESPINASSE	\N	2026-10-06 14:12:54.010221+00	97	\N	\N	\N	\N	bed0c7c0-ef4b-4c08-bb2c-dad7546aff19	relance
9006	933	43	2026-10-08	17:00-18:00	1	VN	THEVENET BVA	\N	2026-10-06 10:49:03.16627+00	1782	2026-10-06 15:18:10.082764+00	1782	\N	\N	87500d9f-75b3-4fc3-bd0e-3a65a7c86584	relance
9266	933	32	2026-10-11	16:00-17:00	1	VN	GIOUX	\N	2026-10-06 15:20:29.57291+00	97	\N	\N	\N	\N	9c2f1b13-17d4-4ef0-b462-6e1679345459	relance
9425	933	26	2026-10-09	15:00-16:00	1	VN	MEZUREI (R5)	\N	2026-10-06 16:39:53.412958+00	2	\N	\N	\N	\N	7d906b1e-dccc-4cd1-8738-fc55f6c5d4f7	relance
9496	933	74	2026-10-10	09:00-10:00	1	VN	COLONGE	\N	2026-10-07 07:55:30.700149+00	5501	\N	\N	\N	\N	def14c4b-9a5b-4001-b25a-8e8f777034f4	relance
9563	933	84	2026-10-08	15:00-16:00	\N	VO	CAYRES	\N	2026-10-07 12:11:17.079682+00	1776	\N	\N	\N	\N	e016352d-3893-4b30-99b0-58d75287b733	relance
9566	933	84	2026-10-09	11:00-12:00	\N	VO	GAUCERAND	\N	2026-10-07 12:11:54.600331+00	1776	\N	\N	\N	\N	2ad21664-657f-4bdb-bfdd-40dc1914a1b0	relance
9693	933	89	2026-10-08	15:00-16:00	2	VN	association duster	\N	2026-10-08 16:46:43.362029+00	1781	\N	\N	\N	\N	161db11b-4ddc-4503-bdc0-36f85604e7a3	relance
9755	933	5769	2026-10-10	10:00-11:00	\N	VO	DALMIERE	\N	2026-10-10 09:41:44.135362+00	5501	\N	\N	\N	\N	99c017e3-536c-41a5-a3b6-7826c8ce3915	relance
8979	933	39	2026-10-08	17:00-18:00	\N	VO	PAILLERET	\N	2026-10-06 10:45:39.839391+00	97	\N	\N	\N	\N	c0d6d909-d84e-46f4-9a97-c633882ecaca	relance
1541	2	66	2026-09-10	15:00-16:00	1	VN	TEST	\N	2026-09-02 09:40:26.168786+00	787	2026-09-02 09:41:06.325855+00	787	2026-09-02 09:41:06.94+00	787	\N	relance
1542	2	66	2026-09-11	10:00-11:00	2	VN	TEST 2	\N	2026-09-02 09:40:30.034751+00	787	2026-09-02 09:41:08.434615+00	787	2026-09-02 09:41:08.993+00	787	\N	relance
1562	2	25	2026-09-10	08:00-09:00	\N	VO	ESSAI PREMIER	\N	2026-09-03 07:13:11.195526+00	92	2026-09-03 07:14:31.272781+00	92	2026-09-03 07:14:30.928+00	92	\N	relance
1563	2	25	2026-09-10	08:00-09:00	\N	VO	ESSAI SECOND	\N	2026-09-03 07:14:18.986022+00	92	2026-09-03 07:14:49.003273+00	92	2026-09-03 07:14:48.684+00	92	\N	relance
1630	2	881	2026-09-10	08:00-09:00	1	VN	test	\N	2026-09-07 11:52:49.746693+00	92	2026-09-07 11:53:00.662423+00	92	2026-09-07 11:52:59.903+00	92	\N	relance
1632	2	881	2026-09-11	11:00-12:00	1	VN	hhhhhhhh	\N	2026-09-07 14:27:08.19074+00	96	2026-09-07 14:27:20.700042+00	96	2026-09-07 14:27:20.734+00	96	\N	relance
1631	2	881	2026-09-10	08:00-09:00	1	VN	test	\N	2026-09-07 13:04:00.760291+00	92	2026-09-07 14:27:20.786674+00	92	2026-09-07 14:27:20.393+00	92	\N	relance
1634	2	78	2026-09-12	10:00-11:00	1	VN	RDV 2	\N	2026-09-07 14:44:41.490721+00	1784	2026-09-07 14:44:59.814091+00	1784	2026-09-07 14:44:59.715+00	1784	\N	relance
1633	2	78	2026-09-11	09:00-10:00	1	VN	RDV 1	\N	2026-09-07 14:44:21.906911+00	1784	2026-09-07 14:45:01.370525+00	1784	2026-09-07 14:45:01.287+00	1784	\N	relance
1635	2	78	2026-09-11	09:00-10:00	1	VN	rdv 1	\N	2026-09-07 15:17:48.507447+00	1784	2026-09-07 15:18:09.14237+00	1784	2026-09-07 15:18:08.911+00	1784	\N	relance
1636	2	92	2026-09-11	09:00-10:00	2	VN	TUPHE	\N	2026-09-08 08:23:55.528329+00	1780	\N	\N	\N	\N	\N	relance
1637	2	95	2026-09-10	14:00-15:00	1	VN	ESTEVES	\N	2026-09-08 08:41:46.910696+00	1780	\N	\N	\N	\N	\N	relance
1638	2	95	2026-09-11	10:00-11:00	1	VN	CHAZETTE	\N	2026-09-08 08:42:02.223552+00	1780	\N	\N	\N	\N	\N	relance
1639	2	95	2026-09-11	11:00-12:00	2	VN	ESTIVE	\N	2026-09-08 08:42:13.0491+00	1780	\N	\N	\N	\N	\N	relance
1640	2	97	2026-09-10	10:00-11:00	1	VN	LADE MEGANE	\N	2026-09-08 08:52:50.467548+00	1775	\N	\N	\N	\N	\N	relance
1641	2	81	2026-09-10	09:00-10:00	1	VN	REBOUL R4	\N	2026-09-08 08:53:01.691902+00	1776	\N	\N	\N	\N	\N	relance
1642	2	81	2026-09-10	10:00-11:00	2	VN	JORCIN BIGSTER	\N	2026-09-08 08:53:26.225039+00	1776	\N	\N	\N	\N	\N	relance
1643	2	97	2026-09-11	10:00-11:00	1	VN	BONNAL AUSTRAL	\N	2026-09-08 08:53:27.345865+00	1775	\N	\N	\N	\N	\N	relance
1644	2	81	2026-09-10	13:00-14:00	1	VN	COMBETTE TW3	\N	2026-09-08 08:53:49.583263+00	1776	\N	\N	\N	\N	\N	relance
1647	2	1886	2026-09-10	08:00-09:00	2	VN	QUERBES DUSTER	\N	2026-09-08 09:03:20.020041+00	1776	\N	\N	\N	\N	\N	relance
1648	2	1886	2026-09-10	10:00-11:00	2	VN	LEBLOND SRPING	\N	2026-09-08 09:03:29.933128+00	1776	\N	\N	\N	\N	\N	relance
1649	2	1886	2026-09-10	15:00-16:00	2	VN	BIOTTET JOGGER	\N	2026-09-08 09:03:48.265559+00	1776	\N	\N	\N	\N	\N	relance
1646	2	89	2026-09-11	10:00-11:00	1	VN	cloarec	\N	2026-09-08 09:02:20.025075+00	1781	2026-09-08 09:04:13.67721+00	1781	2026-09-08 09:04:14.643+00	1781	\N	relance
1645	2	89	2026-09-10	14:00-15:00	2	VN	estival	\N	2026-09-08 09:01:37.606245+00	1781	2026-09-08 09:04:22.152835+00	1781	2026-09-08 09:04:23.124+00	1781	\N	relance
1650	2	90	2026-09-11	10:00-11:00	1	VN	cloarec	\N	2026-09-08 09:04:37.467106+00	1781	\N	\N	\N	\N	\N	relance
1651	2	90	2026-09-10	14:00-15:00	2	VN	estival	\N	2026-09-08 09:04:57.368312+00	1781	\N	\N	\N	\N	\N	relance
1652	2	97	2026-09-11	16:00-17:00	1	VN	MABILLON CLIO	\N	2026-09-08 09:08:06.982586+00	1775	\N	\N	\N	\N	\N	relance
1653	2	97	2026-09-12	11:00-12:00	1	VN	PIZZI TWINGO	\N	2026-09-08 09:08:22.994527+00	1775	\N	\N	\N	\N	\N	relance
1654	2	50	2026-09-13	12:00-13:00	1	VN	TEST	\N	2026-09-08 09:08:35.781911+00	1783	2026-09-08 09:09:34.363913+00	1783	2026-09-08 09:09:36.219+00	1783	\N	relance
1655	2	96	2026-09-12	17:00-18:00	1	VN	LACOMBE R5	\N	2026-09-08 09:13:02.603364+00	1775	\N	\N	\N	\N	\N	relance
1656	2	96	2026-09-13	14:00-15:00	2	VN	NAFAHAPI DUSTER	\N	2026-09-08 09:13:21.594621+00	1775	\N	\N	\N	\N	\N	relance
1657	2	96	2026-09-14	14:00-15:00	1	VN	LATOUR CLIO	\N	2026-09-08 09:13:33.778889+00	1775	\N	\N	\N	\N	\N	relance
1658	2	89	2026-09-10	18:00-19:00	1	VN	robett	\N	2026-09-08 09:14:25.497493+00	1781	\N	\N	\N	\N	\N	relance
1661	2	94	2026-09-10	15:00-16:00	1	VN	PULLES	\N	2026-09-08 09:17:17.116572+00	1780	\N	\N	\N	\N	\N	relance
1662	2	99	2026-09-10	10:00-11:00	2	VN	FERNANDEZ	\N	2026-09-08 09:17:48.616996+00	1778	2026-09-08 09:17:55.007968+00	1778	2026-09-08 09:17:54.726+00	1778	\N	relance
1663	2	99	2026-09-10	14:00-15:00	2	VN	BONNAFOUS	\N	2026-09-08 09:18:20.865902+00	1778	\N	\N	\N	\N	\N	relance
1664	2	94	2026-09-10	11:00-12:00	1	VN	SABLON	\N	2026-09-08 09:18:23.300593+00	1780	\N	\N	\N	\N	\N	relance
1665	2	99	2026-09-11	10:00-11:00	2	VN	LE FRANCOIS	\N	2026-09-08 09:18:36.285615+00	1778	\N	\N	\N	\N	\N	relance
1666	2	94	2026-09-14	18:00-19:00	1	VN	LEROUSSEAU	\N	2026-09-08 09:18:38.4719+00	1780	\N	\N	\N	\N	\N	relance
1667	2	41	2026-09-14	09:00-10:00	\N	VO	corvey biron	\N	2026-09-08 09:18:48.670399+00	97	\N	\N	\N	\N	\N	relance
1668	2	47	2026-09-12	14:00-15:00	\N	VO	RENIER Arkana 14h30	\N	2026-09-08 09:18:48.980608+00	1782	\N	\N	\N	\N	\N	relance
1669	2	41	2026-09-11	10:00-11:00	\N	VO	soulis	\N	2026-09-08 09:18:54.363738+00	97	\N	\N	\N	\N	\N	relance
1670	2	99	2026-09-10	13:00-14:00	2	VN	ALLEGRE	\N	2026-09-08 09:18:54.9814+00	1778	\N	\N	\N	\N	\N	relance
1671	2	74	2026-09-10	09:00-10:00	1	VN	FAURET	\N	2026-09-08 09:19:21.043875+00	1778	\N	\N	\N	\N	\N	relance
1672	2	74	2026-09-10	10:00-11:00	1	VN	GOMBERT	\N	2026-09-08 09:19:31.354115+00	1778	\N	\N	\N	\N	\N	relance
1673	2	74	2026-09-10	14:00-15:00	1	VN	CARRONDO	\N	2026-09-08 09:19:39.722258+00	1778	\N	\N	\N	\N	\N	relance
1674	2	74	2026-09-10	16:00-17:00	2	VN	AUBRY	\N	2026-09-08 09:19:48.107168+00	1778	\N	\N	\N	\N	\N	relance
1675	2	74	2026-09-12	09:00-10:00	1	VN	MARTINEZ	\N	2026-09-08 09:20:09.999666+00	1778	\N	\N	\N	\N	\N	relance
1676	2	74	2026-09-12	14:00-15:00	1	VN	ROUSSELET	\N	2026-09-08 09:20:14.92979+00	1778	\N	\N	\N	\N	\N	relance
1677	2	73	2026-09-10	10:00-11:00	1	VN	OLIVIER	\N	2026-09-08 09:20:45.985507+00	1778	\N	\N	\N	\N	\N	relance
1678	2	73	2026-09-10	11:00-12:00	1	VN	BURRUS	\N	2026-09-08 09:20:57.15924+00	1778	\N	\N	\N	\N	\N	relance
1679	2	73	2026-09-10	14:00-15:00	2	VN	ABDILAHI	\N	2026-09-08 09:21:15.709054+00	1778	2026-09-08 09:21:24.225633+00	1778	2026-09-08 09:21:23.657+00	1778	\N	relance
1681	2	73	2026-09-10	16:00-17:00	2	VN	HISSETE	\N	2026-09-08 09:21:30.065391+00	1778	\N	\N	\N	\N	\N	relance
1680	2	17	2026-09-10	11:00-12:00	1	VN	test	\N	2026-09-08 09:21:29.463722+00	5	2026-09-08 09:21:33.589388+00	5	2026-09-08 09:21:33.899+00	5	\N	relance
1684	2	73	2026-09-11	11:00-12:00	1	VN	TANNEAU	\N	2026-09-08 09:21:56.077416+00	1778	\N	\N	\N	\N	\N	relance
1686	2	73	2026-09-11	14:00-15:00	1	VN	ONTENIENTE	\N	2026-09-08 09:22:18.916535+00	1778	2026-09-08 09:22:20.523947+00	1778	2026-09-08 09:22:20.24+00	1778	\N	relance
1685	2	42	2026-09-10	16:00-17:00	1	VN	DRUETTE SANDERO	\N	2026-09-08 09:22:06.736837+00	1782	2026-09-08 10:27:40.302491+00	1782	2026-09-08 10:27:40.107+00	1782	\N	relance
1687	2	42	2026-09-11	11:00-12:00	1	VN	FRANCHIN DUSTER	\N	2026-09-08 09:22:21.118047+00	1782	2026-09-08 10:27:56.655993+00	1782	2026-09-08 10:27:56.46+00	1782	\N	relance
1660	2	89	2026-09-11	17:00-18:00	1	VN	vayrac r5	\N	2026-09-08 09:16:13.691331+00	1781	2026-09-08 15:04:10.487943+00	1781	\N	\N	\N	relance
1659	2	89	2026-09-11	15:00-16:00	2	VN	lacroix sandero	\N	2026-09-08 09:15:03.762707+00	1781	2026-09-08 15:04:32.901059+00	1781	\N	\N	\N	relance
1706	2	49	2026-09-10	14:00-15:00	1	VN	M RODARIE	\N	2026-09-08 09:26:00.359576+00	1783	\N	\N	\N	\N	\N	relance
1715	2	53	2026-09-10	16:00-17:00	2	VN	CUSSAC	\N	2026-09-08 09:27:25.679373+00	9	\N	\N	\N	\N	\N	relance
1718	2	55	2026-09-10	11:00-12:00	1	VN	BOIRON	\N	2026-09-08 09:28:22.633195+00	9	\N	\N	\N	\N	\N	relance
1719	2	55	2026-09-10	15:00-16:00	1	VN	BAILLEUL	\N	2026-09-08 09:28:31.025968+00	9	\N	\N	\N	\N	\N	relance
1688	2	42	2026-09-11	14:00-15:00	1	VN	GAYET BIGSTER	\N	2026-09-08 09:22:30.22117+00	1782	2026-09-08 10:28:02.468503+00	1782	2026-09-08 10:28:02.272+00	1782	\N	relance
1691	2	42	2026-09-11	16:00-17:00	1	VN	PICCAND BIGSTER	\N	2026-09-08 09:22:46.72217+00	1782	2026-09-08 10:28:08.093042+00	1782	2026-09-08 10:28:07.873+00	1782	\N	relance
8474	933	3215	2026-10-08	08:00-09:00	1	VN	test	\N	2026-10-03 09:39:11.403695+00	92	2026-10-03 09:39:14.958626+00	92	2026-10-03 09:39:15.356+00	92	ad6d2c02-bd1f-42d2-a6ba-e77e6d30851d	relance
8981	933	39	2026-10-09	10:00-11:00	\N	VO	GARDET	\N	2026-10-06 10:45:56.509134+00	97	\N	\N	\N	\N	b44b249f-3cb5-4aa2-9738-a4ba449c0324	relance
8989	933	4204	2026-10-10	14:00-15:00	2	VN	COUDERT DACIA	\N	2026-10-06 10:47:03.004206+00	1782	\N	\N	\N	\N	b3c97162-4539-4114-a534-7f5bef060348	relance
8995	933	49	2026-10-10	15:00-16:00	1	VN	M KOCNAR	\N	2026-10-06 10:47:35.832093+00	1783	\N	\N	\N	\N	127e262e-acca-4ef0-8c7b-4f00e1579665	relance
9104	933	36	2026-10-10	10:00-11:00	1	VN	CHABRIER	\N	2026-10-06 14:11:07.210941+00	97	\N	\N	\N	\N	9a01a51a-7f96-4486-93ff-45a57e0ed5ba	relance
9109	933	34	2026-10-08	10:00-11:00	1	VN	LETTIZIA	\N	2026-10-06 14:11:52.776965+00	97	\N	\N	\N	\N	f42f2ae6-fd30-4e77-bc3c-a5e23313e590	relance
9115	933	34	2026-10-11	14:00-15:00	1	VN	DUFOUR	\N	2026-10-06 14:12:26.835607+00	97	\N	\N	\N	\N	44d37eaa-2aee-4f72-a53e-cb508a64b438	relance
8749	933	79	2026-10-09	10:00-11:00	1	VN	DUCROS	\N	2026-10-06 09:59:39.839637+00	1776	2026-10-06 14:27:26.39989+00	1776	2026-10-06 14:27:26.232+00	1776	a934ab61-da8e-442a-8bd5-e4a83b4af7bf	relance
9268	933	70	2026-10-08	17:00-18:00	\N	VO	BOUCHET DUSTER 4X4	\N	2026-10-06 15:21:30.848639+00	7	\N	\N	\N	\N	2ae765c2-7bd6-4e53-a5a4-21f7a965d0ab	relance
9269	933	42	2026-10-08	15:00-16:00	2	VN	CHENE	\N	2026-10-06 15:24:50.622664+00	1782	\N	\N	\N	\N	3b4ec3f3-0954-4f4a-bfb8-a2254b3fff5d	relance
9270	933	42	2026-10-10	09:00-10:00	2	VN	FICHAUX SANDERO	\N	2026-10-06 15:25:05.300194+00	1782	\N	\N	\N	\N	952cc21b-fa2d-4744-80f9-d6bedbd80fe5	relance
9272	933	27	2026-10-08	13:00-14:00	1	VN	guitard pierre	\N	2026-10-06 15:25:38.785752+00	3	\N	\N	\N	\N	36ca0d04-b6ca-418e-a2d5-28e31e538c05	relance
9275	933	27	2026-10-09	14:00-15:00	1	VN	dubos	\N	2026-10-06 15:26:26.379171+00	3	\N	\N	\N	\N	49849c5f-bd3b-4178-b11c-d3f732fee6c2	relance
9277	933	27	2026-10-10	14:00-15:00	1	VN	devedeux	\N	2026-10-06 15:27:04.669814+00	3	\N	\N	\N	\N	f4e51f50-b143-4f9b-8e2a-7c82fae4ee30	relance
9279	933	27	2026-10-08	17:00-18:00	1	VN	sibial	\N	2026-10-06 15:27:49.546819+00	3	\N	\N	\N	\N	392333f8-3d52-42b2-88b9-728b4cc4ffe2	relance
9290	933	33	2026-10-08	11:00-12:00	1	VN	ASAL	\N	2026-10-06 15:31:33.558229+00	97	\N	\N	\N	\N	b70176fd-4059-481d-9b68-50e592557ca2	relance
9297	933	33	2026-10-08	16:00-17:00	1	VN	PESENTI	\N	2026-10-06 15:32:09.233548+00	97	\N	\N	\N	\N	d4c295e2-f119-4ca8-96e9-2019a4df92a6	relance
9302	933	33	2026-10-09	10:00-11:00	1	VN	HERNANDEZ	\N	2026-10-06 15:32:33.215068+00	97	\N	\N	\N	\N	e19ed749-afe8-48b0-a704-f3c9ac39e326	relance
9304	933	33	2026-10-09	14:00-15:00	1	VN	BENAZET	\N	2026-10-06 15:32:48.375223+00	97	\N	\N	\N	\N	7a8bb638-265a-4802-9857-4b60f8b5f667	relance
9324	933	32	2026-10-08	16:00-17:00	1	VN	BECK	\N	2026-10-06 15:35:58.783432+00	97	\N	\N	\N	\N	114ada5e-f04d-49d4-b5cf-260d77bb292e	relance
9427	933	19	2026-10-11	16:00-17:00	1	VN	GRENIER ( CAPTUR)	\N	2026-10-06 16:40:49.650612+00	2	\N	\N	\N	\N	22b11678-5a28-436b-bba9-d6318c437657	relance
9497	933	74	2026-10-10	10:00-11:00	1	VN	FEDRY	\N	2026-10-07 07:55:35.077985+00	5501	\N	\N	\N	\N	eab992d6-561a-401d-8086-ab21f0253597	relance
9564	933	83	2026-10-09	12:00-13:00	\N	VO	HIMEUR PAYSAGISTE	\N	2026-10-07 12:11:30.845191+00	1776	\N	\N	\N	\N	a879ed21-21c4-40eb-9d24-d26cb08e18ea	relance
9694	933	74	2026-10-08	11:00-12:00	1	VN	CAMPE	\N	2026-10-09 06:45:50.896739+00	5501	\N	\N	\N	\N	f699b1bd-4ca2-4d1f-b3eb-a4c5c6a9e1ae	relance
9756	933	5769	2026-10-10	14:00-15:00	\N	VO	DUPONT	\N	2026-10-10 09:41:54.679911+00	5501	\N	\N	\N	\N	df15b74b-aa1e-4f4c-b35e-ead9197ab202	relance
9008	933	43	2026-10-09	09:00-10:00	1	VN	CAROOLE MEGANE	\N	2026-10-06 10:49:14.998249+00	1782	2026-10-10 15:08:24.138214+00	1782	2026-10-10 15:08:23.126+00	1782	7c4c0c5a-ee99-45e4-9c12-13c5fa6a1c2a	relance
1689	2	73	2026-09-11	15:00-16:00	2	VN	ADER	\N	2026-09-08 09:22:34.833993+00	1778	\N	\N	\N	\N	\N	relance
8750	933	10	2026-10-10	14:00-15:00	1	VN	anzon twingo	\N	2026-10-06 10:00:28.392002+00	4	\N	\N	\N	\N	7fc1e15a-2540-4871-948b-d22c75ffb3c7	relance
9024	933	56	2026-10-10	10:00-11:00	1	VN	DUCHAMP MEGANE	\N	2026-10-06 11:02:16.701829+00	7	\N	\N	\N	\N	c9879e7e-6709-47a4-a8f1-355ba582c054	relance
9105	933	36	2026-10-10	14:00-15:00	1	VN	MICHEL	\N	2026-10-06 14:11:12.059306+00	97	\N	\N	\N	\N	a37692e6-97c7-43e8-aa2e-f4c6c259a30c	relance
9110	933	34	2026-10-08	14:00-15:00	1	VN	PARSAT	\N	2026-10-06 14:11:57.962063+00	97	\N	\N	\N	\N	37c6cf8d-15dd-4d84-9a35-b3fd82d41250	relance
9113	933	34	2026-10-10	11:00-12:00	1	VN	BERNARD	\N	2026-10-06 14:12:15.602618+00	97	\N	\N	\N	\N	41622d49-0a47-4b25-a65c-9bd85827c663	relance
9271	933	42	2026-10-11	14:00-15:00	2	VN	BERTHON SANDERO	\N	2026-10-06 15:25:15.576086+00	1782	\N	\N	\N	\N	949c1f2a-8137-4530-b8f3-1695d2504df3	relance
9273	933	27	2026-10-08	14:00-15:00	1	VN	larroque	\N	2026-10-06 15:25:46.684287+00	3	\N	\N	\N	\N	782201e6-b175-41d5-9051-e3b4f5a126eb	relance
9278	933	27	2026-10-11	15:00-16:00	1	VN	raynaud longy	\N	2026-10-06 15:27:26.674369+00	3	\N	\N	\N	\N	a8efbb34-2f65-40a8-a5dd-fcdae810e5c9	relance
9286	933	26	2026-10-11	14:00-15:00	2	VN	AUDUC ( DUSTER)	\N	2026-10-06 15:29:20.253366+00	2	\N	\N	\N	\N	c0ce0cc3-bf64-49b3-a941-38c5bbaaa4f0	relance
9287	933	60	2026-10-11	11:00-12:00	1	VN	PALMIER R5	\N	2026-10-06 15:30:41.876409+00	7	2026-10-06 15:30:52.836138+00	7	\N	\N	05d5169e-faf5-4a38-b506-6709b65b94b2	relance
9291	933	48	2026-10-08	16:00-17:00	1	VN	M GUIBARD	\N	2026-10-06 15:31:34.970644+00	1783	\N	\N	\N	\N	138c8a85-ee90-47ce-a19f-84e5f460a9cc	relance
9295	933	33	2026-10-08	15:00-16:00	1	VN	BOUILLERAND	\N	2026-10-06 15:32:01.097052+00	97	\N	\N	\N	\N	c5063af1-31ea-4881-80cc-7b8b660cf9f4	relance
9300	933	33	2026-10-09	09:00-10:00	1	VN	GUGLIELMINI	\N	2026-10-06 15:32:22.965985+00	97	\N	\N	\N	\N	5713217c-7ed2-4029-b7a8-fdf47327e523	relance
9308	933	33	2026-10-10	10:00-11:00	1	VN	CEJALON	\N	2026-10-06 15:33:15.912054+00	97	\N	\N	\N	\N	2fd8f642-7b7c-4793-a4ab-430a42442910	relance
9313	933	33	2026-10-11	15:00-16:00	1	VN	RAY	\N	2026-10-06 15:33:45.722414+00	97	\N	\N	\N	\N	7102c171-e75b-4a8c-8b0e-92a0cb96d5b4	relance
9321	933	67	2026-10-09	14:00-15:00	1	VN	FAIDIET / SYMBIOZ	\N	2026-10-06 15:35:02.249867+00	8	\N	\N	\N	\N	c83b27de-586a-4901-9a6e-96b0126ea018	relance
9323	933	69	2026-10-08	13:00-14:00	\N	VO	DECONINCK	\N	2026-10-06 15:35:20.146646+00	8	\N	\N	\N	\N	62bef985-0959-45e1-88a0-d22e8d0809e6	relance
9326	933	35	2026-10-09	14:00-15:00	1	VN	AUDEBERT	\N	2026-10-06 15:37:18.211665+00	97	\N	\N	\N	\N	075cfee5-a3ec-4f2c-9930-f884b14e5b75	relance
9429	933	12	2026-10-10	10:00-11:00	2	VN	MORGE ( SPRING)	\N	2026-10-06 16:42:28.16636+00	2	\N	\N	\N	\N	675fc8c4-2179-4e0b-8892-ef915a051506	relance
9428	933	12	2026-10-10	09:00-10:00	1	VN	PEXOTO ( DUSTER)	\N	2026-10-06 16:42:11.329149+00	2	2026-10-06 16:44:28.015193+00	2	2026-10-06 16:44:28.765+00	2	9a18bc69-ebdf-4409-af24-30471c74e28c	relance
9498	933	74	2026-10-10	14:00-15:00	1	VN	GRANGE	\N	2026-10-07 07:55:44.632888+00	5501	\N	\N	\N	\N	23d4c30f-9b9b-4fe9-a487-3000af89a873	relance
9565	933	80	2026-10-08	16:00-17:00	1	VN	BARBIER DE REULLE	\N	2026-10-07 12:11:41.678944+00	1776	\N	\N	\N	\N	5ad5af5e-95d8-42d9-a017-4072e16fc406	relance
9695	933	74	2026-10-09	15:00-16:00	1	VN	PUECH	\N	2026-10-09 06:46:17.64697+00	5501	\N	\N	\N	\N	6bab336e-613c-49f8-8bfa-7a5dee65ba0c	relance
9757	933	59	2026-10-10	13:00-14:00	1	VN	SALTEL	\N	2026-10-10 14:06:07.265385+00	7	\N	\N	\N	\N	883199fc-2b5e-499b-b276-83973bf62063	relance
1690	2	85	2026-09-10	10:00-11:00	\N	VO	DUPUIS BROSSY	\N	2026-09-08 09:22:45.086638+00	1776	\N	\N	\N	\N	\N	relance
1705	2	49	2026-09-10	10:00-11:00	1	VN	M PERDEREAU	\N	2026-09-08 09:25:53.555599+00	1783	\N	\N	\N	\N	\N	relance
1714	2	53	2026-09-14	14:00-15:00	1	VN	ETEMAD	\N	2026-09-08 09:27:14.98468+00	9	\N	\N	\N	\N	\N	relance
1700	2	32	2026-09-10	15:00-16:00	1	VN	falchetto	\N	2026-09-08 09:24:05.338606+00	97	2026-09-08 15:25:30.301352+00	97	2026-09-08 15:25:30.51+00	97	\N	relance
8545	933	160	2026-10-09	09:00-10:00	1	VN	Miaou	\N	2026-10-03 15:40:55.676974+00	92	2026-10-03 15:42:12.630009+00	92	2026-10-03 15:42:12.729+00	92	9633095a-f470-4e48-a69b-a255e442e81e	relance
8751	933	56	2026-10-08	16:00-17:00	1	VN	SARDA DACIA SANDERO	\N	2026-10-06 10:01:26.227955+00	7	\N	\N	\N	\N	3f2b5ac8-12e7-4e74-8529-1c61add60933	relance
9025	933	882	2026-10-09	16:00-17:00	\N	VO	DARPOECHE	\N	2026-10-06 11:10:56.020752+00	9	\N	\N	\N	\N	5ac1fc0f-655f-4107-9df1-e8cea61ce0ea	relance
9107	933	36	2026-10-11	15:00-16:00	1	VN	MAIHY	\N	2026-10-06 14:11:29.956515+00	97	\N	\N	\N	\N	f0a633b1-18df-4791-8063-fa4d31cd142c	relance
9112	933	34	2026-10-10	10:00-11:00	1	VN	MARTIN	\N	2026-10-06 14:12:10.764093+00	97	\N	\N	\N	\N	a040c757-68f4-4f3c-931c-17a7def6b01f	relance
9116	933	34	2026-10-11	15:00-16:00	1	VN	CHONIER	\N	2026-10-06 14:12:30.813224+00	97	\N	\N	\N	\N	2fe2176e-68cc-4400-b64e-99875cc245d0	relance
9274	933	27	2026-10-09	10:00-11:00	1	VN	bourdier	\N	2026-10-06 15:26:12.410471+00	3	\N	\N	\N	\N	949d2636-2697-417e-bd22-70b72edc8bbd	relance
9280	933	19	2026-10-10	09:00-10:00	1	VN	GALAING ( R5)	\N	2026-10-06 15:27:53.914866+00	2	\N	\N	\N	\N	95b6d9f6-971f-4e2b-8b66-4a8f5d8ca5a6	relance
9307	933	33	2026-10-10	09:00-10:00	1	VN	NODARY	\N	2026-10-06 15:33:07.980814+00	97	\N	\N	\N	\N	a9c2510e-6734-4edb-ab46-e634692eb137	relance
9320	933	36	2026-10-09	15:00-16:00	1	VN	VIAL	\N	2026-10-06 15:35:00.184398+00	97	\N	\N	\N	\N	9ce736b9-f077-4ba9-ba2b-8fc63762564c	relance
9318	933	59	2026-10-10	11:00-12:00	1	VN	BRUAT JOGGER 5 PLACE	\N	2026-10-06 15:34:46.462945+00	7	2026-10-06 15:35:50.846029+00	7	\N	\N	2cdb3039-6cd6-404c-b1c7-28cd681f377e	relance
9430	933	12	2026-10-10	11:00-12:00	2	VN	BOULANGER ( DUSTER)	\N	2026-10-06 16:42:41.806953+00	2	\N	\N	\N	\N	cff9cb64-1380-48b5-a2ad-04a60eb874fb	relance
9499	933	74	2026-10-10	15:00-16:00	1	VN	HUNTZINGER	\N	2026-10-07 07:55:52.271151+00	5501	\N	\N	\N	\N	127266f5-8f7e-4e9b-a1c1-71b79f753c08	relance
9567	933	84	2026-10-09	12:00-13:00	\N	VO	FONS	\N	2026-10-07 12:29:26.904376+00	1776	\N	\N	\N	\N	9a4337e7-4622-4a9d-b6c6-cfa77087bc95	relance
9696	933	74	2026-10-09	16:00-17:00	1	VN	BENNAZET	\N	2026-10-09 06:46:29.548827+00	5501	\N	\N	\N	\N	8545f85b-39da-42b5-9e7a-eb36a3dfa424	relance
9758	933	61	2026-10-10	14:00-15:00	\N	VO	RICHEPIN	\N	2026-10-10 14:13:11.627305+00	7	\N	\N	\N	\N	26a8b2fa-92a3-4173-b137-a96dd72b54f0	showroom
1692	2	73	2026-09-11	17:00-18:00	2	VN	CONDE	\N	2026-09-08 09:22:48.437888+00	1778	\N	\N	\N	\N	\N	relance
1712	2	53	2026-09-11	17:00-18:00	1	VN	COUDIGNAT	\N	2026-09-08 09:26:58.249492+00	9	\N	\N	\N	\N	\N	relance
1716	2	53	2026-09-11	10:00-11:00	2	VN	ETTEN	\N	2026-09-08 09:27:33.303764+00	9	\N	\N	\N	\N	\N	relance
1697	2	32	2026-09-10	10:00-11:00	1	VN	gomard	\N	2026-09-08 09:23:30.813364+00	97	2026-09-08 15:21:50.711393+00	97	2026-09-08 15:21:49.059+00	97	\N	relance
8546	933	33	2026-10-08	08:00-09:00	1	VN	DUPONT	\N	2026-10-05 08:22:51.938172+00	95	2026-10-05 08:23:15.329129+00	95	2026-10-05 08:23:15.257+00	95	099644ec-1e9b-4130-88d1-0a7632b1bff5	relance
8752	933	56	2026-10-10	09:00-10:00	1	VN	PETIT R5	\N	2026-10-06 10:01:40.441099+00	7	\N	\N	\N	\N	8d445659-1b91-44b1-bb7b-7953acefeafb	relance
9026	933	55	2026-10-10	15:00-16:00	1	VN	GUINAND / AUSTRAL	\N	2026-10-06 11:12:11.824385+00	8	\N	\N	\N	\N	7534d606-1099-4e80-a2e7-5fbe7ed1b57f	relance
9108	933	34	2026-10-08	09:00-10:00	1	VN	JOZAT	\N	2026-10-06 14:11:44.983398+00	97	\N	\N	\N	\N	99f172f4-4d33-49e8-b60f-035abfa9e416	relance
9111	933	34	2026-10-08	15:00-16:00	1	VN	COULON	\N	2026-10-06 14:12:04.872477+00	97	\N	\N	\N	\N	93c47eac-7497-4e19-898e-4f6a9bdef541	relance
9114	933	34	2026-10-10	15:00-16:00	1	VN	GRANGER	\N	2026-10-06 14:12:21.110354+00	97	\N	\N	\N	\N	496e39c9-c6a4-4cd0-81dc-1f91e49922b4	relance
9117	933	34	2026-10-12	15:00-16:00	1	VN	MARRIEN	\N	2026-10-06 14:12:41.412129+00	97	\N	\N	\N	\N	9b89b351-2de6-4602-9836-661ba31c2cf6	relance
9276	933	89	2026-10-12	10:00-11:00	1	VN	caminade clio	\N	2026-10-06 15:26:41.462175+00	1781	\N	\N	\N	\N	953dfd2c-6ac0-423a-8599-209465008c5f	relance
9292	933	48	2026-10-09	09:00-10:00	1	VN	M CATHONNET	\N	2026-10-06 15:31:43.909781+00	1783	\N	\N	\N	\N	0163f908-8e96-43c3-bbc6-6b977b8cb9e5	relance
9293	933	33	2026-10-08	14:00-15:00	1	VN	GEOFFROY TERRYN	\N	2026-10-06 15:31:54.599128+00	97	\N	\N	\N	\N	ddab6eeb-49d4-4cdd-897e-4c278238f245	relance
9296	933	48	2026-10-10	10:00-11:00	1	VN	M OZDEMIR	\N	2026-10-06 15:32:06.082187+00	1783	\N	\N	\N	\N	d3134ac3-2084-4eae-b0d7-635c41280032	relance
9299	933	48	2026-10-11	10:00-11:00	1	VN	M CHABANIS	\N	2026-10-06 15:32:16.657598+00	1783	\N	\N	\N	\N	0b760a36-9d70-4126-92b5-3381428ad4fd	relance
9301	933	50	2026-10-09	09:00-10:00	1	VN	M DISCHAMPS	\N	2026-10-06 15:32:26.39279+00	1783	\N	\N	\N	\N	47655615-1dcf-4bda-bcf0-61d155e03fd2	relance
9305	933	33	2026-10-09	16:00-17:00	1	VN	LAURENT	\N	2026-10-06 15:32:54.904771+00	97	\N	\N	\N	\N	4cd61fd7-36c1-4d60-8bbc-a6b7f2a40c86	relance
9309	933	33	2026-10-10	11:00-12:00	1	VN	SAUVAGET	\N	2026-10-06 15:33:24.571476+00	97	\N	\N	\N	\N	b5273f22-94d1-430d-90ee-3e2e9dcdd0a2	relance
9311	933	33	2026-10-11	10:00-11:00	1	VN	PINCON	\N	2026-10-06 15:33:37.977632+00	97	\N	\N	\N	\N	a2ed4b70-7584-44c4-af45-92c4cf4e7124	relance
9316	933	18	2026-10-08	14:00-15:00	1	VN	soumeyras  r5	\N	2026-10-06 15:34:38.360861+00	4	\N	\N	\N	\N	523a8055-0d03-4bb2-8512-7f0dc3e7adb3	relance
9319	933	36	2026-10-09	14:00-15:00	1	VN	PIRONIN	\N	2026-10-06 15:34:49.7003+00	97	\N	\N	\N	\N	2d759208-06e8-4503-8b1e-8b20e8dbb4ee	relance
9325	933	35	2026-10-08	17:00-18:00	1	VN	GANNAT	\N	2026-10-06 15:37:03.485417+00	97	\N	\N	\N	\N	98437bc6-67c1-43a2-b1df-5befd063fd8d	relance
9431	933	12	2026-10-10	13:00-14:00	2	VN	INACIO ( SANDERO)	\N	2026-10-06 16:42:56.395751+00	2	\N	\N	\N	\N	bddc28b1-0b20-406c-af9b-ec3040ea026f	relance
9433	933	12	2026-10-11	10:00-11:00	2	VN	RUIVO (SPRING)	\N	2026-10-06 16:43:21.719566+00	2	\N	\N	\N	\N	50ed1925-365b-4f4a-a680-626f1a08eac4	relance
9435	933	12	2026-10-11	14:00-15:00	2	VN	PRUDENT (JOGGER)	\N	2026-10-06 16:43:44.557903+00	2	\N	\N	\N	\N	19e5c64f-95d5-4efa-a2f2-0634fcc02aa7	relance
9568	933	85	2026-10-12	11:00-12:00	\N	VO	FOURNIER	\N	2026-10-07 12:29:58.563969+00	1776	\N	\N	\N	\N	7c5f6a79-8ab0-4e21-9d2b-68c516ddbceb	relance
9500	933	74	2026-10-08	11:00-12:00	2	VN	CAMPE	\N	2026-10-07 07:56:31.716201+00	5501	2026-10-09 06:45:44.223395+00	5501	2026-10-09 06:45:44.334+00	5501	c04d8974-3985-4898-b817-428d21b973b2	relance
9697	933	74	2026-10-09	17:00-18:00	1	VN	MILLON	\N	2026-10-09 06:46:38.018744+00	5501	\N	\N	\N	\N	a588ba62-1511-4ec2-9c01-70ff563a5c5e	relance
9699	933	74	2026-10-12	10:00-11:00	2	VN	PONS	\N	2026-10-09 06:47:05.479402+00	5501	\N	\N	\N	\N	f936aad6-2add-4a54-8bfb-a1130241d65f	relance
9759	933	4205	2026-10-10	13:00-14:00	\N	VO	CARROUE MEGANE E TECH	\N	2026-10-10 15:08:41.542563+00	1782	\N	\N	\N	\N	a93f1927-3f12-4d4f-bd4e-03164affcfed	relance
1693	2	85	2026-09-12	15:00-16:00	\N	VO	BILLARD BROSS	\N	2026-09-08 09:22:59.248937+00	1776	\N	\N	\N	\N	\N	relance
1694	2	73	2026-09-11	18:00-19:00	1	VN	BRADFER	\N	2026-09-08 09:23:02.463865+00	1778	\N	\N	\N	\N	\N	relance
1703	2	51	2026-09-12	14:00-15:00	\N	VO	M NACHIMY	\N	2026-09-08 09:24:31.109576+00	1783	\N	\N	\N	\N	\N	relance
1711	2	53	2026-09-11	10:00-11:00	1	VN	DUPUY	\N	2026-09-08 09:26:49.565371+00	9	\N	\N	\N	\N	\N	relance
8547	933	55	2026-10-08	09:00-10:00	1	VN	DUPONT	\N	2026-10-05 08:23:40.034967+00	95	2026-10-05 14:56:16.618286+00	95	2026-10-05 14:56:16.086+00	95	03d09f45-a190-4e8a-be09-048753d30507	relance
8753	933	56	2026-10-10	14:00-15:00	1	VN	EXBRAYAT R5	\N	2026-10-06 10:02:03.035543+00	7	\N	\N	\N	\N	59aa20ce-c74f-40b1-8952-53feb6b9bfb2	relance
9027	933	67	2026-10-11	09:00-10:00	1	VN	ESTEVE / R5	\N	2026-10-06 11:13:58.974038+00	8	\N	\N	\N	\N	166fd2a1-15b6-47f0-8c25-6444a25e8859	relance
9119	933	32	2026-10-10	09:00-10:00	1	VN	LAURENT	\N	2026-10-06 14:13:34.237148+00	97	\N	\N	\N	\N	a067339e-f72f-4981-9795-b0e53b503492	relance
9281	933	27	2026-10-09	17:00-18:00	1	VN	bussiere paysage	\N	2026-10-06 15:27:58.661067+00	3	\N	\N	\N	\N	b68ffc0b-e91d-4d0b-bf34-7819dfe8f92b	relance
9284	933	59	2026-10-12	10:00-11:00	1	VN	DEFIVE  MASTER ET DUSTER	\N	2026-10-06 15:28:29.297613+00	7	\N	\N	\N	\N	9ddcb7bb-ef65-4220-ae91-65a9c9521e0b	relance
9288	933	33	2026-10-08	09:00-10:00	1	VN	CHARLIEU	\N	2026-10-06 15:31:23.556121+00	97	\N	\N	\N	\N	d050e1a2-f823-4ef1-805e-266626f26ee1	relance
9298	933	33	2026-10-08	17:00-18:00	1	VN	BORI	\N	2026-10-06 15:32:14.264728+00	97	\N	\N	\N	\N	162aa067-97ff-41ac-a994-ac4f68fd99ca	relance
9303	933	33	2026-10-09	11:00-12:00	1	VN	BOMPARD	\N	2026-10-06 15:32:38.112416+00	97	\N	\N	\N	\N	0fa429d7-dec3-4bd3-a853-2f2500c66678	relance
9306	933	33	2026-10-09	17:00-18:00	1	VN	MORIN	\N	2026-10-06 15:32:59.571932+00	97	\N	\N	\N	\N	d502d7fb-e773-428b-83e9-f0af414a5764	relance
9312	933	33	2026-10-11	11:00-12:00	1	VN	BAL	\N	2026-10-06 15:33:42.076069+00	97	\N	\N	\N	\N	a99788e6-7cb4-4c76-bfcb-8c8052caac38	relance
9314	933	33	2026-10-12	09:00-10:00	1	VN	DIOT	\N	2026-10-06 15:33:52.200287+00	97	\N	\N	\N	\N	d7a61f4f-14a2-46de-9159-8352d5dd9569	relance
9432	933	12	2026-10-10	14:00-15:00	2	VN	COLVEZ ( SANDERO)	\N	2026-10-06 16:43:06.754219+00	2	\N	\N	\N	\N	46831e13-adb7-41b3-998b-af023c6251fd	relance
9434	933	12	2026-10-11	11:00-12:00	2	VN	FALGOUX (SANDERO)	\N	2026-10-06 16:43:33.313688+00	2	\N	\N	\N	\N	a2c6d83e-90e3-45db-8324-31b2a39b54b3	relance
9501	933	73	2026-10-08	11:00-12:00	1	VN	DUPONT	\N	2026-10-07 07:57:31.921075+00	5501	\N	\N	\N	\N	44a4995f-8e04-4df4-b879-92928f9b826d	relance
9569	933	92	2026-10-09	15:00-16:00	1	VN	BONNET	\N	2026-10-07 13:24:57.307848+00	1780	\N	\N	\N	\N	b78401e5-735b-407c-84c0-08de50a882ad	relance
9698	933	74	2026-10-12	10:00-11:00	1	VN	PONS	\N	2026-10-09 06:46:59.639106+00	5501	2026-10-09 06:47:02.05691+00	5501	2026-10-09 06:47:01.997+00	5501	29920b63-0fef-4378-b079-13ac95452881	relance
9760	933	14	2026-10-10	14:00-15:00	1	VN	BERNARD BIGSTER	\N	2026-10-10 15:17:34.433331+00	5	\N	\N	\N	\N	dd5365e2-bc3d-45a6-b97d-9dbc124e20f8	relance
1717	2	53	2026-09-12	09:00-10:00	2	VN	GOMMET	\N	2026-09-08 09:27:36.987598+00	9	\N	\N	\N	\N	\N	relance
1695	2	42	2026-09-12	09:00-10:00	1	VN	PERIN 9H30 DACIA	\N	2026-09-08 09:23:10.43796+00	1782	2026-09-08 10:28:13.170945+00	1782	2026-09-08 10:28:12.373+00	1782	\N	relance
1699	2	32	2026-09-10	11:00-12:00	1	VN	ribes	\N	2026-09-08 09:23:45.603392+00	97	2026-09-08 15:22:02.595021+00	97	2026-09-08 15:22:02.004+00	97	\N	relance
8548	933	55	2026-10-09	10:00-11:00	1	VN	DURAND	\N	2026-10-05 08:25:23.965931+00	95	2026-10-05 14:56:13.464691+00	95	2026-10-05 14:56:12.922+00	95	d609bbd9-e8db-449c-b04c-596ea8e97dee	relance
8754	933	70	2026-10-11	14:00-15:00	\N	VO	LAURENSON  CAPTUR PLUG IN	\N	2026-10-06 10:03:17.252256+00	7	\N	\N	\N	\N	0f3b32a6-98ff-407a-8db9-a3b01ce3d651	relance
9028	933	65	2026-10-08	18:00-19:00	1	VN	VISBEC / SCENIC	\N	2026-10-06 11:14:34.133598+00	8	2026-10-06 15:06:51.416923+00	8	\N	\N	1c923387-a1dc-4d87-9e38-84df1071c199	relance
9120	933	32	2026-10-10	14:00-15:00	1	VN	CANCRE	\N	2026-10-06 14:13:41.747995+00	97	2026-10-06 15:09:01.308849+00	97	2026-10-06 15:09:01.861+00	97	1c64907f-9e2c-4c95-9c6d-a1038b5314f0	relance
9282	933	19	2026-10-10	10:00-11:00	1	VN	OLSZACK ( MEGANE)	\N	2026-10-06 15:28:08.41956+00	2	\N	\N	\N	\N	d14eb08d-ee88-4a8d-97a1-630013ad86e9	relance
9283	933	19	2026-10-10	11:00-12:00	1	VN	CHAMBRIAS (CLIO)	\N	2026-10-06 15:28:22.998565+00	2	\N	\N	\N	\N	7c5b11e4-698b-42e7-a793-f207598923c6	relance
9285	933	26	2026-10-10	14:00-15:00	1	VN	VERDIER ( TWINGO)	\N	2026-10-06 15:28:59.081076+00	2	\N	\N	\N	\N	ae78a164-ed98-463c-8d39-385948d5f253	relance
9289	933	33	2026-10-08	10:00-11:00	1	VN	RAVET	\N	2026-10-06 15:31:28.203144+00	97	\N	\N	\N	\N	371b8d89-8861-457b-8685-26e6e82eae01	relance
9294	933	48	2026-10-09	16:00-17:00	1	VN	M TEIXERA	\N	2026-10-06 15:31:54.837718+00	1783	\N	\N	\N	\N	7a0d84e7-ea45-46c4-842e-bbe0e7fa4b6c	relance
9310	933	33	2026-10-10	14:00-15:00	1	VN	BATTIER	\N	2026-10-06 15:33:29.813568+00	97	\N	\N	\N	\N	06fecf10-47d8-413a-8472-43926b78bc4e	relance
9315	933	18	2026-10-08	08:00-09:00	1	VN	fofana  austral  9h30	\N	2026-10-06 15:34:21.000593+00	4	\N	\N	\N	\N	3b4b2e50-fcc2-4dba-a772-33c3bf6bda45	relance
9317	933	36	2026-10-08	17:00-18:00	1	VN	ROUGERON	\N	2026-10-06 15:34:39.267211+00	97	\N	\N	\N	\N	2ed18054-25a4-44f5-9fc1-16c4e9408ef2	relance
9322	933	36	2026-10-12	15:00-16:00	1	VN	MATHAT	\N	2026-10-06 15:35:12.273745+00	97	\N	\N	\N	\N	91b3b7a8-570e-4675-b964-35500a16d0ec	relance
9436	933	15	2026-10-10	15:00-16:00	2	VN	SANDERO HEV	\N	2026-10-06 16:43:46.830159+00	5	\N	\N	\N	\N	f723a1e9-722e-41bc-8d81-03a38dbc4539	relance
9438	933	12	2026-10-12	16:00-17:00	2	VN	NROZINSKI (SPRING)	\N	2026-10-06 16:44:17.141169+00	2	\N	\N	\N	\N	862a37aa-99af-4163-9f47-9bcdce080aee	relance
9502	933	73	2026-10-09	10:00-11:00	2	VN	CARMONA	\N	2026-10-07 07:58:38.638114+00	5501	\N	\N	\N	\N	ce318a18-ae43-4afb-ad50-873526105f5b	relance
9700	933	74	2026-10-12	14:00-15:00	2	VN	FABRE	\N	2026-10-09 06:47:17.749156+00	5501	\N	\N	\N	\N	5025b728-3971-4425-944d-e8221731c999	relance
9570	933	92	2026-10-08	11:00-12:00	1	VN	LENZY	\N	2026-10-07 13:25:35.589431+00	1780	2026-10-09 14:58:09.318556+00	1780	2026-10-09 14:58:09.213+00	1780	2bf20051-70eb-4e0f-99d3-a75d3bcb547b	relance
9761	933	19	2026-10-10	13:00-14:00	1	VN	HOTEL DU SANCY R5	\N	2026-10-10 15:34:41.746177+00	5	\N	\N	\N	\N	a4520736-861c-4f5a-beca-9ced344a6661	relance
1696	2	85	2026-09-12	16:00-17:00	\N	VO	DOMERGUE KANGOO	\N	2026-09-08 09:23:22.818866+00	1776	\N	\N	\N	\N	\N	relance
1704	2	160	2026-09-10	08:00-09:00	1	VN	test	\N	2026-09-08 09:25:26.110306+00	2	2026-09-08 09:25:30.804557+00	2	2026-09-08 09:25:31.597+00	2	\N	relance
1710	2	53	2026-09-10	16:00-17:00	1	VN	THEUREL	\N	2026-09-08 09:26:34.237244+00	9	\N	\N	\N	\N	\N	relance
1713	2	53	2026-09-12	15:00-16:00	1	VN	JOUBERT	\N	2026-09-08 09:27:09.628867+00	9	\N	\N	\N	\N	\N	relance
1698	2	42	2026-09-13	11:00-12:00	1	VN	MARIE DUSTER	\N	2026-09-08 09:23:32.324379+00	1782	2026-09-08 10:28:19.568281+00	1782	2026-09-08 10:28:19.373+00	1782	\N	relance
1702	2	42	2026-09-14	14:00-15:00	1	VN	MITAULT SPRING	\N	2026-09-08 09:24:24.715633+00	1782	2026-09-08 10:28:33.56922+00	1782	2026-09-08 10:28:33.37+00	1782	\N	relance
8549	933	54	2026-10-08	13:00-14:00	1	VN	MARTIN	\N	2026-10-05 08:31:26.330661+00	95	2026-10-05 14:56:23.457116+00	95	2026-10-05 14:56:22.9+00	95	ca9d0b0c-21cb-4cdf-b0a9-bb79d8a4b2e9	relance
8755	933	65	2026-10-10	10:00-11:00	1	VN	PROEHL / TWINGO	\N	2026-10-06 10:03:50.800665+00	8	2026-10-06 10:03:58.204125+00	8	\N	\N	bc14c852-f21b-4512-b3c8-923427c98a2b	relance
8756	933	4	2026-10-08	09:00-10:00	1	VN	PERAZI R5	\N	2026-10-06 10:04:20.501668+00	5	\N	\N	\N	\N	e26417f6-e330-43f1-91b9-8837d125b642	relance
8764	933	4	2026-10-09	15:00-16:00	1	VN	CENTRI CAPTUR	\N	2026-10-06 10:05:37.126978+00	5	\N	\N	\N	\N	64e964a5-a9f3-4034-94ad-ac04503b4a06	relance
8765	933	4	2026-10-09	16:00-17:00	1	VN	CHARETTE R5	\N	2026-10-06 10:05:43.543298+00	5	\N	\N	\N	\N	ba72f5af-b10b-4c17-afd3-bfb1a345011f	relance
8770	933	4	2026-10-10	09:00-10:00	1	VN	CAPTUR BOYER	\N	2026-10-06 10:06:15.066312+00	5	\N	\N	\N	\N	0434af1b-98e7-4388-9b24-874aac82bc45	relance
8773	933	4	2026-10-10	14:00-15:00	1	VN	CHAPELON TWINGO	\N	2026-10-06 10:06:26.999935+00	5	2026-10-06 10:06:37.801617+00	5	\N	\N	82eb04d4-cb02-4933-88eb-d814142daacb	relance
8815	933	44	2026-10-08	10:00-11:00	1	VN	FRADIN R5	\N	2026-10-06 10:11:41.82267+00	1782	\N	\N	\N	\N	9ea2e873-d93e-4327-b833-11cf4e676213	relance
8824	933	15	2026-10-09	11:00-12:00	2	VN	ALARD BIGSTER	\N	2026-10-06 10:12:59.995434+00	5	\N	\N	\N	\N	33a2c2af-6069-40a8-a9b8-4ec9dce94ae2	relance
8838	933	18	2026-10-08	09:00-10:00	1	VN	sebillaud  austral	\N	2026-10-06 10:16:52.288181+00	4	\N	\N	\N	\N	bdb1b494-b280-4ba3-aace-206dc8b94a83	relance
8843	933	17	2026-10-08	08:00-09:00	1	VN	Ballaleuf R5	\N	2026-10-06 10:18:07.307262+00	3	\N	\N	\N	\N	dfb73970-8640-4b52-8b6f-c92a4a3d857c	relance
8845	933	42	2026-10-08	10:00-11:00	2	VN	NONMENMACHER SANDERO	\N	2026-10-06 10:18:22.541779+00	1782	\N	\N	\N	\N	1058c23f-6e7e-4bc8-ab33-f4db507a8ac2	relance
8856	933	42	2026-10-10	16:00-17:00	2	VN	POIRIER DUSTER	\N	2026-10-06 10:19:17.064999+00	1782	\N	\N	\N	\N	3e7526ae-28a2-48df-808d-ce7c5f28729a	relance
8877	933	2	2026-10-08	14:00-15:00	1	VN	Serre Symbioz	\N	2026-10-06 10:23:06.933023+00	3	\N	\N	\N	\N	5f3555f4-4a37-41e9-a728-49414ca72b24	relance
8884	933	67	2026-10-08	09:00-10:00	1	VN	MARTIN / MEGANE	\N	2026-10-06 10:23:59.549192+00	8	\N	\N	\N	\N	1a8c008d-06c8-4ad0-9ecb-4061fa4ecd32	relance
9029	933	65	2026-10-09	10:00-11:00	1	VN	PORTALIER / R5	\N	2026-10-06 11:16:29.193929+00	8	\N	\N	\N	\N	9d874d8d-5fe3-453b-a350-a94221a1b31b	relance
9121	933	56	2026-10-10	16:00-17:00	1	VN	VEYRES TWINGO	\N	2026-10-06 14:17:21.999738+00	7	\N	\N	\N	\N	2112a79d-9ec0-4c2f-b62c-7bb6e0343984	relance
9327	933	41	2026-10-11	11:00-12:00	\N	VO	GUIZOT	\N	2026-10-06 15:38:32.271192+00	97	\N	\N	\N	\N	23655c63-a298-4c73-8e34-de56d67b6c8c	relance
9437	933	12	2026-10-12	09:00-10:00	2	VN	LESAGE( SANDERO)	\N	2026-10-06 16:44:02.593623+00	2	\N	\N	\N	\N	9d4f34e1-946c-440e-b6b0-08fd03815c9b	relance
9442	933	6	2026-10-11	14:00-15:00	1	VN	GAIRAUT (ESPACE)	\N	2026-10-06 16:45:47.539785+00	2	\N	\N	\N	\N	85129770-d4e6-4e85-bc4b-08b7be8fd309	relance
9571	933	90	2026-10-09	14:00-15:00	1	VN	lagarrigue clio 5	\N	2026-10-07 13:33:07.163069+00	1781	\N	\N	\N	\N	fe76e12a-3e56-4142-b6cd-6d6a62224288	relance
9701	933	74	2026-10-12	09:00-10:00	1	VN	BOUISSET	\N	2026-10-09 06:47:56.355354+00	5501	\N	\N	\N	\N	b244ec1a-9257-4899-9b0d-f816473b8809	relance
9503	933	73	2026-10-09	11:00-12:00	1	VN	LEGER	\N	2026-10-07 07:58:46.244601+00	5501	2026-10-09 15:26:14.753776+00	5501	\N	\N	77ce09a2-9b15-4614-93e7-a9e43a494be1	relance
9762	933	19	2026-10-10	15:00-16:00	1	VN	BERTELO SPRING	\N	2026-10-10 15:35:17.783489+00	5	2026-10-10 15:36:12.043713+00	5	\N	\N	ebe91a44-2d25-4440-8aaa-d39e0029e622	relance
8781	933	59	2026-10-08	09:00-10:00	1	VN	DELTORCHIO  R5	\N	2026-10-06 10:07:30.33164+00	7	2026-10-11 16:44:15.048628+00	7	2026-10-11 16:44:14.882+00	7	4223c217-7c2f-4bd5-9053-33b39426ad9c	relance
1707	2	97	2026-09-10	14:00-15:00	1	VN	MAYRAT R5	\N	2026-09-08 09:26:10.840015+00	1775	\N	\N	\N	\N	\N	relance
1708	2	53	2026-09-10	10:00-11:00	1	VN	ROLLAND-ROBERT	\N	2026-09-08 09:26:11.702611+00	9	\N	\N	\N	\N	\N	relance
1709	2	53	2026-09-10	11:00-12:00	1	VN	COLLIN	\N	2026-09-08 09:26:16.139923+00	9	\N	\N	\N	\N	\N	relance
1720	2	55	2026-09-14	15:00-16:00	1	VN	DOFFIN	\N	2026-09-08 09:28:49.935649+00	9	\N	\N	\N	\N	\N	relance
1721	2	29	2026-09-10	09:00-10:00	3	VN	HOTEL MURA	\N	2026-09-08 09:30:08.766175+00	4	\N	\N	\N	\N	\N	relance
1722	2	55	2026-09-14	17:00-18:00	1	VN	LARCISI	\N	2026-09-08 09:30:14.812857+00	9	\N	\N	\N	\N	\N	relance
1723	2	29	2026-09-10	14:00-15:00	3	VN	LOGIK2A	\N	2026-09-08 09:30:30.213002+00	4	\N	\N	\N	\N	\N	relance
1724	2	29	2026-09-10	10:00-11:00	3	VN	GALPIER	\N	2026-09-08 09:30:34.539376+00	4	\N	\N	\N	\N	\N	relance
1725	2	61	2026-09-11	10:00-11:00	\N	VO	LYON	\N	2026-09-08 09:30:35.939412+00	9	\N	\N	\N	\N	\N	relance
1726	2	61	2026-09-11	14:00-15:00	\N	VO	MARTIN	\N	2026-09-08 09:30:42.570065+00	9	\N	\N	\N	\N	\N	relance
1727	2	29	2026-09-10	11:00-12:00	3	VN	OVEROCK	\N	2026-09-08 09:30:46.470314+00	4	\N	\N	\N	\N	\N	relance
1728	2	29	2026-09-10	18:00-19:00	3	VN	LAPORTE	\N	2026-09-08 09:30:52.457386+00	4	\N	\N	\N	\N	\N	relance
1729	2	61	2026-09-12	09:00-10:00	\N	VO	CORRAL	\N	2026-09-08 09:30:52.969382+00	9	\N	\N	\N	\N	\N	relance
1730	2	61	2026-09-12	14:00-15:00	\N	VO	JULIEN	\N	2026-09-08 09:30:56.678674+00	9	\N	\N	\N	\N	\N	relance
1731	2	68	2026-09-10	09:00-10:00	\N	VO	DEPAILLER	\N	2026-09-08 09:31:24.120704+00	9	\N	\N	\N	\N	\N	relance
1732	2	213	2026-09-10	09:00-10:00	\N	VO	PIERRON	\N	2026-09-08 09:31:31.599764+00	6	\N	\N	\N	\N	\N	relance
1733	2	68	2026-09-10	14:00-15:00	\N	VO	SLAGHENAUFI	\N	2026-09-08 09:31:38.264356+00	9	\N	\N	\N	\N	\N	relance
1734	2	68	2026-09-10	17:00-18:00	\N	VO	VRIGNON	\N	2026-09-08 09:31:53.618402+00	9	\N	\N	\N	\N	\N	relance
1735	2	68	2026-09-11	15:00-16:00	\N	VO	COUDERT	\N	2026-09-08 09:31:57.954515+00	9	\N	\N	\N	\N	\N	relance
1736	2	213	2026-09-10	08:00-09:00	\N	VO	LAGARDE	\N	2026-09-08 09:32:31.234482+00	6	\N	\N	\N	\N	\N	relance
1738	2	80	2026-09-10	08:00-09:00	1	VN	CALDIER KANGOO	\N	2026-09-08 09:33:06.523173+00	1776	\N	\N	\N	\N	\N	relance
1739	2	28	2026-09-12	11:00-12:00	\N	VO	EZZINE	\N	2026-09-08 09:33:08.425505+00	6	\N	\N	\N	\N	\N	relance
1740	2	65	2026-09-10	11:00-12:00	2	VN	ALDEGUER	\N	2026-09-08 09:33:12.303751+00	9	\N	\N	\N	\N	\N	relance
1741	2	80	2026-09-10	09:00-10:00	1	VN	MERCADIER MEG EL	\N	2026-09-08 09:33:13.715521+00	1776	\N	\N	\N	\N	\N	relance
1742	2	80	2026-09-10	10:00-11:00	1	VN	DUSSOAUCY MELEC	\N	2026-09-08 09:33:29.033383+00	1776	\N	\N	\N	\N	\N	relance
1743	2	80	2026-09-10	14:00-15:00	1	VN	ROUQUIER R5	\N	2026-09-08 09:33:34.745208+00	1776	\N	\N	\N	\N	\N	relance
1744	2	28	2026-09-12	15:00-16:00	\N	VO	BEGOT	\N	2026-09-08 09:33:35.835926+00	6	\N	\N	\N	\N	\N	relance
1746	2	24	2026-09-12	10:00-11:00	\N	VO	MANSARD	\N	2026-09-08 09:33:47.147145+00	4	\N	\N	\N	\N	\N	relance
1747	2	65	2026-09-10	17:00-18:00	2	VN	BERNAL	\N	2026-09-08 09:34:04.759582+00	9	\N	\N	\N	\N	\N	relance
1748	2	215	2026-09-10	15:00-16:00	\N	VO	BEGON ZOE	\N	2026-09-08 09:34:05.997319+00	3	\N	\N	\N	\N	\N	relance
1749	2	65	2026-09-10	08:00-09:00	1	VN	CLINIQUE VETERINAIRE	\N	2026-09-08 09:34:13.587241+00	9	\N	\N	\N	\N	\N	relance
1745	2	65	2026-09-10	08:00-09:00	2	VN	CLINIQUE VETERINAIRE	\N	2026-09-08 09:33:44.478591+00	9	2026-09-08 09:34:18.426492+00	9	2026-09-08 09:34:18.128+00	9	\N	relance
1750	2	2	2026-09-14	18:00-19:00	1	VN	POILROUX CLIO6	\N	2026-09-08 09:35:15.728001+00	3	\N	\N	\N	\N	\N	relance
1751	2	1886	2026-09-11	10:00-11:00	2	VN	SERRE DUSTER	\N	2026-09-08 09:35:15.849572+00	1776	\N	\N	\N	\N	\N	relance
1752	2	1886	2026-09-11	13:00-14:00	2	VN	SENEZERGUES SANDERO	\N	2026-09-08 09:35:28.900961+00	1776	\N	\N	\N	\N	\N	relance
1753	2	81	2026-09-10	10:00-11:00	1	VN	MASSOL R5	\N	2026-09-08 09:35:59.170268+00	1776	\N	\N	\N	\N	\N	relance
1754	2	2	2026-09-13	11:00-12:00	1	VN	DELMAS	\N	2026-09-08 09:36:11.255463+00	3	\N	\N	\N	\N	\N	relance
1755	2	81	2026-09-10	14:00-15:00	1	VN	SAHQUIE MEGANE ELEC	\N	2026-09-08 09:36:15.615754+00	1776	\N	\N	\N	\N	\N	relance
1757	2	12	2026-09-10	10:00-11:00	1	VN	CHEVALLET DUSTER	\N	2026-09-08 09:37:20.830365+00	4	2026-09-09 16:21:16.482652+00	92	2026-09-09 16:21:16.118+00	92	\N	relance
1760	2	79	2026-09-10	09:00-10:00	1	VN	DESMESURE TW3	\N	2026-09-08 09:37:39.318763+00	1776	\N	\N	\N	\N	\N	relance
1761	2	19	2026-09-10	09:00-10:00	1	VN	BAILLY TWINGO	\N	2026-09-08 09:37:41.439415+00	2	\N	\N	\N	\N	\N	relance
1763	2	65	2026-09-10	14:00-15:00	1	VN	HENIN	\N	2026-09-08 09:37:54.665795+00	9	\N	\N	\N	\N	\N	relance
1764	2	79	2026-09-10	10:00-11:00	1	VN	FLOTTES R5	\N	2026-09-08 09:38:06.081947+00	1776	\N	\N	\N	\N	\N	relance
1765	2	19	2026-09-10	10:00-11:00	1	VN	BAUD R5	\N	2026-09-08 09:38:13.686585+00	2	\N	\N	\N	\N	\N	relance
1766	2	27	2026-09-10	14:00-15:00	1	VN	MME DUFAURE CLIO	\N	2026-09-08 09:39:59.271983+00	5	\N	\N	\N	\N	\N	relance
1767	2	15	2026-09-10	09:00-10:00	1	VN	SOL AUSTRAL	\N	2026-09-08 09:40:01.281664+00	2	\N	\N	\N	\N	\N	relance
1768	2	97	2026-09-12	14:00-15:00	1	VN	HERNANDEZ R5	\N	2026-09-08 09:40:20.476768+00	1775	\N	\N	\N	\N	\N	relance
1770	2	5	2026-09-10	08:00-09:00	1	VN	MR BRULURU POUR CLIO	\N	2026-09-08 09:41:52.425444+00	5	\N	\N	\N	\N	\N	relance
1771	2	71	2026-09-10	10:00-11:00	1	VN	VERDAN	\N	2026-09-08 09:41:57.66497+00	1778	\N	\N	\N	\N	\N	relance
1772	2	5	2026-09-10	09:00-10:00	1	VN	MME BENOIT POUR R5	\N	2026-09-08 09:42:05.461433+00	5	\N	\N	\N	\N	\N	relance
1773	2	71	2026-09-10	14:00-15:00	1	VN	HOARAU	\N	2026-09-08 09:42:09.389202+00	1778	\N	\N	\N	\N	\N	relance
1774	2	5	2026-09-10	10:00-11:00	1	VN	MR CARLEY POUR MEGANE	\N	2026-09-08 09:42:17.639012+00	5	\N	\N	\N	\N	\N	relance
1775	2	71	2026-09-10	18:00-19:00	1	VN	ALIBERT	\N	2026-09-08 09:42:19.188686+00	1778	\N	\N	\N	\N	\N	relance
1776	2	84	2026-09-12	09:00-10:00	\N	VO	PISTRE	\N	2026-09-08 09:42:21.681933+00	1776	\N	\N	\N	\N	\N	relance
1777	2	84	2026-09-10	09:00-10:00	\N	VO	PUEL ZOE	\N	2026-09-08 09:42:32.291406+00	1776	\N	\N	\N	\N	\N	relance
1778	2	71	2026-09-11	09:00-10:00	1	VN	POMPONE	\N	2026-09-08 09:42:34.683117+00	1778	\N	\N	\N	\N	\N	relance
1779	2	84	2026-09-11	09:00-10:00	\N	VO	COMBRET TWINGO	\N	2026-09-08 09:42:46.991396+00	1776	\N	\N	\N	\N	\N	relance
1780	2	71	2026-09-11	14:00-15:00	1	VN	CAVALIE	\N	2026-09-08 09:42:49.771474+00	1778	\N	\N	\N	\N	\N	relance
1781	2	71	2026-09-11	16:00-17:00	1	VN	DABLAN	\N	2026-09-08 09:43:00.403504+00	1778	\N	\N	\N	\N	\N	relance
1782	2	71	2026-09-12	10:00-11:00	1	VN	GERY	\N	2026-09-08 09:43:13.212759+00	1778	\N	\N	\N	\N	\N	relance
1783	2	84	2026-09-11	10:00-11:00	\N	VO	BLANC TW3 LOA	\N	2026-09-08 09:43:15.510312+00	1776	\N	\N	\N	\N	\N	relance
1701	2	32	2026-09-10	16:00-17:00	1	VN	descriaux	\N	2026-09-08 09:24:15.101165+00	97	2026-09-08 15:30:41.856672+00	97	2026-09-08 15:29:00.199+00	97	\N	relance
1737	2	213	2026-09-12	09:00-10:00	\N	VO	la brosse	\N	2026-09-08 09:32:41.542063+00	6	2026-09-08 16:01:29.53813+00	6	\N	\N	\N	relance
1758	2	12	2026-09-10	11:00-12:00	1	VN	ALEDO DUSTER	\N	2026-09-08 09:37:35.099855+00	4	2026-09-09 16:21:31.566696+00	92	2026-09-09 16:21:31.193+00	92	\N	relance
1762	2	12	2026-09-10	14:00-15:00	1	VN	TRONCHERE JOGGER	\N	2026-09-08 09:37:51.142586+00	4	2026-09-09 16:22:02.588211+00	92	2026-09-09 16:22:02.238+00	92	\N	relance
1769	2	6	2026-09-10	08:00-09:00	1	VN	MR FOLLEAS SANDERO	\N	2026-09-08 09:41:31.262959+00	5	2026-09-09 16:25:04.478111+00	92	2026-09-09 16:25:04.144+00	92	\N	relance
1785	2	211	2026-09-12	10:00-11:00	\N	VO	DEGEZ  SYMBIOZ	\N	2026-09-08 09:43:50.057815+00	2	\N	\N	\N	\N	\N	relance
1786	2	53	2026-09-12	10:00-11:00	1	VN	BONGIRAUD	\N	2026-09-08 09:46:23.622073+00	9	\N	\N	\N	\N	\N	relance
1787	2	41	2026-09-10	14:00-15:00	\N	VO	baudesson	\N	2026-09-08 09:47:45.540011+00	97	\N	\N	\N	\N	\N	relance
1788	2	1887	2026-09-12	09:00-10:00	\N	VO	M HADDAD	\N	2026-09-08 09:47:47.786602+00	1783	\N	\N	\N	\N	\N	relance
1789	2	41	2026-09-10	16:00-17:00	\N	VO	teyssier	\N	2026-09-08 09:47:55.282205+00	97	\N	\N	\N	\N	\N	relance
1790	2	50	2026-09-10	15:00-16:00	1	VN	M BONNET	\N	2026-09-08 09:47:59.675115+00	1783	\N	\N	\N	\N	\N	relance
1791	2	51	2026-09-11	18:00-19:00	\N	VO	M HEMET	\N	2026-09-08 09:48:13.184423+00	1783	\N	\N	\N	\N	\N	relance
1792	2	95	2026-09-10	18:00-19:00	2	VN	CHALVIGNAC	\N	2026-09-08 09:48:20.387809+00	1780	\N	\N	\N	\N	\N	relance
1793	2	41	2026-09-11	14:00-15:00	\N	VO	faucher garros	\N	2026-09-08 09:48:27.589053+00	97	\N	\N	\N	\N	\N	relance
1794	2	95	2026-09-11	09:00-10:00	1	VN	SALESSE	\N	2026-09-08 09:48:32.53648+00	1780	\N	\N	\N	\N	\N	relance
1795	2	95	2026-09-11	17:00-18:00	1	VN	GUILLOU	\N	2026-09-08 09:48:40.542519+00	1780	\N	\N	\N	\N	\N	relance
1796	2	41	2026-09-12	10:00-11:00	\N	VO	pawelczyk	\N	2026-09-08 09:48:54.157463+00	97	\N	\N	\N	\N	\N	relance
1797	2	93	2026-09-10	14:00-15:00	1	VN	GRENIER	\N	2026-09-08 09:49:03.736144+00	1780	\N	\N	\N	\N	\N	relance
1798	2	41	2026-09-14	17:00-18:00	\N	VO	roddier	\N	2026-09-08 09:49:09.809776+00	97	\N	\N	\N	\N	\N	relance
1799	2	93	2026-09-10	16:00-17:00	1	VN	MALGOUZOU	\N	2026-09-08 09:49:13.632228+00	1780	\N	\N	\N	\N	\N	relance
1800	2	93	2026-09-12	09:00-10:00	2	VN	BRIANCEAU	\N	2026-09-08 09:49:24.381684+00	1780	\N	\N	\N	\N	\N	relance
1802	2	65	2026-09-11	09:00-10:00	2	VN	DESGRUGILLERS	\N	2026-09-08 09:49:45.565745+00	9	\N	\N	\N	\N	\N	relance
1803	2	60	2026-09-10	09:00-10:00	2	VN	MOUSTADRAF	\N	2026-09-08 09:49:48.826484+00	7	\N	\N	\N	\N	\N	relance
1805	2	92	2026-09-11	11:00-12:00	1	VN	BUCHON	\N	2026-09-08 09:50:04.113582+00	1780	\N	\N	\N	\N	\N	relance
1806	2	60	2026-09-10	11:00-12:00	2	VN	KIRCHER	\N	2026-09-08 09:50:07.757054+00	7	\N	\N	\N	\N	\N	relance
1807	2	92	2026-09-12	09:00-10:00	1	VN	VANTALON	\N	2026-09-08 09:50:14.746762+00	1780	\N	\N	\N	\N	\N	relance
1808	2	60	2026-09-11	10:00-11:00	2	VN	RICARD	\N	2026-09-08 09:50:17.388037+00	7	\N	\N	\N	\N	\N	relance
1809	2	92	2026-09-12	10:00-11:00	2	VN	DUCROS	\N	2026-09-08 09:50:39.335721+00	1780	\N	\N	\N	\N	\N	relance
1810	2	60	2026-09-11	14:00-15:00	2	VN	PAULHIAC	\N	2026-09-08 09:50:40.516669+00	7	\N	\N	\N	\N	\N	relance
1811	2	82	2026-09-10	09:00-10:00	1	VN	CHAMPREDONDE MEGA	\N	2026-09-08 09:50:44.652509+00	1776	\N	\N	\N	\N	\N	relance
1812	2	17	2026-09-10	10:00-11:00	1	VN	TINEL SYMBIOZ	\N	2026-09-08 09:51:01.476466+00	5	\N	\N	\N	\N	\N	relance
1813	2	82	2026-09-10	10:00-11:00	2	VN	PERRICHOU SP	\N	2026-09-08 09:51:03.217754+00	1776	2026-09-08 09:51:10.36912+00	1776	\N	\N	\N	relance
1816	2	35	2026-09-10	09:00-10:00	1	VN	gil	\N	2026-09-08 09:51:12.956307+00	97	\N	\N	\N	\N	\N	relance
1814	2	92	2026-09-12	14:00-15:00	1	VN	ANESA	\N	2026-09-08 09:51:05.663171+00	1780	2026-09-08 09:51:19.380391+00	1780	2026-09-08 09:51:16.479+00	1780	\N	relance
1818	2	35	2026-09-10	14:00-15:00	1	VN	vales	\N	2026-09-08 09:51:22.940505+00	97	\N	\N	\N	\N	\N	relance
1819	2	82	2026-09-10	11:00-12:00	1	VN	LOUIS CLIO 5	\N	2026-09-08 09:51:27.498404+00	1776	\N	\N	\N	\N	\N	relance
1815	2	92	2026-09-12	14:00-15:00	1	VN	ANESA	\N	2026-09-08 09:51:09.309534+00	1780	2026-09-08 09:51:31.321112+00	1780	2026-09-08 09:51:30.762+00	1780	\N	relance
1817	2	17	2026-09-10	14:00-15:00	1	VN	GUILLEMON SCENIC	\N	2026-09-08 09:51:16.673419+00	5	2026-09-08 09:51:33.008873+00	5	\N	\N	\N	relance
1821	2	35	2026-09-10	17:00-18:00	1	VN	jourdil	\N	2026-09-08 09:51:37.97741+00	97	\N	\N	\N	\N	\N	relance
1822	2	17	2026-09-10	15:00-16:00	1	VN	TERRIAS CLIO	\N	2026-09-08 09:51:43.153063+00	5	\N	\N	\N	\N	\N	relance
1825	2	53	2026-09-10	09:00-10:00	1	VN	POMOGIER	\N	2026-09-08 09:51:47.327661+00	9	\N	\N	\N	\N	\N	relance
1824	2	82	2026-09-10	14:00-15:00	1	VN	PORTIER M3 ELC	\N	2026-09-08 09:51:46.218277+00	1776	2026-09-08 09:51:51.813035+00	1776	2026-09-08 09:51:51.756+00	1776	\N	relance
1826	2	17	2026-09-10	16:00-17:00	1	VN	MARTINS R5	\N	2026-09-08 09:51:53.65314+00	5	\N	\N	\N	\N	\N	relance
1827	2	35	2026-09-11	09:00-10:00	1	VN	roussin	\N	2026-09-08 09:51:53.852407+00	97	\N	\N	\N	\N	\N	relance
1820	2	60	2026-09-11	14:00-15:00	1	VN	BRAZ	\N	2026-09-08 09:51:30.709399+00	7	2026-09-08 09:51:57.414981+00	7	2026-09-08 09:51:57.272+00	7	\N	relance
1828	2	17	2026-09-10	17:00-18:00	1	VN	LAPEYRE SANDERO	\N	2026-09-08 09:52:01.274869+00	5	\N	\N	\N	\N	\N	relance
1829	2	82	2026-09-10	14:00-15:00	1	VN	PORTIER M3	\N	2026-09-08 09:52:05.645065+00	1776	2026-09-08 09:52:10.759212+00	1776	2026-09-08 09:52:11.07+00	1776	\N	relance
1830	2	35	2026-09-12	14:00-15:00	1	VN	chafotte	\N	2026-09-08 09:52:12.158247+00	97	\N	\N	\N	\N	\N	relance
1831	2	57	2026-09-11	14:00-15:00	\N	VO	BRAZ	\N	2026-09-08 09:52:13.653527+00	7	\N	\N	\N	\N	\N	relance
1832	2	35	2026-09-14	11:00-12:00	1	VN	meilland	\N	2026-09-08 09:52:26.081954+00	97	\N	\N	\N	\N	\N	relance
1833	2	82	2026-09-10	14:00-15:00	1	VN	PORTIER M3	\N	2026-09-08 09:52:43.163822+00	1776	\N	\N	\N	\N	\N	relance
1834	2	57	2026-09-12	14:00-15:00	\N	VO	COLIC DINO	\N	2026-09-08 09:52:47.156567+00	7	\N	\N	\N	\N	\N	relance
1835	2	82	2026-09-10	16:00-17:00	1	VN	PUECHAGUT SCENIC EL	\N	2026-09-08 09:52:58.306891+00	1776	\N	\N	\N	\N	\N	relance
1836	2	82	2026-09-10	17:00-18:00	1	VN	PUECH SYMBIOZ	\N	2026-09-08 09:53:09.95063+00	1776	\N	\N	\N	\N	\N	relance
1837	2	82	2026-09-11	10:00-11:00	1	VN	GUIBERT CAPTUR	\N	2026-09-08 09:53:24.693288+00	1776	\N	\N	\N	\N	\N	relance
1838	2	81	2026-09-11	09:00-10:00	1	VN	BESSIERE R4	\N	2026-09-08 09:54:00.11229+00	1776	\N	\N	\N	\N	\N	relance
1839	2	72	2026-09-10	09:00-10:00	1	VN	PAULIN	\N	2026-09-08 09:54:00.455501+00	1778	\N	\N	\N	\N	\N	relance
1840	2	81	2026-09-11	15:00-16:00	1	VN	CLEMENT CLIO 6	\N	2026-09-08 09:54:11.13023+00	1776	\N	\N	\N	\N	\N	relance
1841	2	72	2026-09-10	11:00-12:00	1	VN	AUGE	\N	2026-09-08 09:54:18.022801+00	1778	\N	\N	\N	\N	\N	relance
1842	2	72	2026-09-10	14:00-15:00	2	VN	PARRA	\N	2026-09-08 09:54:30.404554+00	1778	\N	\N	\N	\N	\N	relance
1843	2	72	2026-09-10	16:00-17:00	1	VN	ROBIN	\N	2026-09-08 09:54:33.603379+00	1778	\N	\N	\N	\N	\N	relance
1844	2	60	2026-09-11	16:00-17:00	1	VN	TROUSSELIER	\N	2026-09-08 09:54:37.25368+00	7	\N	\N	\N	\N	\N	relance
1845	2	72	2026-09-10	17:00-18:00	2	VN	CABRI	\N	2026-09-08 09:54:37.323742+00	1778	\N	\N	\N	\N	\N	relance
1846	2	43	2026-09-11	09:00-10:00	1	VN	ARRAULT R5	\N	2026-09-08 09:54:54.841745+00	1782	\N	\N	\N	\N	\N	relance
1847	2	72	2026-09-12	10:00-11:00	1	VN	GORDON	\N	2026-09-08 09:55:00.78317+00	1778	\N	\N	\N	\N	\N	relance
1848	2	72	2026-09-12	11:00-12:00	1	VN	BOYER	\N	2026-09-08 09:55:05.164075+00	1778	\N	\N	\N	\N	\N	relance
1849	2	43	2026-09-12	09:00-10:00	1	VN	PIC AUSTRAL	\N	2026-09-08 09:55:06.754641+00	1782	\N	\N	\N	\N	\N	relance
1850	2	72	2026-09-12	14:00-15:00	1	VN	LOUBERSSAC	\N	2026-09-08 09:55:09.192711+00	1778	\N	\N	\N	\N	\N	relance
1851	2	72	2026-09-14	14:00-15:00	1	VN	SALANDIN	\N	2026-09-08 09:55:19.229623+00	1778	\N	\N	\N	\N	\N	relance
1852	2	60	2026-09-12	14:00-15:00	2	VN	TINTILLIER	\N	2026-09-08 09:55:38.258925+00	7	\N	\N	\N	\N	\N	relance
1804	2	32	2026-09-11	16:00-17:00	1	VN	viguie	\N	2026-09-08 09:49:49.333125+00	97	2026-09-08 15:39:23.553655+00	97	2026-09-08 15:39:23.282+00	97	\N	relance
1823	2	92	2026-09-12	14:00-15:00	1	VN	ANESA	\N	2026-09-08 09:51:43.115029+00	1780	2026-09-08 16:07:58.059288+00	1780	2026-09-08 16:07:57.755+00	1780	\N	relance
1853	2	43	2026-09-12	14:00-15:00	1	VN	COMMEAUSIGN R5	\N	2026-09-08 09:55:39.862397+00	1782	\N	\N	\N	\N	\N	relance
1854	2	60	2026-09-13	10:00-11:00	2	VN	SAUMADE	\N	2026-09-08 09:55:56.900593+00	7	\N	\N	\N	\N	\N	relance
1865	2	44	2026-09-10	11:00-12:00	1	VN	GOURNON AUSTRAM	\N	2026-09-08 09:57:28.898737+00	1782	2026-09-08 09:57:52.56666+00	1782	2026-09-08 09:57:52.339+00	1782	\N	relance
1889	2	47	2026-09-12	13:00-14:00	\N	VO	MARTIN SERGE 0606459077	\N	2026-09-08 10:01:43.632605+00	1782	\N	\N	\N	\N	\N	relance
1891	2	66	2026-09-10	09:00-10:00	1	VN	COUDERT / TWINGO	\N	2026-09-08 10:02:31.358979+00	8	\N	\N	\N	\N	\N	relance
1895	2	66	2026-09-11	17:00-18:00	2	VN	CAVELIER / DUSTER	\N	2026-09-08 10:03:01.556699+00	8	\N	\N	\N	\N	\N	relance
1899	2	70	2026-09-10	09:00-10:00	\N	VO	LOZE / MEGANE VO	\N	2026-09-08 10:03:49.88022+00	8	\N	\N	\N	\N	\N	relance
1904	2	70	2026-09-10	10:00-11:00	\N	VO	ECHALIER /  VO GPL	\N	2026-09-08 10:04:18.82975+00	8	\N	\N	\N	\N	\N	relance
1906	2	87	2026-09-10	16:00-17:00	2	VN	ROYER - DUSTER VN	\N	2026-09-08 10:04:33.337639+00	1777	\N	\N	\N	\N	\N	relance
1920	2	87	2026-09-14	18:00-19:00	2	VN	LAVIEILLE - ARKANA A RENOUVELER	\N	2026-09-08 10:06:07.57324+00	1777	\N	\N	\N	\N	\N	relance
8757	933	65	2026-10-08	16:00-17:00	1	VN	FREYSSINER / R5	\N	2026-10-06 10:04:20.929064+00	8	\N	\N	\N	\N	b6119ef1-b4a2-4a3d-b7c7-871d8d0b2188	relance
8766	933	4	2026-10-09	17:00-18:00	1	VN	ARNAUD R5	\N	2026-10-06 10:05:52.226789+00	5	\N	\N	\N	\N	c3d1b544-efae-49b0-8657-bf656b4a0089	relance
8767	933	50	2026-10-08	10:00-11:00	1	VN	MME DESSITE	\N	2026-10-06 10:05:59.547091+00	1783	\N	\N	\N	\N	d6cdc0cf-964c-47e5-a80b-072e0416b7ad	relance
8779	933	4	2026-10-11	15:00-16:00	1	VN	JOUVIN R5	\N	2026-10-06 10:07:20.549952+00	5	\N	\N	\N	\N	5d6f7d8c-dac6-4d04-b200-ef182933524a	relance
8782	933	55	2026-10-09	14:00-15:00	1	VN	ROUSSEAU / KANGOO	\N	2026-10-06 10:07:34.493655+00	8	\N	\N	\N	\N	dc203a51-d31b-4e63-8237-9a0bbcbdd837	relance
8789	933	55	2026-10-12	17:00-18:00	1	VN	LEBRAT / TWINGO	\N	2026-10-06 10:08:41.290283+00	8	\N	\N	\N	\N	27ab7c9e-7342-4a50-a366-7b787578c6b4	relance
8790	933	4	2026-10-11	09:00-10:00	2	VN	BINION SPRING	\N	2026-10-06 10:08:46.657467+00	5	\N	\N	\N	\N	4c81ff56-a7ad-4d10-a268-0a5cb2d361f4	relance
8795	933	5766	2026-10-09	12:00-13:00	\N	VO	SAHUC  ZOE	\N	2026-10-06 10:09:23.064403+00	8	\N	\N	\N	\N	cb0862eb-339b-400c-a86e-fae93c50e386	relance
8809	933	5	2026-10-10	17:00-18:00	1	VN	FABREGUETTE CLIO	\N	2026-10-06 10:11:00.663829+00	5	\N	\N	\N	\N	a957e3b7-86b9-4329-a42f-efba4a0b3160	relance
8818	933	3216	2026-10-10	11:00-12:00	\N	VO	obert  duster	\N	2026-10-06 10:12:07.771432+00	4	\N	\N	\N	\N	2ba4a9a8-fd66-4f17-80d4-c9c91adc66cd	relance
8828	933	15	2026-10-10	09:00-10:00	2	VN	GARGNE	\N	2026-10-06 10:13:38.45514+00	5	2026-10-06 10:13:46.216842+00	5	2026-10-06 10:13:46.063+00	5	aa2ac833-2dd6-4a6f-a3ad-0ed0d9a4773a	relance
8830	933	15	2026-10-10	14:00-15:00	1	VN	MORAT SPRING	\N	2026-10-06 10:14:15.396801+00	5	2026-10-06 10:14:24.77799+00	5	\N	\N	b9daa1f0-2b43-4525-91aa-097a33997290	relance
9030	933	882	2026-10-11	12:00-13:00	\N	VO	CELESTIN	\N	2026-10-06 11:20:36.567971+00	9	\N	\N	\N	\N	3aa79ce2-732b-43fd-b30d-c4bf80eb0033	relance
9122	933	56	2026-10-11	14:00-15:00	1	VN	VO MOREL STEPWAY	\N	2026-10-06 14:17:54.963648+00	7	\N	\N	\N	\N	b7a1f1cb-910a-4823-88f1-b162b5501677	relance
9328	933	57	2026-10-08	16:00-17:00	\N	VO	collin / captur	\N	2026-10-06 15:38:53.527212+00	8	2026-10-06 15:38:59.420045+00	8	\N	\N	8be636da-9c8c-4cbe-90ac-7181b30ea38a	relance
9330	933	54	2026-10-10	11:00-12:00	1	VN	AMIRA TWINGO	\N	2026-10-06 15:41:13.744359+00	7	\N	\N	\N	\N	f53200a2-4847-4dd8-9c04-166966fde14c	relance
9333	933	2	2026-10-10	09:00-10:00	1	VN	Bosc Megane	\N	2026-10-06 15:43:37.816201+00	3	\N	\N	\N	\N	15f04d5a-7cfe-47ee-8d7b-6f8a0ee99e95	relance
9354	933	17	2026-10-11	10:00-11:00	1	VN	Sejourne Twingo	\N	2026-10-06 15:49:44.14374+00	3	\N	\N	\N	\N	182e1dc5-494d-4618-aada-c277401b2910	relance
9361	933	18	2026-10-11	15:00-16:00	1	VN	gaume captur	\N	2026-10-06 15:53:07.032291+00	4	\N	\N	\N	\N	76986018-0a5a-41cc-a0c2-db51b26eb317	relance
9363	933	16	2026-10-09	11:00-12:00	1	VN	Barbier R5	\N	2026-10-06 15:53:58.253063+00	3	\N	\N	\N	\N	27c7a34f-1889-4672-9563-f2cf1b542970	relance
9439	933	15	2026-10-09	09:00-10:00	2	VN	CHABRIER 9H30	\N	2026-10-06 16:44:22.349204+00	5	\N	\N	\N	\N	86e9c0d6-8b85-4c94-bd11-f87190cd970b	relance
9441	933	6	2026-10-11	10:00-11:00	2	VN	FOUCAUD (sandero°	\N	2026-10-06 16:45:19.732146+00	2	\N	\N	\N	\N	dfd37965-e845-4c24-9349-be6ee9ccaf04	relance
9504	933	73	2026-10-10	10:00-11:00	1	VN	VEISSIERE	\N	2026-10-07 07:59:06.783922+00	5501	\N	\N	\N	\N	4bdc60a3-e340-4b9a-aafc-8696551b8ebe	relance
9572	933	95	2026-10-08	15:00-16:00	1	VN	FRANCE	\N	2026-10-07 13:39:13.58052+00	1780	\N	\N	\N	\N	f1671791-f788-49b9-9307-5726e01c1386	relance
9702	933	73	2026-10-08	14:00-15:00	1	VN	CORNU	\N	2026-10-09 06:57:41.745757+00	5501	\N	\N	\N	\N	a9d3a79d-a3c1-46e4-a4d8-38830c253afd	relance
9763	933	17	2026-10-10	08:00-09:00	1	VN	BONALDI TWINGO	\N	2026-10-10 15:50:52.766508+00	5	\N	\N	\N	\N	7a02b641-17f3-4ba6-b75a-211817bd265a	relance
1855	2	43	2026-09-13	10:00-11:00	1	VN	REVERDY TWINGO	\N	2026-09-08 09:55:59.792707+00	1782	\N	\N	\N	\N	\N	relance
1860	2	74	2026-09-11	09:00-10:00	2	VN	ORIENTE	\N	2026-09-08 09:56:34.05638+00	1778	\N	\N	\N	\N	\N	relance
1861	2	74	2026-09-11	10:00-11:00	2	VN	ARCA	\N	2026-09-08 09:56:39.194819+00	1778	\N	\N	\N	\N	\N	relance
1863	2	74	2026-09-10	16:00-17:00	1	VN	ESTEVE	\N	2026-09-08 09:57:11.508376+00	1778	\N	\N	\N	\N	\N	relance
1867	2	62	2026-09-10	10:00-11:00	2	VN	MONCET	\N	2026-09-08 09:57:42.913771+00	7	\N	\N	\N	\N	\N	relance
1870	2	44	2026-09-11	11:00-12:00	1	VN	LASNI	\N	2026-09-08 09:58:00.782675+00	1782	\N	\N	\N	\N	\N	relance
1908	2	78	2026-09-11	17:00-18:00	1	VN	BESSETES	\N	2026-09-08 10:04:43.505792+00	1778	\N	\N	\N	\N	\N	relance
1922	2	1885	2026-09-10	15:00-16:00	1	VN	ALLINAT - DUSTER VO	\N	2026-09-08 10:06:39.326094+00	1777	\N	\N	\N	\N	\N	relance
1924	2	59	2026-09-10	09:00-10:00	1	VN	SAINT LEGER / CAPTUR	\N	2026-09-08 10:07:10.704162+00	8	\N	\N	\N	\N	\N	relance
1927	2	59	2026-09-10	10:00-11:00	1	VN	CELLIER / TWINGO	\N	2026-09-08 10:07:40.911267+00	8	\N	\N	\N	\N	\N	relance
8758	933	4	2026-10-08	10:00-11:00	1	VN	HERAZ 9H30 MEGANE	\N	2026-10-06 10:04:45.046606+00	5	\N	\N	\N	\N	31d7894b-9650-449b-9223-cef00ea10fb9	relance
8760	933	4	2026-10-08	16:00-17:00	1	VN	GUITTARD CAPTUR	\N	2026-10-06 10:05:00.950852+00	5	\N	\N	\N	\N	254d84fb-6f63-49a1-906e-244bd48a8932	relance
8777	933	59	2026-10-08	08:00-09:00	1	VN	POUS   R5 OU CLIO	\N	2026-10-06 10:06:59.38665+00	7	\N	\N	\N	\N	1b261a1a-42ca-4f24-b258-53b08f58ba02	relance
8791	933	5766	2026-10-08	17:00-18:00	\N	VO	LEBRUN / SANDERO	\N	2026-10-06 10:08:54.552781+00	8	\N	\N	\N	\N	63b85ce7-34db-4528-ae76-a396aba0cdf6	relance
8787	933	54	2026-10-08	17:00-18:00	1	VN	PEYRELONG  TWINGO	\N	2026-10-06 10:08:22.944989+00	7	2026-10-06 10:08:56.605941+00	7	\N	\N	a938aa3c-8ec1-4ce9-9d7d-48715e73e222	relance
8798	933	59	2026-10-09	11:00-12:00	1	VN	PONS R5	\N	2026-10-06 10:10:01.544919+00	7	\N	\N	\N	\N	595e58f4-0556-4ff5-bc34-ef849072769c	relance
8813	933	5	2026-10-11	15:00-16:00	1	VN	PORTIER SCENIC ETECH	\N	2026-10-06 10:11:19.747394+00	5	\N	\N	\N	\N	15f9f8db-80ad-4454-9ae9-85f588b4040b	relance
8801	933	59	2026-10-09	13:00-14:00	1	VN	DOUSSIERE CLIO	\N	2026-10-06 10:10:20.731373+00	7	2026-10-06 10:32:28.919828+00	7	\N	\N	9e6b6c51-ddcf-44fd-a32e-3f530d8eb801	relance
8816	933	59	2026-10-10	14:00-15:00	1	VN	SALTEL TWINGO	\N	2026-10-06 10:11:49.499893+00	7	2026-10-06 10:32:59.252777+00	7	\N	\N	525e1929-d8ca-4034-9128-ed84923843df	relance
9031	933	57	2026-10-09	09:00-10:00	\N	VO	PEIREIRA	\N	2026-10-06 11:21:19.47607+00	9	\N	\N	\N	\N	fa586bb2-2b2a-4660-a8dc-fd93ff7a1c81	relance
9123	933	56	2026-10-08	11:00-12:00	1	VN	BACH R4	\N	2026-10-06 14:18:09.183102+00	7	\N	\N	\N	\N	2f18f2c2-c3b9-4e73-9f07-4179485c0017	relance
9329	933	59	2026-10-11	15:00-16:00	1	VN	BREMONT R4 R5 MEGANE	\N	2026-10-06 15:40:33.978684+00	7	\N	\N	\N	\N	6ce81655-6f7d-40e0-a8e1-a511c918fa6d	relance
9440	933	12	2026-10-10	09:00-10:00	2	VN	PEXOTO (DUSTER)	\N	2026-10-06 16:44:38.939057+00	2	\N	\N	\N	\N	ee846420-04bb-4179-9e3e-ad67ec507b93	relance
9505	933	73	2026-10-10	11:00-12:00	1	VN	CLICQUOT	\N	2026-10-07 07:59:50.729102+00	5501	\N	\N	\N	\N	380c9076-2ca1-4a05-ac08-92bfdf78973b	relance
9573	933	89	2026-10-10	11:00-12:00	1	VN	rigal captur	\N	2026-10-07 14:18:43.119655+00	1781	\N	\N	\N	\N	ee692830-3c12-4342-82b7-2ec501ade2ef	relance
9703	933	73	2026-10-08	15:00-16:00	1	VN	HETCHEVERI	\N	2026-10-09 06:57:48.176776+00	5501	\N	\N	\N	\N	81d6e8ac-a6d2-4064-b373-b77c7871fa65	relance
9764	933	17	2026-10-10	12:00-13:00	1	VN	BAIL.LOU R5	\N	2026-10-10 15:50:59.10005+00	5	\N	\N	\N	\N	2ea235ac-d5ef-4170-b5a7-d385d111b6ee	relance
1856	2	53	2026-09-12	11:00-12:00	2	VN	TENDIL	\N	2026-09-08 09:56:05.745322+00	9	\N	\N	\N	\N	\N	relance
1926	2	1885	2026-09-12	11:00-12:00	1	VN	GERVAUD VNSO	\N	2026-09-08 10:07:27.884438+00	1777	\N	\N	\N	\N	\N	relance
1930	2	59	2026-09-10	16:00-17:00	1	VN	FILET / R4	\N	2026-09-08 10:08:25.195276+00	8	\N	\N	\N	\N	\N	relance
8626	933	33	2026-10-09	08:00-09:00	2	VN	test	\N	2026-10-05 12:02:11.986697+00	92	2026-10-05 13:18:34.280209+00	92	2026-10-05 13:18:33.525+00	92	67d158ac-d162-4b9c-b262-b4cde5ffec15	relance
8759	933	4	2026-10-08	14:00-15:00	1	VN	SERVIERE CLIO	\N	2026-10-06 10:04:54.191945+00	5	\N	\N	\N	\N	8df128b0-591e-422a-9757-aef6b1bb9433	relance
8762	933	4	2026-10-09	09:00-10:00	1	VN	JAMBOU AUSTRAL	\N	2026-10-06 10:05:18.517772+00	5	\N	\N	\N	\N	adb9b948-b465-4b1a-9be4-c787e5a6b60e	relance
8771	933	4	2026-10-10	10:00-11:00	1	VN	LOLIO KANGOO	\N	2026-10-06 10:06:20.232997+00	5	\N	\N	\N	\N	9f4fe36d-09b7-40c4-b2fc-7042e36e4762	relance
8780	933	55	2026-10-08	17:00-18:00	1	VN	GALLAN / CAPTUR	\N	2026-10-06 10:07:20.651473+00	8	\N	\N	\N	\N	ae2f5695-a69e-4136-9fbc-a2e05ee26753	relance
8785	933	55	2026-10-10	10:00-11:00	1	VN	AZBITI / R5	\N	2026-10-06 10:08:08.418535+00	8	\N	\N	\N	\N	0f9a0153-e08f-4f6b-b511-f582940872e3	relance
8788	933	4	2026-10-09	14:00-15:00	2	VN	CHERVEL SANDERO	\N	2026-10-06 10:08:30.569751+00	5	\N	\N	\N	\N	e16237a4-bda1-4f01-9d0c-e7a05f6253ea	relance
8796	933	5766	2026-10-11	10:00-11:00	\N	VO	FREVOL / CLIO	\N	2026-10-06 10:09:28.957373+00	8	\N	\N	\N	\N	3a99b856-69ca-4388-91d2-1aaf1caa6637	relance
8799	933	5	2026-10-08	09:00-10:00	1	VN	MAJCHERCIK TGWINGO OU R5	\N	2026-10-06 10:10:08.746964+00	5	\N	\N	\N	\N	a0736be3-e0d7-496a-ae7d-ebb02b62bbba	relance
8803	933	5	2026-10-08	16:00-17:00	1	VN	FAVIER R5	\N	2026-10-06 10:10:28.86789+00	5	\N	\N	\N	\N	41dc6901-c04f-4182-b2be-0f5debd6c1ec	relance
8808	933	882	2026-10-11	10:00-11:00	\N	VO	DUMAS	\N	2026-10-06 10:10:56.218469+00	9	\N	\N	\N	\N	8b8a4d70-cabf-4064-a99b-7e6bec9a230c	relance
8822	933	15	2026-10-08	09:00-10:00	2	VN	PORTAL JOGGER	\N	2026-10-06 10:12:46.504392+00	5	\N	\N	\N	\N	a15b951f-5b32-4b3a-8223-d98e7aae2028	relance
8831	933	15	2026-10-11	09:00-10:00	2	VN	JOSS DUSTER	\N	2026-10-06 10:14:40.958086+00	5	\N	\N	\N	\N	d5e9388f-1acc-461d-89a3-0e5cbf909d97	relance
9032	933	61	2026-10-10	10:00-11:00	\N	VO	CABIROU  SANDERO	\N	2026-10-06 11:21:54.180889+00	7	\N	\N	\N	\N	e6dcc9e9-51bd-4b2d-99b5-ac1209061352	relance
9124	933	70	2026-10-11	11:00-12:00	\N	VO	ADMIRAL ZOE	\N	2026-10-06 14:20:46.191181+00	7	\N	\N	\N	\N	7ee0d109-1e9c-4bb7-ac76-7984bd1f41c1	relance
9331	933	2	2026-10-11	14:00-15:00	1	VN	Bernard Megane	\N	2026-10-06 15:43:09.225954+00	3	\N	\N	\N	\N	0b543adc-342c-4007-8e0f-3fbb9ab93d43	relance
9335	933	160	2026-10-11	09:00-10:00	1	VN	Bernon VO CLIO V	\N	2026-10-06 15:44:51.11877+00	3	2026-10-06 15:45:11.135187+00	3	\N	\N	bd89008d-b9e1-47b3-a02f-5b716574c260	relance
9343	933	4204	2026-10-11	16:00-17:00	2	VN	GUEDON ECO G	\N	2026-10-06 15:47:32.36769+00	1782	\N	\N	\N	\N	a7870ef0-a77d-4060-9d19-567765441bd9	relance
9350	933	62	2026-10-11	09:00-10:00	1	VN	DUPARC	\N	2026-10-06 15:48:43.421072+00	95	\N	\N	\N	\N	cbe1d7f9-2ef5-4a1f-a3f1-e2f3bdcf1093	relance
9443	933	6	2026-10-11	15:00-16:00	1	VN	DEMEUSE (CLIO)	\N	2026-10-06 16:46:05.236372+00	2	\N	\N	\N	\N	1e40640b-bdcd-40e1-995a-1ebe5cdeaa8f	relance
9506	933	73	2026-10-09	14:00-15:00	1	VN	CARABAKA	\N	2026-10-07 08:00:07.029365+00	5501	\N	\N	\N	\N	6fac2af2-3499-4d84-8986-f4b477187e5d	relance
9509	933	73	2026-10-08	09:00-10:00	2	VN	BLANC	\N	2026-10-07 08:00:34.639741+00	5501	\N	\N	\N	\N	9d1166eb-4fdd-4a1b-95df-e4dd737617d6	relance
9574	933	89	2026-10-09	10:00-11:00	2	VN	laurent sandero	\N	2026-10-07 14:19:01.282991+00	1781	\N	\N	\N	\N	b69bac0d-916d-439a-8528-65145f5d412b	relance
9704	933	73	2026-10-08	16:00-17:00	1	VN	FRACOU	\N	2026-10-09 06:57:53.63951+00	5501	\N	\N	\N	\N	f96b02db-179f-42d7-b1cb-ce3812ce4e66	relance
9765	933	17	2026-10-10	15:00-16:00	1	VN	LA PRONONCIERE MEGANE	\N	2026-10-10 15:51:17.835093+00	5	\N	\N	\N	\N	c5bc24b9-7d3a-469d-b3d2-aae45ab18be0	relance
1857	2	74	2026-09-14	15:00-16:00	1	VN	ROUSSEAU	\N	2026-09-08 09:56:07.314868+00	1778	\N	\N	\N	\N	\N	relance
1868	2	44	2026-09-10	10:00-11:00	1	VN	GOURNON AUSTRAL	\N	2026-09-08 09:57:46.761359+00	1782	\N	\N	\N	\N	\N	relance
1877	2	44	2026-09-13	11:00-12:00	1	VN	CHAMIGNON	\N	2026-09-08 09:58:26.781506+00	1782	\N	\N	\N	\N	\N	relance
1883	2	62	2026-09-12	15:00-16:00	1	VN	MAGNIER PERE	\N	2026-09-08 09:59:32.321943+00	7	\N	\N	\N	\N	\N	relance
1890	2	96	2026-09-10	09:00-10:00	1	VN	DEAL CASE MASTER	\N	2026-09-08 10:02:04.674604+00	1775	\N	\N	\N	\N	\N	relance
1894	2	78	2026-09-10	14:00-15:00	1	VN	SOLER	\N	2026-09-08 10:02:56.353371+00	1778	\N	\N	\N	\N	\N	relance
1910	2	87	2026-09-10	18:00-19:00	2	VN	BACQUET - CAPTUR VN	\N	2026-09-08 10:04:56.038832+00	1777	\N	\N	\N	\N	\N	relance
1915	2	70	2026-09-11	17:00-18:00	\N	VO	BOUGNES / CLIO	\N	2026-09-08 10:05:33.938529+00	8	2026-09-08 10:05:41.936506+00	8	\N	\N	\N	relance
1918	2	78	2026-09-13	10:00-11:00	1	VN	FONTES	\N	2026-09-08 10:05:52.645641+00	1778	\N	\N	\N	\N	\N	relance
8761	933	4	2026-10-08	18:00-19:00	1	VN	GRIMBERG R5	\N	2026-10-06 10:05:08.124167+00	5	\N	\N	\N	\N	d8d1b8ae-8e60-4f0d-8c94-2d2f381fc1c7	relance
8776	933	50	2026-10-09	14:00-15:00	1	VN	M  QUILLET	\N	2026-10-06 10:06:51.281197+00	1783	\N	\N	\N	\N	1a10bf50-528a-4ce0-8294-f1bb9838bd28	relance
8805	933	5	2026-10-08	18:00-19:00	1	VN	BULARD CAPTUR OU MEGANE	\N	2026-10-06 10:10:41.377565+00	5	\N	\N	\N	\N	f5067c9e-3206-4807-873f-d24e4a850c7d	relance
8811	933	5	2026-10-11	09:00-10:00	1	VN	MARION TWINGO	\N	2026-10-06 10:11:06.420551+00	5	\N	\N	\N	\N	06df7306-6912-4f15-aada-e2d4889d0810	relance
8829	933	15	2026-10-10	09:00-10:00	1	VN	GARGNE CLIO 9H30	\N	2026-10-06 10:14:01.327397+00	5	\N	\N	\N	\N	602d0e29-b0f2-46da-8952-359df0ec138b	relance
8835	933	68	2026-10-08	18:00-19:00	\N	VO	NEBOUT ARKANA	\N	2026-10-06 10:15:32.065902+00	7	\N	\N	\N	\N	36c990e6-72db-4d60-a43b-ae2436ae5c27	relance
8837	933	18	2026-10-10	09:00-10:00	1	VN	ferrier clio	\N	2026-10-06 10:16:20.176552+00	4	\N	\N	\N	\N	40959d86-c32b-4b22-bbe4-ce6aba9faf84	relance
8846	933	17	2026-10-08	11:00-12:00	1	VN	Chabosson Twingo	\N	2026-10-06 10:18:25.042988+00	3	\N	\N	\N	\N	b1a23923-75d2-463c-af42-319cce5732ed	relance
8849	933	11	2026-10-08	15:00-16:00	1	VN	ESTEVE R5	\N	2026-10-06 10:18:39.214821+00	5	\N	\N	\N	\N	d18502ae-96f8-4cd0-8d28-ba6901cb17a1	relance
8852	933	11	2026-10-09	10:00-11:00	1	VN	VAURE R5	\N	2026-10-06 10:18:58.548288+00	5	\N	\N	\N	\N	212263fd-0188-473d-b8eb-29f2a8f4d557	relance
8871	933	3216	2026-10-09	15:00-16:00	\N	VO	cabrit  gpl  vo	\N	2026-10-06 10:21:12.606482+00	4	\N	\N	\N	\N	c9eeb6b3-ed83-492f-90e1-4215da312537	relance
8885	933	32	2026-10-08	14:00-15:00	2	VN	SINSSAINE	\N	2026-10-06 10:24:13.945048+00	97	\N	\N	\N	\N	509636eb-e6e7-431a-8cbb-0920fe7f5b3a	relance
8814	933	59	2026-10-10	10:00-11:00	1	VN	GRANIER SANDERO	\N	2026-10-06 10:11:24.685599+00	7	2026-10-06 10:33:56.538654+00	7	2026-10-06 10:33:56.463+00	7	8b547a5d-f28f-4158-81ee-2cd58aec9120	relance
9033	933	882	2026-10-11	14:00-15:00	\N	VO	JOUVE	\N	2026-10-06 11:23:27.518861+00	9	\N	\N	\N	\N	2d46308b-012b-4bc9-8b8f-e3e663e5b8e3	relance
9035	933	65	2026-10-08	14:00-15:00	1	VN	NIVOL / R5-MEGANE	\N	2026-10-06 11:24:58.915772+00	8	\N	\N	\N	\N	74c4a43b-d876-4ebb-a4e9-06f2f71be61d	relance
9125	933	55	2026-10-11	11:00-12:00	1	VN	MOREL / MEGANE	\N	2026-10-06 14:22:49.585179+00	8	\N	\N	\N	\N	a5b27502-a92a-463b-a203-20fe956b693a	relance
9332	933	40	2026-10-10	09:00-10:00	\N	VO	ANTIQUI	\N	2026-10-06 15:43:37.174726+00	97	\N	\N	\N	\N	530b8eff-e510-436a-ac5e-2d8f5c887064	relance
9334	933	2	2026-10-10	11:00-12:00	1	VN	Morel Megane	\N	2026-10-06 15:43:57.474987+00	3	\N	\N	\N	\N	80e7ff2a-6e97-4801-be10-f34ee94fd740	relance
9341	933	19	2026-10-10	14:00-15:00	1	VN	COMBES (R5)	\N	2026-10-06 15:46:53.125711+00	2	\N	\N	\N	\N	7e447d27-3f95-4c98-95a3-a856e3e540ab	relance
9355	933	17	2026-10-12	14:00-15:00	1	VN	Auriol R5	\N	2026-10-06 15:50:00.64295+00	3	\N	\N	\N	\N	18e24335-2634-449e-83eb-fe4c2d75b01d	relance
9358	933	17	2026-10-12	10:00-11:00	1	VN	Richard Megane	\N	2026-10-06 15:50:21.199265+00	3	\N	\N	\N	\N	1e6b12ef-9e9b-4e64-b551-c43c2ff75793	relance
9364	933	89	2026-10-10	09:00-10:00	2	VN	hugonenc sandero	\N	2026-10-06 15:54:33.451204+00	1781	\N	\N	\N	\N	15aab506-7b03-47b7-90fc-621e3cfe10f3	relance
9367	933	6	2026-10-10	15:00-16:00	1	VN	PERROT (TWINGO)	\N	2026-10-06 15:57:15.039708+00	2	\N	\N	\N	\N	001945d5-cc97-404d-a710-cec434b7ee52	relance
9368	933	42	2026-10-12	16:00-17:00	2	VN	DUFLOS SANDERO	\N	2026-10-06 15:58:00.841963+00	1782	\N	\N	\N	\N	140c67d4-50bc-4633-963e-63adcf4a0616	relance
8832	933	44	2026-10-10	14:00-15:00	1	VN	MONIER RAFALE	\N	2026-10-06 10:14:46.764528+00	1782	2026-10-06 16:32:41.59481+00	1782	2026-10-06 16:32:41.206+00	1782	ac8134ea-a305-44e9-b81c-4ba0f4be4b52	relance
9444	933	6	2026-10-12	10:00-11:00	2	VN	SEIDEL(DUSTER)	\N	2026-10-06 16:46:36.426683+00	2	\N	\N	\N	\N	c4253600-bdc0-4453-9718-9789c3cfc1cd	relance
9507	933	73	2026-10-09	15:00-16:00	2	VN	ORIENTE	\N	2026-10-07 08:00:11.316925+00	5501	\N	\N	\N	\N	16ceaf35-dcff-4e62-8008-3a34ab1e6cbf	relance
9575	933	87	2026-10-08	15:00-16:00	2	VN	ESCAFFRE (R4 VN)	\N	2026-10-07 14:44:09.719622+00	1777	\N	\N	\N	\N	1aa9364a-8449-4529-97d4-c771f88ac84d	relance
9705	933	73	2026-10-08	17:00-18:00	1	VN	REILLES	\N	2026-10-09 06:58:02.599856+00	5501	\N	\N	\N	\N	bcbce13a-5d27-4a4d-982b-9d12d3e8ce1f	relance
9766	933	2	2026-10-10	15:00-16:00	1	VN	SALOME	\N	2026-10-10 15:54:46.067108+00	2	\N	\N	\N	\N	435db65d-e52d-40c3-88f1-7daa9eef88c6	showroom
9767	933	2	2026-10-10	11:00-12:00	1	VN	LAFARGE	\N	2026-10-10 15:55:18.147642+00	2	\N	\N	\N	\N	32304883-86db-4b03-941b-cde3f4a46d05	showroom
1858	2	60	2026-09-13	13:00-14:00	2	VN	ANDRE	\N	2026-09-08 09:56:14.346299+00	7	\N	\N	\N	\N	\N	relance
1862	2	74	2026-09-11	15:00-16:00	2	VN	VERAT	\N	2026-09-08 09:56:48.835483+00	1778	\N	\N	\N	\N	\N	relance
1869	2	76	2026-09-10	14:00-15:00	1	VN	MONTESQUIEU	\N	2026-09-08 09:57:59.828994+00	1778	\N	\N	\N	\N	\N	relance
1874	2	62	2026-09-10	14:00-15:00	1	VN	BADUEL	\N	2026-09-08 09:58:13.728392+00	7	\N	\N	\N	\N	\N	relance
1875	2	44	2026-09-12	16:00-17:00	1	VN	LABBE	\N	2026-09-08 09:58:21.521122+00	1782	\N	\N	\N	\N	\N	relance
1878	2	62	2026-09-11	11:00-12:00	2	VN	LEGILLON	\N	2026-09-08 09:58:34.795797+00	7	\N	\N	\N	\N	\N	relance
1880	2	76	2026-09-12	10:00-11:00	1	VN	ARTUSO	\N	2026-09-08 09:58:53.151907+00	1778	\N	\N	\N	\N	\N	relance
1886	2	96	2026-09-13	10:00-11:00	1	VN	CHALARD CLIO	\N	2026-09-08 10:00:36.064897+00	1775	\N	\N	\N	\N	\N	relance
1897	2	78	2026-09-10	16:00-17:00	1	VN	MAMBETOV	\N	2026-09-08 10:03:08.324332+00	1778	\N	\N	\N	\N	\N	relance
1919	2	70	2026-09-12	14:00-15:00	\N	VO	MAZOYER / CAPTUR	\N	2026-09-08 10:06:00.841859+00	8	\N	\N	\N	\N	\N	relance
1921	2	70	2026-09-12	16:00-17:00	\N	VO	VERNUS / CAPTUR	\N	2026-09-08 10:06:14.323555+00	8	\N	\N	\N	\N	\N	relance
1923	2	1885	2026-09-10	17:00-18:00	1	VN	MONTEILLET - VO DIVERS	\N	2026-09-08 10:06:53.343255+00	1777	\N	\N	\N	\N	\N	relance
8673	933	60	2026-10-10	10:00-11:00	1	VN	kevin	\N	2026-10-05 14:40:39.671608+00	95	2026-10-05 14:41:32.226832+00	95	2026-10-05 14:41:31.689+00	95	c6623f6a-aa59-454c-a00b-2d4464fc269d	relance
8668	933	60	2026-10-08	08:00-09:00	1	VN	martin	\N	2026-10-05 14:40:11.59605+00	95	2026-10-05 14:55:24.793497+00	95	2026-10-05 14:55:24.187+00	95	a2db751c-3903-45cb-bb39-ef93f2dccc5b	relance
8669	933	60	2026-10-08	10:00-11:00	1	VN	dupont	\N	2026-10-05 14:40:16.554749+00	95	2026-10-05 14:55:29.646679+00	95	2026-10-05 14:55:29.101+00	95	427f893c-c1e4-4706-86ea-758cab90ae61	relance
8670	933	60	2026-10-08	14:00-15:00	1	VN	pauli	\N	2026-10-05 14:40:20.199331+00	95	2026-10-05 14:55:32.34716+00	95	2026-10-05 14:55:31.786+00	95	fb5a1e78-c080-433f-a952-ea7b30d35374	relance
8671	933	60	2026-10-09	10:00-11:00	1	VN	mendou	\N	2026-10-05 14:40:24.24547+00	95	2026-10-05 14:55:45.980386+00	95	2026-10-05 14:55:45.462+00	95	c45513b2-9d41-4fb7-b312-dc623e58d5a6	relance
8672	933	60	2026-10-09	12:00-13:00	1	VN	zazi	\N	2026-10-05 14:40:28.35147+00	95	2026-10-05 14:55:48.543176+00	95	2026-10-05 14:55:48.029+00	95	a2179272-c567-4ec5-ac3d-70a85f0237f5	relance
8677	933	60	2026-10-10	10:00-11:00	2	VN	kevin	\N	2026-10-05 14:41:36.815894+00	95	2026-10-05 14:55:50.783932+00	95	2026-10-05 14:55:50.266+00	95	df7a58a6-7049-4828-864d-d33157f645ce	relance
8675	933	60	2026-10-11	09:00-10:00	1	VN	tre	\N	2026-10-05 14:41:15.397179+00	95	2026-10-05 14:55:52.550855+00	95	2026-10-05 14:55:52.04+00	95	423d465c-70cc-4f6f-86a1-4abed81cdfd8	relance
8674	933	60	2026-10-11	11:00-12:00	1	VN	jean louis	\N	2026-10-05 14:40:54.542267+00	95	2026-10-05 14:55:55.569629+00	95	2026-10-05 14:55:55.046+00	95	7e2e440e-95fd-49b6-8e4e-e1c02391ea51	relance
8676	933	60	2026-10-12	10:00-11:00	2	VN	passy	\N	2026-10-05 14:41:22.705042+00	95	2026-10-05 14:55:59.07312+00	95	2026-10-05 14:55:58.543+00	95	b0720d9d-7dd8-4380-b779-7cae5be976e5	relance
8763	933	4	2026-10-09	11:00-12:00	1	VN	LENORMAND TRAFFIC	\N	2026-10-06 10:05:27.380293+00	5	\N	\N	\N	\N	b2538b32-95ec-4a1c-a5c2-633ca7bc0ef8	relance
8768	933	50	2026-10-08	15:00-16:00	1	VN	M CHABROL	\N	2026-10-06 10:06:05.171835+00	1783	\N	\N	\N	\N	5cd39a20-36f8-49b3-a805-479aa4cab609	relance
8772	933	54	2026-10-11	10:00-11:00	1	VN	JOUVE SCENIC	\N	2026-10-06 10:06:24.329112+00	7	\N	\N	\N	\N	b95aebb2-c14b-4c28-9214-1edd91c0fb20	relance
8775	933	4	2026-10-11	10:00-11:00	1	VN	GARCIA CLIO 6	\N	2026-10-06 10:06:47.076729+00	5	\N	\N	\N	\N	8ef392c3-15bf-4519-b428-22bcb884d6d5	relance
8778	933	55	2026-10-08	14:00-15:00	1	VN	SAUGUE / AUSTRAL	\N	2026-10-06 10:07:02.775476+00	8	\N	\N	\N	\N	4e8ec59c-403d-4f7a-a221-c86668374a42	relance
8783	933	59	2026-10-08	10:00-11:00	1	VN	METAS R4	\N	2026-10-06 10:07:43.733091+00	7	\N	\N	\N	\N	c9762349-809b-42a7-b951-ac8a75dccd34	relance
8802	933	5	2026-10-08	14:00-15:00	1	VN	CHAMBON TRAFFIC VU	\N	2026-10-06 10:10:22.834118+00	5	\N	\N	\N	\N	a2d92c0f-0583-4a8f-88c3-b188f03c368a	relance
8804	933	59	2026-10-09	14:00-15:00	1	VN	LACASSE R5 TECHNO	\N	2026-10-06 10:10:37.365688+00	7	\N	\N	\N	\N	c0847169-a03e-4869-93f3-8e3fdbb248f9	relance
8807	933	59	2026-10-09	15:00-16:00	1	VN	PRESENCE RURALE	\N	2026-10-06 10:10:54.495042+00	7	\N	\N	\N	\N	8b33222e-6b93-41a5-99c4-6bdacb168f2c	relance
8820	933	3216	2026-10-09	17:00-18:00	\N	VO	brunel  duster	\N	2026-10-06 10:12:24.933441+00	4	\N	\N	\N	\N	74d5c4a2-a9d1-4ff1-917c-445e83c83767	relance
8827	933	15	2026-10-09	17:00-18:00	2	VN	ZAMI 17H30 DUSTER	\N	2026-10-06 10:13:23.278659+00	5	2026-10-06 10:13:42.653917+00	5	\N	\N	e810304b-e809-4df7-ac17-5a22d8fca5be	relance
8840	933	44	2026-10-11	11:00-12:00	1	VN	KLEIN MEGANE E TECH	\N	2026-10-06 10:17:17.620866+00	1782	\N	\N	\N	\N	e707c532-f6c0-44c0-b442-f414923c2d6b	relance
8841	933	18	2026-10-08	11:00-12:00	1	VN	liagre  r5	\N	2026-10-06 10:17:19.655031+00	4	\N	\N	\N	\N	e70cf65c-5171-445c-b345-da7880ec4aea	relance
8826	933	59	2026-10-11	14:00-15:00	1	VN	MELANIE  AUSTRALE OU MEGANE	\N	2026-10-06 10:13:09.593776+00	7	2026-10-06 10:33:39.525643+00	7	\N	\N	ec3a455f-5bef-45a8-8a4c-6a740105e998	relance
9034	933	61	2026-10-10	14:00-15:00	\N	VO	HUGON   AUSTRAL	\N	2026-10-06 11:23:37.665042+00	7	\N	\N	\N	\N	83bde869-d3c9-42e4-b7f7-2d87f13e6792	relance
9126	933	67	2026-10-08	11:00-12:00	2	VN	MAISONNEUVE / SPRING	\N	2026-10-06 14:23:26.450149+00	8	\N	\N	\N	\N	3d245b4f-420b-434d-b16d-bc70ae86ae51	relance
9336	933	160	2026-10-08	15:00-16:00	1	VN	Poupin VO twingo /zoe vo	\N	2026-10-06 15:45:24.733859+00	3	\N	\N	\N	\N	b3cebce3-a7ac-408c-be12-16b62b636cb8	relance
9337	933	54	2026-10-08	18:00-19:00	1	VN	RESSEGUIR TWINGO	\N	2026-10-06 15:45:36.888204+00	7	\N	\N	\N	\N	f81aae1c-bb47-432b-93e2-0788bb7f7127	relance
9346	933	26	2026-10-11	09:00-10:00	1	VN	SOUNY (CLIO)	\N	2026-10-06 15:48:08.687162+00	2	\N	\N	\N	\N	3f5992be-f409-48ae-a6ba-6d801f9febd3	relance
9351	933	17	2026-10-10	17:00-18:00	1	VN	Augheard clio	\N	2026-10-06 15:49:05.849787+00	3	\N	\N	\N	\N	3c40eb4a-dfe7-44af-bf26-9976f4044b32	relance
9445	933	6	2026-10-12	14:00-15:00	2	VN	DOUAY ( R5)	\N	2026-10-06 16:46:52.907242+00	2	\N	\N	\N	\N	4743f149-29bd-405e-857c-e709cdc09025	relance
9576	933	87	2026-10-08	16:00-17:00	2	VN	MARCHETTI (CLIO VO)	\N	2026-10-07 14:49:41.14402+00	1777	\N	\N	\N	\N	774a0982-ef2f-4a28-a204-7a79f6d5f017	relance
9706	933	73	2026-10-08	18:00-19:00	1	VN	RENAUD	\N	2026-10-09 06:58:05.590599+00	5501	2026-10-09 06:58:08.403215+00	5501	2026-10-09 06:58:08.296+00	5501	f6cf659e-3dd1-4685-8d32-512125a5b783	relance
9508	933	73	2026-10-09	16:00-17:00	2	VN	RAYNAUD	\N	2026-10-07 08:00:17.159796+00	5501	2026-10-09 06:58:24.339182+00	5501	2026-10-09 06:58:24.215+00	5501	407a6040-e443-4695-8fc9-352739054f51	relance
9768	933	62	2026-10-09	17:00-18:00	1	VN	ACHON	\N	2026-10-10 15:59:48.993557+00	9	\N	\N	\N	\N	27ba384b-441a-4930-9065-0d5835c7ebdd	showroom
1859	2	74	2026-09-14	09:00-10:00	1	VN	CORAIL	\N	2026-09-08 09:56:17.694849+00	1778	\N	\N	\N	\N	\N	relance
1866	2	76	2026-09-11	10:00-11:00	2	VN	DECHAUME	\N	2026-09-08 09:57:39.199757+00	1778	\N	\N	\N	\N	\N	relance
1872	2	76	2026-09-11	14:00-15:00	2	VN	JULIEN	\N	2026-09-08 09:58:11.05131+00	1778	\N	\N	\N	\N	\N	relance
1876	2	76	2026-09-12	14:00-15:00	1	VN	MORGADO	\N	2026-09-08 09:58:24.848581+00	1778	\N	\N	\N	\N	\N	relance
1882	2	62	2026-09-12	14:00-15:00	1	VN	RODIER	\N	2026-09-08 09:59:17.81274+00	7	\N	\N	\N	\N	\N	relance
1888	2	47	2026-09-12	12:00-13:00	\N	VO	BRENON CAROLE 0686043729	\N	2026-09-08 10:01:16.551998+00	1782	2026-09-08 10:01:28.272934+00	1782	\N	\N	\N	relance
1900	2	94	2026-09-12	14:00-15:00	1	VN	FERNANDEZ	\N	2026-09-08 10:04:02.464963+00	1780	\N	\N	\N	\N	\N	relance
1901	2	87	2026-09-10	09:00-10:00	2	VN	BOYER - MEG VO	\N	2026-09-08 10:04:06.517803+00	1777	\N	\N	\N	\N	\N	relance
1902	2	78	2026-09-10	17:00-18:00	2	VN	POTE	\N	2026-09-08 10:04:16.858387+00	1778	\N	\N	\N	\N	\N	relance
1907	2	70	2026-09-10	17:00-18:00	\N	VO	ROMAN / CLIO	\N	2026-09-08 10:04:33.577165+00	8	\N	\N	\N	\N	\N	relance
1909	2	78	2026-09-12	09:00-10:00	1	VN	BONNET	\N	2026-09-08 10:04:47.330487+00	1778	\N	\N	\N	\N	\N	relance
1928	2	68	2026-09-12	11:00-12:00	\N	VO	DISSAY	\N	2026-09-08 10:07:44.336409+00	9	\N	\N	\N	\N	\N	relance
8678	933	60	2026-10-08	15:00-16:00	2	VN	PASSE PARTOUT	\N	2026-10-05 14:45:05.166207+00	95	2026-10-05 14:55:42.996568+00	95	2026-10-05 14:55:42.463+00	95	f4180af2-5e87-4220-a648-6218ca125b17	showroom
8769	933	50	2026-10-08	16:00-17:00	1	VN	M CHABOT	\N	2026-10-06 10:06:11.128364+00	1783	2026-10-06 10:06:20.160123+00	1783	\N	\N	07dc1203-4bee-4ef1-8955-e730af9bda4f	relance
8784	933	55	2026-10-09	16:00-17:00	1	VN	DEJOUE / R5	\N	2026-10-06 10:07:46.988779+00	8	\N	\N	\N	\N	ae087094-f7ea-4212-9aad-9ad77e8c7033	relance
8793	933	5766	2026-10-09	10:00-11:00	\N	VO	COLOMBET / CLIO	\N	2026-10-06 10:09:07.20176+00	8	\N	\N	\N	\N	348e6b46-6bde-40d0-a760-8027f26aa2b2	relance
8810	933	44	2026-10-08	08:00-09:00	1	VN	CARRAY TWINGO	\N	2026-10-06 10:11:05.883193+00	1782	\N	\N	\N	\N	6c0397db-7503-4db2-a657-c983dc679224	relance
8819	933	44	2026-10-08	18:00-19:00	1	VN	RIBAUD KANGOO	\N	2026-10-06 10:12:12.208029+00	1782	\N	\N	\N	\N	32c21dbe-0a0c-451a-9453-b380ba5256a9	relance
8821	933	44	2026-10-09	17:00-18:00	1	VN	MARIDET SCENIC	\N	2026-10-06 10:12:42.346743+00	1782	\N	\N	\N	\N	0a22164a-0e2b-4394-9282-ddc1b45bc8cf	relance
8823	933	44	2026-10-10	10:00-11:00	1	VN	LUPUS R5	\N	2026-10-06 10:12:58.811083+00	1782	\N	\N	\N	\N	20491206-8017-4b23-9695-362e89d51cce	relance
9036	933	67	2026-10-11	11:00-12:00	1	VN	LALOUP / MEGANE	\N	2026-10-06 11:25:13.119631+00	8	\N	\N	\N	\N	eada03b4-165a-45da-b88c-c76f60ab1694	relance
9338	933	160	2026-10-10	15:00-16:00	1	VN	Perrot Twingo	\N	2026-10-06 15:45:54.760154+00	3	\N	\N	\N	\N	0cacb7d3-e842-41a5-b1bd-bd3a0a9c8390	relance
9347	933	62	2026-10-09	10:00-11:00	1	VN	APTEL	\N	2026-10-06 15:48:17.923071+00	95	\N	\N	\N	\N	4907694b-eca7-4c96-9ae4-1d4ddabf94c1	relance
9353	933	17	2026-10-11	09:00-10:00	1	VN	Laprononciere Megane	\N	2026-10-06 15:49:31.631822+00	3	\N	\N	\N	\N	54ae3665-ede5-4e68-a6e9-70dec072fa22	relance
9362	933	16	2026-10-08	11:00-12:00	1	VN	Pachot	\N	2026-10-06 15:53:15.878301+00	3	\N	\N	\N	\N	0e7227d8-2516-454b-abfd-d6b5d4e4f79b	relance
9446	933	6	2026-10-08	15:00-16:00	2	VN	BRUNEL (DUSTER)	\N	2026-10-06 16:47:16.398796+00	2	\N	\N	\N	\N	05ff673e-742e-46be-92ee-ac421582563a	relance
9510	933	73	2026-10-09	09:00-10:00	2	VN	KOMBELEMSIGI	\N	2026-10-07 08:00:53.782236+00	5501	\N	\N	\N	\N	5fad43bd-b59a-4ab2-982f-af0186458903	relance
9577	933	87	2026-10-10	13:00-14:00	2	VN	GLINZ (Twingo etech VN)	\N	2026-10-07 14:51:01.09958+00	1777	\N	\N	\N	\N	267db06a-9097-4331-a0f1-2405f611b7fc	relance
9707	933	73	2026-10-08	18:00-19:00	2	VN	RAYNAUD	\N	2026-10-09 06:58:14.203751+00	5501	\N	\N	\N	\N	e58c682c-ee9c-4ae1-80e1-8183d5927d10	relance
9127	933	60	2026-10-11	15:00-16:00	2	VN	VILLARET	\N	2026-10-06 14:23:44.479445+00	7	2026-10-09 14:11:15.982228+00	7	\N	\N	e8e10705-3afe-4da1-b789-a0b82c14fe50	relance
9769	933	5769	2026-10-10	15:00-16:00	\N	VO	DOMMERGUE	\N	2026-10-10 16:08:16.292051+00	5501	2026-10-10 16:08:22.407891+00	5501	\N	\N	12d08360-eae9-4064-9007-9c69ffc35377	relance
9771	933	2	2026-10-10	16:00-17:00	1	VN	GUILLAUME	\N	2026-10-10 16:09:42.095303+00	2	\N	\N	\N	\N	bba043fa-5374-4fdd-9811-08f27f8bad3a	showroom
1864	2	44	2026-09-10	09:00-10:00	1	VN	DHERET	\N	2026-09-08 09:57:17.843251+00	1782	\N	\N	\N	\N	\N	relance
1871	2	62	2026-09-10	11:00-12:00	2	VN	BACONNET	\N	2026-09-08 09:58:03.021408+00	7	\N	\N	\N	\N	\N	relance
1881	2	62	2026-09-12	11:00-12:00	1	VN	RODIER	\N	2026-09-08 09:58:54.441496+00	7	2026-09-08 09:59:09.964897+00	7	2026-09-08 09:59:09.935+00	7	\N	relance
1911	2	70	2026-09-11	09:00-10:00	\N	VO	VALENTE / VO ELEC	\N	2026-09-08 10:04:56.04629+00	8	\N	\N	\N	\N	\N	relance
8679	933	4	2026-10-09	08:00-09:00	1	VN	test	\N	2026-10-06 07:34:31.345835+00	4	2026-10-06 08:35:55.606559+00	92	2026-10-06 08:35:54.73+00	92	c8461886-0521-4f9c-b33f-ceeb3d5862a7	relance
8774	933	55	2026-10-08	13:00-14:00	1	VN	GUARDES / CAPTUR	\N	2026-10-06 10:06:44.875956+00	8	\N	\N	\N	\N	37388394-8f15-45ab-ba4c-f70c80ba9b4d	relance
8786	933	55	2026-10-10	14:00-15:00	1	VN	GIRAUD / R5	\N	2026-10-06 10:08:20.226448+00	8	\N	\N	\N	\N	fa9c4ef4-37ea-46e4-82e1-1fa1457e2737	relance
8792	933	4	2026-10-10	15:00-16:00	2	VN	LAROCHE 15H30	\N	2026-10-06 10:09:00.550754+00	5	\N	\N	\N	\N	296c2a2b-e682-4324-b5e9-fb182ee357a1	relance
8800	933	5	2026-10-08	10:00-11:00	1	VN	DRUET RAFALE	\N	2026-10-06 10:10:15.827416+00	5	\N	\N	\N	\N	018f511e-9488-4fcf-8dc0-66df452c8c17	relance
8806	933	5	2026-10-09	18:00-19:00	1	VN	PRULIERE R5	\N	2026-10-06 10:10:52.667043+00	5	\N	\N	\N	\N	aea9a7ef-36b4-45e9-91a8-4563863d0776	relance
8812	933	5	2026-10-11	10:00-11:00	1	VN	BREUIL TWINGO	\N	2026-10-06 10:11:12.758742+00	5	\N	\N	\N	\N	7e2b30cf-838f-4372-a201-f88a624acdb3	relance
8817	933	5	2026-10-09	09:00-10:00	2	VN	LONGERA DUSTER	\N	2026-10-06 10:12:02.682806+00	5	\N	\N	\N	\N	11203550-ec2a-41a3-87e3-661d3a479cc8	relance
8825	933	59	2026-10-11	10:00-11:00	1	VN	TRINQUE R5	\N	2026-10-06 10:13:05.745131+00	7	\N	\N	\N	\N	f84e0318-4a92-4775-94ce-761076a97673	relance
8833	933	59	2026-10-08	11:00-12:00	1	VN	POUCHOU RAFALE	\N	2026-10-06 10:14:52.303354+00	7	\N	\N	\N	\N	de183264-d711-4b55-94f0-093b5b56a1f3	relance
8834	933	54	2026-10-08	14:00-15:00	1	VN	BARRY R5	\N	2026-10-06 10:15:15.800274+00	7	\N	\N	\N	\N	2e6ec7c3-7648-47dc-a3f3-8985ff2a1d59	relance
8794	933	59	2026-10-08	14:00-15:00	1	VN	BRECHET  ELECTRIQUE	\N	2026-10-06 10:09:21.744607+00	7	2026-10-06 10:32:25.114198+00	7	\N	\N	f41ebef4-beda-4c51-b12f-245019f19f60	relance
9037	933	54	2026-10-09	16:00-17:00	2	VN	BARLET R4	\N	2026-10-06 11:36:15.308171+00	7	\N	\N	\N	\N	e21ea573-4133-4547-a0e2-499173b83459	relance
9128	933	1886	2026-10-08	09:00-10:00	2	VN	LEDOLLEY DUSTER	\N	2026-10-06 14:25:18.792776+00	1776	\N	\N	\N	\N	f465c498-085e-4163-97bc-a294993b9093	relance
9339	933	54	2026-10-09	10:00-11:00	2	VN	LAPORTE SPRING	\N	2026-10-06 15:46:00.494037+00	7	\N	\N	\N	\N	b37d5971-a861-4949-b7b4-e3cee7f81a73	relance
9342	933	4204	2026-10-11	10:00-11:00	1	VN	THOMAS TWINGO	\N	2026-10-06 15:47:04.734003+00	1782	\N	\N	\N	\N	1e1d0ff0-a3ac-4caa-85e1-d2c139529e27	relance
9345	933	4204	2026-10-09	08:00-09:00	1	VN	BONIOUX MEGANE E TECH	\N	2026-10-06 15:48:03.026831+00	1782	\N	\N	\N	\N	998ea7fc-7283-4296-bab6-465435a12f02	relance
9349	933	17	2026-10-10	17:00-18:00	1	VN	augheard Clio	\N	2026-10-06 15:48:38.546929+00	3	2026-10-06 15:48:44.650912+00	3	2026-10-06 15:48:47.223+00	3	071ace99-522a-4802-ad58-998aa1f31ca4	relance
9352	933	59	2026-10-12	16:00-17:00	1	VN	NAVECTH JOGGER	\N	2026-10-06 15:49:31.019388+00	7	2026-10-06 15:49:47.601415+00	7	\N	\N	387dec8c-0c0a-4d66-a4db-2f406eadb3c6	relance
9357	933	17	2026-10-12	16:00-17:00	1	VN	Sioly R5	\N	2026-10-06 15:50:11.330498+00	3	\N	\N	\N	\N	3d028a07-6f3e-4f6b-bdd0-2daa5dbf2935	relance
9359	933	48	2026-10-10	14:00-15:00	1	VN	M BEARD	\N	2026-10-06 15:52:08.798804+00	1783	\N	\N	\N	\N	e7e95849-1089-4535-958f-73f1f1777bbc	relance
9447	933	19	2026-10-12	09:00-10:00	1	VN	GAILLE ( TWINGO)	\N	2026-10-06 16:48:02.672537+00	2	\N	\N	\N	\N	0178cb7a-30fb-4108-bf16-4d0fc0bc4035	relance
9511	933	5769	2026-10-08	10:00-11:00	\N	VO	VIGNE	\N	2026-10-07 08:02:08.574417+00	5501	\N	\N	\N	\N	488b7736-cece-428f-89cb-e3047e6300f0	relance
9514	933	5769	2026-10-09	14:00-15:00	\N	VO	LANDELLE	\N	2026-10-07 08:03:02.815769+00	5501	\N	\N	\N	\N	dc020b79-5ef6-4c5c-b0da-27b425664ffc	relance
9578	933	90	2026-10-08	11:00-12:00	2	VN	grard sandero	\N	2026-10-07 15:08:00.992059+00	1781	\N	\N	\N	\N	61171fa8-b8ef-40f0-89d1-29d95f6d4c63	relance
8797	933	59	2026-10-08	16:00-17:00	1	VN	RAMON R5 LOA	\N	2026-10-06 10:09:34.085126+00	7	2026-10-08 16:20:16.176995+00	7	\N	\N	72313120-fbc8-4688-90db-66a9dc88ae90	relance
9708	933	70	2026-10-08	08:00-09:00	\N	VO	PIOL	\N	2026-10-09 07:12:32.189947+00	9	\N	\N	\N	\N	cba66f39-6552-4bf9-aed2-36bc40d00ce1	showroom
9770	933	5769	2026-10-10	16:00-17:00	\N	VO	GENUIT	\N	2026-10-10 16:08:35.688311+00	5501	\N	\N	\N	\N	dfbe69d8-413e-4e53-b78b-6b4f73b73b58	relance
1873	2	44	2026-09-11	13:00-14:00	1	VN	RESSOT	\N	2026-09-08 09:58:12.49399+00	1782	\N	\N	\N	\N	\N	relance
1884	2	62	2026-09-12	16:00-17:00	1	VN	MANIER  FILS	\N	2026-09-08 09:59:42.528317+00	7	\N	\N	\N	\N	\N	relance
1887	2	47	2026-09-12	13:00-14:00	\N	VO	MARTIN SERGE 0606459077	\N	2026-09-08 10:00:38.921398+00	1782	2026-09-08 10:01:20.019991+00	1782	2026-09-08 10:01:19.836+00	1782	\N	relance
1892	2	78	2026-09-10	09:00-10:00	1	VN	BASSO	\N	2026-09-08 10:02:47.266806+00	1778	\N	\N	\N	\N	\N	relance
1893	2	66	2026-09-10	10:00-11:00	1	VN	BERTHON / R4	\N	2026-09-08 10:02:49.516711+00	8	\N	\N	\N	\N	\N	relance
1898	2	78	2026-09-10	17:00-18:00	1	VN	POTE	\N	2026-09-08 10:03:22.424164+00	1778	2026-09-08 10:04:21.268974+00	1778	2026-09-08 10:04:19.846+00	1778	\N	relance
1912	2	78	2026-09-12	14:00-15:00	1	VN	SYLVESTRE	\N	2026-09-08 10:05:03.282595+00	1778	\N	\N	\N	\N	\N	relance
1913	2	87	2026-09-11	17:00-18:00	2	VN	VALTAT - CLIO VN	\N	2026-09-08 10:05:13.228427+00	1777	\N	\N	\N	\N	\N	relance
1916	2	87	2026-09-14	14:00-15:00	2	VN	LAURENT - SANDERO / CLIO	\N	2026-09-08 10:05:35.345423+00	1777	\N	\N	\N	\N	\N	relance
1925	2	1885	2026-09-11	14:00-15:00	1	VN	GALLINQUE - DUSTER VN	\N	2026-09-08 10:07:17.113401+00	1777	\N	\N	\N	\N	\N	relance
8680	933	15	2026-10-09	08:00-09:00	1	VN	h	\N	2026-10-06 08:08:29.222902+00	5	2026-10-06 08:10:08.533626+00	5	2026-10-06 08:10:08.203+00	5	06627439-8633-41d7-9f42-a00a06b402df	relance
8836	933	18	2026-10-10	10:00-11:00	1	VN	raymond espace	\N	2026-10-06 10:16:01.353764+00	4	\N	\N	\N	\N	e179e87b-d2ec-49ac-9859-ce0e39eee13a	relance
9038	933	93	2026-10-10	14:00-15:00	1	VN	COUDERC	\N	2026-10-06 11:49:15.478612+00	1780	\N	\N	\N	\N	485a7bb3-6420-49f6-877a-bfef528e0abc	relance
9129	933	1886	2026-10-08	16:00-17:00	2	VN	VELLEILE SPRING	\N	2026-10-06 14:25:33.717327+00	1776	\N	\N	\N	\N	8ffe6804-5536-459b-a25b-af1582f7bd8a	relance
9340	933	54	2026-10-10	12:00-13:00	2	VN	PESSENTI TWINGO	\N	2026-10-06 15:46:26.39981+00	7	\N	\N	\N	\N	8cd8c56b-1596-4499-a762-35c061f3231a	relance
9344	933	19	2026-10-11	10:00-11:00	1	VN	BONHOURE ( CLIO)	\N	2026-10-06 15:47:40.159152+00	2	\N	\N	\N	\N	9a2b0767-1e0b-4c79-930b-17ec2a75e4c0	relance
9356	933	54	2026-10-08	10:00-11:00	2	VN	MALGAC	\N	2026-10-06 15:50:05.119767+00	7	\N	\N	\N	\N	45fbf2da-e2f6-4790-878d-8e0a384f3174	relance
9448	933	19	2026-10-12	14:00-15:00	1	VN	LEGER (SYMBIOZ)	\N	2026-10-06 16:48:35.916274+00	2	\N	\N	\N	\N	59ecf1f1-8329-415f-8e00-6859f3addede	relance
9512	933	5769	2026-10-08	15:00-16:00	\N	VO	LAUTREC	\N	2026-10-07 08:02:28.906921+00	5501	\N	\N	\N	\N	89db2d7d-9a96-467e-bf55-56ce665d7ae6	relance
9579	933	90	2026-10-09	16:00-17:00	2	VN	papillon sandero	\N	2026-10-07 15:08:35.194425+00	1781	\N	\N	\N	\N	6ddf792e-279a-4e94-a2ca-1b58b0586417	relance
9709	933	67	2026-10-08	08:00-09:00	1	VN	AMSELLEM	\N	2026-10-09 07:15:20.037482+00	9	\N	\N	\N	\N	2a001c64-28b3-4db6-bd34-4add29ac4b4f	showroom
9772	933	11	2026-10-10	11:00-12:00	1	VN	CREPIEU	\N	2026-10-10 16:10:19.45259+00	5	\N	\N	\N	\N	5d2b19fb-ef91-4f9c-9890-23673e5675b0	relance
9773	933	2	2026-10-10	10:00-11:00	1	VN	MEGE	\N	2026-10-10 16:10:25.437537+00	2	\N	\N	\N	\N	3df8b624-8458-467e-bf8d-91da748a5047	showroom
1879	2	76	2026-09-14	09:00-10:00	1	VN	DURAND	\N	2026-09-08 09:58:39.282248+00	1778	\N	\N	\N	\N	\N	relance
1896	2	92	2026-09-11	18:00-19:00	2	VN	VITTORI	\N	2026-09-08 10:03:06.628126+00	1780	\N	\N	\N	\N	\N	relance
1903	2	94	2026-09-11	10:00-11:00	1	VN	BLEUZET	\N	2026-09-08 10:04:16.898011+00	1780	\N	\N	\N	\N	\N	relance
1914	2	78	2026-09-12	16:00-17:00	1	VN	VIREZILIER	\N	2026-09-08 10:05:18.654109+00	1778	\N	\N	\N	\N	\N	relance
1917	2	87	2026-09-14	15:00-16:00	2	VN	DRUART - CLIO VN	\N	2026-09-08 10:05:47.760201+00	1777	\N	\N	\N	\N	\N	relance
1929	2	59	2026-09-10	11:00-12:00	1	VN	VANOVERMEIRE / CAPTUR	\N	2026-09-08 10:08:12.684772+00	8	\N	\N	\N	\N	\N	relance
8681	933	3216	2026-10-09	09:00-10:00	\N	VO	teee	\N	2026-10-06 09:10:36.642418+00	2	2026-10-06 09:10:43.902589+00	2	2026-10-06 09:10:44.282+00	2	e142f1e0-fe31-4a4b-893c-940e537e3ea1	relance
8839	933	44	2026-10-11	10:00-11:00	1	VN	FLOUZAT R5	\N	2026-10-06 10:17:00.66717+00	1782	\N	\N	\N	\N	3d4902b6-b5e1-4f0d-afce-75c556fadb39	relance
9039	933	93	2026-10-08	17:00-18:00	1	VN	GOURDIN	\N	2026-10-06 11:49:25.356247+00	1780	\N	\N	\N	\N	331dff2b-4b5c-452d-af58-c44c46b6d9ab	relance
9130	933	1886	2026-10-08	17:00-18:00	2	VN	JOURDAN DACIA	\N	2026-10-06 14:25:44.588846+00	1776	\N	\N	\N	\N	f87da370-319f-4f6e-930d-9656fdc2ed98	relance
9133	933	1886	2026-10-10	10:00-11:00	2	VN	TOURRETTE SANDERO	\N	2026-10-06 14:26:35.061522+00	1776	\N	\N	\N	\N	b42ac132-217b-48d6-b95f-7d2579a1db92	relance
9135	933	1886	2026-10-12	14:00-15:00	2	VN	AUREJAC SANDERO	\N	2026-10-06 14:27:01.194492+00	1776	\N	\N	\N	\N	e8afe253-b057-4a25-a0b4-522de8fbe588	relance
9140	933	85	2026-10-08	14:00-15:00	\N	VO	FAVIER	\N	2026-10-06 14:28:31.118773+00	1776	\N	\N	\N	\N	c10d0c1c-7917-4bed-b786-be1a5ca0e9ea	relance
9143	933	84	2026-10-08	14:00-15:00	\N	VO	VEYRUNES	\N	2026-10-06 14:29:28.488204+00	1776	\N	\N	\N	\N	18ec54a8-f0bd-41a7-9493-aa38bb3bf042	relance
9348	933	62	2026-10-10	09:00-10:00	1	VN	FAIDIT	\N	2026-10-06 15:48:35.252961+00	95	\N	\N	\N	\N	27670f64-8ffb-4e96-9f58-4103fa6830f6	relance
9360	933	44	2026-10-10	17:00-18:00	1	VN	THERIOT R5	\N	2026-10-06 15:52:46.53797+00	1782	\N	\N	\N	\N	c70e16cf-0e68-428d-9939-94c920ee9e93	relance
9449	933	12	2026-10-12	14:00-15:00	2	VN	MATHEVEN (DUSTER)	\N	2026-10-06 16:50:24.177249+00	2	\N	\N	\N	\N	0b99c5ad-dc23-4501-b419-359913a5cb82	relance
9513	933	5769	2026-10-09	09:00-10:00	\N	VO	GOURMANEL	\N	2026-10-07 08:02:57.539926+00	5501	\N	\N	\N	\N	801899e8-9ba7-48f1-a6b0-7b0f0b89e5c5	relance
9580	933	90	2026-10-12	10:00-11:00	2	VN	bruel r5	\N	2026-10-07 15:08:52.815018+00	1781	2026-10-07 15:08:57.93739+00	1781	2026-10-07 15:08:57.796+00	1781	bc0ea95c-11d5-44cd-aeb3-b86832dd7300	relance
9710	933	74	2026-10-09	10:00-11:00	1	VN	OLIVIER	\N	2026-10-09 07:41:51.108163+00	5501	\N	\N	\N	\N	d9051bc0-520b-43f4-8915-970ea9db7b2a	relance
9774	933	59	2026-10-10	17:00-18:00	1	VN	BRAJON	\N	2026-10-10 16:41:40.254219+00	7	\N	\N	\N	\N	be54c910-03bb-4880-81df-3540a102ea9c	showroom
1885	2	62	2026-09-12	09:00-10:00	1	VN	ROSSIGNOL	\N	2026-09-08 09:59:54.015525+00	7	\N	\N	\N	\N	\N	relance
1905	2	87	2026-09-10	14:00-15:00	2	VN	GASSIN - CAPTUR VN	\N	2026-09-08 10:04:25.448754+00	1777	\N	\N	\N	\N	\N	relance
1931	2	59	2026-09-10	18:00-19:00	2	VN	MAILLET / SANDERO	\N	2026-09-08 10:08:39.627699+00	8	\N	\N	\N	\N	\N	relance
1932	2	59	2026-09-11	09:00-10:00	2	VN	SALENDRE / SANDERO	\N	2026-09-08 10:09:09.462882+00	8	\N	\N	\N	\N	\N	relance
1933	2	59	2026-09-11	10:00-11:00	1	VN	VIGNEMASSE / CAPTUR	\N	2026-09-08 10:09:31.41844+00	8	\N	\N	\N	\N	\N	relance
1934	2	59	2026-09-11	15:00-16:00	1	VN	REDON / CLIO	\N	2026-09-08 10:09:43.78823+00	8	\N	\N	\N	\N	\N	relance
1935	2	59	2026-09-11	16:00-17:00	2	VN	SCHMID / DUSTER	\N	2026-09-08 10:10:06.557908+00	8	\N	\N	\N	\N	\N	relance
1936	2	59	2026-09-11	18:00-19:00	1	VN	ANINO / CLIO	\N	2026-09-08 10:10:23.530522+00	8	\N	\N	\N	\N	\N	relance
1938	2	18	2026-09-10	09:00-10:00	1	VN	fadigrand clio	\N	2026-09-08 10:11:00.884739+00	4	\N	\N	\N	\N	\N	relance
1937	2	59	2026-09-12	10:00-11:00	1	VN	SALENDRE / CAPTUR	\N	2026-09-08 10:10:56.941395+00	8	2026-09-08 10:11:08.693752+00	8	\N	\N	\N	relance
1939	2	18	2026-09-10	18:00-19:00	1	VN	rodier clio	\N	2026-09-08 10:11:18.8069+00	4	\N	\N	\N	\N	\N	relance
1940	2	59	2026-09-13	14:00-15:00	1	VN	HALLEUX / CLIO	\N	2026-09-08 10:11:32.943887+00	8	\N	\N	\N	\N	\N	relance
1941	2	27	2026-09-12	11:00-12:00	1	VN	CESSAC CLIO	\N	2026-09-08 10:11:42.918528+00	5	\N	\N	\N	\N	\N	relance
1942	2	18	2026-09-10	17:00-18:00	1	VN	rispal twingo	\N	2026-09-08 10:11:47.130224+00	4	\N	\N	\N	\N	\N	relance
1944	2	59	2026-09-14	10:00-11:00	2	VN	CHASTEL / SANDERO	\N	2026-09-08 10:12:04.170845+00	8	\N	\N	\N	\N	\N	relance
1943	2	27	2026-09-10	10:00-11:00	1	VN	MANCHEZ SANDERO	\N	2026-09-08 10:11:57.030945+00	5	2026-09-08 10:12:11.767625+00	5	\N	\N	\N	relance
1945	2	34	2026-09-10	09:00-10:00	1	VN	lacroix	\N	2026-09-08 10:12:18.776836+00	97	\N	\N	\N	\N	\N	relance
1946	2	27	2026-09-11	10:00-11:00	1	VN	LEGROS JOGGER	\N	2026-09-08 10:12:23.790139+00	5	\N	\N	\N	\N	\N	relance
1947	2	34	2026-09-11	16:00-17:00	1	VN	chambon	\N	2026-09-08 10:12:38.092196+00	97	\N	\N	\N	\N	\N	relance
1948	2	59	2026-09-14	15:00-16:00	1	VN	DE LESCURE / MEGANE	\N	2026-09-08 10:12:38.769812+00	8	\N	\N	\N	\N	\N	relance
1949	2	27	2026-09-12	10:00-11:00	1	VN	MUSELER R5	\N	2026-09-08 10:12:40.999922+00	5	\N	\N	\N	\N	\N	relance
1950	2	34	2026-09-11	17:00-18:00	1	VN	ducand	\N	2026-09-08 10:12:44.0254+00	97	\N	\N	\N	\N	\N	relance
1951	2	34	2026-09-12	09:00-10:00	1	VN	blanc	\N	2026-09-08 10:12:55.699608+00	97	\N	\N	\N	\N	\N	relance
1952	2	34	2026-09-12	11:00-12:00	1	VN	claret	\N	2026-09-08 10:13:01.62949+00	97	\N	\N	\N	\N	\N	relance
1953	2	9	2026-09-10	10:00-11:00	\N	VO	dinquer	\N	2026-09-08 10:13:02.755385+00	6	\N	\N	\N	\N	\N	relance
1954	2	215	2026-09-10	10:00-11:00	\N	VO	VERLAGUET	\N	2026-09-08 10:13:04.737279+00	3	\N	\N	\N	\N	\N	relance
1956	2	34	2026-09-12	14:00-15:00	1	VN	casiot	\N	2026-09-08 10:13:11.686687+00	97	\N	\N	\N	\N	\N	relance
1957	2	34	2026-09-13	10:00-11:00	1	VN	randoing	\N	2026-09-08 10:13:16.474844+00	97	\N	\N	\N	\N	\N	relance
1955	2	59	2026-09-14	17:00-18:00	1	VN	SCHMID / MEGANE	\N	2026-09-08 10:13:07.293562+00	8	2026-09-08 10:13:17.282482+00	8	\N	\N	\N	relance
1958	2	215	2026-09-11	09:00-10:00	\N	VO	ENFANTIN	\N	2026-09-08 10:13:18.222956+00	3	\N	\N	\N	\N	\N	relance
1960	2	9	2026-09-11	11:00-12:00	\N	VO	peinturier	\N	2026-09-08 10:13:23.762943+00	6	\N	\N	\N	\N	\N	relance
1961	2	34	2026-09-13	14:00-15:00	1	VN	delmotte	\N	2026-09-08 10:13:33.460929+00	97	\N	\N	\N	\N	\N	relance
1959	2	34	2026-09-13	13:00-14:00	1	VN	delmotte	\N	2026-09-08 10:13:22.058686+00	97	2026-09-08 10:13:38.035572+00	97	2026-09-08 10:13:38.291+00	97	\N	relance
1962	2	9	2026-09-11	16:00-17:00	\N	VO	rossler	\N	2026-09-08 10:13:41.563186+00	6	\N	\N	\N	\N	\N	relance
1963	2	23	2026-09-10	10:00-11:00	\N	VO	MOULIN	\N	2026-09-08 10:13:59.672587+00	3	\N	\N	\N	\N	\N	relance
1964	2	9	2026-09-13	09:00-10:00	\N	VO	alidra	\N	2026-09-08 10:14:09.355454+00	6	\N	\N	\N	\N	\N	relance
1966	2	9	2026-09-13	10:00-11:00	\N	VO	gerbin	\N	2026-09-08 10:14:18.143787+00	6	\N	\N	\N	\N	\N	relance
1967	2	53	2026-09-13	11:00-12:00	1	VN	PROTO	\N	2026-09-08 10:15:35.707451+00	9	\N	\N	\N	\N	\N	relance
1968	2	33	2026-09-10	09:00-10:00	1	VN	maillaud	\N	2026-09-08 10:15:35.87194+00	97	\N	\N	\N	\N	\N	relance
1969	2	33	2026-09-10	10:00-11:00	1	VN	guglielmini	\N	2026-09-08 10:15:44.139036+00	97	\N	\N	\N	\N	\N	relance
1970	2	33	2026-09-10	11:00-12:00	1	VN	letiers	\N	2026-09-08 10:15:50.730239+00	97	\N	\N	\N	\N	\N	relance
1971	2	54	2026-09-10	14:00-15:00	2	VN	VERGRIETTE / SANDERO	\N	2026-09-08 10:15:51.775837+00	8	\N	\N	\N	\N	\N	relance
1973	2	33	2026-09-10	14:00-15:00	1	VN	mougne	\N	2026-09-08 10:15:58.072109+00	97	\N	\N	\N	\N	\N	relance
1972	2	60	2026-09-12	09:00-10:00	2	VN	FIORI	\N	2026-09-08 10:15:54.209958+00	7	2026-09-08 10:16:02.222317+00	7	\N	\N	\N	relance
1974	2	33	2026-09-10	15:00-16:00	1	VN	balestrino	\N	2026-09-08 10:16:07.053624+00	97	\N	\N	\N	\N	\N	relance
1975	2	54	2026-09-10	10:00-11:00	1	VN	SCOTTI / R5	\N	2026-09-08 10:16:13.827148+00	8	\N	\N	\N	\N	\N	relance
1976	2	33	2026-09-10	18:00-19:00	1	VN	bidaud	\N	2026-09-08 10:16:21.876258+00	97	\N	\N	\N	\N	\N	relance
1977	2	33	2026-09-11	09:00-10:00	1	VN	desforges	\N	2026-09-08 10:16:38.538394+00	97	\N	\N	\N	\N	\N	relance
1978	2	29	2026-09-11	10:00-11:00	3	VN	LAROYE	\N	2026-09-08 10:16:43.652405+00	4	\N	\N	\N	\N	\N	relance
1979	2	33	2026-09-11	10:00-11:00	1	VN	hernandez	\N	2026-09-08 10:16:46.045281+00	97	\N	\N	\N	\N	\N	relance
1980	2	29	2026-09-11	14:00-15:00	3	VN	RICHARD	\N	2026-09-08 10:16:48.587866+00	4	\N	\N	\N	\N	\N	relance
1982	2	33	2026-09-11	15:00-16:00	1	VN	dardier	\N	2026-09-08 10:16:55.538815+00	97	\N	\N	\N	\N	\N	relance
1983	2	882	2026-09-12	16:00-17:00	\N	VO	CHAMBAUD / VO	\N	2026-09-08 10:17:05.803889+00	8	\N	\N	\N	\N	\N	relance
1984	2	33	2026-09-11	14:00-15:00	1	VN	joumel	\N	2026-09-08 10:17:05.862962+00	97	\N	\N	\N	\N	\N	relance
8842	933	11	2026-10-08	08:00-09:00	1	VN	BRUHAT SYMBIOZE REPRISE AUSTRAL	\N	2026-10-06 10:18:01.021568+00	5	\N	\N	\N	\N	46b68c2d-de04-47ad-b11a-3384a6a661b1	relance
1981	2	33	2026-09-11	14:00-15:00	1	VN	joumel	\N	2026-09-08 10:16:50.503195+00	97	2026-09-08 10:17:20.867889+00	97	2026-09-08 10:17:21.098+00	97	\N	relance
1986	2	882	2026-09-11	17:00-18:00	\N	VO	DE RAILLE	\N	2026-09-08 10:17:24.02647+00	8	\N	\N	\N	\N	\N	relance
1987	2	33	2026-09-11	16:00-17:00	1	VN	varennes	\N	2026-09-08 10:17:38.515183+00	97	\N	\N	\N	\N	\N	relance
1988	2	29	2026-09-11	16:00-17:00	3	VN	CHANEAC	\N	2026-09-08 10:17:40.012548+00	4	\N	\N	\N	\N	\N	relance
1989	2	33	2026-09-11	18:00-19:00	1	VN	fradin	\N	2026-09-08 10:17:45.779652+00	97	\N	\N	\N	\N	\N	relance
1990	2	24	2026-09-11	15:00-16:00	\N	VO	FARGE	\N	2026-09-08 10:17:46.408364+00	4	\N	\N	\N	\N	\N	relance
1991	2	29	2026-09-11	11:00-12:00	3	VN	CUBIZOL	\N	2026-09-08 10:18:32.909512+00	4	\N	\N	\N	\N	\N	relance
1992	2	69	2026-09-10	14:00-15:00	\N	VO	ROCHE	\N	2026-09-08 10:18:34.168951+00	7	\N	\N	\N	\N	\N	relance
1993	2	69	2026-09-10	16:00-17:00	\N	VO	MORS	\N	2026-09-08 10:18:44.285158+00	7	\N	\N	\N	\N	\N	relance
1994	2	69	2026-09-11	14:00-15:00	\N	VO	SOLIGNAT	\N	2026-09-08 10:19:13.789031+00	7	\N	\N	\N	\N	\N	relance
1995	2	213	2026-09-11	10:00-11:00	\N	VO	flament	\N	2026-09-08 10:19:33.949087+00	6	\N	\N	\N	\N	\N	relance
1997	2	28	2026-09-11	18:00-19:00	\N	VO	bounhoure	\N	2026-09-08 10:20:13.007402+00	6	\N	\N	\N	\N	\N	relance
1996	2	27	2026-09-13	15:00-16:00	1	VN	SANDONIN AUSTRAL	\N	2026-09-08 10:20:09.014722+00	5	2026-09-08 16:08:59.405328+00	3	2026-09-08 16:08:59.332+00	3	\N	relance
2001	2	68	2026-09-10	08:00-09:00	\N	VO	ABRIOL	\N	2026-09-08 10:20:51.223884+00	9	\N	\N	\N	\N	\N	relance
2019	2	11	2026-09-12	09:00-10:00	1	VN	GENESTOUX CAPTUR	\N	2026-09-08 10:23:27.930311+00	2	\N	\N	\N	\N	\N	relance
2028	2	54	2026-09-11	10:00-11:00	2	VN	CARCAGAGUE / SANDERO	\N	2026-09-08 10:24:53.677238+00	8	\N	\N	\N	\N	\N	relance
2031	2	42	2026-09-10	16:00-17:00	2	VN	DRUETTE SANDERO	\N	2026-09-08 10:25:10.703402+00	1782	\N	\N	\N	\N	\N	relance
2052	2	66	2026-09-13	15:00-16:00	1	VN	FIGUEIREDO / R5	\N	2026-09-08 10:27:32.535073+00	8	\N	\N	\N	\N	\N	relance
2020	2	42	2026-09-10	18:00-19:00	1	VN	CHEDE SANDERO	\N	2026-09-08 10:23:33.45409+00	1782	2026-09-08 10:27:46.82825+00	1782	2026-09-08 10:27:46.636+00	1782	\N	relance
2054	2	10	2026-09-11	16:00-17:00	1	VN	KIRSH	\N	2026-09-08 10:28:09.662457+00	3	\N	\N	\N	\N	\N	relance
1998	2	14	2026-09-10	09:00-10:00	1	VN	SCATOLIN DUSTER	\N	2026-09-08 10:20:26.443687+00	5	2026-09-09 16:23:14.537614+00	92	2026-09-09 16:23:14.161+00	92	\N	relance
8682	933	2	2026-10-09	10:00-11:00	2	VN	rerer	\N	2026-10-06 09:11:03.337382+00	2	2026-10-06 09:12:28.38919+00	2	2026-10-06 09:12:29.003+00	2	db21629a-4a15-4fe2-9fef-4f261319ed7b	relance
8844	933	11	2026-10-08	14:00-15:00	1	VN	DOMAS CAPTUR PR CAPTUR	\N	2026-10-06 10:18:13.936985+00	5	\N	\N	\N	\N	6c7b632b-9e21-4d64-b878-4ae61506d2ab	relance
8857	933	17	2026-10-09	14:00-15:00	1	VN	Gotiaux Twingo	\N	2026-10-06 10:19:19.365594+00	3	\N	\N	\N	\N	1bf68c1b-a87b-407f-99a9-f6d3cbf13e32	relance
8861	933	11	2026-10-12	10:00-11:00	1	VN	DEVES CLIO	\N	2026-10-06 10:19:35.714833+00	5	\N	\N	\N	\N	89fb0c7e-f9eb-4392-bcca-d1c6d78356c7	relance
8872	933	18	2026-10-10	16:00-17:00	1	VN	martin  twingo	\N	2026-10-06 10:21:34.348165+00	4	\N	\N	\N	\N	76824913-f4c1-4e0b-b2b8-53cb60bbdab7	relance
8873	933	40	2026-10-08	11:00-12:00	\N	VO	BOEUF	\N	2026-10-06 10:22:24.772019+00	97	\N	\N	\N	\N	fcfe2fd4-6d3e-4f8f-b651-a0eef75e81a7	relance
8879	933	35	2026-10-08	16:00-17:00	1	VN	LORDERON	\N	2026-10-06 10:23:15.634598+00	97	\N	\N	\N	\N	d50eab09-3330-4ec4-88c0-a34af0d0f228	relance
8883	933	35	2026-10-12	17:00-18:00	1	VN	FOUILLOT	\N	2026-10-06 10:23:41.924071+00	97	\N	\N	\N	\N	4f7a4aa6-0eb3-4255-aa59-ba8c25d79903	relance
8888	933	2	2026-10-09	09:00-10:00	1	VN	Monpied VO	\N	2026-10-06 10:24:42.32711+00	3	\N	\N	\N	\N	4126f9b6-a391-4961-bdb6-f0389e1c259f	relance
8894	933	65	2026-10-08	11:00-12:00	2	VN	ADORNO / SANDER	\N	2026-10-06 10:25:43.256787+00	8	\N	\N	\N	\N	a3cf9c4a-fcbd-494e-bb41-655eaef5739c	relance
8867	933	16	2026-10-09	09:00-10:00	1	VN	Brunelle	\N	2026-10-06 10:20:22.60432+00	3	2026-10-06 10:28:25.11811+00	3	\N	\N	cc0aca90-3419-4087-b7e3-8ca2532d1a44	relance
9040	933	93	2026-10-09	11:00-12:00	2	VN	POMMIER	\N	2026-10-06 11:49:45.350572+00	1780	\N	\N	\N	\N	db0f08c9-f734-49d9-83ab-a03f70b493a5	relance
9131	933	1886	2026-10-09	10:00-11:00	2	VN	JASPART SPRING	\N	2026-10-06 14:26:01.37689+00	1776	\N	\N	\N	\N	34de9fa0-42ce-45a9-9ca1-6393e217cd57	relance
9132	933	1886	2026-10-10	09:00-10:00	2	VN	ESPITALIER DUSTER	\N	2026-10-06 14:26:29.349677+00	1776	\N	\N	\N	\N	9b6631f1-1a59-47ba-87d1-18c8e69abe0a	relance
9141	933	84	2026-10-08	10:00-11:00	\N	VO	TERRIER	\N	2026-10-06 14:28:37.786706+00	1776	\N	\N	\N	\N	64595616-2d71-443b-a6fc-96a22c03ed36	relance
9145	933	85	2026-10-09	10:00-11:00	\N	VO	DELAUR	\N	2026-10-06 14:29:49.937943+00	1776	\N	\N	\N	\N	a38c370c-d371-402b-923c-0dba6fd2b8e8	relance
9134	933	1886	2026-10-10	14:00-15:00	2	VN	KILLING SANDERO	\N	2026-10-06 14:26:48.849384+00	1776	2026-10-06 15:03:11.423859+00	1776	2026-10-06 15:03:11.313+00	1776	b087db01-fc9b-4274-9fcc-b424989619ce	relance
9365	933	10	2026-10-12	17:00-18:00	1	VN	combaret  twingo	\N	2026-10-06 15:55:18.042363+00	4	\N	\N	\N	\N	f02f255c-d505-4d7f-b12c-8626b1f61a53	relance
9450	933	3216	2026-10-09	18:00-19:00	\N	VO	martin  megane	\N	2026-10-06 16:52:25.501725+00	4	\N	\N	\N	\N	e7ed6c50-8541-4780-9622-22b4ff07f477	relance
9515	933	5768	2026-10-08	16:00-17:00	\N	VO	PERRODY	\N	2026-10-07 08:03:38.188571+00	5501	\N	\N	\N	\N	400d2982-8f40-4aa0-873f-08746028b270	relance
9581	933	90	2026-10-12	10:00-11:00	1	VN	bruel r5	\N	2026-10-07 15:09:04.835105+00	1781	\N	\N	\N	\N	5ae562ad-b2d6-484f-a111-88eb5f358e62	relance
9711	933	94	2026-10-10	11:00-12:00	1	VN	VERMEYRE	\N	2026-10-09 07:44:13.625556+00	1780	\N	\N	\N	\N	9c1caf40-f1b3-4a70-9e21-0850a7cf9a40	relance
9775	933	21	2026-10-10	12:00-13:00	\N	VO	duarrt megane	\N	2026-10-11 07:08:11.780273+00	5	2026-10-11 07:08:20.840586+00	5	\N	\N	c0e70163-3235-4a6e-aa5a-8ed57a3b2d03	relance
2000	2	49	2026-09-11	10:00-11:00	1	VN	M BEAUDIAU	\N	2026-09-08 10:20:43.717537+00	1783	\N	\N	\N	\N	\N	relance
2006	2	26	2026-09-10	16:00-17:00	1	VN	CHEMINADE SANDERO	\N	2026-09-08 10:21:27.736296+00	4	\N	\N	\N	\N	\N	relance
2018	2	75	2026-09-10	17:00-18:00	2	VN	STEPHAN	\N	2026-09-08 10:23:26.058484+00	1778	\N	\N	\N	\N	\N	relance
2023	2	11	2026-09-13	09:00-10:00	1	VN	GENESTOUX CAPTUR	\N	2026-09-08 10:23:43.624478+00	2	2026-09-08 10:24:04.474326+00	2	2026-09-08 10:24:05.317+00	2	\N	relance
2065	2	6	2026-09-10	16:00-17:00	1	VN	BOSSIR CLIO 5	\N	2026-09-08 10:29:54.194389+00	5	\N	\N	\N	\N	\N	relance
2071	2	67	2026-09-10	13:00-14:00	1	VN	PORTEFAIS / MEGANE	\N	2026-09-08 10:30:35.111461+00	8	\N	\N	\N	\N	\N	relance
2082	2	10	2026-09-12	08:00-09:00	1	VN	ROGOWCZ	\N	2026-09-08 10:31:38.495999+00	3	\N	\N	\N	\N	\N	relance
2087	2	19	2026-09-10	16:00-17:00	1	VN	MORLET MEGANE	\N	2026-09-08 10:32:12.092986+00	2	\N	\N	\N	\N	\N	relance
2004	2	50	2026-09-10	10:00-11:00	1	VN	M SANTARELLI	\N	2026-09-08 10:21:14.681686+00	1783	2026-09-08 16:11:43.650023+00	1783	\N	\N	\N	relance
1999	2	14	2026-09-10	14:00-15:00	1	VN	DIOUGAN DUSTER	\N	2026-09-08 10:20:39.750373+00	5	2026-09-09 16:23:45.928775+00	92	2026-09-09 16:23:45.6+00	92	\N	relance
8683	933	33	2026-10-08	08:00-09:00	1	VN	test	\N	2026-10-06 09:14:38.186486+00	92	2026-10-06 09:14:45.520018+00	92	2026-10-06 09:14:44.657+00	92	b5759a07-9f3b-4908-96b6-2b2da5d4f186	relance
8686	933	10	2026-10-08	15:00-16:00	1	VN	jean captur	\N	2026-10-06 09:16:34.918962+00	4	\N	\N	\N	\N	f41b3842-b258-4d81-8611-fabfcfab8910	relance
8688	933	10	2026-10-09	09:00-10:00	1	VN	lavergne megane	\N	2026-10-06 09:17:13.319079+00	4	\N	\N	\N	\N	1df320e0-0074-4315-bdb6-fae35c086b44	relance
8690	933	10	2026-10-09	16:00-17:00	1	VN	loubaresse  scenic	\N	2026-10-06 09:17:43.21262+00	4	\N	\N	\N	\N	7c3e08e9-6338-408b-acfb-80ba64a9cb84	relance
8847	933	42	2026-10-08	14:00-15:00	2	VN	HAMON SPRING	\N	2026-10-06 10:18:34.386475+00	1782	\N	\N	\N	\N	220edd8a-e61f-4950-a82d-e7cc5e62dd0c	relance
8859	933	11	2026-10-11	14:00-15:00	1	VN	SIBERE EV	\N	2026-10-06 10:19:26.9339+00	5	\N	\N	\N	\N	3ec5d22a-d564-44b8-aef9-3ea7aae74070	relance
8863	933	42	2026-10-11	16:00-17:00	2	VN	LAIB DUSTER	\N	2026-10-06 10:19:42.917832+00	1782	\N	\N	\N	\N	99e15620-3f8b-46df-8eaf-48a0fb66484b	relance
8874	933	40	2026-10-11	11:00-12:00	\N	VO	BENARD	\N	2026-10-06 10:22:33.196313+00	97	\N	\N	\N	\N	9eacfbbc-8de1-43de-903b-be6c095efdc7	relance
8689	933	10	2026-10-09	14:00-15:00	1	VN	bouchet r5	\N	2026-10-06 09:17:28.446141+00	4	2026-10-06 10:29:57.67824+00	4	2026-10-06 10:29:57.156+00	4	7876a36b-7e1f-4dad-ad6f-9c17aa89295e	relance
9041	933	95	2026-10-08	16:00-17:00	2	VN	BRUNEL	\N	2026-10-06 11:49:59.105912+00	1780	\N	\N	\N	\N	092f1563-d5de-40c2-8702-b4c5047b6fb0	relance
9136	933	1886	2026-10-09	15:00-16:00	2	VN	LONBARD SANDERO	\N	2026-10-06 14:27:08.667694+00	1776	\N	\N	\N	\N	60d65ea4-0350-4423-9bf3-3bc3354d7b19	relance
9137	933	79	2026-10-09	10:00-11:00	2	VN	DUCROS	\N	2026-10-06 14:27:32.925694+00	1776	\N	\N	\N	\N	b0b9b58f-523a-4b94-a593-091c5700f7b6	relance
9139	933	85	2026-10-08	10:00-11:00	\N	VO	FAGES	\N	2026-10-06 14:28:25.016113+00	1776	\N	\N	\N	\N	237df484-2335-48bf-ac67-92a05aca9808	relance
9144	933	83	2026-10-08	10:00-11:00	\N	VO	DELPOUVE	\N	2026-10-06 14:29:38.070406+00	1776	\N	\N	\N	\N	7a6c88b3-f5b2-420f-8ce7-c9ece66d6c42	relance
9366	933	6	2026-10-09	11:00-12:00	1	VN	CHAPUT ( R5)	\N	2026-10-06 15:56:39.858117+00	2	\N	\N	\N	\N	4383e780-d30e-4c24-8798-3f4f6d22fdea	relance
9451	933	16	2026-10-10	10:00-11:00	1	VN	tapissier r5	\N	2026-10-06 16:52:32.868362+00	3	\N	\N	\N	\N	571f079e-002c-4daf-af3b-f5a655c4bf6f	relance
9516	933	5768	2026-10-10	10:00-11:00	\N	VO	LE ROUGET	\N	2026-10-07 08:04:08.177684+00	5501	\N	\N	\N	\N	6acfeee4-afe9-4529-b61e-929b6add6e61	relance
9147	933	81	2026-10-09	08:00-09:00	1	VN	MALADIE	\N	2026-10-06 14:31:56.945578+00	1776	2026-10-07 09:14:40.612568+00	92	2026-10-07 09:14:40.684+00	92	ca9409ee-2aed-4c94-8466-d5d6c88a74bb	relance
9146	933	81	2026-10-08	08:00-09:00	1	VN	MALADIE	\N	2026-10-06 14:31:50.711954+00	1776	2026-10-07 09:14:42.382755+00	92	2026-10-07 09:14:42.468+00	92	27ef43eb-f855-4ac0-9a38-1c402b2d8652	relance
9582	933	84	2026-10-09	15:00-16:00	\N	VO	CAMPARGUE	\N	2026-10-07 15:19:30.502072+00	1776	\N	\N	\N	\N	1a77fe47-3b71-4c76-b816-5f9a9b7159e9	relance
9712	933	92	2026-10-08	18:00-19:00	1	VN	MERDRIGNAC	\N	2026-10-09 07:51:19.404732+00	1780	\N	\N	\N	\N	0ce006a2-d88d-4138-bb96-fc8d1bd32551	relance
9776	933	21	2026-10-10	13:00-14:00	\N	VO	MEDJEBEUR AUSTRAL	\N	2026-10-11 07:09:13.843594+00	5	\N	\N	\N	\N	82178a2d-b144-4c2c-8ff4-7ef021bbb11c	relance
2002	2	1887	2026-09-12	11:00-12:00	\N	VO	M METRO	\N	2026-09-08 10:20:58.019389+00	1783	\N	\N	\N	\N	\N	relance
2034	2	10	2026-09-10	11:00-12:00	1	VN	LATRY	\N	2026-09-08 10:25:38.648378+00	3	\N	\N	\N	\N	\N	relance
2012	2	11	2026-09-10	16:00-17:00	1	VN	CACELA	\N	2026-09-08 10:22:33.00889+00	2	2026-09-08 10:25:40.798538+00	2	\N	\N	\N	relance
2042	2	42	2026-09-11	14:00-15:00	2	VN	GAYET BIGSTER	\N	2026-09-08 10:26:30.685499+00	1782	\N	\N	\N	\N	\N	relance
2050	2	10	2026-09-10	17:00-18:00	1	VN	ARAGON	\N	2026-09-08 10:27:07.383242+00	3	\N	\N	\N	\N	\N	relance
2051	2	42	2026-09-14	15:00-16:00	2	VN	GAGNOL DUSTER	\N	2026-09-08 10:27:13.30696+00	1782	\N	\N	\N	\N	\N	relance
1683	2	42	2026-09-10	14:00-15:00	1	VN	BELIN DUSTER	\N	2026-09-08 09:21:50.970047+00	1782	2026-09-08 10:27:33.754652+00	1782	2026-09-08 10:27:33.55+00	1782	\N	relance
2053	2	10	2026-09-11	14:00-15:00	1	VN	MONCE	\N	2026-09-08 10:27:37.497518+00	3	\N	\N	\N	\N	\N	relance
2055	2	99	2026-09-10	09:00-10:00	2	VN	FERNANDEZ	\N	2026-09-08 10:28:11.662379+00	1778	\N	\N	\N	\N	\N	relance
2056	2	41	2026-09-12	09:00-10:00	\N	VO	dubost	\N	2026-09-08 10:28:52.167466+00	97	\N	\N	\N	\N	\N	relance
2060	2	83	2026-09-10	14:00-15:00	\N	VO	JOGGER GAILLAC	\N	2026-09-08 10:29:31.18286+00	1776	2026-09-08 10:30:04.848939+00	1776	\N	\N	\N	relance
2080	2	67	2026-09-11	15:00-16:00	1	VN	JOSEPH / SCENIC	\N	2026-09-08 10:31:27.578239+00	8	\N	\N	\N	\N	\N	relance
8684	933	53	2026-10-09	11:00-12:00	1	VN	test	\N	2026-10-06 09:14:50.319038+00	787	2026-10-06 09:15:30.328861+00	787	2026-10-06 09:15:30.419+00	787	30501d3b-a1bc-4018-9523-6064de3aa112	relance
8685	933	10	2026-10-08	14:00-15:00	1	VN	moreira r5	\N	2026-10-06 09:16:17.159316+00	4	\N	\N	\N	\N	28e49720-7bb1-4e09-a1d0-a23d43bcda5c	relance
8692	933	10	2026-10-10	09:00-10:00	1	VN	corentin  clio	\N	2026-10-06 09:18:11.492556+00	4	\N	\N	\N	\N	8fd19404-f7eb-4cc7-bfe3-d5b04f6f6be3	relance
8848	933	17	2026-10-08	14:00-15:00	1	VN	Merlot Rafale	\N	2026-10-06 10:18:35.726015+00	3	\N	\N	\N	\N	3dc57588-de8c-4362-84d4-40695071f108	relance
8855	933	11	2026-10-09	18:00-19:00	1	VN	BODIN R5	\N	2026-10-06 10:19:10.885722+00	5	\N	\N	\N	\N	3f9ab085-246a-4f77-a58d-378c700ddee4	relance
8870	933	10	2026-10-11	16:00-17:00	1	VN	lasciouve  captur	\N	2026-10-06 10:20:40.455032+00	4	\N	\N	\N	\N	114d5a0c-f5ad-40c0-bcb8-2005b4594a70	relance
8878	933	35	2026-10-08	14:00-15:00	1	VN	DUPLOMB	\N	2026-10-06 10:23:10.416122+00	97	\N	\N	\N	\N	c1ba888c-76f1-488a-b3d1-1390ba6fdcce	relance
8887	933	67	2026-10-09	18:00-19:00	1	VN	GAUTIER / SCENIC	\N	2026-10-06 10:24:34.968031+00	8	\N	\N	\N	\N	9d21d79b-e24d-4781-8046-56a4692c5a35	relance
8892	933	67	2026-10-12	10:00-11:00	1	VN	RIBEYRE / MEGANE	\N	2026-10-06 10:25:16.631084+00	8	\N	\N	\N	\N	e45a6193-4d52-42c3-a5ec-12291b829c7b	relance
8869	933	16	2026-10-11	11:00-12:00	1	VN	Fraysse	\N	2026-10-06 10:20:33.495979+00	3	2026-10-06 10:28:12.64197+00	3	\N	\N	3a1c42d8-1414-45ac-a4be-5fcfcb2309af	relance
9042	933	95	2026-10-09	09:00-10:00	1	VN	COULON	\N	2026-10-06 11:50:09.353522+00	1780	\N	\N	\N	\N	8e3164f9-32fe-4ac0-9e4a-23fd3ee1d916	relance
9138	933	85	2026-10-08	09:00-10:00	\N	VO	ALONZO	\N	2026-10-06 14:28:21.081412+00	1776	\N	\N	\N	\N	108cdb25-a669-42ed-bd52-13a3d734cd7e	relance
9369	933	6	2026-10-11	09:00-10:00	1	VN	CAREO ( R5)	\N	2026-10-06 15:58:36.816192+00	2	\N	\N	\N	\N	2d85733d-a82f-4724-8eb0-59ce0cb882b1	relance
9370	933	4	2026-10-10	11:00-12:00	2	VN	NONY SANDERO	\N	2026-10-06 15:59:45.03041+00	5	\N	\N	\N	\N	59f7d441-6571-43bf-9fd4-1f6bb4c13124	relance
9372	933	4	2026-10-08	17:00-18:00	1	VN	LARGERON RENAULT	\N	2026-10-06 16:00:13.874505+00	5	\N	\N	\N	\N	bef73e0e-5145-42f0-b8fc-38cc00f9f7e9	relance
9452	933	92	2026-10-09	14:00-15:00	1	VN	Gaston	\N	2026-10-06 16:53:32.196258+00	1780	\N	\N	\N	\N	d8b4285b-d003-4609-b2b0-9bf5c28767f0	relance
9517	933	5768	2026-10-10	11:00-12:00	\N	VO	DENA	\N	2026-10-07 08:04:10.271003+00	5501	\N	\N	\N	\N	46733a40-031c-428e-8695-508e5a916f79	relance
9453	933	92	2026-10-09	16:00-17:00	2	VN	BOYER	\N	2026-10-06 16:54:04.661093+00	1780	2026-10-07 13:25:26.52728+00	1780	\N	\N	1f2e4a62-82e7-490f-8459-733d026f2e25	relance
9583	933	83	2026-10-09	14:00-15:00	\N	VO	PONCE	\N	2026-10-07 15:19:47.46861+00	1776	\N	\N	\N	\N	fdfb37de-f02e-48c2-95b9-770fda943fda	relance
9713	933	92	2026-10-09	08:00-09:00	1	VN	VENDROUX	\N	2026-10-09 07:55:13.715357+00	1780	\N	\N	\N	\N	797d7107-ca6b-481e-989f-a55d1957c82b	relance
9777	933	15	2026-10-10	16:00-17:00	1	VN	NORMAND	\N	2026-10-11 07:13:38.22136+00	5	2026-10-11 07:13:40.654557+00	5	2026-10-11 07:13:41.162+00	5	728c8144-9c68-4aad-a077-5bcecd7a958a	relance
2005	2	26	2026-09-11	09:00-10:00	1	VN	CONTET JOGGER	\N	2026-09-08 10:21:17.240127+00	4	\N	\N	\N	\N	\N	relance
2007	2	5	2026-09-11	09:00-10:00	1	VN	HANIEZ CAPTUR	\N	2026-09-08 10:21:46.810508+00	5	2026-09-08 10:21:57.946453+00	5	\N	\N	\N	relance
8687	933	10	2026-10-08	17:00-18:00	1	VN	arthur r5	\N	2026-10-06 09:16:50.967254+00	4	\N	\N	\N	\N	61af6965-6fd2-43c8-b1c4-e43f1c30d9e1	relance
2010	2	5	2026-09-11	14:00-15:00	1	VN	GOIGGOU JOGGER	\N	2026-09-08 10:22:12.662533+00	5	2026-09-08 10:22:19.385507+00	5	\N	\N	\N	relance
2016	2	75	2026-09-10	15:00-16:00	2	VN	MASSIER	\N	2026-09-08 10:23:08.969846+00	1778	\N	\N	\N	\N	\N	relance
2021	2	2	2026-09-10	09:00-10:00	1	VN	MAGAUD TWINGO	\N	2026-09-08 10:23:35.126025+00	3	\N	\N	\N	\N	\N	relance
2009	2	11	2026-09-10	09:00-10:00	1	VN	LEMOINE CLIO6	\N	2026-09-08 10:22:04.871415+00	2	2026-09-08 10:25:33.264405+00	2	\N	\N	\N	relance
2013	2	11	2026-09-10	17:00-18:00	1	VN	PRIVAT CLIO6	\N	2026-09-08 10:22:48.385667+00	2	2026-09-08 10:25:51.037699+00	2	\N	\N	\N	relance
2041	2	66	2026-09-11	09:00-10:00	1	VN	DUFRECHOU / CLIO	\N	2026-09-08 10:26:25.832399+00	8	\N	\N	\N	\N	\N	relance
1682	2	42	2026-09-10	10:00-11:00	1	VN	DESCRIAUX DUSTER	\N	2026-09-08 09:21:41.849278+00	1782	2026-09-08 10:27:25.859096+00	1782	2026-09-08 10:27:25.255+00	1782	\N	relance
2075	2	67	2026-09-10	14:00-15:00	2	VN	MONTAGNON / DUSTER	\N	2026-09-08 10:30:58.220819+00	8	\N	\N	\N	\N	\N	relance
2079	2	87	2026-09-11	10:00-11:00	2	VN	PORTES - DACIA	\N	2026-09-08 10:31:25.679898+00	1777	\N	\N	\N	\N	\N	relance
2027	2	10	2026-09-10	09:00-10:00	1	VN	PLANTELIGNE	\N	2026-09-08 10:24:52.361408+00	3	2026-09-08 15:18:10.305396+00	3	2026-09-08 15:18:10.133+00	3	\N	relance
2003	2	14	2026-09-10	16:00-17:00	1	VN	BESSERVE TWINGO	\N	2026-09-08 10:21:01.757645+00	5	2026-09-09 16:23:55.31433+00	92	2026-09-09 16:23:54.984+00	92	\N	relance
8850	933	11	2026-10-09	09:00-10:00	1	VN	ANTOINE TWINGO	\N	2026-10-06 10:18:48.297442+00	5	\N	\N	\N	\N	08e0e0f7-d6a8-4c7d-a91e-2373ee7d5d3f	relance
8853	933	17	2026-10-09	10:00-11:00	1	VN	Bonaldi Twingo	\N	2026-10-06 10:19:04.278232+00	3	\N	\N	\N	\N	f021cbcf-1c95-41c5-899d-d60775cb9a03	relance
8862	933	17	2026-10-09	16:00-17:00	1	VN	Mignot R4	\N	2026-10-06 10:19:35.784683+00	3	\N	\N	\N	\N	7b393927-853d-4599-8f99-b6848284ec64	relance
8868	933	16	2026-10-11	10:00-11:00	1	VN	Mallet	\N	2026-10-06 10:20:28.404617+00	3	2026-10-06 10:28:19.04233+00	3	\N	\N	bed5b28e-974b-4ca3-8644-765c0a3e959d	relance
9043	933	95	2026-10-09	14:00-15:00	1	VN	DEJOU	\N	2026-10-06 11:50:16.823222+00	1780	\N	\N	\N	\N	851e6536-e274-473d-aa28-80b862fc7a81	relance
9142	933	83	2026-10-10	10:00-11:00	\N	VO	RAYNAL	\N	2026-10-06 14:28:48.454029+00	1776	\N	\N	\N	\N	e75ce586-32c8-4a49-9155-f72adafec1ec	relance
9371	933	4	2026-10-11	13:00-14:00	1	VN	COSSU TWINGO	\N	2026-10-06 16:00:05.801651+00	5	\N	\N	\N	\N	23783cf3-26ab-4845-9a0f-75aa49fea9be	relance
9454	933	26	2026-10-08	16:00-17:00	1	VN	Simmonot Captur	\N	2026-10-06 16:57:42.82083+00	3	\N	\N	\N	\N	070db82f-8554-4fdf-afb1-9bee991bf10c	relance
9518	933	5768	2026-10-08	09:00-10:00	\N	VO	COUDERC	\N	2026-10-07 08:04:23.90848+00	5501	\N	\N	\N	\N	3dca272d-7df4-4b55-80b4-34f4ef426137	relance
9584	933	83	2026-10-10	14:00-15:00	\N	VO	BONNEFOUS	\N	2026-10-07 15:19:50.796959+00	1776	\N	\N	\N	\N	4c97cfa5-52c8-406a-a442-427abe727032	relance
9714	933	93	2026-10-08	15:00-16:00	1	VN	VERGNE	\N	2026-10-09 07:56:20.406414+00	1780	\N	\N	\N	\N	f38a8e20-404d-4676-ad8e-1337fd53eb80	relance
9778	933	15	2026-10-10	16:00-17:00	2	VN	NORMAND	\N	2026-10-11 07:13:47.635502+00	5	\N	\N	\N	\N	074eef1e-ef28-4c33-9b24-b5e212f8e134	relance
2008	2	11	2026-09-10	08:00-09:00	1	VN	THEROND R5	\N	2026-09-08 10:21:56.761387+00	2	2026-09-08 10:25:17.366815+00	2	\N	\N	\N	relance
2038	2	42	2026-09-11	09:00-10:00	2	VN	THOMAS BIGSTER	\N	2026-09-08 10:26:18.37207+00	1782	\N	\N	\N	\N	\N	relance
2040	2	160	2026-09-12	10:00-11:00	1	VN	HERBST CAPTUR	\N	2026-09-08 10:26:24.382088+00	2	\N	\N	\N	\N	\N	relance
2043	2	42	2026-09-11	16:00-17:00	2	VN	PICCAND BIGSTER	\N	2026-09-08 10:26:35.920658+00	1782	\N	\N	\N	\N	\N	relance
2049	2	42	2026-09-14	14:00-15:00	2	VN	MITAULT SPRING	\N	2026-09-08 10:27:04.178898+00	1782	\N	\N	\N	\N	\N	relance
2024	2	42	2026-09-11	09:00-10:00	1	VN	THOMAS BIGSTER	\N	2026-09-08 10:24:05.767771+00	1782	2026-09-08 10:27:51.575799+00	1782	2026-09-08 10:27:51.392+00	1782	\N	relance
2058	2	99	2026-09-11	16:00-17:00	1	VN	RAYSSAC	\N	2026-09-08 10:29:15.875387+00	1778	\N	\N	\N	\N	\N	relance
2070	2	36	2026-09-11	15:00-16:00	1	VN	auroy	\N	2026-09-08 10:30:22.513475+00	97	\N	\N	\N	\N	\N	relance
2077	2	36	2026-09-13	10:00-11:00	1	VN	pothonnier	\N	2026-09-08 10:31:12.911388+00	97	\N	\N	\N	\N	\N	relance
2078	2	99	2026-09-14	10:00-11:00	2	VN	AMALRIC	\N	2026-09-08 10:31:17.20278+00	1778	\N	\N	\N	\N	\N	relance
8691	933	10	2026-10-09	18:00-19:00	1	VN	savareux  rafale	\N	2026-10-06 09:17:56.376614+00	4	\N	\N	\N	\N	655bb9a7-ef14-494d-ba36-43497a0177e3	relance
8693	933	10	2026-10-10	10:00-11:00	1	VN	dubuc  twingo	\N	2026-10-06 09:18:24.10371+00	4	\N	\N	\N	\N	af266750-8c66-46e5-9c46-3abaa65e08ab	relance
8694	933	10	2026-10-10	16:00-17:00	1	VN	dubois  megane	\N	2026-10-06 09:18:35.423468+00	4	\N	\N	\N	\N	f01ec03f-9173-4801-b83b-37f15f63eb15	relance
8851	933	42	2026-10-10	10:00-11:00	2	VN	PLE DUSTER	\N	2026-10-06 10:18:56.480805+00	1782	\N	\N	\N	\N	23cb55b9-85de-419c-9e80-a50ffa61fee4	relance
8860	933	42	2026-10-11	10:00-11:00	2	VN	GOURAND DUSTER	\N	2026-10-06 10:19:28.763573+00	1782	\N	\N	\N	\N	efcbff9c-4821-418b-aeb9-9bbc49cb7e90	relance
8864	933	11	2026-10-12	14:00-15:00	1	VN	CHASTAZIN	\N	2026-10-06 10:19:46.958991+00	5	2026-10-06 10:19:51.743645+00	5	2026-10-06 10:19:51.574+00	5	91010458-c051-4ad9-a971-46ac5b563832	relance
8866	933	16	2026-10-08	10:00-11:00	1	VN	Martins	\N	2026-10-06 10:20:13.271378+00	3	\N	\N	\N	\N	82f7468b-4ebf-4d57-8533-cb63e490c062	relance
8875	933	2	2026-10-08	10:00-11:00	1	VN	Boukami R5	\N	2026-10-06 10:22:39.593978+00	3	\N	\N	\N	\N	72739d36-4520-41b0-997b-4b9d860f0e8e	relance
8881	933	35	2026-10-11	11:00-12:00	1	VN	POULAIN	\N	2026-10-06 10:23:32.951613+00	97	\N	\N	\N	\N	e6aef873-a891-4199-acf3-a3d93d8d7f5d	relance
8882	933	2	2026-10-08	16:00-17:00	1	VN	Roche Austral	\N	2026-10-06 10:23:38.32295+00	3	2026-10-06 10:24:31.878265+00	3	\N	\N	7b449ea6-39f7-454d-96d4-60460989e9f2	relance
9044	933	95	2026-10-10	10:00-11:00	1	VN	HOURTOULE	\N	2026-10-06 11:50:29.266065+00	1780	\N	\N	\N	\N	1134a53f-3e36-40ee-a8d2-71cfcf2ff9a5	relance
9148	933	89	2026-10-08	14:00-15:00	1	VN	vers megane	\N	2026-10-06 14:33:23.683081+00	1781	\N	\N	\N	\N	32d7884d-568c-46ac-87e1-dd4960648d0e	relance
9157	933	80	2026-10-08	10:00-11:00	1	VN	CLAMENS TW3	\N	2026-10-06 14:37:14.42223+00	1776	\N	\N	\N	\N	c8b01bfb-7ad6-4ad6-ad82-2ee6400283ee	relance
9160	933	80	2026-10-08	17:00-18:00	1	VN	MURATET MEGANE ELEC	\N	2026-10-06 14:37:35.448174+00	1776	\N	\N	\N	\N	eb26b301-61b2-4331-926a-9f0a78fc6e15	relance
9167	933	80	2026-10-08	11:00-12:00	1	VN	MARTIN CLIO	\N	2026-10-06 14:38:46.660655+00	1776	\N	\N	\N	\N	fe379f5c-b06d-4394-8de3-43762c84d6c5	relance
9373	933	4	2026-10-09	13:00-14:00	1	VN	ANTOINE TWINGO	\N	2026-10-06 16:00:36.66208+00	5	\N	\N	\N	\N	0daa09d8-ad80-42cb-9e49-32f6b7bbbf85	relance
9376	933	15	2026-10-09	16:00-17:00	1	VN	GAY CAPTUR	\N	2026-10-06 16:01:27.490012+00	5	2026-10-06 16:01:52.854665+00	5	2026-10-06 16:01:52.613+00	5	b9a2b20d-013f-4d5b-9971-32da6d9b3001	relance
9455	933	16	2026-10-10	14:00-15:00	1	VN	Leonardi r5	\N	2026-10-06 16:57:59.783773+00	3	\N	\N	\N	\N	886b6bf1-aacf-4e2d-9bf4-be207f187243	relance
9519	933	89	2026-10-08	17:00-18:00	2	VN	petit duster	\N	2026-10-07 08:19:03.639775+00	1781	\N	\N	\N	\N	493b975d-5d4d-477d-9c42-ee4a3e01255f	relance
9585	933	82	2026-10-10	15:00-16:00	1	VN	ANGLES R4	\N	2026-10-07 15:21:27.618155+00	1776	\N	\N	\N	\N	8b59e35b-af97-4e23-8241-f779943c29c0	relance
9715	933	92	2026-10-08	17:00-18:00	2	VN	CHAILLOU	\N	2026-10-09 07:59:37.011557+00	1780	\N	\N	\N	\N	afa47fe2-4af0-4a72-b936-ef929f8fa85c	relance
9779	933	29	2026-10-10	16:00-17:00	3	VN	BERAUD	\N	2026-10-11 09:42:11.686574+00	5502	\N	\N	\N	\N	974566c3-8732-4071-9e2c-a43f694cf505	relance
2011	2	5	2026-09-11	16:00-17:00	1	VN	DOGAS TWINGO	\N	2026-09-08 10:22:27.695996+00	5	\N	\N	\N	\N	\N	relance
2030	2	42	2026-09-10	14:00-15:00	2	VN	BELIN DUSTER	\N	2026-09-08 10:25:03.597543+00	1782	\N	\N	\N	\N	\N	relance
2046	2	66	2026-09-12	11:00-12:00	1	VN	ASTIER / CLIO	\N	2026-09-08 10:26:48.631533+00	8	\N	\N	\N	\N	\N	relance
2025	2	42	2026-09-14	15:00-16:00	1	VN	GAGNOL DUSTER	\N	2026-09-08 10:24:27.547138+00	1782	2026-09-08 10:28:37.700246+00	1782	2026-09-08 10:28:37.513+00	1782	\N	relance
2059	2	36	2026-09-10	10:00-11:00	1	VN	guilloud	\N	2026-09-08 10:29:18.589887+00	97	\N	\N	\N	\N	\N	relance
2057	2	6	2026-09-10	14:00-15:00	1	VN	TINEL SYMBIOZ	\N	2026-09-08 10:29:13.388736+00	5	2026-09-08 10:29:22.353389+00	5	\N	\N	\N	relance
2067	2	67	2026-09-10	10:00-11:00	1	VN	THOMAIN / R5	\N	2026-09-08 10:30:00.299538+00	8	\N	\N	\N	\N	\N	relance
2069	2	99	2026-09-12	16:00-17:00	1	VN	DUBUY	\N	2026-09-08 10:30:20.5829+00	1778	\N	\N	\N	\N	\N	relance
8695	933	10	2026-10-11	09:00-10:00	1	VN	bonnemoy  twingo	\N	2026-10-06 09:18:59.505047+00	4	\N	\N	\N	\N	c966dbe3-9b61-4d99-9e90-5928b3d0fe9d	relance
8696	933	10	2026-10-11	11:00-12:00	1	VN	azzaro megane	\N	2026-10-06 09:19:14.681961+00	4	\N	\N	\N	\N	afc707ae-08f4-4c75-81eb-5fe8c4a9a0d0	relance
8854	933	42	2026-10-10	14:00-15:00	2	VN	CHAPAZE SPRING	\N	2026-10-06 10:19:08.727503+00	1782	\N	\N	\N	\N	8435f9e9-09b8-4781-9720-655507e4675b	relance
8858	933	17	2026-10-09	17:00-18:00	1	VN	Bonnet Scenic	\N	2026-10-06 10:19:25.039995+00	3	2026-10-06 10:19:54.656573+00	3	\N	\N	19881cfc-32db-477a-b81d-11332ba65926	relance
8865	933	11	2026-10-12	14:00-15:00	2	VN	CHASTAING DUSTER	\N	2026-10-06 10:19:59.473201+00	5	\N	\N	\N	\N	f01b9052-b656-4f6b-a027-54f027191e8d	relance
9045	933	94	2026-10-09	14:00-15:00	1	VN	KARINTHI	\N	2026-10-06 12:07:23.77743+00	1780	\N	\N	\N	\N	c1b514c8-39d2-4ca2-a7bb-354612b4c6ff	relance
9149	933	89	2026-10-08	09:00-10:00	2	VN	poussergues sandero	\N	2026-10-06 14:34:05.795608+00	1781	\N	\N	\N	\N	1d91d6b9-8071-4f40-8255-bec0042b9fc2	relance
9150	933	89	2026-10-08	11:00-12:00	2	VN	lacazes sandero	\N	2026-10-06 14:34:17.31656+00	1781	\N	\N	\N	\N	a6d6b946-0e5c-4a6a-823b-78e8e3bf6907	relance
9163	933	80	2026-10-10	10:00-11:00	1	VN	SAULIERES R5	\N	2026-10-06 14:38:00.810564+00	1776	\N	\N	\N	\N	44ded885-43fe-4c16-a378-61c94ed0ca96	relance
9165	933	80	2026-10-11	10:00-11:00	1	VN	ASSIE MEGANE ELC	\N	2026-10-06 14:38:25.781684+00	1776	\N	\N	\N	\N	4056ef44-a67b-4a4f-a016-8a46ea9fe0cb	relance
9170	933	80	2026-10-09	18:00-19:00	1	VN	AUGUY MEGANE ELEC VS MG	\N	2026-10-06 14:39:27.114102+00	1776	\N	\N	\N	\N	b60447fd-e90c-4393-ba71-2dc1012cfdc5	relance
9374	933	15	2026-10-08	11:00-12:00	2	VN	ALLARD BIGSTER	\N	2026-10-06 16:00:48.89891+00	5	\N	\N	\N	\N	c07a1ca5-4940-49e9-88d0-a813df87fd7b	relance
9379	933	11	2026-10-09	16:00-17:00	1	VN	GAY CAPTUR	\N	2026-10-06 16:02:40.75045+00	5	\N	\N	\N	\N	4aaaebe3-9751-4658-8330-9455bcecbfe1	relance
9456	933	160	2026-10-12	10:00-11:00	1	VN	Seidel 2 SANDERO (dijoux)	\N	2026-10-06 16:58:53.99413+00	3	\N	\N	\N	\N	afd7514f-107e-4402-b558-1c77d50d06a6	relance
9520	933	89	2026-10-12	17:00-18:00	1	VN	bezon r5	\N	2026-10-07 08:19:39.310967+00	1781	2026-10-07 14:20:01.41549+00	1781	\N	\N	5d99dbd1-655d-48f6-8d9b-7bda9da173c9	relance
9586	933	94	2026-10-08	16:00-17:00	1	VN	VERMEYRE	\N	2026-10-07 15:49:43.556655+00	1780	2026-10-09 07:44:19.673033+00	1780	2026-10-09 07:44:19.386+00	1780	7cc6a4e9-2901-4109-9098-22d538947f96	relance
9716	933	59	2026-10-09	12:00-13:00	1	VN	REY DUSTER	\N	2026-10-09 08:33:59.808226+00	7	2026-10-09 14:03:36.752254+00	7	2026-10-09 14:03:36.793+00	7	f48f7054-6480-40d0-9bd9-c8305fc03e79	relance
9152	933	60	2026-10-10	11:00-12:00	2	VN	GUIGON AUSTRAL /SCENIC	\N	2026-10-06 14:34:30.903903+00	7	2026-10-10 09:27:33.412543+00	7	2026-10-10 09:27:33.804+00	7	862dea59-53e0-4461-a5a3-7fc181854bf0	relance
9780	933	5770	2026-10-11	14:00-15:00	3	VN	GRANGEON	\N	2026-10-11 09:43:10.579896+00	5502	\N	\N	\N	\N	f2afa2e6-70b0-4445-a542-5088b4d2e2cf	relance
2022	2	75	2026-09-11	10:00-11:00	2	VN	GIRAUD	\N	2026-09-08 10:23:37.374447+00	1778	\N	\N	\N	\N	\N	relance
2014	2	11	2026-09-13	09:00-10:00	1	VN	GENESTOUX CAPTUR	\N	2026-09-08 10:23:00.085575+00	2	2026-09-08 10:23:40.241403+00	2	2026-09-08 10:23:38.598+00	2	\N	relance
2032	2	70	2026-09-12	10:00-11:00	\N	VO	TENOT / CLIO	\N	2026-09-08 10:25:31.43122+00	8	\N	\N	\N	\N	\N	relance
2033	2	42	2026-09-10	18:00-19:00	2	VN	CHEDE SANDERO	\N	2026-09-08 10:25:37.640404+00	1782	\N	\N	\N	\N	\N	relance
2036	2	66	2026-09-10	14:00-15:00	1	VN	GUSTA	\N	2026-09-08 10:26:09.205284+00	8	\N	\N	\N	\N	\N	relance
2037	2	10	2026-09-11	10:00-11:00	1	VN	MARGOUM	\N	2026-09-08 10:26:16.980264+00	3	2026-09-08 10:26:25.730756+00	3	\N	\N	\N	relance
2047	2	42	2026-09-13	11:00-12:00	2	VN	MARIE DUSTER	\N	2026-09-08 10:26:52.03752+00	1782	\N	\N	\N	\N	\N	relance
1985	2	10	2026-09-13	17:00-18:00	1	VN	BEAUFILS CAPTUR	\N	2026-09-08 10:17:11.661767+00	3	2026-09-08 10:29:27.871403+00	3	2026-09-08 10:29:29.784+00	3	\N	relance
2072	2	36	2026-09-11	16:00-17:00	1	VN	kroudo	\N	2026-09-08 10:30:42.570634+00	97	\N	\N	\N	\N	\N	relance
2074	2	99	2026-09-13	10:00-11:00	1	VN	FERENZEC	\N	2026-09-08 10:30:52.678555+00	1778	\N	\N	\N	\N	\N	relance
2061	2	6	2026-09-10	15:00-16:00	1	VN	DUTUEL SANDERO	\N	2026-09-08 10:29:34.477275+00	5	2026-09-09 16:24:38.127549+00	92	2026-09-09 16:24:37.764+00	92	\N	relance
8697	933	10	2026-10-09	11:00-12:00	1	VN	mussard  scenic	\N	2026-10-06 09:24:51.484029+00	4	\N	\N	\N	\N	ee36dace-0129-4004-94a7-635a81a42e08	relance
8876	933	35	2026-10-08	10:00-11:00	1	VN	MUS	\N	2026-10-06 10:23:03.535131+00	97	\N	\N	\N	\N	e507a970-a575-4b89-a363-3a71cd6e95c6	relance
9046	933	94	2026-10-12	11:00-12:00	1	VN	BONNET	\N	2026-10-06 12:08:09.047904+00	1780	\N	\N	\N	\N	5b4cbfc0-adb2-41d6-9025-3e8e91f77555	relance
9151	933	89	2026-10-08	16:00-17:00	2	VN	defaisse spring	\N	2026-10-06 14:34:28.142897+00	1781	\N	\N	\N	\N	72a9bf20-b31a-43b4-82eb-2321095f0433	relance
9155	933	65	2026-10-09	15:00-16:00	1	VN	jouan / ?	\N	2026-10-06 14:35:38.813796+00	8	\N	\N	\N	\N	dc53a138-fe90-4920-9dbf-6ef89c290bd5	relance
9158	933	80	2026-10-08	14:00-15:00	1	VN	CARLIER KANGOO VAN	\N	2026-10-06 14:37:24.817084+00	1776	\N	\N	\N	\N	08e7b6d1-d860-4d10-801c-cac7e831e6d1	relance
9162	933	80	2026-10-09	09:00-10:00	1	VN	GOUDY REN LS	\N	2026-10-06 14:37:48.68675+00	1776	\N	\N	\N	\N	6943093d-721d-4a3b-9649-7aa56f9a69b3	relance
9164	933	80	2026-10-10	16:00-17:00	1	VN	MARTY R5 TW3	\N	2026-10-06 14:38:10.229051+00	1776	\N	\N	\N	\N	4a035367-1213-4f59-b014-b97e40c99e67	relance
9168	933	80	2026-10-08	15:00-16:00	1	VN	GINESTET R4 / MEGANE	\N	2026-10-06 14:38:59.074386+00	1776	\N	\N	\N	\N	3cabfdde-e2e6-44ea-960e-6600c1e09594	relance
9375	933	15	2026-10-09	14:00-15:00	2	VN	TROUVER SANDERO	\N	2026-10-06 16:01:10.090047+00	5	2026-10-06 16:02:05.138796+00	5	2026-10-06 16:02:04.922+00	5	601fd287-01e8-434b-a72d-f32226451406	relance
9377	933	11	2026-10-09	16:00-17:00	1	VN	TROUVER SANDERO	\N	2026-10-06 16:02:19.870154+00	5	2026-10-06 16:02:28.428447+00	5	2026-10-06 16:02:28.181+00	5	d5f2cb95-3901-4f22-8656-ed3cdefd6273	relance
9457	933	17	2026-10-08	10:00-11:00	1	VN	Brun R5	\N	2026-10-06 16:59:29.538449+00	3	\N	\N	\N	\N	e0f20245-2513-448f-9984-ff15328f42be	relance
9521	933	90	2026-10-09	10:00-11:00	1	VN	cloarec twingo	\N	2026-10-07 08:24:49.031521+00	1781	\N	\N	\N	\N	5fe75339-4490-4fe7-be76-381f47aaf35e	relance
9587	933	76	2026-10-08	09:00-10:00	1	VN	HILLS	\N	2026-10-07 15:52:23.339063+00	1778	\N	\N	\N	\N	1273b098-61e5-4927-a20f-bac639559c79	relance
9588	933	76	2026-10-08	15:00-16:00	1	VN	ZIEGLER	\N	2026-10-07 15:52:38.699878+00	1778	\N	\N	\N	\N	8e727167-b2ca-4199-8ef0-600755380384	relance
9592	933	76	2026-10-10	11:00-12:00	1	VN	COSTES	\N	2026-10-07 15:53:31.065005+00	1778	\N	\N	\N	\N	1ba8ae56-2bd7-42b0-a545-2894ec726156	relance
9717	933	65	2026-10-08	08:00-09:00	2	VN	RAYNAL	\N	2026-10-09 08:43:40.327879+00	9	\N	\N	\N	\N	70c4225c-4ca2-438b-9b29-cc49b50e2746	showroom
9781	933	5770	2026-10-11	16:00-17:00	3	VN	MEIRELES	\N	2026-10-11 09:44:55.113813+00	5502	\N	\N	\N	\N	7139f3ca-e355-4f02-854c-66d8b48b4b0b	relance
2015	2	75	2026-09-10	14:00-15:00	2	VN	BENIMELIS	\N	2026-09-08 10:23:02.160797+00	1778	\N	\N	\N	\N	\N	relance
2017	2	11	2026-09-13	15:00-16:00	1	VN	DUMAS AUSTRAL	\N	2026-09-08 10:23:17.867055+00	2	2026-09-08 10:24:12.118015+00	2	2026-09-08 10:24:12.904+00	2	\N	relance
2026	2	11	2026-09-12	15:00-16:00	1	VN	DUMAS  AUSTRAL	\N	2026-09-08 10:24:33.941161+00	2	\N	\N	\N	\N	\N	relance
2035	2	10	2026-09-11	09:00-10:00	1	VN	TEISSEDRE	\N	2026-09-08 10:25:58.933382+00	3	\N	\N	\N	\N	\N	relance
2044	2	66	2026-09-12	09:00-10:00	1	VN	NIS / SCENIC R5	\N	2026-09-08 10:26:41.439833+00	8	\N	\N	\N	\N	\N	relance
2083	2	10	2026-09-12	16:00-17:00	1	VN	COUFIGNAL	\N	2026-09-08 10:31:46.276801+00	3	\N	\N	\N	\N	\N	relance
2086	2	99	2026-09-13	14:00-15:00	1	VN	MUPHATO	\N	2026-09-08 10:31:59.246228+00	1778	\N	\N	\N	\N	\N	relance
2089	2	19	2026-09-10	18:00-19:00	1	VN	AUBERT CLIO6	\N	2026-09-08 10:32:34.383387+00	2	\N	\N	\N	\N	\N	relance
2090	2	2	2026-09-13	16:00-17:00	1	VN	MONIER	\N	2026-09-08 10:32:49.337799+00	3	\N	\N	\N	\N	\N	relance
8698	933	6	2026-10-08	08:00-09:00	1	VN	ROBERT  ( MEGANE ETECH)	\N	2026-10-06 09:30:12.143402+00	2	\N	\N	\N	\N	69f5df87-778d-466e-ae97-2872b3acf0f8	relance
8880	933	35	2026-10-09	10:00-11:00	1	VN	BERNARDIN	\N	2026-10-06 10:23:26.906522+00	97	\N	\N	\N	\N	9f6c687c-d3cb-4e22-a6cb-ae80665f0af5	relance
9047	933	92	2026-10-08	08:00-09:00	1	VN	MEYNIAL	\N	2026-10-06 12:14:31.65971+00	1780	\N	\N	\N	\N	90b7261e-c41d-4943-9440-8b3b72ce4e38	relance
9051	933	92	2026-10-08	15:00-16:00	1	VN	DUQUESNE	\N	2026-10-06 12:15:08.188132+00	1780	\N	\N	\N	\N	16c21443-5f1b-495f-8030-2f4cd2119c4b	relance
9055	933	92	2026-10-09	10:00-11:00	1	VN	CALMELS	\N	2026-10-06 12:15:41.434563+00	1780	\N	\N	\N	\N	204a279f-df2e-4a93-9f4e-7fdde726dd65	relance
9057	933	92	2026-10-10	10:00-11:00	1	VN	REY	\N	2026-10-06 12:16:06.805602+00	1780	\N	\N	\N	\N	e6f19ca1-6d6d-47ff-a279-34a4e981b9f8	relance
9153	933	89	2026-10-09	16:00-17:00	2	VN	savreux sandero	\N	2026-10-06 14:34:41.205396+00	1781	\N	\N	\N	\N	c88e647a-830f-413f-92ca-dd73a33d105b	relance
9159	933	57	2026-10-09	16:00-17:00	\N	VO	BALLA	\N	2026-10-06 14:37:29.823407+00	9	\N	\N	\N	\N	b4ab8016-b849-49cd-9bb4-f6d8ee3f30e0	relance
9169	933	80	2026-10-08	18:00-19:00	1	VN	GALTIER R5	\N	2026-10-06 14:39:15.829456+00	1776	\N	\N	\N	\N	1cc50888-897a-47dd-91fc-cd86d588be44	relance
9378	933	11	2026-10-09	14:00-15:00	2	VN	TROUVER SANDERO	\N	2026-10-06 16:02:34.965842+00	5	\N	\N	\N	\N	8ddd3174-878c-499f-9dc4-b56fcff38220	relance
9458	933	11	2026-10-11	16:00-17:00	1	VN	LASCIOVU FIN DE LOA CAPTUR	\N	2026-10-06 16:59:35.703038+00	5	\N	\N	\N	\N	a21a9db7-bded-44ac-b6ed-24db183d0925	relance
9522	933	97	2026-10-08	16:00-17:00	1	VN	miquel	\N	2026-10-07 08:37:41.374034+00	1775	\N	\N	\N	\N	ed183131-676f-475f-adb0-8ff588160663	relance
9589	933	76	2026-10-09	10:00-11:00	1	VN	MOSSELLO	\N	2026-10-07 15:52:56.047299+00	1778	\N	\N	\N	\N	67a32d74-a02e-4f1c-a306-327a719dfe9a	relance
9062	933	92	2026-10-09	18:00-19:00	1	VN	MERDRIGNAC	\N	2026-10-06 12:16:41.635398+00	1780	2026-10-09 07:51:23.605979+00	1780	2026-10-09 07:51:23.399+00	1780	61f5f984-c1e9-40e5-a874-61b1387b3be7	relance
9053	933	92	2026-10-08	17:00-18:00	2	VN	VENROUX	\N	2026-10-06 12:15:28.043978+00	1780	2026-10-09 07:55:17.054557+00	1780	2026-10-09 07:55:16.907+00	1780	5f23d895-3a1e-48c9-aea5-68b4371440ef	relance
9056	933	92	2026-10-09	11:00-12:00	2	VN	CHAILLOU	\N	2026-10-06 12:15:50.056307+00	1780	2026-10-09 07:59:40.762851+00	1780	2026-10-09 07:59:40.663+00	1780	fe6867e3-778a-45a8-83c3-94cd9926f119	relance
9782	933	12	2026-10-11	09:00-10:00	2	VN	GAUTHIER SANDERO	\N	2026-10-11 14:39:40.111644+00	5	\N	\N	\N	\N	89acb5a4-4ef1-4e93-a16d-1fd852e627fd	relance
9718	933	59	2026-10-11	16:00-17:00	1	VN	ALDRAVANDI  TWINGO	\N	2026-10-09 08:49:39.283775+00	7	2026-10-11 16:42:57.470375+00	7	2026-10-11 16:42:57.39+00	7	ff012c19-e788-41f0-8fca-3a4626f247ec	relance
2029	2	42	2026-09-10	10:00-11:00	2	VN	DESCRIAUX DUSTER	\N	2026-09-08 10:24:57.034689+00	1782	\N	\N	\N	\N	\N	relance
2045	2	42	2026-09-12	09:00-10:00	2	VN	PERIN 9H30 DACIA	\N	2026-09-08 10:26:45.12962+00	1782	\N	\N	\N	\N	\N	relance
2048	2	66	2026-09-13	14:00-15:00	1	VN	BLANDIN / SCENIC	\N	2026-09-08 10:27:03.540716+00	8	\N	\N	\N	\N	\N	relance
2063	2	36	2026-09-10	17:00-18:00	1	VN	richard	\N	2026-09-08 10:29:41.69784+00	97	\N	\N	\N	\N	\N	relance
2066	2	36	2026-09-11	10:00-11:00	1	VN	benassy	\N	2026-09-08 10:29:56.111798+00	97	\N	\N	\N	\N	\N	relance
2068	2	36	2026-09-11	14:00-15:00	1	VN	marié	\N	2026-09-08 10:30:06.474834+00	97	\N	\N	\N	\N	\N	relance
2076	2	1885	2026-09-10	10:00-11:00	1	VN	CASTEILLE - VN R	\N	2026-09-08 10:31:11.54951+00	1777	\N	\N	\N	\N	\N	relance
2081	2	19	2026-09-10	11:00-12:00	1	VN	LAURIERE R5	\N	2026-09-08 10:31:33.453931+00	2	\N	\N	\N	\N	\N	relance
8699	933	6	2026-10-08	18:00-19:00	1	VN	SOCIETE KESER (SCENIC E TECH)	\N	2026-10-06 09:30:36.430907+00	2	\N	\N	\N	\N	ede555ab-bb01-420b-8343-b27e56b48936	relance
8886	933	67	2026-10-09	17:00-18:00	2	VN	HOSMALIN / JOGGER	\N	2026-10-06 10:24:23.001206+00	8	\N	\N	\N	\N	9819b4d8-17fe-4c53-aef0-e9564f74f0ca	relance
9048	933	92	2026-10-08	09:00-10:00	2	VN	KAIQUE	\N	2026-10-06 12:14:40.236463+00	1780	\N	\N	\N	\N	7bfc2f16-72e2-44b3-9819-2ba908f40906	relance
9049	933	92	2026-10-08	10:00-11:00	1	VN	HAREUX	\N	2026-10-06 12:14:50.613664+00	1780	\N	\N	\N	\N	8a70754d-c08a-418d-9b9d-9423955b0de6	relance
9052	933	92	2026-10-08	16:00-17:00	1	VN	VILLEMIN	\N	2026-10-06 12:15:15.842937+00	1780	\N	\N	\N	\N	d925fd5e-557a-4c6e-880c-61eb866972fd	relance
9058	933	92	2026-10-10	11:00-12:00	1	VN	HURIER	\N	2026-10-06 12:16:11.110484+00	1780	\N	\N	\N	\N	0291b4b5-c740-4c74-8ef9-8c18bfc64fec	relance
9059	933	92	2026-10-10	14:00-15:00	1	VN	RICHARD	\N	2026-10-06 12:16:16.113558+00	1780	\N	\N	\N	\N	d31f92a7-3990-448a-b447-c959a91f1921	relance
9060	933	92	2026-10-10	15:00-16:00	1	VN	FOURNIER	\N	2026-10-06 12:16:22.437621+00	1780	\N	\N	\N	\N	e9531461-c859-4277-b778-ab50674d512b	relance
9154	933	89	2026-10-10	14:00-15:00	2	VN	ruols sandero	\N	2026-10-06 14:34:57.519439+00	1781	\N	\N	\N	\N	a7257827-2269-44a3-b852-67a5451efe7d	relance
9156	933	882	2026-10-10	10:00-11:00	\N	VO	CHANAL	\N	2026-10-06 14:36:18.928307+00	9	\N	\N	\N	\N	4793ccf3-f121-40b9-a1e1-32d9a2ef59b4	relance
9161	933	5766	2026-10-11	14:00-15:00	\N	VO	GERMAIN / CLIO	\N	2026-10-06 14:37:40.687104+00	8	\N	\N	\N	\N	ae3a221f-ba13-4fce-8d24-d09a1af14cac	relance
9166	933	80	2026-10-08	09:00-10:00	1	VN	OUSTRY R5	\N	2026-10-06 14:38:39.158152+00	1776	\N	\N	\N	\N	158e82a5-fc65-434b-a455-67e243d43566	relance
9380	933	11	2026-10-10	09:00-10:00	1	VN	CRFEPIEU R5	\N	2026-10-06 16:02:54.417702+00	5	\N	\N	\N	\N	67973074-be10-456d-9304-1d0c783c131c	relance
9459	933	17	2026-10-11	14:00-15:00	1	VN	MIGNOT R4	\N	2026-10-06 16:59:40.677163+00	3	2026-10-06 17:00:01.885195+00	3	\N	\N	b6ad03d7-86f4-4f0f-8437-7f364a0062be	relance
9523	933	83	2026-10-09	11:00-12:00	\N	VO	BOUSQUIE	\N	2026-10-07 08:41:29.557728+00	1776	\N	\N	\N	\N	b64ca9e8-1a87-44d8-b53f-bc27d53dc0e5	relance
9590	933	76	2026-10-09	14:00-15:00	1	VN	GALAN	\N	2026-10-07 15:53:06.455853+00	1778	\N	\N	\N	\N	e0f3d1d5-6d8a-4344-96ee-db0911d19b6f	relance
9593	933	76	2026-10-10	12:00-13:00	1	VN	COSTES	\N	2026-10-07 15:53:41.628053+00	1778	\N	\N	\N	\N	a0a73285-9523-4285-b9bc-11238c51ba12	relance
9594	933	76	2026-10-12	14:00-15:00	1	VN	CASTILLON	\N	2026-10-07 15:53:57.792547+00	1778	\N	\N	\N	\N	3848bee5-f9ae-4e53-ab1e-9d8dd62f8242	relance
9596	933	76	2026-10-10	14:00-15:00	2	VN	ORLANDINI	\N	2026-10-07 15:54:32.813303+00	1778	\N	\N	\N	\N	c067171d-6a7d-4ae3-86e6-3af03f813c9c	relance
9719	933	59	2026-10-09	16:00-17:00	2	VN	REY	\N	2026-10-09 14:03:49.497692+00	7	\N	\N	\N	\N	cd9ca80f-582e-4f26-b1d6-ca14b04d68c7	relance
9783	933	12	2026-10-11	12:00-13:00	2	VN	NEOLIER SANDERO	\N	2026-10-11 14:40:21.759458+00	5	\N	\N	\N	\N	c987a3b3-fc1d-4608-8996-c1f567ebf0f4	relance
2039	2	42	2026-09-11	11:00-12:00	2	VN	FRANCHIN DUSTER	\N	2026-09-08 10:26:23.582796+00	1782	\N	\N	\N	\N	\N	relance
2064	2	10	2026-09-13	18:00-19:00	1	VN	BEAUFILS	\N	2026-09-08 10:29:43.278903+00	3	\N	\N	\N	\N	\N	relance
2073	2	36	2026-09-11	18:00-19:00	1	VN	dajoux	\N	2026-09-08 10:30:51.089135+00	97	\N	\N	\N	\N	\N	relance
2084	2	19	2026-09-10	14:00-15:00	1	VN	POURTON CAPTUR	\N	2026-09-08 10:31:49.883196+00	2	\N	\N	\N	\N	\N	relance
2085	2	67	2026-09-12	11:00-12:00	2	VN	CUENA / SANDERO	\N	2026-09-08 10:31:51.280715+00	8	\N	\N	\N	\N	\N	relance
2088	2	10	2026-09-14	17:00-18:00	1	VN	LOPEZ	\N	2026-09-08 10:32:23.522548+00	3	\N	\N	\N	\N	\N	relance
2091	2	15	2026-09-10	11:00-12:00	1	VN	DELABRE TWINGO	\N	2026-09-08 10:33:29.013919+00	2	\N	\N	\N	\N	\N	relance
2093	2	16	2026-09-10	09:00-10:00	1	VN	BRUNEL	\N	2026-09-08 10:33:45.408483+00	3	\N	\N	\N	\N	\N	relance
2094	2	15	2026-09-10	17:00-18:00	1	VN	VIALLE R5	\N	2026-09-08 10:33:46.115368+00	2	\N	\N	\N	\N	\N	relance
2092	2	17	2026-09-11	09:00-10:00	1	VN	VILLATA MR	\N	2026-09-08 10:33:41.245648+00	5	2026-09-08 10:33:47.929473+00	5	\N	\N	\N	relance
2096	2	16	2026-09-10	14:00-15:00	1	VN	CARMIR	\N	2026-09-08 10:33:56.737797+00	3	\N	\N	\N	\N	\N	relance
2097	2	16	2026-09-10	17:00-18:00	1	VN	RICHARD	\N	2026-09-08 10:34:00.332944+00	3	\N	\N	\N	\N	\N	relance
2095	2	17	2026-09-11	10:00-11:00	1	VN	VILLATTA MME	\N	2026-09-08 10:33:53.573422+00	5	2026-09-08 10:34:06.173388+00	5	\N	\N	\N	relance
2098	2	16	2026-09-11	17:00-18:00	1	VN	TRABUT	\N	2026-09-08 10:34:14.789628+00	3	\N	\N	\N	\N	\N	relance
2099	2	16	2026-09-11	18:00-19:00	1	VN	BAILLARD	\N	2026-09-08 10:34:18.148393+00	3	\N	\N	\N	\N	\N	relance
2100	2	69	2026-09-12	11:00-12:00	\N	VO	JANVION	\N	2026-09-08 10:34:21.839545+00	7	\N	\N	\N	\N	\N	relance
2101	2	211	2026-09-12	14:00-15:00	\N	VO	PIRON SYMBIOZ	\N	2026-09-08 10:34:28.31625+00	2	\N	\N	\N	\N	\N	relance
2102	2	44	2026-09-13	15:00-16:00	1	VN	GUICHARD CLIO	\N	2026-09-08 10:34:42.107026+00	1782	\N	\N	\N	\N	\N	relance
2103	2	16	2026-09-12	14:00-15:00	1	VN	BARDY	\N	2026-09-08 10:34:43.219766+00	3	\N	\N	\N	\N	\N	relance
2104	2	16	2026-09-13	10:00-11:00	1	VN	MESURE	\N	2026-09-08 10:34:53.012159+00	3	\N	\N	\N	\N	\N	relance
2105	2	44	2026-09-11	15:00-16:00	1	VN	BRUN CLIO	\N	2026-09-08 10:34:55.258701+00	1782	\N	\N	\N	\N	\N	relance
2106	2	16	2026-09-13	15:00-16:00	1	VN	DALY	\N	2026-09-08 10:35:06.963057+00	3	\N	\N	\N	\N	\N	relance
2107	2	68	2026-09-10	11:00-12:00	\N	VO	SARRON	\N	2026-09-08 10:35:08.364241+00	9	\N	\N	\N	\N	\N	relance
2108	2	882	2026-09-10	14:00-15:00	\N	VO	FORCE / VO	\N	2026-09-08 10:36:11.081047+00	8	\N	\N	\N	\N	\N	relance
8700	933	6	2026-10-08	10:00-11:00	1	VN	MAILLET (MEGANE E TECH)	\N	2026-10-06 09:30:58.18998+00	2	\N	\N	\N	\N	baebb8de-4692-4c3b-85fe-c59d17332263	relance
2110	2	9	2026-09-10	17:00-18:00	\N	VO	causse	\N	2026-09-08 10:36:25.250575+00	6	\N	\N	\N	\N	\N	relance
2111	2	23	2026-09-11	16:00-17:00	\N	VO	AUSSET	\N	2026-09-08 10:36:27.476303+00	3	\N	\N	\N	\N	\N	relance
2113	2	9	2026-09-12	14:00-15:00	\N	VO	villanne	\N	2026-09-08 10:36:46.318853+00	6	\N	\N	\N	\N	\N	relance
2114	2	67	2026-09-13	09:00-10:00	1	VN	KUSNIEREK / CLIO	\N	2026-09-08 10:36:52.526219+00	8	\N	\N	\N	\N	\N	relance
2115	2	9	2026-09-12	08:00-09:00	\N	VO	fernandes	\N	2026-09-08 10:36:59.670798+00	6	\N	\N	\N	\N	\N	relance
2116	2	215	2026-09-11	17:00-18:00	\N	VO	PORTAL	\N	2026-09-08 10:37:03.662197+00	3	\N	\N	\N	\N	\N	relance
2117	2	215	2026-09-11	18:00-19:00	\N	VO	FORISSIER	\N	2026-09-08 10:37:15.754949+00	3	\N	\N	\N	\N	\N	relance
2118	2	67	2026-09-11	09:00-10:00	1	VN	TRIDOT / ESPACE	\N	2026-09-08 10:37:18.180288+00	8	\N	\N	\N	\N	\N	relance
2120	2	54	2026-09-11	14:00-15:00	1	VN	BESSON	\N	2026-09-08 10:37:40.159301+00	8	\N	\N	\N	\N	\N	relance
2124	2	57	2026-09-11	09:00-10:00	\N	VO	GURODON	\N	2026-09-08 10:38:29.905246+00	92	\N	\N	\N	\N	\N	relance
2125	2	18	2026-09-10	16:00-17:00	1	VN	BOUSSIRON CLIO	\N	2026-09-08 10:38:37.973396+00	4	\N	\N	\N	\N	\N	relance
2126	2	18	2026-09-11	09:00-10:00	1	VN	CHINCHILLA CLIO	\N	2026-09-08 10:38:56.014572+00	4	\N	\N	\N	\N	\N	relance
2127	2	18	2026-09-10	10:00-11:00	1	VN	MASSARD R5	\N	2026-09-08 10:39:04.519151+00	4	\N	\N	\N	\N	\N	relance
2129	2	55	2026-09-12	14:00-15:00	2	VN	JOURDAIN	\N	2026-09-08 10:39:40.208068+00	9	\N	\N	\N	\N	\N	relance
2131	2	44	2026-09-10	18:00-19:00	1	VN	PETIT MEGANE E TECH	\N	2026-09-08 10:39:55.415117+00	1782	\N	\N	\N	\N	\N	relance
2132	2	53	2026-09-14	17:00-18:00	1	VN	LANGLADE	\N	2026-09-08 10:40:25.588194+00	9	\N	\N	\N	\N	\N	relance
2134	2	61	2026-09-13	10:00-11:00	\N	VO	PERE	\N	2026-09-08 10:41:05.538899+00	9	\N	\N	\N	\N	\N	relance
2135	2	61	2026-09-14	14:00-15:00	\N	VO	MORIN	\N	2026-09-08 10:41:14.027939+00	9	\N	\N	\N	\N	\N	relance
2136	2	61	2026-09-12	11:00-12:00	\N	VO	VALETTE	\N	2026-09-08 10:41:28.086872+00	9	\N	\N	\N	\N	\N	relance
2138	2	9	2026-09-10	11:00-12:00	\N	VO	quinsat	\N	2026-09-08 10:42:30.257478+00	6	\N	\N	\N	\N	\N	relance
2141	2	9	2026-09-11	18:00-19:00	\N	VO	billet	\N	2026-09-08 10:44:04.032545+00	6	\N	\N	\N	\N	\N	relance
2142	2	66	2026-09-14	10:00-11:00	1	VN	TEISSEDRE / CLIO	\N	2026-09-08 10:44:10.08692+00	8	\N	\N	\N	\N	\N	relance
2130	2	12	2026-09-11	17:00-18:00	1	VN	LAFEUILLE SANDERO	\N	2026-09-08 10:39:47.712523+00	4	2026-09-09 16:22:39.616546+00	92	2026-09-09 16:22:39.239+00	92	\N	relance
2139	2	9	2026-09-11	14:00-15:00	\N	VO	marcilhac	\N	2026-09-08 10:43:30.692832+00	6	2026-09-08 10:43:42.427393+00	6	\N	\N	\N	relance
2140	2	9	2026-09-11	17:00-18:00	\N	VO	croizet	\N	2026-09-08 10:43:55.341665+00	6	\N	\N	\N	\N	\N	relance
2144	2	9	2026-09-12	10:00-11:00	\N	VO	faure	\N	2026-09-08 10:44:18.875244+00	6	\N	\N	\N	\N	\N	relance
2145	2	9	2026-09-13	11:00-12:00	\N	VO	otsmane	\N	2026-09-08 10:44:30.042875+00	6	\N	\N	\N	\N	\N	relance
2146	2	9	2026-09-13	14:00-15:00	\N	VO	pitiot	\N	2026-09-08 10:44:39.192957+00	6	\N	\N	\N	\N	\N	relance
2147	2	67	2026-09-12	14:00-15:00	1	VN	SUGERE / CLIO	\N	2026-09-08 10:45:56.267801+00	8	\N	\N	\N	\N	\N	relance
2148	2	48	2026-09-10	09:00-10:00	1	VN	M Vigier	\N	2026-09-08 10:47:27.80418+00	1783	\N	\N	\N	\N	\N	relance
2149	2	48	2026-09-10	10:00-11:00	1	VN	M Simonet	\N	2026-09-08 10:47:35.310295+00	1783	\N	\N	\N	\N	\N	relance
2152	2	48	2026-09-10	11:00-12:00	1	VN	Mme Simonet	\N	2026-09-08 10:48:12.104509+00	1783	\N	\N	\N	\N	\N	relance
2121	2	12	2026-09-11	09:00-10:00	1	VN	MIOCHE SPRING	\N	2026-09-08 10:37:43.221199+00	4	2026-09-09 16:21:04.358826+00	92	2026-09-09 16:21:03.992+00	92	\N	relance
2122	2	12	2026-09-11	11:00-12:00	1	VN	GAILLARD SANDERO	\N	2026-09-08 10:37:56.300392+00	4	2026-09-09 16:21:36.202388+00	92	2026-09-09 16:21:35.866+00	92	\N	relance
2137	2	12	2026-09-10	13:00-14:00	1	VN	JORDA DUSTER	\N	2026-09-08 10:42:29.095371+00	4	2026-09-09 16:21:51.80269+00	92	2026-09-09 16:21:51.449+00	92	\N	relance
2123	2	12	2026-09-11	14:00-15:00	1	VN	FLORY CLIO	\N	2026-09-08 10:38:11.903288+00	4	2026-09-09 16:22:06.656017+00	92	2026-09-09 16:22:06.257+00	92	\N	relance
2128	2	12	2026-09-11	15:00-16:00	1	VN	ROBERT SANDERO	\N	2026-09-08 10:39:31.39627+00	4	2026-09-09 16:22:18.350049+00	92	2026-09-09 16:22:17.991+00	92	\N	relance
2112	2	12	2026-09-10	17:00-18:00	1	VN	CAILLE SANDERO	\N	2026-09-08 10:36:30.525116+00	4	2026-09-09 16:22:29.747025+00	92	2026-09-09 16:22:29.339+00	92	\N	relance
2119	2	12	2026-09-10	18:00-19:00	1	VN	AUBERT SANDERO	\N	2026-09-08 10:37:19.048403+00	4	2026-09-09 16:22:36.123634+00	92	2026-09-09 16:22:35.786+00	92	\N	relance
2062	2	6	2026-09-10	15:00-16:00	1	VN	DUTUEL SANDERO	\N	2026-09-08 10:29:39.732594+00	5	2026-09-09 16:25:19.084927+00	92	2026-09-09 16:25:18.701+00	92	\N	relance
2151	2	17	2026-09-11	11:00-12:00	1	VN	TOURNADRE TWINGO	\N	2026-09-08 10:47:45.766566+00	5	2026-09-10 15:25:05.825133+00	5	2026-09-10 15:25:06.035+00	5	\N	relance
2158	2	51	2026-09-13	10:00-11:00	\N	VO	M FONTANIER	\N	2026-09-08 10:49:07.036291+00	1783	\N	\N	\N	\N	\N	relance
2159	2	6	2026-09-11	08:00-09:00	1	VN	SE2A AUSTRAL	\N	2026-09-08 10:49:13.021577+00	5	\N	\N	\N	\N	\N	relance
2162	2	49	2026-09-11	11:00-12:00	1	VN	M MARQUES	\N	2026-09-08 10:49:51.812179+00	1783	\N	\N	\N	\N	\N	relance
2153	2	14	2026-09-10	17:00-18:00	1	VN	MEGRESIF BIGSTER	\N	2026-09-08 10:48:19.006161+00	5	2026-09-09 16:23:57.774563+00	92	2026-09-09 16:23:57.445+00	92	\N	relance
8701	933	6	2026-10-08	14:00-15:00	2	VN	TRISSE  (SANDERO)	\N	2026-10-06 09:31:27.501767+00	2	\N	\N	\N	\N	22a4db35-6b03-4194-a6d2-69b9ba3ffd56	relance
8889	933	67	2026-10-10	09:00-10:00	1	VN	COURTIER / MEGANE	\N	2026-10-06 10:24:51.765114+00	8	\N	\N	\N	\N	2d9861c0-1d58-4a2a-86b9-9dbe9f1f723c	relance
8891	933	67	2026-10-10	11:00-12:00	1	VN	DELPLAST / TWINGO	\N	2026-10-06 10:25:04.89466+00	8	\N	\N	\N	\N	3fbd782c-91f2-42fb-8aa0-c42703dd6bdc	relance
9050	933	92	2026-10-08	14:00-15:00	2	VN	WATTELIER	\N	2026-10-06 12:14:58.638367+00	1780	\N	\N	\N	\N	fb7977bb-eff9-4358-b190-9eb05380d1a9	relance
9054	933	92	2026-10-09	09:00-10:00	2	VN	LACIPIERE	\N	2026-10-06 12:15:36.141397+00	1780	\N	\N	\N	\N	6342d0c9-e3ea-4743-a025-6e50508f6ff4	relance
9061	933	92	2026-10-10	17:00-18:00	1	VN	RAYMOND	\N	2026-10-06 12:16:31.458103+00	1780	\N	\N	\N	\N	bda8eb66-cf06-40e6-bfa2-b7d1afa17d56	relance
9171	933	160	2026-10-08	10:00-11:00	1	VN	Continsouza Rafale	\N	2026-10-06 14:43:03.536255+00	3	2026-10-06 14:43:46.719677+00	3	2026-10-06 14:43:49.292+00	3	717d07b6-9f3c-4d7e-8d2a-8f41ff1c57f7	relance
9176	933	27	2026-10-08	10:00-11:00	1	VN	Continsouza Rafale	\N	2026-10-06 14:44:46.283076+00	3	\N	\N	\N	\N	e332a56d-dead-4f2a-8cd2-0e1276731a88	relance
9381	933	11	2026-10-11	10:00-11:00	1	VN	BUIRCKEL SPRING	\N	2026-10-06 16:03:09.135772+00	5	2026-10-06 16:03:36.052133+00	5	\N	\N	9fef194b-572a-4c5e-9fb6-b3633894db02	relance
9460	933	11	2026-10-12	15:00-16:00	1	VN	VONMOOSSE SANDERO	\N	2026-10-06 16:59:47.613874+00	5	2026-10-06 16:59:58.525299+00	5	\N	\N	631e9f9f-c4c7-42f1-ab57-89eee1f9947a	relance
9524	933	79	2026-10-09	14:00-15:00	1	VN	MAGNI RENAUTL	\N	2026-10-07 08:41:43.63655+00	1776	\N	\N	\N	\N	2c568915-5e14-4248-a746-8943832b9ae4	relance
9591	933	76	2026-10-10	09:00-10:00	1	VN	PIRMAN	\N	2026-10-07 15:53:19.092145+00	1778	\N	\N	\N	\N	14a4b312-2e0b-4f99-b979-03ed7ffba72c	relance
9720	933	59	2026-10-09	17:00-18:00	2	VN	TONDU	\N	2026-10-09 14:03:58.861971+00	7	\N	\N	\N	\N	605da4e2-e1cb-4c9d-823c-efdb89b4dc15	relance
9784	933	12	2026-10-11	13:00-14:00	2	VN	ANGIBAUD SANDERO	\N	2026-10-11 14:41:07.543531+00	5	\N	\N	\N	\N	d783077b-f49d-4a17-9e58-1e75f1202211	relance
9785	933	12	2026-10-10	15:00-16:00	2	VN	DUPICHAUD BIGSTER	\N	2026-10-11 14:42:05.032746+00	5	2026-10-11 14:42:10.810631+00	5	\N	\N	1c1e49ae-e222-4b01-9a33-bd193574cac2	relance
2154	2	49	2026-09-11	14:00-15:00	1	VN	M VACHER	\N	2026-09-08 10:48:26.211408+00	1783	\N	\N	\N	\N	\N	relance
2155	2	49	2026-09-13	10:00-11:00	1	VN	M FONTANIER	\N	2026-09-08 10:48:36.918473+00	1783	2026-09-08 10:48:47.35567+00	1783	2026-09-08 10:48:49.134+00	1783	\N	relance
2157	2	6	2026-09-10	18:00-19:00	1	VN	MASSON TWINO	\N	2026-09-08 10:49:02.204825+00	5	\N	\N	\N	\N	\N	relance
2160	2	51	2026-09-13	11:00-12:00	\N	VO	M PLANTELIGNE	\N	2026-09-08 10:49:29.742935+00	1783	\N	\N	\N	\N	\N	relance
2163	2	5	2026-09-13	09:00-10:00	1	VN	GUYO MEGANE	\N	2026-09-08 10:50:00.131373+00	5	\N	\N	\N	\N	\N	relance
2164	2	5	2026-09-13	15:00-16:00	1	VN	HARY AUSTRAL	\N	2026-09-08 10:50:06.080298+00	5	\N	\N	\N	\N	\N	relance
2166	2	48	2026-09-11	16:00-17:00	1	VN	MME MALLEVAL	\N	2026-09-08 10:50:53.52646+00	1783	\N	\N	\N	\N	\N	relance
2169	2	35	2026-09-14	14:00-15:00	1	VN	sallet	\N	2026-09-08 10:52:00.892864+00	97	\N	\N	\N	\N	\N	relance
2161	2	6	2026-09-11	10:00-11:00	1	VN	CHOMILLER DUSTER	\N	2026-09-08 10:49:30.768494+00	5	2026-09-09 16:25:11.464099+00	92	2026-09-09 16:25:11.118+00	92	\N	relance
2156	2	6	2026-09-10	17:00-18:00	1	VN	KALINSKI DUSTER	\N	2026-09-08 10:48:49.001715+00	5	2026-09-09 16:25:32.527167+00	92	2026-09-09 16:25:32.188+00	92	\N	relance
8702	933	12	2026-10-08	09:00-10:00	2	VN	GHOUT ( SPRING)	\N	2026-10-06 09:32:37.607638+00	2	\N	\N	\N	\N	76d2d8dd-e7da-4b32-9f42-eb652e859cc0	relance
8705	933	12	2026-10-08	14:00-15:00	2	VN	RAUSCH (SPRING)	\N	2026-10-06 09:33:36.458707+00	2	\N	\N	\N	\N	72748e90-107e-42f2-bed3-7ed09939cb14	relance
8706	933	12	2026-10-08	15:00-16:00	2	VN	LANGLADE ( BIGSTER)	\N	2026-10-06 09:34:04.848682+00	2	\N	\N	\N	\N	a57d2c82-4475-4d3c-bf13-7d7ab2568ce5	relance
8890	933	2	2026-10-09	11:00-12:00	1	VN	Franco Megane	\N	2026-10-06 10:24:53.906649+00	3	\N	\N	\N	\N	e6540755-5125-47a3-a0ac-525459d0fae5	relance
9063	933	97	2026-10-08	09:00-10:00	1	VN	DUTHEIL R5	\N	2026-10-06 12:24:29.00603+00	1775	\N	\N	\N	\N	586c0440-fcad-4bc8-befc-afe8169c8ffa	relance
9067	933	97	2026-10-10	10:00-11:00	1	VN	DE CAMPOS	\N	2026-10-06 12:24:53.734702+00	1775	\N	\N	\N	\N	36fc4ba4-f296-4441-a549-0932d69e5a06	relance
9172	933	160	2026-10-08	13:00-14:00	1	VN	guitard pierre	\N	2026-10-06 14:43:24.012818+00	3	2026-10-06 14:43:55.894009+00	3	2026-10-06 14:43:58.361+00	3	098af091-a441-4d1f-aae7-61d5763205cf	relance
9175	933	70	2026-10-10	10:00-11:00	\N	VO	PAJOT ELECTRIQUE	\N	2026-10-06 14:44:37.703676+00	7	\N	\N	\N	\N	638b2352-464c-404c-b8e5-984798faac35	relance
9382	933	11	2026-10-11	11:00-12:00	2	VN	CARDIN SANDERO	\N	2026-10-06 16:03:30.244991+00	5	\N	\N	\N	\N	aec9f1c9-cbd5-40b8-b6a9-aa16e280fdc7	relance
9461	933	15	2026-10-09	14:00-15:00	2	VN	DUVALER SANDERO	\N	2026-10-06 17:00:30.459016+00	5	\N	\N	\N	\N	49515e99-1106-424a-8857-f044b674a947	relance
9531	933	29	2026-10-10	09:00-10:00	3	VN	JANVIER	\N	2026-10-07 08:49:24.470013+00	5502	\N	\N	\N	\N	eabb2c1e-2efb-40c8-91ee-2a5a7f33d328	relance
9595	933	76	2026-10-12	18:00-19:00	1	VN	BAFFOIGNE	\N	2026-10-07 15:54:09.597968+00	1778	\N	\N	\N	\N	a4e5ede1-7170-474e-b78c-8f7b0b81b531	relance
9721	933	60	2026-10-09	13:00-14:00	1	VN	DRUTEL	\N	2026-10-09 14:08:37.321735+00	7	2026-10-09 14:11:44.842889+00	7	2026-10-09 14:11:44.788+00	7	99671cea-7753-4ccd-994e-026077927ecf	relance
9526	933	29	2026-10-08	17:00-18:00	3	VN	BEBEL	\N	2026-10-07 08:48:51.824686+00	5502	2026-10-11 09:43:17.79201+00	5502	2026-10-11 09:43:17.6+00	5502	e9f7766a-25ff-49e3-b401-c1538fdbeca4	relance
9525	933	29	2026-10-08	10:00-11:00	3	VN	GAUTHIER	\N	2026-10-07 08:47:15.888859+00	5502	2026-10-11 09:43:28.981669+00	5502	2026-10-11 09:43:28.821+00	5502	588bc4b8-f2c2-4847-9e11-597a007ac8d1	relance
9786	933	61	2026-10-11	17:00-18:00	\N	VO	FERAUDY	\N	2026-10-11 15:58:49.952606+00	7	\N	\N	\N	\N	2139dda0-9820-4924-990c-d92cce188d1b	showroom
2165	2	48	2026-09-11	16:00-17:00	1	VN	M MALLEVAL	\N	2026-09-08 10:50:15.583399+00	1783	\N	\N	\N	\N	\N	relance
2167	2	50	2026-09-11	14:00-15:00	1	VN	LEZOUX ELECTRICITE	\N	2026-09-08 10:51:11.667621+00	1783	\N	\N	\N	\N	\N	relance
2168	2	35	2026-09-11	14:00-15:00	1	VN	gleizes	\N	2026-09-08 10:51:53.166883+00	97	\N	\N	\N	\N	\N	relance
2170	2	29	2026-09-12	09:00-10:00	3	VN	DOUNON	\N	2026-09-08 10:53:19.933777+00	4	\N	\N	\N	\N	\N	relance
2171	2	29	2026-09-12	14:00-15:00	3	VN	HUGUES	\N	2026-09-08 10:53:29.078797+00	4	\N	\N	\N	\N	\N	relance
2172	2	29	2026-09-12	15:00-16:00	3	VN	PRAT	\N	2026-09-08 10:53:33.257428+00	4	\N	\N	\N	\N	\N	relance
2173	2	29	2026-09-13	10:00-11:00	3	VN	DUMONT	\N	2026-09-08 10:53:41.511956+00	4	\N	\N	\N	\N	\N	relance
2174	2	11	2026-09-10	15:00-16:00	1	VN	FRANCOIS CLIO6	\N	2026-09-08 11:00:33.54364+00	2	\N	\N	\N	\N	\N	relance
2175	2	19	2026-09-11	09:00-10:00	1	VN	QUENOT CAPTUR	\N	2026-09-08 11:01:11.168283+00	2	\N	\N	\N	\N	\N	relance
2176	2	19	2026-09-11	14:00-15:00	1	VN	GENEVRIER R5	\N	2026-09-08 11:01:29.011637+00	2	\N	\N	\N	\N	\N	relance
2177	2	2	2026-09-11	09:00-10:00	1	VN	CARRIES	\N	2026-09-08 11:03:03.498528+00	3	\N	\N	\N	\N	\N	relance
2178	2	2	2026-09-10	11:00-12:00	1	VN	RUIZ	\N	2026-09-08 11:03:12.478681+00	3	\N	\N	\N	\N	\N	relance
2179	2	881	2026-09-10	09:00-10:00	1	VN	test	\N	2026-09-08 13:50:45.669854+00	92	2026-09-08 13:50:51.38377+00	92	2026-09-08 13:50:50.351+00	92	\N	relance
2180	2	28	2026-09-13	15:00-16:00	\N	VO	PICHERI	\N	2026-09-08 13:53:54.096638+00	6	\N	\N	\N	\N	\N	relance
2181	2	28	2026-09-12	10:00-11:00	\N	VO	ROUGET	\N	2026-09-08 13:54:03.544273+00	6	\N	\N	\N	\N	\N	relance
2182	2	28	2026-09-13	10:00-11:00	\N	VO	LY	\N	2026-09-08 13:54:12.800096+00	6	\N	\N	\N	\N	\N	relance
2183	2	213	2026-09-10	15:00-16:00	\N	VO	BARGE	\N	2026-09-08 13:54:46.498761+00	6	\N	\N	\N	\N	\N	relance
2184	2	1889	2026-09-10	10:00-11:00	\N	VO	vettese	\N	2026-09-08 13:54:49.275421+00	1775	\N	\N	\N	\N	\N	relance
2185	2	1889	2026-09-10	16:00-17:00	\N	VO	boissiere	\N	2026-09-08 13:55:03.871234+00	1775	\N	\N	\N	\N	\N	relance
2186	2	1889	2026-09-11	10:00-11:00	\N	VO	valentin	\N	2026-09-08 13:55:19.724375+00	1775	\N	\N	\N	\N	\N	relance
2187	2	1889	2026-09-11	14:00-15:00	\N	VO	pailhoux	\N	2026-09-08 13:55:36.781774+00	1775	\N	\N	\N	\N	\N	relance
2188	2	1889	2026-09-11	15:00-16:00	\N	VO	do rosario	\N	2026-09-08 13:55:53.869573+00	1775	\N	\N	\N	\N	\N	relance
2189	2	1889	2026-09-12	10:00-11:00	\N	VO	henri juliette	\N	2026-09-08 13:56:26.428218+00	1775	\N	\N	\N	\N	\N	relance
2190	2	1889	2026-09-12	15:00-16:00	\N	VO	blasquez	\N	2026-09-08 13:56:44.06095+00	1775	\N	\N	\N	\N	\N	relance
2191	2	97	2026-09-14	09:00-10:00	1	VN	causse twingo	\N	2026-09-08 14:00:41.886821+00	1775	\N	\N	\N	\N	\N	relance
2192	2	29	2026-09-13	09:00-10:00	3	VN	BOUCHET	\N	2026-09-08 14:05:16.713005+00	4	\N	\N	\N	\N	\N	relance
2193	2	29	2026-09-13	11:00-12:00	3	VN	BRUNMUROL	\N	2026-09-08 14:05:33.02248+00	4	\N	\N	\N	\N	\N	relance
2194	2	29	2026-09-13	13:00-14:00	3	VN	VIEIRA	\N	2026-09-08 14:05:47.894569+00	4	\N	\N	\N	\N	\N	relance
2195	2	29	2026-09-13	14:00-15:00	3	VN	MALLET	\N	2026-09-08 14:05:54.86101+00	4	\N	\N	\N	\N	\N	relance
2196	2	29	2026-09-13	15:00-16:00	3	VN	LAPLACE	\N	2026-09-08 14:05:58.805459+00	4	\N	\N	\N	\N	\N	relance
2197	2	29	2026-09-13	16:00-17:00	3	VN	BONJOUR	\N	2026-09-08 14:06:03.904622+00	4	\N	\N	\N	\N	\N	relance
2198	2	24	2026-09-11	10:00-11:00	\N	VO	COURSOL	\N	2026-09-08 14:13:36.017264+00	4	\N	\N	\N	\N	\N	relance
2199	2	96	2026-09-11	10:00-11:00	1	VN	trebosc	\N	2026-09-08 14:13:41.703063+00	1775	\N	\N	\N	\N	\N	relance
2200	2	26	2026-09-10	09:00-10:00	1	VN	DOUBLET CAPTUR	\N	2026-09-08 14:14:18.447732+00	4	\N	\N	\N	\N	\N	relance
2201	2	26	2026-09-10	10:00-11:00	1	VN	CHABANNE CAPTUR	\N	2026-09-08 14:14:27.862038+00	4	\N	\N	\N	\N	\N	relance
2202	2	26	2026-09-10	14:00-15:00	1	VN	ARFEUILLE R5	\N	2026-09-08 14:14:37.562959+00	4	\N	\N	\N	\N	\N	relance
2203	2	26	2026-09-12	09:00-10:00	1	VN	BOUIGE	\N	2026-09-08 14:14:54.752878+00	4	\N	\N	\N	\N	\N	relance
2204	2	26	2026-09-13	10:00-11:00	1	VN	VINCENT SPRING	\N	2026-09-08 14:15:07.910891+00	4	\N	\N	\N	\N	\N	relance
2205	2	26	2026-09-13	14:00-15:00	1	VN	DURET	\N	2026-09-08 14:15:15.270229+00	4	\N	\N	\N	\N	\N	relance
2206	2	96	2026-09-10	08:00-09:00	2	VN	alcouffe sandero	\N	2026-09-08 14:15:25.892743+00	1775	\N	\N	\N	\N	\N	relance
2207	2	26	2026-09-14	14:00-15:00	1	VN	BOUDOT TWINGO	\N	2026-09-08 14:15:31.009925+00	4	\N	\N	\N	\N	\N	relance
2208	2	80	2026-09-11	14:00-15:00	1	VN	CAPDECOUME	\N	2026-09-08 14:15:36.052516+00	1776	\N	\N	\N	\N	\N	relance
2210	2	80	2026-09-10	15:00-16:00	1	VN	PALLOT REN ZOE	\N	2026-09-08 14:15:55.21113+00	1776	2026-09-08 14:16:03.39915+00	1776	\N	\N	\N	relance
2209	2	80	2026-09-11	15:00-16:00	1	VN	2	\N	2026-09-08 14:15:50.245865+00	1776	2026-09-08 14:16:06.876903+00	1776	2026-09-08 14:16:07.191+00	1776	\N	relance
2211	2	1885	2026-09-12	14:00-15:00	1	VN	LABAUME - VN	\N	2026-09-08 14:16:10.379802+00	1777	\N	\N	\N	\N	\N	relance
2212	2	1885	2026-09-11	16:00-17:00	1	VN	CAPELLE - TWINGO	\N	2026-09-08 14:16:35.516699+00	1777	\N	\N	\N	\N	\N	relance
2213	2	81	2026-09-11	17:00-18:00	2	VN	GALY BIGSTER	\N	2026-09-08 14:17:26.808057+00	1776	\N	\N	\N	\N	\N	relance
2214	2	81	2026-09-14	10:00-11:00	1	VN	PATENERE R	\N	2026-09-08 14:17:44.88551+00	1776	\N	\N	\N	\N	\N	relance
2215	2	215	2026-09-11	10:00-11:00	\N	VO	RAYNAUD	\N	2026-09-08 14:17:47.214355+00	3	\N	\N	\N	\N	\N	relance
2216	2	87	2026-09-10	17:00-18:00	2	VN	SAULLES - DUSTER VN	\N	2026-09-08 14:17:54.286128+00	1777	\N	\N	\N	\N	\N	relance
2217	2	87	2026-09-12	10:00-11:00	2	VN	CHEYRON - SANDERO	\N	2026-09-08 14:18:06.499403+00	1777	\N	\N	\N	\N	\N	relance
2221	2	73	2026-09-10	14:00-15:00	2	VN	ABDILAHI	\N	2026-09-08 14:18:34.726317+00	1778	\N	\N	\N	\N	\N	relance
2222	2	215	2026-09-10	09:00-10:00	\N	VO	OZER	\N	2026-09-08 14:18:40.919794+00	3	\N	\N	\N	\N	\N	relance
2225	2	73	2026-09-11	16:00-17:00	1	VN	ONTENIENTE	\N	2026-09-08 14:19:07.257052+00	1778	\N	\N	\N	\N	\N	relance
2226	2	73	2026-09-12	09:00-10:00	1	VN	MESTE	\N	2026-09-08 14:19:19.774067+00	1778	\N	\N	\N	\N	\N	relance
2227	2	73	2026-09-12	10:00-11:00	1	VN	BIBAL	\N	2026-09-08 14:19:27.611411+00	1778	\N	\N	\N	\N	\N	relance
2228	2	73	2026-09-12	11:00-12:00	1	VN	BOYER	\N	2026-09-08 14:19:36.708623+00	1778	\N	\N	\N	\N	\N	relance
2229	2	73	2026-09-12	12:00-13:00	1	VN	BUVAT	\N	2026-09-08 14:19:50.31835+00	1778	\N	\N	\N	\N	\N	relance
2230	2	73	2026-09-12	15:00-16:00	1	VN	FONTAINE	\N	2026-09-08 14:19:59.327272+00	1778	\N	\N	\N	\N	\N	relance
2231	2	73	2026-09-14	10:00-11:00	1	VN	BOUNDUH	\N	2026-09-08 14:20:18.469888+00	1778	\N	\N	\N	\N	\N	relance
2232	2	99	2026-09-12	10:00-11:00	2	VN	DERROIR	\N	2026-09-08 14:21:37.636328+00	1778	\N	\N	\N	\N	\N	relance
2233	2	99	2026-09-11	14:00-15:00	2	VN	MICHAUD	\N	2026-09-08 14:21:48.421598+00	1778	\N	\N	\N	\N	\N	relance
2234	2	99	2026-09-14	15:00-16:00	1	VN	CARDONA	\N	2026-09-08 14:22:04.663969+00	1778	\N	\N	\N	\N	\N	relance
2235	2	99	2026-09-11	18:00-19:00	2	VN	GARRIC	\N	2026-09-08 14:22:30.518721+00	1778	\N	\N	\N	\N	\N	relance
2236	2	18	2026-09-14	10:00-11:00	1	VN	BOUZY CAPTUR	\N	2026-09-08 14:22:33.78149+00	4	\N	\N	\N	\N	\N	relance
2223	2	31	2026-09-12	15:00-16:00	1	VN	brun	\N	2026-09-08 14:18:45.752141+00	97	2026-09-08 15:48:03.414815+00	97	2026-09-08 15:47:11.603+00	97	\N	relance
2219	2	31	2026-09-11	17:00-18:00	1	VN	buchard	\N	2026-09-08 14:18:29.54489+00	97	2026-09-08 15:50:22.074752+00	97	2026-09-08 15:50:07.721+00	97	\N	relance
2220	2	31	2026-09-11	16:00-17:00	1	VN	brenet	\N	2026-09-08 14:18:33.733703+00	97	2026-09-08 15:50:36.448431+00	97	2026-09-08 15:50:22.146+00	97	\N	relance
2237	2	99	2026-09-11	15:00-16:00	2	VN	LAGARDE	\N	2026-09-08 14:22:53.728287+00	1778	\N	\N	\N	\N	\N	relance
2238	2	99	2026-09-13	16:00-17:00	1	VN	BOULE	\N	2026-09-08 14:23:30.541616+00	1778	\N	\N	\N	\N	\N	relance
2239	2	99	2026-09-13	15:00-16:00	1	VN	GONIN	\N	2026-09-08 14:23:43.200075+00	1778	\N	\N	\N	\N	\N	relance
2240	2	2	2026-09-14	17:00-18:00	1	VN	BOYER	\N	2026-09-08 14:23:51.678206+00	3	\N	\N	\N	\N	\N	relance
2241	2	2	2026-09-11	18:00-19:00	1	VN	RUAT	\N	2026-09-08 14:24:18.320223+00	3	\N	\N	\N	\N	\N	relance
2242	2	99	2026-09-12	11:00-12:00	1	VN	RAYNAL	\N	2026-09-08 14:24:25.058871+00	1778	\N	\N	\N	\N	\N	relance
2246	2	81	2026-09-10	11:00-12:00	2	VN	LADEUX SPRING	\N	2026-09-08 14:29:01.818532+00	1776	\N	\N	\N	\N	\N	relance
2251	2	1886	2026-09-14	09:00-10:00	2	VN	BOISSONNADE SANDERO	\N	2026-09-08 14:29:44.061995+00	1776	\N	\N	\N	\N	\N	relance
2254	2	1886	2026-09-12	09:00-10:00	2	VN	QULIN DUSTER	\N	2026-09-08 14:29:58.520726+00	1776	\N	\N	\N	\N	\N	relance
2258	2	12	2026-09-12	16:00-17:00	1	VN	FERNANDES SANDERO	\N	2026-09-08 14:30:40.024102+00	4	2026-09-09 16:22:46.226749+00	92	2026-09-09 16:22:45.879+00	92	\N	relance
2260	2	85	2026-09-12	11:00-12:00	\N	VO	ROUSSEAU CAPTUR	\N	2026-09-08 14:31:03.042872+00	1776	\N	\N	\N	\N	\N	relance
2261	2	85	2026-09-11	10:00-11:00	\N	VO	GUIRODI R	\N	2026-09-08 14:31:24.690261+00	1776	\N	\N	\N	\N	\N	relance
2262	2	18	2026-09-13	10:00-11:00	1	VN	CARRE R5	\N	2026-09-08 14:32:41.670455+00	4	\N	\N	\N	\N	\N	relance
2263	2	18	2026-09-10	08:00-09:00	1	VN	BERNARD R5	\N	2026-09-08 14:33:24.350885+00	4	\N	\N	\N	\N	\N	relance
2264	2	81	2026-09-11	11:00-12:00	2	VN	RAYNAL DUSTER	\N	2026-09-08 14:33:40.295356+00	1776	\N	\N	\N	\N	\N	relance
2265	2	29	2026-09-12	11:00-12:00	3	VN	MONTREY	\N	2026-09-08 14:33:42.227592+00	4	\N	\N	\N	\N	\N	relance
2266	2	29	2026-09-12	11:00-12:00	3	VN	MONTREY	\N	2026-09-08 14:33:50.283846+00	4	\N	\N	\N	\N	\N	relance
2267	2	24	2026-09-12	09:00-10:00	\N	VO	FABRE	\N	2026-09-08 14:34:48.47311+00	4	\N	\N	\N	\N	\N	relance
2268	2	15	2026-09-11	10:00-11:00	1	VN	LEBRAUD SYMBIOZ	\N	2026-09-08 14:34:57.972589+00	2	\N	\N	\N	\N	\N	relance
2270	2	15	2026-09-12	14:00-15:00	2	VN	LAFOUGERE DUSTER	\N	2026-09-08 14:35:24.307948+00	2	\N	\N	\N	\N	\N	relance
2269	2	15	2026-09-11	14:00-15:00	1	VN	LAFOUGERE	\N	2026-09-08 14:35:16.993262+00	2	2026-09-08 14:35:28.58875+00	2	2026-09-08 14:35:29.429+00	2	\N	relance
2271	2	23	2026-09-11	10:00-11:00	\N	VO	GRAUWIN	\N	2026-09-08 14:35:31.266586+00	3	\N	\N	\N	\N	\N	relance
2272	2	15	2026-09-11	17:00-18:00	1	VN	MARCHAND TWINGO	\N	2026-09-08 14:35:40.445498+00	2	\N	\N	\N	\N	\N	relance
2273	2	23	2026-09-11	17:00-18:00	\N	VO	COUSTEIX	\N	2026-09-08 14:35:49.094639+00	3	\N	\N	\N	\N	\N	relance
2274	2	23	2026-09-10	09:00-10:00	\N	VO	BLANC	\N	2026-09-08 14:36:06.951146+00	3	\N	\N	\N	\N	\N	relance
1965	2	23	2026-09-10	13:00-14:00	\N	VO	BOUCHEIX	\N	2026-09-08 10:14:10.819269+00	3	2026-09-08 14:36:19.537453+00	3	2026-09-08 14:36:19.351+00	3	\N	relance
2275	2	23	2026-09-10	14:00-15:00	\N	VO	BOUCHEIX	\N	2026-09-08 14:36:24.96678+00	3	\N	\N	\N	\N	\N	relance
2276	2	15	2026-09-12	14:00-15:00	1	VN	GUILLET CLIO6	\N	2026-09-08 14:37:04.987726+00	2	\N	\N	\N	\N	\N	relance
2277	2	28	2026-09-11	15:00-16:00	\N	VO	magout	\N	2026-09-08 14:37:54.399752+00	6	\N	\N	\N	\N	\N	relance
2278	2	97	2026-09-14	17:00-18:00	1	VN	herbin kangoo ze	\N	2026-09-08 14:37:55.933525+00	1775	\N	\N	\N	\N	\N	relance
2279	2	15	2026-09-14	10:00-11:00	2	VN	POTRINEAU SANDERO	\N	2026-09-08 14:38:07.840729+00	2	\N	\N	\N	\N	\N	relance
2280	2	28	2026-09-13	16:00-17:00	\N	VO	fourengare	\N	2026-09-08 14:38:22.68007+00	6	\N	\N	\N	\N	\N	relance
2281	2	74	2026-09-12	11:00-12:00	1	VN	PORTAL	\N	2026-09-08 14:38:36.898402+00	1778	\N	\N	\N	\N	\N	relance
2282	2	211	2026-09-11	11:00-12:00	\N	VO	REINA CLIO	\N	2026-09-08 14:38:49.965014+00	2	\N	\N	\N	\N	\N	relance
2283	2	40	2026-09-10	10:00-11:00	\N	VO	colon	\N	2026-09-08 14:39:06.579604+00	97	\N	\N	\N	\N	\N	relance
2284	2	9	2026-09-10	18:00-19:00	\N	VO	filandon	\N	2026-09-08 14:39:08.682137+00	6	\N	\N	\N	\N	\N	relance
2285	2	211	2026-09-12	16:00-17:00	\N	VO	VIRZI 2008	\N	2026-09-08 14:39:12.457413+00	2	\N	\N	\N	\N	\N	relance
2286	2	40	2026-09-10	14:00-15:00	\N	VO	chades	\N	2026-09-08 14:39:23.611687+00	97	\N	\N	\N	\N	\N	relance
2287	2	4	2026-09-10	09:00-10:00	1	VN	TARDIF  TWINGO	\N	2026-09-08 14:39:26.135534+00	4	\N	\N	\N	\N	\N	relance
2143	2	9	2026-09-12	10:00-11:00	\N	VO	faure	\N	2026-09-08 10:44:11.946273+00	6	2026-09-08 14:39:31.701941+00	6	2026-09-08 14:39:31.506+00	6	\N	relance
2288	2	4	2026-09-11	15:00-16:00	1	VN	MICHEL  CLIO	\N	2026-09-08 14:39:34.990051+00	4	\N	\N	\N	\N	\N	relance
2289	2	40	2026-09-11	09:00-10:00	\N	VO	crozatier	\N	2026-09-08 14:39:43.881654+00	97	\N	\N	\N	\N	\N	relance
2290	2	74	2026-09-12	10:00-11:00	1	VN	SAGE	\N	2026-09-08 14:39:48.795753+00	1778	\N	\N	\N	\N	\N	relance
2291	2	19	2026-09-11	17:00-18:00	1	VN	ROCHEGUCH SCENIC	\N	2026-09-08 14:39:54.067292+00	2	\N	\N	\N	\N	\N	relance
2292	2	4	2026-09-11	17:00-18:00	1	VN	BOUFFONNET  AUSTRAL	\N	2026-09-08 14:39:54.418701+00	4	\N	\N	\N	\N	\N	relance
2293	2	60	2026-09-10	14:00-15:00	2	VN	BRUEL	\N	2026-09-08 14:39:58.370453+00	7	\N	\N	\N	\N	\N	relance
2294	2	4	2026-09-13	10:00-11:00	1	VN	DELON  CLIO	\N	2026-09-08 14:40:00.532008+00	4	\N	\N	\N	\N	\N	relance
2295	2	213	2026-09-12	14:00-15:00	\N	VO	poissonnet	\N	2026-09-08 14:40:06.053564+00	6	\N	\N	\N	\N	\N	relance
2296	2	40	2026-09-11	14:00-15:00	\N	VO	etienne	\N	2026-09-08 14:40:07.666634+00	97	\N	\N	\N	\N	\N	relance
2297	2	4	2026-09-11	11:00-12:00	1	VN	TELLES  TWINGO	\N	2026-09-08 14:40:13.010405+00	4	\N	\N	\N	\N	\N	relance
2298	2	19	2026-09-12	09:00-10:00	1	VN	TONNEAU MEGANE	\N	2026-09-08 14:40:15.671383+00	2	\N	\N	\N	\N	\N	relance
2299	2	19	2026-09-12	10:00-11:00	1	VN	TONNEAU MEGANE	\N	2026-09-08 14:40:31.295407+00	2	\N	\N	\N	\N	\N	relance
2300	2	19	2026-09-12	11:00-12:00	1	VN	COUTERON SCENIC	\N	2026-09-08 14:41:18.280032+00	2	\N	\N	\N	\N	\N	relance
2302	2	84	2026-09-12	17:00-18:00	\N	VO	BASCOUL CAPTUR	\N	2026-09-08 14:41:56.604366+00	1776	\N	\N	\N	\N	\N	relance
2303	2	11	2026-09-13	10:00-11:00	2	VN	TIXIER SANDERO	\N	2026-09-08 14:41:56.628484+00	2	\N	\N	\N	\N	\N	relance
2305	2	84	2026-09-12	10:00-11:00	\N	VO	GOURDON SANDERO	\N	2026-09-08 14:42:11.589219+00	1776	\N	\N	\N	\N	\N	relance
2252	2	32	2026-09-13	09:00-10:00	1	VN	duchassin	\N	2026-09-08 14:29:49.85389+00	97	2026-09-08 15:20:54.917378+00	97	2026-09-08 15:20:55.066+00	97	\N	relance
2253	2	32	2026-09-13	11:00-12:00	1	VN	renard	\N	2026-09-08 14:29:53.835654+00	97	2026-09-08 15:22:24.899402+00	97	2026-09-08 15:22:22.461+00	97	\N	relance
2249	2	32	2026-09-12	14:00-15:00	1	VN	julien	\N	2026-09-08 14:29:27.782406+00	97	2026-09-08 15:23:18.458298+00	97	2026-09-08 15:23:17.823+00	97	\N	relance
2257	2	32	2026-09-14	14:00-15:00	1	VN	fieschi	\N	2026-09-08 14:30:31.882826+00	97	2026-09-08 15:24:27.963062+00	97	2026-09-08 15:24:27.665+00	97	\N	relance
2250	2	32	2026-09-12	15:00-16:00	1	VN	despalles	\N	2026-09-08 14:29:33.656852+00	97	2026-09-08 15:25:25.176837+00	97	2026-09-08 15:25:24.136+00	97	\N	relance
2259	2	32	2026-09-14	17:00-18:00	1	VN	chanat	\N	2026-09-08 14:30:41.008617+00	97	2026-09-08 15:26:33.588775+00	97	2026-09-08 15:26:19.966+00	97	\N	relance
2244	2	12	2026-09-11	10:00-11:00	1	VN	DA SILVA SPRING	\N	2026-09-08 14:27:48.49197+00	4	2026-09-09 16:21:19.239936+00	92	2026-09-09 16:21:18.864+00	92	\N	relance
2248	2	12	2026-09-12	11:00-12:00	1	VN	BOGTOB BIGSTER	\N	2026-09-08 14:29:23.228625+00	4	2026-09-09 16:21:38.945548+00	92	2026-09-09 16:21:38.613+00	92	\N	relance
2256	2	12	2026-09-12	13:00-14:00	1	VN	NAULT SANDERO	\N	2026-09-08 14:30:07.647112+00	4	2026-09-09 16:21:56.079992+00	92	2026-09-09 16:21:55.736+00	92	\N	relance
2304	2	71	2026-09-12	14:00-15:00	1	VN	HIMED	\N	2026-09-08 14:42:03.68611+00	1778	\N	\N	\N	\N	\N	relance
2307	2	11	2026-09-13	11:00-12:00	2	VN	ZEHE SANDERO	\N	2026-09-08 14:42:21.087862+00	2	\N	\N	\N	\N	\N	relance
2308	2	71	2026-09-12	09:00-10:00	1	VN	REVAILLER	\N	2026-09-08 14:42:26.660055+00	1778	\N	\N	\N	\N	\N	relance
2309	2	84	2026-09-11	16:00-17:00	\N	VO	CANIVENQ CLIO	\N	2026-09-08 14:42:27.961711+00	1776	\N	\N	\N	\N	\N	relance
2306	2	11	2026-09-13	11:00-12:00	1	VN	ZEHE	\N	2026-09-08 14:42:14.264416+00	2	2026-09-08 14:43:36.500136+00	2	2026-09-08 14:43:37.261+00	2	\N	relance
2326	2	34	2026-09-14	10:00-11:00	1	VN	jozat	\N	2026-09-08 14:44:41.087795+00	97	\N	\N	\N	\N	\N	relance
8703	933	12	2026-10-08	10:00-11:00	2	VN	PIERRE (DUSTER)	\N	2026-10-06 09:32:52.730191+00	2	\N	\N	\N	\N	5046f532-886f-47db-a17d-c499780f8569	relance
8893	933	2	2026-10-09	17:00-18:00	1	VN	Bassinet r5/Megane	\N	2026-10-06 10:25:25.140656+00	3	\N	\N	\N	\N	3261581f-f112-4341-9e2a-d4753cea3636	relance
9064	933	97	2026-10-09	11:00-12:00	1	VN	GARES	\N	2026-10-06 12:24:34.938971+00	1775	\N	\N	\N	\N	5981900e-bebf-44d2-8ff9-160d25e55d2d	relance
9173	933	160	2026-10-08	14:00-15:00	1	VN	Larroque	\N	2026-10-06 14:43:37.831007+00	3	2026-10-06 14:43:39.357366+00	3	2026-10-06 14:43:41.917+00	3	f743dafc-f928-4555-a1cc-9e0fa26202aa	relance
9383	933	5	2026-10-09	10:00-11:00	2	VN	PONTYIER SANDERO	\N	2026-10-06 16:04:44.717826+00	5	\N	\N	\N	\N	2c401a54-c5b1-4111-b552-0ac7e2426021	relance
9392	933	14	2026-10-09	14:00-15:00	2	VN	VINATIER (SANDERO)	\N	2026-10-06 16:10:11.247443+00	2	\N	\N	\N	\N	e282d603-3e39-4f07-a9c9-7d75be56c2d8	relance
9393	933	18	2026-10-08	15:00-16:00	1	VN	addamo  scenic	\N	2026-10-06 16:12:52.808923+00	4	\N	\N	\N	\N	47d6acb9-e694-4306-a266-01fcad54929d	relance
9462	933	17	2026-10-08	09:00-10:00	1	VN	Faure R4	\N	2026-10-06 17:04:44.92939+00	3	\N	\N	\N	\N	f94c19ed-b2b4-4f7f-aace-eeaa11f0aedc	relance
9527	933	29	2026-10-09	10:00-11:00	3	VN	SEIGNOL	\N	2026-10-07 08:48:59.18963+00	5502	\N	\N	\N	\N	776b5f7d-a95f-46a4-9e7f-dbdb0dda2111	relance
9528	933	29	2026-10-09	11:00-12:00	3	VN	MULNET	\N	2026-10-07 08:49:05.55667+00	5502	\N	\N	\N	\N	accd4cad-b70b-4a16-a6ad-aeef1603d65a	relance
9529	933	29	2026-10-09	16:00-17:00	3	VN	BAUDONNAT	\N	2026-10-07 08:49:10.963392+00	5502	\N	\N	\N	\N	e59fd0d0-8578-4523-b8ee-07c58ccda531	relance
9533	933	29	2026-10-08	18:00-19:00	3	VN	RONGIER	\N	2026-10-07 08:49:42.20059+00	5502	\N	\N	\N	\N	98795582-346b-41c9-b6dd-b331c57c4d2a	relance
9597	933	78	2026-10-09	09:00-10:00	1	VN	MEDIONDO	\N	2026-10-07 15:55:46.480793+00	1778	\N	\N	\N	\N	4d1760ab-b54a-4cfd-89e3-c9c44808aade	relance
9599	933	78	2026-10-10	10:00-11:00	1	VN	LEROUDIER	\N	2026-10-07 15:56:08.530791+00	1778	\N	\N	\N	\N	57f138bf-ce8d-42d3-89af-cdef2ec37718	relance
9722	933	60	2026-10-12	15:00-16:00	2	VN	VOLPILIERE	\N	2026-10-09 14:11:05.413692+00	7	\N	\N	\N	\N	b00ae79e-8435-4b56-bddb-3d25235c711e	relance
9530	933	29	2026-10-09	17:00-18:00	3	VN	MEIRELES	\N	2026-10-07 08:49:16.836491+00	5502	2026-10-11 09:44:47.146564+00	5502	2026-10-11 09:44:46.988+00	5502	d8e11e38-7e6d-46ca-a61f-371380e265a7	relance
9787	933	56	2026-10-12	15:00-16:00	1	VN	ROUGERY	\N	2026-10-11 16:00:06.036059+00	7	2026-10-11 16:00:27.504577+00	7	2026-10-11 16:00:28.581+00	7	028543ac-e58f-4d01-a8c0-d64203e5bb85	relance
2301	2	11	2026-09-13	10:00-11:00	1	VN	TIXIER	\N	2026-09-08 14:41:48.577101+00	2	2026-09-08 14:42:04.744031+00	2	2026-09-08 14:42:05.527+00	2	\N	relance
2316	2	34	2026-09-10	14:00-15:00	1	VN	auger	\N	2026-09-08 14:43:19.635601+00	97	\N	\N	\N	\N	\N	relance
2319	2	34	2026-09-11	09:00-10:00	1	VN	debost	\N	2026-09-08 14:43:35.40495+00	97	\N	\N	\N	\N	\N	relance
2322	2	1885	2026-09-12	09:00-10:00	1	VN	AGNES - VN RENAULT	\N	2026-09-08 14:44:04.27308+00	1777	2026-09-08 14:44:26.899465+00	1777	\N	\N	\N	relance
2332	2	43	2026-09-13	09:00-10:00	1	VN	BONJEAN CAPTUR	\N	2026-09-08 14:47:38.87283+00	1782	\N	\N	\N	\N	\N	relance
8704	933	12	2026-10-08	11:00-12:00	2	VN	TROUCAT ( SANDERO)	\N	2026-10-06 09:33:19.551537+00	2	\N	\N	\N	\N	ab917806-712f-4c89-aadd-e5c8f0b241e1	relance
9065	933	97	2026-10-09	14:00-15:00	1	VN	MINEL	\N	2026-10-06 12:24:41.23758+00	1775	\N	\N	\N	\N	3054e884-bbde-42f0-8f63-4a6f8196eb39	relance
9174	933	70	2026-10-10	14:00-15:00	\N	VO	CHADUC  DUSTER	\N	2026-10-06 14:44:20.182298+00	7	\N	\N	\N	\N	889814bd-42bf-46dd-b969-7691c0931f7d	relance
8895	933	2	2026-10-10	14:00-15:00	1	VN	Bernard Megane	\N	2026-10-06 10:25:49.593874+00	3	2026-10-06 15:43:05.998569+00	3	2026-10-06 15:43:08.574+00	3	bfd3ef15-d05a-4ac5-8026-6cf19b9ec25d	relance
9384	933	5	2026-10-10	09:00-10:00	2	VN	SEIDEL DACIA	\N	2026-10-06 16:04:57.711358+00	5	\N	\N	\N	\N	4ba03825-ea2b-4843-ae6e-388bae255018	relance
9386	933	5	2026-10-09	16:00-17:00	1	VN	GAUCHE CAPTUR	\N	2026-10-06 16:05:28.094648+00	5	\N	\N	\N	\N	0493c28f-22c5-41f3-b281-986cc77a2fba	relance
9388	933	5	2026-10-10	18:00-19:00	1	VN	PETRUTCHI R4/R5	\N	2026-10-06 16:05:53.414389+00	5	\N	\N	\N	\N	63cfc984-4c45-4145-836f-f8e1c7cf6fcd	relance
9463	933	18	2026-10-09	15:00-16:00	1	VN	TRIDOUX  R5	\N	2026-10-06 17:07:27.371428+00	4	\N	\N	\N	\N	349d0c2e-52ca-4496-957b-b706df4ca72d	relance
9532	933	29	2026-10-10	14:00-15:00	3	VN	DUTREUIL	\N	2026-10-07 08:49:32.501927+00	5502	\N	\N	\N	\N	5a3910b3-66c4-42a1-809e-d1204e7e7b3c	relance
9598	933	78	2026-10-09	17:00-18:00	1	VN	DUPUY	\N	2026-10-07 15:55:55.332437+00	1778	\N	\N	\N	\N	6cf09562-8ac3-4903-a90d-02fb511ed7e6	relance
9601	933	78	2026-10-10	14:00-15:00	1	VN	HASSAIN	\N	2026-10-07 15:56:18.957028+00	1778	\N	\N	\N	\N	57a38ee3-cb95-4a68-b5fb-5f1bc6ae3886	relance
9723	933	60	2026-10-09	13:00-14:00	2	VN	DRUTEL	\N	2026-10-09 14:11:52.083914+00	7	\N	\N	\N	\N	1febc4d8-37ec-45ef-b8dd-d361b43a14a6	relance
9788	933	61	2026-10-12	16:00-17:00	\N	VO	ROUGERY SANDERO OU CLIO	\N	2026-10-11 16:00:54.302041+00	7	\N	\N	\N	\N	11ddad33-1874-40ce-bb51-56205f6faac5	relance
2310	2	71	2026-09-12	11:00-12:00	1	VN	LEJAY	\N	2026-09-08 14:42:39.321394+00	1778	2026-09-08 14:42:55.426743+00	1778	\N	\N	\N	relance
2313	2	87	2026-09-11	14:00-15:00	2	VN	GAL - SANDERO VN	\N	2026-09-08 14:42:56.500538+00	1777	\N	\N	\N	\N	\N	relance
2329	2	90	2026-09-12	14:00-15:00	1	VN	grunenwald	\N	2026-09-08 14:45:27.76248+00	1781	\N	\N	\N	\N	\N	relance
8707	933	12	2026-10-08	16:00-17:00	2	VN	TAYLOR ( Sandero)	\N	2026-10-06 09:34:41.462926+00	2	\N	\N	\N	\N	b9d9c3fc-470e-492f-9ee8-85a01d42721e	relance
8896	933	160	2026-10-10	14:00-15:00	1	VN	Delcher florence R5/Twingo	\N	2026-10-06 10:26:32.435919+00	3	\N	\N	\N	\N	7b5f4545-0d96-4fcb-8bc2-cd1cb74217ee	relance
9066	933	97	2026-10-09	17:00-18:00	1	VN	RAYNAC	\N	2026-10-06 12:24:47.721228+00	1775	\N	\N	\N	\N	f82f2ed0-672c-4e6c-9d1e-58839e0c8fd7	relance
9177	933	15	2026-10-08	14:00-15:00	2	VN	SHMITT SANDERO	\N	2026-10-06 14:45:29.600642+00	5	\N	\N	\N	\N	4a4c7d78-93db-4bdd-831b-33880a64ba37	relance
9385	933	1886	2026-10-09	17:00-18:00	2	VN	CHARAIRE SANDERO	\N	2026-10-06 16:05:15.341765+00	1776	\N	\N	\N	\N	283ea56a-fa0b-496c-ac8d-5af92c0070a4	relance
9387	933	5	2026-10-09	17:00-18:00	1	VN	GIDEL TWINGO	\N	2026-10-06 16:05:37.052802+00	5	\N	\N	\N	\N	50db75b1-fce1-494f-8a48-5df3d133d691	relance
9389	933	83	2026-10-08	11:00-12:00	\N	VO	LANDES	\N	2026-10-06 16:09:07.275014+00	1776	\N	\N	\N	\N	efc225b4-02a5-4a9e-a093-a245d8b66a83	relance
9390	933	14	2026-10-09	14:00-15:00	1	VN	VINATIER (SANDERO)	\N	2026-10-06 16:09:34.56731+00	2	2026-10-06 16:09:48.74309+00	2	2026-10-06 16:09:49.557+00	2	aa50a62c-3107-47a6-8ee4-6fcc800fbbc3	relance
9464	933	12	2026-10-12	11:00-12:00	2	VN	LESAGE ( SPRING)	\N	2026-10-06 17:10:17.723155+00	2	\N	\N	\N	\N	be41abdd-4f9f-41fb-97e2-e7fed9758822	relance
9534	933	29	2026-10-08	14:00-15:00	3	VN	ROC	\N	2026-10-07 08:49:45.175782+00	5502	\N	\N	\N	\N	aa070f2e-f75c-410d-a19f-2e6c90d1e776	relance
9600	933	90	2026-10-08	14:00-15:00	2	VN	latrace duster	\N	2026-10-07 15:56:13.95662+00	1781	\N	\N	\N	\N	35af5852-3236-4511-8110-d400abfdf315	relance
9724	933	17	2026-10-09	11:00-12:00	1	VN	KIIEFFER TWINGO	\N	2026-10-09 14:38:19.260234+00	5	\N	\N	\N	\N	043c89dc-622c-4356-b8f8-275cbba05d04	relance
9789	933	60	2026-10-11	14:00-15:00	1	VN	FONTAINE	\N	2026-10-11 16:29:50.358808+00	7	\N	\N	\N	\N	d0586978-1c61-4081-9ab0-e9ef0a063d6a	showroom
2311	2	11	2026-09-14	14:00-15:00	1	VN	DUTEIL	\N	2026-09-08 14:42:41.65049+00	2	2026-09-08 14:43:07.8944+00	2	2026-09-08 14:43:08.508+00	2	\N	relance
2321	2	75	2026-09-10	11:00-12:00	1	VN	PORTE	\N	2026-09-08 14:44:01.026883+00	1778	\N	\N	\N	\N	\N	relance
2323	2	34	2026-09-13	15:00-16:00	1	VN	landrieaux	\N	2026-09-08 14:44:07.068411+00	97	\N	\N	\N	\N	\N	relance
2330	2	47	2026-09-10	08:00-09:00	\N	VO	ROMBAUT SANDERO	\N	2026-09-08 14:46:10.218566+00	1782	\N	\N	\N	\N	\N	relance
2331	2	44	2026-09-14	11:00-12:00	1	VN	CHASSAING	\N	2026-09-08 14:46:44.430309+00	1782	\N	\N	\N	\N	\N	relance
8708	933	12	2026-10-08	18:00-19:00	2	VN	ROBIN ( SPRING)	\N	2026-10-06 09:35:02.355185+00	2	\N	\N	\N	\N	62dc46b8-c47b-4f00-ab55-96efc97f4305	relance
8712	933	32	2026-10-09	09:00-10:00	2	VN	LIGER	\N	2026-10-06 09:36:46.552229+00	97	\N	\N	\N	\N	8387d3d9-885e-404c-9dcd-92cdc82e7d3c	relance
8709	933	68	2026-10-08	17:00-18:00	\N	VO	SAURET  ZOE	\N	2026-10-06 09:35:49.695526+00	7	2026-10-06 09:40:21.732802+00	7	\N	\N	551e32e0-875d-44c1-917b-d397b07b3f47	relance
8897	933	160	2026-10-11	15:00-16:00	1	VN	Demeuse Stephanie Twingo	\N	2026-10-06 10:27:06.573723+00	3	\N	\N	\N	\N	d2f74dea-aab3-4202-886f-17b80b4aa6dc	relance
8898	933	6	2026-10-09	08:00-09:00	1	VN	MARTY ( R5)	\N	2026-10-06 10:27:37.664258+00	2	\N	\N	\N	\N	bf8f2c8e-48b8-44b9-b8b4-1dfd28cc56bc	relance
9068	933	97	2026-10-10	14:00-15:00	1	VN	ATIK	\N	2026-10-06 12:24:56.784865+00	1775	\N	\N	\N	\N	06346cae-d709-43e4-b8cf-f6619078cea9	relance
9178	933	15	2026-10-08	17:00-18:00	2	VN	BLANC SANDERO	\N	2026-10-06 14:45:39.946286+00	5	\N	\N	\N	\N	2ee20f5c-c87f-4f42-95e2-cebe7842f734	relance
9391	933	17	2026-10-12	17:00-18:00	1	VN	Carriol Twingo	\N	2026-10-06 16:09:54.99284+00	3	\N	\N	\N	\N	2fb76dd1-be19-4ef4-b61e-25c95d4627a9	relance
9465	933	19	2026-10-12	18:00-19:00	1	VN	SAHUC (SYMBIOZ)	\N	2026-10-06 17:11:06.848296+00	2	\N	\N	\N	\N	206bc569-b68e-449e-912f-f7e39624a722	relance
9535	933	84	2026-10-11	11:00-12:00	\N	VO	BASCOUL	\N	2026-10-07 08:58:27.710005+00	1776	\N	\N	\N	\N	c9d5eada-f6f3-4fb4-a45c-562103caf8f0	relance
9602	933	78	2026-10-10	15:00-16:00	1	VN	LAGASSE	\N	2026-10-07 15:56:27.264098+00	1778	\N	\N	\N	\N	c9581e95-7aa5-4f92-a974-d947a3204fb0	relance
9725	933	17	2026-10-09	09:00-10:00	1	VN	RIBEIRO R5	\N	2026-10-09 14:38:31.747249+00	5	\N	\N	\N	\N	18e37716-0bf0-481f-b4ff-90d12ae9ebcf	relance
9790	933	60	2026-10-11	17:00-18:00	1	VN	ROUBIRA	\N	2026-10-11 16:31:06.805875+00	7	\N	\N	\N	\N	f25de62d-aad4-4f83-abc1-db1561ec97d4	showroom
2314	2	11	2026-09-14	18:00-19:00	1	VN	PELOUX CAPTUR	\N	2026-09-08 14:42:59.622851+00	2	\N	\N	\N	\N	\N	relance
2318	2	90	2026-09-10	18:00-19:00	1	VN	st marc	\N	2026-09-08 14:43:26.456404+00	1781	\N	\N	\N	\N	\N	relance
2312	2	11	2026-09-14	14:00-15:00	2	VN	DUTEIL SPRING	\N	2026-09-08 14:42:49.527209+00	2	2026-09-08 14:43:30.39823+00	2	\N	\N	\N	relance
8710	933	32	2026-10-08	09:00-10:00	2	VN	GUILLOT	\N	2026-10-06 09:36:16.566254+00	97	\N	\N	\N	\N	0e68bd26-44f9-49fc-be84-a9bdcb21d83c	relance
8711	933	32	2026-10-08	10:00-11:00	2	VN	GUEPIN	\N	2026-10-06 09:36:26.430309+00	97	\N	\N	\N	\N	1cb97251-67c0-4d19-ab40-03784e7ddf9d	relance
8715	933	32	2026-10-09	17:00-18:00	2	VN	DUFOUR MME	\N	2026-10-06 09:37:08.686399+00	97	\N	\N	\N	\N	288221b8-58f9-48aa-baa8-100cc1220c4f	relance
8899	933	16	2026-10-11	14:00-15:00	1	VN	Lafarge R4	\N	2026-10-06 10:28:05.779103+00	3	\N	\N	\N	\N	89ecc00e-e351-422a-ab6c-b67abb02dbb4	relance
9069	933	97	2026-10-08	15:00-16:00	1	VN	delperrier	\N	2026-10-06 12:53:58.763674+00	1775	\N	\N	\N	\N	5ee2ef2f-e4f4-469a-99c1-e0c0b3a0ca7d	relance
9179	933	15	2026-10-11	14:00-15:00	2	VN	CHALIER SANDERO	\N	2026-10-06 14:46:16.024129+00	5	\N	\N	\N	\N	e6d7d405-8404-417f-82d3-f1c8318f224a	relance
9394	933	18	2026-10-09	18:00-19:00	1	VN	coskoun  scenic	\N	2026-10-06 16:13:34.359893+00	4	\N	\N	\N	\N	cf669c45-c951-4709-9253-2680c3c6f10e	relance
9395	933	3216	2026-10-08	09:00-10:00	\N	VO	anastasia  duster	\N	2026-10-06 16:15:11.739372+00	4	\N	\N	\N	\N	65f24dc1-1bac-420d-9b6b-57f9c42499eb	relance
9466	933	2	2026-10-11	11:00-12:00	1	VN	Morange R4	\N	2026-10-06 17:12:29.888026+00	3	2026-10-06 17:12:58.666638+00	3	\N	\N	b71d85a4-4307-4cf1-8393-e824020338af	relance
9536	933	74	2026-10-08	15:00-16:00	2	VN	TOUZALIN	\N	2026-10-07 09:02:23.16191+00	5501	2026-10-07 09:02:35.853536+00	5501	2026-10-07 09:02:35.692+00	5501	af869087-2779-4133-a233-78fa59f12348	relance
9603	933	89	2026-10-09	12:00-13:00	1	VN	surneau scenic	\N	2026-10-07 16:07:02.748718+00	1781	\N	\N	\N	\N	521b1e6f-9419-476c-9f68-895fcace13fe	relance
9726	933	10	2026-10-09	10:00-11:00	1	VN	GUILLO TWINGO	\N	2026-10-09 14:55:15.914684+00	5	\N	\N	\N	\N	39dcb7f1-d8de-45a1-8f59-eedbfaaab90a	relance
9791	933	59	2026-10-11	12:00-13:00	1	VN	ROUSSON	\N	2026-10-11 16:42:50.516096+00	7	\N	\N	\N	\N	123e5320-9263-482a-abdf-15136928e0df	relance
2315	2	71	2026-09-12	12:00-13:00	1	VN	DUZAC	\N	2026-09-08 14:43:06.81877+00	1778	\N	\N	\N	\N	\N	relance
2324	2	34	2026-09-13	16:00-17:00	1	VN	passat	\N	2026-09-08 14:44:11.392043+00	97	\N	\N	\N	\N	\N	relance
8713	933	32	2026-10-09	14:00-15:00	2	VN	RAHLA	\N	2026-10-06 09:36:54.938771+00	97	\N	\N	\N	\N	7cb97022-e459-4edb-ac34-acc78a7becb1	relance
8900	933	51	2026-10-08	14:00-15:00	\N	VO	M DOZOLME	\N	2026-10-06 10:28:35.218128+00	1783	\N	\N	\N	\N	6864515f-f0f7-43e3-888b-f2a1a21bfcf8	relance
8905	933	6	2026-10-09	10:00-11:00	1	VN	DIOGON (AUSTRAL)	\N	2026-10-06 10:29:55.865073+00	2	\N	\N	\N	\N	07688e86-62f8-4d4b-82eb-48c3fab5117a	relance
8918	933	6	2026-10-09	18:00-19:00	2	VN	BUIS ( sandero stepway)	\N	2026-10-06 10:31:31.373064+00	2	\N	\N	\N	\N	ec0f0864-45cc-4b79-b668-15b2d6f4634f	relance
8922	933	60	2026-10-09	10:00-11:00	1	VN	ROUSSON	\N	2026-10-06 10:33:05.195232+00	9	\N	\N	\N	\N	e6a7b9ad-f46a-4847-93ac-6e3381fa0427	relance
8925	933	4206	2026-10-10	15:00-16:00	\N	VO	ABRANTES SCENIC	\N	2026-10-06 10:33:39.915441+00	1782	\N	\N	\N	\N	830ed442-f671-4766-805a-79f433c0bd76	relance
8926	933	14	2026-10-10	11:00-12:00	2	VN	BOURDELIER ( DUSTER BIGSTER)	\N	2026-10-06 10:34:03.29562+00	2	\N	\N	\N	\N	a045d644-5b73-4f36-bb2a-772477efde3b	relance
8934	933	12	2026-10-09	17:00-18:00	2	VN	BONNY( SANDERO)	\N	2026-10-06 10:36:13.057409+00	2	\N	\N	\N	\N	a6a419d1-44d6-4cb3-bd05-84a76e2bc9e2	relance
9070	933	96	2026-10-08	10:00-11:00	1	VN	GAYRAL	\N	2026-10-06 13:04:32.378637+00	1775	\N	\N	\N	\N	5a5ed828-adf3-483c-8794-d44a6d87457b	relance
9074	933	96	2026-10-11	10:00-11:00	1	VN	BENABER	\N	2026-10-06 13:05:02.812978+00	1775	\N	\N	\N	\N	3ca55af6-430c-4cd1-9f45-42f038154b26	relance
9076	933	96	2026-10-10	14:00-15:00	2	VN	DIAZ	\N	2026-10-06 13:05:18.559234+00	1775	\N	\N	\N	\N	d30e8aca-c770-47e9-8454-04d3bfba3505	relance
9180	933	5766	2026-10-10	11:00-12:00	\N	VO	GIBAUD / CLIO	\N	2026-10-06 14:52:52.142469+00	8	\N	\N	\N	\N	f839c2e6-3770-404e-8fe9-9c6bfab15f60	relance
9396	933	51	2026-10-09	14:00-15:00	\N	VO	M CHABROL	\N	2026-10-06 16:16:42.566955+00	1783	\N	\N	\N	\N	bdcb0762-ca8d-444a-bd16-3f1b1020d513	relance
9467	933	2	2026-10-12	15:00-16:00	1	VN	Usclade R5	\N	2026-10-06 17:12:49.770233+00	3	\N	\N	\N	\N	40290b42-f41a-43b0-873a-d3ca506d7f2c	relance
9537	933	74	2026-10-08	15:00-16:00	1	VN	TOUZALIN	\N	2026-10-07 09:02:46.758982+00	5501	\N	\N	\N	\N	cd5a891f-944b-4771-b5f7-5ab9a6dfd1de	relance
9604	933	75	2026-10-08	09:00-10:00	1	VN	BIAU	\N	2026-10-07 16:09:15.35331+00	1778	2026-10-07 16:09:32.513312+00	1778	2026-10-07 16:09:32.204+00	1778	1f6852de-abdb-4468-a3e2-dccf1fdbd011	relance
9611	933	75	2026-10-08	15:00-16:00	2	VN	PINEAU	\N	2026-10-07 16:10:21.124936+00	1778	\N	\N	\N	\N	b1b66224-1df5-4bf6-b35f-9af9a43a8c0a	relance
9727	933	92	2026-10-08	11:00-12:00	2	VN	LENZY	\N	2026-10-09 14:58:14.975467+00	1780	\N	\N	\N	\N	8afad83a-8e75-49e0-b094-560a97b821d6	relance
9792	933	59	2026-10-11	18:00-19:00	1	VN	CHALEY	\N	2026-10-11 16:43:19.240249+00	7	2026-10-11 16:43:31.585125+00	7	\N	\N	6ca28f2d-dbfb-4d32-a3ad-7675ac32df4f	relance
2317	2	34	2026-09-10	15:00-16:00	1	VN	soudan	\N	2026-09-08 14:43:23.670851+00	97	\N	\N	\N	\N	\N	relance
2327	2	90	2026-09-11	14:00-15:00	1	VN	moissie	\N	2026-09-08 14:44:47.219543+00	1781	\N	\N	\N	\N	\N	relance
8714	933	32	2026-10-09	16:00-17:00	2	VN	DUFOUR MR	\N	2026-10-06 09:37:01.940786+00	97	2026-10-06 09:37:12.798132+00	97	\N	\N	cf58be92-f42f-427d-8b3d-e31d80b56ea1	relance
8901	933	51	2026-10-08	15:00-16:00	\N	VO	DALBEGUE ELECTRIQUE	\N	2026-10-06 10:28:49.108634+00	1783	\N	\N	\N	\N	86fdeef5-519a-4197-aa1c-c666b0b66376	relance
9071	933	96	2026-10-08	16:00-17:00	1	VN	RAMIER	\N	2026-10-06 13:04:37.873447+00	1775	\N	\N	\N	\N	e64050f7-02ba-4efa-a030-044942da0171	relance
9073	933	96	2026-10-10	16:00-17:00	1	VN	THERONDEL	\N	2026-10-06 13:04:54.033148+00	1775	\N	\N	\N	\N	e4157e48-e020-46c2-b6ef-3cf14a305c8a	relance
9075	933	96	2026-10-11	14:00-15:00	1	VN	CARIE	\N	2026-10-06 13:05:07.017393+00	1775	\N	\N	\N	\N	87ec0053-c2a9-4fbe-a54d-715cbf17478b	relance
9077	933	96	2026-10-09	14:00-15:00	1	VN	GAREL	\N	2026-10-06 13:05:37.238876+00	1775	\N	\N	\N	\N	dc499c5d-68ab-4d5d-a910-10f8d55cfa56	relance
9181	933	10	2026-10-09	14:00-15:00	1	VN	barot  twingo	\N	2026-10-06 14:52:52.912223+00	4	\N	\N	\N	\N	5051774b-0aad-4463-9647-1f865f3d2a42	relance
9182	933	54	2026-10-08	11:00-12:00	1	VN	arraujo  R5	\N	2026-10-06 14:54:22.755676+00	7	\N	\N	\N	\N	5227de26-5b51-434a-92ea-68d0439ef556	relance
9397	933	35	2026-10-10	10:00-11:00	1	VN	DUGNE	\N	2026-10-06 16:17:46.940718+00	97	\N	\N	\N	\N	06a42938-0056-4f9b-9a58-bfbc72218947	relance
9468	933	2	2026-10-12	17:00-18:00	1	VN	Madic vo	\N	2026-10-06 17:13:07.773169+00	3	\N	\N	\N	\N	08d1e45f-2d2f-422d-b117-ec7b2180da8f	relance
9538	933	83	2026-10-08	15:00-16:00	\N	VO	SAGNET	\N	2026-10-07 09:08:09.450815+00	1776	\N	\N	\N	\N	80509428-5758-4a37-9bc9-ed50b36bbde4	relance
9605	933	75	2026-10-08	10:00-11:00	1	VN	ORROYOS	\N	2026-10-07 16:09:22.372253+00	1778	2026-10-07 16:09:35.565401+00	1778	2026-10-07 16:09:35.273+00	1778	e487067b-1ca7-4d2e-832d-a5988520df87	relance
9612	933	75	2026-10-09	14:00-15:00	2	VN	LAVERSENNE	\N	2026-10-07 16:10:27.870793+00	1778	\N	\N	\N	\N	d7b57d99-1fab-4cd0-9054-0f281c8c3901	relance
9613	933	75	2026-10-09	16:00-17:00	2	VN	MELENGO	\N	2026-10-07 16:10:41.107247+00	1778	\N	\N	\N	\N	215515ea-c152-44c8-a982-ab9ac34efe26	relance
9616	933	75	2026-10-10	16:00-17:00	2	VN	FAVAREL	\N	2026-10-07 16:11:07.105658+00	1778	\N	\N	\N	\N	3e452e7a-80c3-4ffb-848b-5311ecea81d2	relance
9728	933	16	2026-10-09	10:00-11:00	1	VN	SATURNIN R4	\N	2026-10-09 15:09:04.410004+00	5	\N	\N	\N	\N	3c8e4014-2b8b-4483-ae68-547c8a9cf117	relance
9793	933	59	2026-10-11	11:00-12:00	1	VN	DELTORCHIO  R5	\N	2026-10-11 16:44:05.289753+00	7	\N	\N	\N	\N	8a8806cd-f3ae-4b21-aee7-35abccf23690	relance
2320	2	1885	2026-09-12	15:00-16:00	1	VN	LALOY - CLIO VI	\N	2026-09-08 14:43:45.633794+00	1777	\N	\N	\N	\N	\N	relance
2325	2	90	2026-09-10	17:00-18:00	2	VN	lemaitre	\N	2026-09-08 14:44:16.575883+00	1781	\N	\N	\N	\N	\N	relance
2328	2	75	2026-09-10	09:00-10:00	1	VN	CAMINADE	\N	2026-09-08 14:45:11.706939+00	1778	\N	\N	\N	\N	\N	relance
2333	2	23	2026-09-10	18:00-19:00	\N	VO	SERVANTI	\N	2026-09-08 14:49:14.502507+00	3	\N	\N	\N	\N	\N	relance
2334	2	27	2026-09-14	17:00-18:00	1	VN	SIBIAL DUSTER	\N	2026-09-08 14:50:41.821793+00	5	\N	\N	\N	\N	\N	relance
2335	2	27	2026-09-13	10:00-11:00	1	VN	BORDAS CLIO	\N	2026-09-08 14:50:54.04882+00	5	\N	\N	\N	\N	\N	relance
2336	2	215	2026-09-14	09:00-10:00	\N	VO	HABRIAL	\N	2026-09-08 14:51:05.670142+00	3	\N	\N	\N	\N	\N	relance
2337	2	6	2026-09-11	15:00-16:00	1	VN	MATHIEU SCENIC E TECH	\N	2026-09-08 14:51:19.935803+00	5	\N	\N	\N	\N	\N	relance
2338	2	6	2026-09-11	17:00-18:00	1	VN	SURER R5 ETETCH	\N	2026-09-08 14:51:31.376093+00	5	\N	\N	\N	\N	\N	relance
2339	2	60	2026-09-12	11:00-12:00	2	VN	JURET	\N	2026-09-08 14:51:42.223204+00	7	\N	\N	\N	\N	\N	relance
8716	933	54	2026-10-08	09:00-10:00	1	VN	ROUSSEAU SCENIC	\N	2026-10-06 09:39:33.293432+00	7	\N	\N	\N	\N	2ecb2b33-b03c-47ae-bb20-c503ed45d424	relance
2341	2	6	2026-09-12	09:00-10:00	1	VN	BOURBONNER TWINGO	\N	2026-09-08 14:52:00.781446+00	5	\N	\N	\N	\N	\N	relance
2343	2	6	2026-09-12	14:00-15:00	1	VN	ACHIN AUSTRAL	\N	2026-09-08 14:52:19.685918+00	5	\N	\N	\N	\N	\N	relance
2344	2	1887	2026-09-10	14:00-15:00	\N	VO	M DUBOIS	\N	2026-09-08 14:52:21.855705+00	1783	\N	\N	\N	\N	\N	relance
2345	2	49	2026-09-12	09:00-10:00	1	VN	M DEBEUF	\N	2026-09-08 14:52:36.683442+00	1783	\N	\N	\N	\N	\N	relance
2346	2	6	2026-09-12	15:00-16:00	1	VN	DI SOCCIO TWINGO	\N	2026-09-08 14:52:38.716291+00	5	\N	\N	\N	\N	\N	relance
2347	2	49	2026-09-12	11:00-12:00	1	VN	M LOZERAL	\N	2026-09-08 14:52:44.320383+00	1783	\N	\N	\N	\N	\N	relance
2348	2	6	2026-09-12	17:00-18:00	1	VN	ZIMANOSKI MEGANE	\N	2026-09-08 14:52:56.062019+00	5	\N	\N	\N	\N	\N	relance
2349	2	49	2026-09-12	16:00-17:00	1	VN	M CHABANE	\N	2026-09-08 14:52:56.180145+00	1783	\N	\N	\N	\N	\N	relance
2350	2	50	2026-09-11	17:00-18:00	1	VN	M BONNAL	\N	2026-09-08 14:53:07.7629+00	1783	\N	\N	\N	\N	\N	relance
2352	2	50	2026-09-12	10:00-11:00	1	VN	M ARCHEMI	\N	2026-09-08 14:53:16.899489+00	1783	\N	\N	\N	\N	\N	relance
2353	2	48	2026-09-11	10:00-11:00	1	VN	M AUSSERT	\N	2026-09-08 14:53:32.507681+00	1783	\N	\N	\N	\N	\N	relance
2354	2	1887	2026-09-12	14:00-15:00	\N	VO	M DOGAN	\N	2026-09-08 14:53:44.260606+00	1783	\N	\N	\N	\N	\N	relance
2356	2	42	2026-09-14	16:00-17:00	2	VN	CROUES SANDERO	\N	2026-09-08 14:53:59.294876+00	1782	\N	\N	\N	\N	\N	relance
2357	2	50	2026-09-12	15:00-16:00	1	VN	MME MOINS	\N	2026-09-08 14:54:01.547146+00	1783	\N	\N	\N	\N	\N	relance
2359	2	42	2026-09-10	09:00-10:00	2	VN	THOMAS SANDERO	\N	2026-09-08 14:54:09.851403+00	1782	\N	\N	\N	\N	\N	relance
2361	2	50	2026-09-12	11:00-12:00	1	VN	M NORMANS	\N	2026-09-08 14:54:25.655418+00	1783	\N	\N	\N	\N	\N	relance
2364	2	6	2026-09-14	16:00-17:00	1	VN	ASTAIX AUSTRAL	\N	2026-09-08 14:54:55.988464+00	5	2026-09-09 16:29:23.068613+00	92	2026-09-09 16:29:22.748+00	92	\N	relance
2363	2	94	2026-09-12	16:00-17:00	1	VN	VEILLY	\N	2026-09-08 14:54:44.43329+00	1780	\N	\N	\N	\N	\N	relance
2365	2	94	2026-09-11	11:00-12:00	1	VN	LOUBIERES	\N	2026-09-08 14:55:06.622119+00	1780	\N	\N	\N	\N	\N	relance
2367	2	94	2026-09-12	11:00-12:00	1	VN	CANCHES	\N	2026-09-08 14:55:32.169144+00	1780	\N	\N	\N	\N	\N	relance
2371	2	5	2026-09-10	14:00-15:00	1	VN	TAILLANDIER MASTER	\N	2026-09-08 14:57:11.99243+00	5	\N	\N	\N	\N	\N	relance
2372	2	5	2026-09-10	15:00-16:00	1	VN	LABE KANGOO VU	\N	2026-09-08 14:57:20.683594+00	5	\N	\N	\N	\N	\N	relance
2373	2	5	2026-09-10	17:00-18:00	1	VN	BRUNEL AUSTRAL	\N	2026-09-08 14:57:27.301615+00	5	\N	\N	\N	\N	\N	relance
2374	2	87	2026-09-11	11:00-12:00	2	VN	BARBAUD - TWGO VO	\N	2026-09-08 14:57:28.761687+00	1777	\N	\N	\N	\N	\N	relance
2375	2	73	2026-09-11	09:00-10:00	1	VN	MICHEL	\N	2026-09-08 14:58:00.354019+00	1778	\N	\N	\N	\N	\N	relance
2377	2	882	2026-09-13	11:00-12:00	\N	VO	DARDELET / SCENIC VO	\N	2026-09-08 14:58:15.868206+00	8	\N	\N	\N	\N	\N	relance
2378	2	35	2026-09-11	17:00-18:00	1	VN	boukra	\N	2026-09-08 14:58:51.144306+00	97	\N	\N	\N	\N	\N	relance
2379	2	35	2026-09-12	11:00-12:00	1	VN	fouillot	\N	2026-09-08 14:59:06.778106+00	97	\N	\N	\N	\N	\N	relance
2380	2	35	2026-09-12	15:00-16:00	1	VN	desmaret	\N	2026-09-08 14:59:36.596967+00	97	\N	\N	\N	\N	\N	relance
2381	2	57	2026-09-12	16:00-17:00	\N	VO	CASTENET	\N	2026-09-08 14:59:49.486512+00	7	\N	\N	\N	\N	\N	relance
2382	2	90	2026-09-10	10:00-11:00	2	VN	garnier	\N	2026-09-08 15:01:12.850043+00	1781	\N	\N	\N	\N	\N	relance
2383	2	89	2026-09-12	09:00-10:00	1	VN	pons r5	\N	2026-09-08 15:03:06.471027+00	1781	2026-09-08 15:03:16.580768+00	1781	\N	\N	\N	relance
2384	2	1886	2026-09-10	16:00-17:00	2	VN	PUECH DUSTER	\N	2026-09-08 15:03:18.356684+00	1776	\N	\N	\N	\N	\N	relance
2385	2	89	2026-09-10	10:00-11:00	1	VN	brechet clio	\N	2026-09-08 15:03:32.477861+00	1781	\N	\N	\N	\N	\N	relance
2386	2	1886	2026-09-10	18:00-19:00	2	VN	VIARGUES SANDERO	\N	2026-09-08 15:03:34.622546+00	1776	\N	\N	\N	\N	\N	relance
2387	2	89	2026-09-10	15:00-16:00	2	VN	espinasse spring	\N	2026-09-08 15:03:53.713778+00	1781	\N	\N	\N	\N	\N	relance
2388	2	51	2026-09-14	14:00-15:00	\N	VO	M HALIME	\N	2026-09-08 15:03:59.766679+00	1783	\N	\N	\N	\N	\N	relance
2389	2	89	2026-09-12	11:00-12:00	1	VN	mas r5	\N	2026-09-08 15:04:23.733956+00	1781	\N	\N	\N	\N	\N	relance
2390	2	89	2026-09-12	17:00-18:00	1	VN	bost clio	\N	2026-09-08 15:04:40.969832+00	1781	\N	\N	\N	\N	\N	relance
2391	2	89	2026-09-14	14:00-15:00	2	VN	darbilly sand	\N	2026-09-08 15:05:16.937583+00	1781	\N	\N	\N	\N	\N	relance
2392	2	97	2026-09-12	16:00-17:00	1	VN	serres clio	\N	2026-09-08 15:05:19.23775+00	1775	\N	\N	\N	\N	\N	relance
2393	2	89	2026-09-14	17:00-18:00	1	VN	chambon austral	\N	2026-09-08 15:05:35.222165+00	1781	\N	\N	\N	\N	\N	relance
2394	2	16	2026-09-10	11:00-12:00	1	VN	PUYFAGE	\N	2026-09-08 15:06:00.756116+00	3	\N	\N	\N	\N	\N	relance
2395	2	16	2026-09-12	17:00-18:00	1	VN	GRENIER	\N	2026-09-08 15:06:09.598557+00	3	\N	\N	\N	\N	\N	relance
2396	2	60	2026-09-10	17:00-18:00	2	VN	TOURNADRE	\N	2026-09-08 15:06:10.228603+00	7	\N	\N	\N	\N	\N	relance
2397	2	79	2026-09-10	15:00-16:00	1	VN	GASSIM CAPTUR	\N	2026-09-08 15:07:23.666609+00	1776	\N	\N	\N	\N	\N	relance
2370	2	62	2026-09-11	16:00-17:00	2	VN	CROCOMBETTE	\N	2026-09-08 14:56:56.696468+00	7	2026-09-08 16:53:16.061021+00	7	2026-09-08 16:53:16.219+00	7	\N	relance
2368	2	14	2026-09-11	11:00-12:00	1	VN	MARTIN SANDERO	\N	2026-09-08 14:55:41.253918+00	5	2026-09-09 16:23:39.958981+00	92	2026-09-09 16:23:39.621+00	92	\N	relance
2369	2	14	2026-09-11	14:00-15:00	1	VN	SAURIN DUSTER	\N	2026-09-08 14:55:55.774048+00	5	2026-09-09 16:23:49.211481+00	92	2026-09-09 16:23:48.883+00	92	\N	relance
2358	2	6	2026-09-14	14:00-15:00	1	VN	ROYER SANDERO	\N	2026-09-08 14:54:05.819402+00	5	2026-09-09 16:24:51.650454+00	92	2026-09-09 16:24:51.187+00	92	\N	relance
2342	2	6	2026-09-12	10:00-11:00	1	VN	FOURNER SPRING	\N	2026-09-08 14:52:07.151384+00	5	2026-09-09 16:28:53.929554+00	92	2026-09-09 16:28:53.619+00	92	\N	relance
2351	2	6	2026-09-13	10:00-11:00	1	VN	JEANJEAN SANDERO	\N	2026-09-08 14:53:10.041403+00	5	2026-09-09 16:29:00.353062+00	92	2026-09-09 16:29:00.006+00	92	\N	relance
2355	2	6	2026-09-14	09:00-10:00	1	VN	BONABRI SPRING	\N	2026-09-08 14:53:45.746422+00	5	2026-09-09 16:29:05.641288+00	92	2026-09-09 16:29:05.298+00	92	\N	relance
2362	2	6	2026-09-14	15:00-16:00	1	VN	EVENO SANDERO	\N	2026-09-08 14:54:34.712788+00	5	2026-09-09 16:29:19.907925+00	92	2026-09-09 16:29:19.579+00	92	\N	relance
2398	2	42	2026-09-12	10:00-11:00	2	VN	BISSON SANDERO	\N	2026-09-08 15:07:31.244727+00	1782	\N	\N	\N	\N	\N	relance
2405	2	72	2026-09-11	15:00-16:00	1	VN	RAVAZIO	\N	2026-09-08 15:09:04.058403+00	1778	\N	\N	\N	\N	\N	relance
2410	2	54	2026-09-10	09:00-10:00	1	VN	BOYER / TWINGO	\N	2026-09-08 15:09:39.903241+00	8	\N	\N	\N	\N	\N	relance
8902	933	51	2026-10-10	09:00-10:00	\N	VO	M RIVIERE	\N	2026-10-06 10:29:02.170925+00	1783	\N	\N	\N	\N	185646ee-36c3-4d5b-967e-3ffd422bcadd	relance
9072	933	96	2026-10-09	10:00-11:00	1	VN	CUVELIER	\N	2026-10-06 13:04:50.817836+00	1775	\N	\N	\N	\N	21018a5c-1201-41a1-ad0a-00fbf0e044ea	relance
9183	933	59	2026-10-11	17:00-18:00	1	VN	RUVIRA  CAPTUR	\N	2026-10-06 14:55:01.647064+00	7	\N	\N	\N	\N	b1f77314-9bca-4287-a433-c02a6d16565a	relance
8717	933	14	2026-10-08	09:00-10:00	2	VN	VINATIER ( SANDERO)	\N	2026-10-06 09:46:27.397438+00	2	2026-10-06 16:10:18.027291+00	2	2026-10-06 16:10:18.871+00	2	c213d218-035f-42b4-8d1d-8f274fdc29d9	relance
9398	933	4204	2026-10-09	15:00-16:00	2	VN	JACQUI SANDERO	\N	2026-10-06 16:21:15.437383+00	1782	\N	\N	\N	\N	52496a0b-843b-49e0-8271-8649574c0eec	relance
9469	933	17	2026-10-12	12:00-13:00	1	VN	Rigaud r5/megane	\N	2026-10-06 17:15:25.931602+00	3	\N	\N	\N	\N	9f9555d7-58cb-4287-a497-b19aa065de92	relance
9539	933	83	2026-10-09	15:00-16:00	\N	VO	DD	\N	2026-10-07 09:08:16.463879+00	1776	2026-10-07 09:08:20.475615+00	1776	2026-10-07 09:08:20.35+00	1776	ff84cc79-971c-486a-bd6b-3bad1e1657f9	relance
9606	933	75	2026-10-08	12:00-13:00	1	VN	BLA	\N	2026-10-07 16:09:28.346159+00	1778	2026-10-07 16:09:39.126374+00	1778	2026-10-07 16:09:38.815+00	1778	3e606549-05b8-4d62-9ef7-48f4d94e155f	relance
9607	933	75	2026-10-08	08:00-09:00	2	VN	BEAU	\N	2026-10-07 16:09:52.682294+00	1778	\N	\N	\N	\N	8328da0b-e05a-4765-a374-2c2053d02fcc	relance
9614	933	75	2026-10-10	11:00-12:00	2	VN	TRUCHET	\N	2026-10-07 16:10:54.42295+00	1778	\N	\N	\N	\N	f414dab3-4a7d-4e7c-a694-532ac5cdea18	relance
9729	933	61	2026-10-10	16:00-17:00	\N	VO	PRADERE	\N	2026-10-09 15:11:10.672361+00	7	\N	\N	\N	\N	e3d358b2-e24f-4851-bd07-a3c18214129e	relance
9794	933	2	2026-10-11	08:00-09:00	1	VN	THION	\N	2026-10-12 06:01:52.873271+00	2	\N	\N	\N	\N	af2d5f43-92db-4f7e-8888-6c3250834fb2	showroom
9795	933	2	2026-10-11	09:00-10:00	1	VN	BLANQUET	\N	2026-10-12 06:02:29.367121+00	2	\N	\N	\N	\N	8b51e16c-75ec-4dc3-a42d-5f7290400c6b	showroom
9796	933	2	2026-10-11	14:00-15:00	2	VN	AUDIBERT	\N	2026-10-12 06:02:57.2407+00	2	\N	\N	\N	\N	a7318409-b440-4141-9cf6-767bc047fd37	showroom
2399	2	15	2026-09-12	10:00-11:00	2	VN	GABRILLARGUES DUSTER	\N	2026-09-08 15:07:53.693795+00	2	\N	\N	\N	\N	\N	relance
2417	2	80	2026-09-12	15:00-16:00	1	VN	RAYNAL CLIO 5	\N	2026-09-08 15:10:49.375036+00	1776	\N	\N	\N	\N	\N	relance
8718	933	14	2026-10-08	14:00-15:00	2	VN	TAILLANDIER	\N	2026-10-06 09:46:49.024013+00	2	\N	\N	\N	\N	5fc41982-b1c1-4000-be04-edf610e35705	relance
8903	933	6	2026-10-09	09:00-10:00	1	VN	GOUTTEBEL ( TWINGO)	\N	2026-10-06 10:29:38.493268+00	2	\N	\N	\N	\N	10ce2332-25dc-4dd1-b82b-30d7c4ed435f	relance
8914	933	56	2026-10-09	15:00-16:00	1	VN	MARET TWINGO	\N	2026-10-06 10:31:02.789929+00	7	\N	\N	\N	\N	ee4ca1e1-19a0-4141-a47f-0e0559bba56c	relance
8911	933	6	2026-10-09	15:00-16:00	2	VN	MALLET ( SANDERO AUTOMATIQUE)	\N	2026-10-06 10:30:44.37527+00	2	2026-10-06 10:31:12.576578+00	2	\N	\N	eb238219-02a8-42e5-90c9-927e8641104d	relance
8917	933	56	2026-10-09	17:00-18:00	1	VN	MILLARD TWINGO	\N	2026-10-06 10:31:17.8501+00	7	\N	\N	\N	\N	d59ad2b1-1c38-41d4-b4fe-005dd2343b62	relance
9078	933	95	2026-10-09	15:00-16:00	1	VN	ROUCHES	\N	2026-10-06 13:34:26.777581+00	1780	\N	\N	\N	\N	3648306f-7918-4af7-abeb-25257f804908	relance
9184	933	3215	2026-10-09	10:00-11:00	1	VN	loubaresse  scenic	\N	2026-10-06 14:55:54.024544+00	4	\N	\N	\N	\N	36b998a6-77f4-4c79-9037-9b685ee46158	relance
9399	933	33	2026-10-11	14:00-15:00	1	VN	DAUPHANT	\N	2026-10-06 16:21:46.96638+00	97	\N	\N	\N	\N	af871957-507a-4366-a9d1-aa454213fd7b	relance
9470	933	94	2026-10-10	10:00-11:00	1	VN	Plaina	\N	2026-10-06 18:39:08.6086+00	1780	\N	\N	\N	\N	750a134f-8445-4d2f-a88b-b724d5f44a3e	relance
9540	933	85	2026-10-09	09:00-10:00	\N	VO	POUCHOU	\N	2026-10-07 09:08:51.748125+00	1776	\N	\N	\N	\N	a3d8e98a-aa31-4eb5-8617-453037fabd40	relance
9608	933	75	2026-10-08	10:00-11:00	2	VN	ORROYOS	\N	2026-10-07 16:09:58.599734+00	1778	\N	\N	\N	\N	a07e618b-1d4c-4acd-9190-ef893100f560	relance
9610	933	75	2026-10-08	13:00-14:00	2	VN	MAS	\N	2026-10-07 16:10:10.567489+00	1778	\N	\N	\N	\N	227e07e9-38ae-4bfc-b29b-6a7202338084	relance
9615	933	75	2026-10-10	14:00-15:00	2	VN	RICAZRD	\N	2026-10-07 16:11:02.139969+00	1778	\N	\N	\N	\N	1063542e-a94b-4dd1-81d8-d30c053f70e7	relance
9617	933	75	2026-10-10	12:00-13:00	1	VN	PALAZY	\N	2026-10-07 16:11:28.053174+00	1778	\N	\N	\N	\N	d51947da-7426-4e63-afc5-1e84e919ed42	relance
9730	933	61	2026-10-11	14:00-15:00	\N	VO	DIGBEU	\N	2026-10-09 15:13:51.429439+00	7	\N	\N	\N	\N	138abdb1-3402-484d-b3ec-ee6699912d68	relance
1759	2	79	2026-09-10	09:00-10:00	1	VN	DESMESURE TW3	\N	2026-09-08 09:37:38.329405+00	1776	2026-09-08 15:07:54.312782+00	1776	2026-09-08 15:07:54.308+00	1776	\N	relance
8719	933	14	2026-10-09	09:00-10:00	2	VN	CHAHID ( SANDERO)	\N	2026-10-06 09:47:08.635616+00	2	\N	\N	\N	\N	266d8c21-6a96-4706-b605-b58cc7ae7a42	relance
8904	933	10	2026-10-08	11:00-12:00	1	VN	fontes  captur	\N	2026-10-06 10:29:45.810512+00	4	\N	\N	\N	\N	2e3012d2-9fc7-49e7-bca9-50ddbe027fe2	relance
8906	933	48	2026-10-08	10:00-11:00	1	VN	M DA SILVA	\N	2026-10-06 10:30:09.386209+00	1783	\N	\N	\N	\N	ffdc837d-8eed-4b74-929d-575ae46cd342	relance
8912	933	48	2026-10-10	09:00-10:00	1	VN	GUERREIRO	\N	2026-10-06 10:30:48.861749+00	1783	\N	\N	\N	\N	2ad094ae-b1ac-4814-bc8a-7e5be11270b3	relance
9079	933	95	2026-10-10	15:00-16:00	1	VN	PEYRE	\N	2026-10-06 13:34:37.595237+00	1780	\N	\N	\N	\N	228dfde6-ff96-493a-b875-a7489f5ff82f	relance
9185	933	3215	2026-10-10	10:00-11:00	1	VN	de araujo r5	\N	2026-10-06 14:56:11.781888+00	4	\N	\N	\N	\N	89f93317-61d5-4a2a-a774-8558a89aa2f4	relance
9400	933	33	2026-10-11	16:00-17:00	1	VN	HURDIEL 1	\N	2026-10-06 16:22:00.106906+00	97	\N	\N	\N	\N	cb3122b2-91cf-4257-8bf7-ea27a4107a77	relance
9471	933	94	2026-10-12	14:00-15:00	1	VN	Gauzin	\N	2026-10-06 19:31:06.672742+00	1780	\N	\N	\N	\N	31678dde-2a83-4e73-9cc4-cd3f4f462254	relance
9541	933	5770	2026-10-08	14:00-15:00	3	VN	LEOTY	\N	2026-10-07 09:23:18.020795+00	5502	\N	\N	\N	\N	5aaa7c73-3aba-4c6e-a47f-d8161fd3b942	relance
9609	933	75	2026-10-08	11:00-12:00	2	VN	BLANC	\N	2026-10-07 16:10:04.471636+00	1778	\N	\N	\N	\N	6683d1d7-a2ba-4533-a194-0680f5ae42c2	relance
9731	933	61	2026-10-08	14:00-15:00	\N	VO	GAPAIX SYLVIE	\N	2026-10-09 15:27:55.47341+00	7	\N	\N	\N	\N	2390476d-afea-4cef-a16a-31bbd673946f	showroom
2400	2	9	2026-09-12	15:00-16:00	\N	VO	vaz	\N	2026-09-08 15:08:16.335851+00	6	\N	\N	\N	\N	\N	relance
2401	2	18	2026-09-10	14:00-15:00	1	VN	SEGAUD SCENIC	\N	2026-09-08 15:08:28.6541+00	4	\N	\N	\N	\N	\N	relance
2407	2	18	2026-09-11	10:00-11:00	1	VN	DAOULAS CLIO	\N	2026-09-08 15:09:18.45764+00	4	\N	\N	\N	\N	\N	relance
2415	2	80	2026-09-11	10:00-11:00	1	VN	RIEU CLIO 6	\N	2026-09-08 15:10:17.413401+00	1776	\N	\N	\N	\N	\N	relance
8720	933	19	2026-10-08	08:00-09:00	1	VN	DURAND ( TWINGO)	\N	2026-10-06 09:47:48.575315+00	2	\N	\N	\N	\N	dedf6a48-5c8e-4071-b3f3-22d9e63964e3	relance
8723	933	19	2026-10-08	10:00-11:00	1	VN	CANALES ( ESPACE)	\N	2026-10-06 09:48:13.141187+00	2	\N	\N	\N	\N	2a2b0fb5-1493-4824-8d74-8ed357332e50	relance
8725	933	60	2026-10-09	17:00-18:00	2	VN	BUISSON	\N	2026-10-06 09:48:34.275947+00	9	\N	\N	\N	\N	90ee2981-fb9f-4060-a8ca-80a073e95a89	relance
8907	933	6	2026-10-09	14:00-15:00	2	VN	PEYRIND ( SANDER STEPWAY)	\N	2026-10-06 10:30:20.674718+00	2	\N	\N	\N	\N	2d03fe16-e153-49f3-ba72-31518253540d	relance
8916	933	65	2026-10-10	09:00-10:00	1	VN	VERRIER / MEGANE	\N	2026-10-06 10:31:15.922551+00	8	\N	\N	\N	\N	0b09104a-2d9e-4477-9fd8-eee8613b4aa7	relance
8919	933	5766	2026-10-10	14:00-15:00	\N	VO	CHANAL / SANDERO	\N	2026-10-06 10:31:35.265503+00	8	\N	\N	\N	\N	94ebeb8b-1491-4547-bca4-0b30dc5957f5	relance
8920	933	59	2026-10-12	13:00-14:00	1	VN	TICHET MEGANE	\N	2026-10-06 10:32:02.898095+00	7	\N	\N	\N	\N	a0910330-8cbe-48de-803a-3d5a05fe4318	relance
8923	933	26	2026-10-09	14:00-15:00	1	VN	CHANTELAIN ( CLIO)	\N	2026-10-06 10:33:09.93439+00	2	\N	\N	\N	\N	556a4f60-80f2-48e4-8ef2-7884999dea01	relance
8930	933	12	2026-10-09	10:00-11:00	2	VN	DELBEGUE (SPRING°	\N	2026-10-06 10:35:07.722842+00	2	\N	\N	\N	\N	e6f59830-fdf3-491b-b4e7-f0ee875c91db	relance
9080	933	95	2026-10-11	14:00-15:00	2	VN	LE SAOUT	\N	2026-10-06 13:34:58.178693+00	1780	\N	\N	\N	\N	77127793-5c92-446d-9b30-086f490e9aab	relance
9186	933	3215	2026-10-12	11:00-12:00	1	VN	camoux  r5  le 15/10	\N	2026-10-06 14:56:43.49714+00	4	2026-10-06 14:56:52.216822+00	4	\N	\N	93e7b0de-d674-4898-8e08-e0cb11c8cf54	relance
9187	933	3215	2026-10-09	11:00-12:00	1	VN	fouconnier r5	\N	2026-10-06 14:57:02.445289+00	4	\N	\N	\N	\N	627adfcc-26f4-4534-a5e9-180fa3e69148	relance
9190	933	94	2026-10-09	16:00-17:00	2	VN	HENRY	\N	2026-10-06 14:57:36.898249+00	1780	\N	\N	\N	\N	56ceb2ed-6cfb-43b0-a9d9-60de90f238f0	relance
9194	933	57	2026-10-08	10:00-11:00	\N	VO	BOYER	\N	2026-10-06 14:58:24.534741+00	9	\N	\N	\N	\N	d4e257fc-7d39-42be-9ef9-fd5d4b9e5f79	relance
9198	933	69	2026-10-09	14:00-15:00	\N	VO	VERRIEL	\N	2026-10-06 14:58:56.581514+00	8	\N	\N	\N	\N	5cf649aa-d338-4c3f-bbc7-ccc04bba647e	relance
9401	933	4204	2026-10-09	10:00-11:00	1	VN	PARAUT SYMBIOZ	\N	2026-10-06 16:22:00.457438+00	1782	\N	\N	\N	\N	13677c32-3607-485a-ae9e-e8150c564da8	relance
9472	933	93	2026-10-10	11:00-12:00	2	VN	FAIVRE	\N	2026-10-07 06:58:22.260744+00	1780	\N	\N	\N	\N	551926b2-fc49-483a-a07b-6f9a9ab52ac6	relance
9542	933	5770	2026-10-09	10:00-11:00	3	VN	GUIBARD	\N	2026-10-07 09:23:54.941664+00	5502	\N	\N	\N	\N	0ef4f76b-10db-4b39-801b-9b69c8be02c1	relance
9618	933	61	2026-10-08	14:00-15:00	\N	VO	PUEL ZOE OU SPRING	\N	2026-10-07 16:11:46.65095+00	7	\N	\N	\N	\N	e6da76d2-4d55-4155-9028-5df311e520c9	relance
9732	933	73	2026-10-09	16:00-17:00	1	VN	ALQUIER	\N	2026-10-09 15:28:41.26567+00	5501	\N	\N	\N	\N	8fd77245-6274-427e-b937-b4ba93333693	relance
9734	933	73	2026-10-09	17:00-18:00	2	VN	ALQUIE	\N	2026-10-09 15:28:55.966761+00	5501	\N	\N	\N	\N	2d36a197-60d6-484c-8892-5b0cd28df25f	relance
2402	2	54	2026-09-13	09:00-10:00	1	VN	SYLVESTRE / ALPINE A 290	\N	2026-09-08 15:08:32.51981+00	8	\N	\N	\N	\N	\N	relance
2403	2	72	2026-09-11	09:00-10:00	1	VN	GASTON	\N	2026-09-08 15:08:57.504238+00	1778	\N	\N	\N	\N	\N	relance
2411	2	72	2026-09-14	10:00-11:00	1	VN	JOUNEAU	\N	2026-09-08 15:09:56.410616+00	1778	\N	\N	\N	\N	\N	relance
8721	933	19	2026-10-08	09:00-10:00	1	VN	DEFRANCE ( R5)	\N	2026-10-06 09:48:00.869551+00	2	\N	\N	\N	\N	a0e3518f-076d-43e2-ab4d-4a6671b90086	relance
8908	933	48	2026-10-08	14:00-15:00	1	VN	M NENOT	\N	2026-10-06 10:30:29.992662+00	1783	\N	\N	\N	\N	0d9bc13e-11a9-401d-af32-8fbd118feaed	relance
8915	933	35	2026-10-09	09:00-10:00	1	VN	MOUSSODUN	\N	2026-10-06 10:31:06.938641+00	97	\N	\N	\N	\N	6f6d2ea2-0312-494a-8d28-1e872d2b5a28	relance
9081	933	53	2026-10-08	09:00-10:00	1	VN	BRUHAT	\N	2026-10-06 13:41:08.302748+00	9	\N	\N	\N	\N	a1a196aa-0ca2-4682-bdfc-32eb01370c1f	relance
9188	933	69	2026-10-08	16:00-17:00	\N	VO	CLEMEMORELLE	\N	2026-10-06 14:57:17.813418+00	8	\N	\N	\N	\N	d59d9849-1043-4b64-9b1e-9e626490ad66	relance
9402	933	33	2026-10-11	17:00-18:00	1	VN	HURDIEL 2	\N	2026-10-06 16:22:04.707205+00	97	\N	\N	\N	\N	be3d124f-676c-4e90-bb1b-c0553f0e6bf4	relance
9473	933	79	2026-10-10	11:00-12:00	2	VN	HERANT	\N	2026-10-07 07:09:03.549202+00	1776	2026-10-07 07:09:08.82392+00	1776	2026-10-07 07:09:08.643+00	1776	68462489-7904-4966-b5bd-799a9358a38d	relance
9543	933	5770	2026-10-10	09:00-10:00	3	VN	IMPECO	\N	2026-10-07 09:24:06.75117+00	5502	\N	\N	\N	\N	30316ac5-715e-451d-a322-6e34d4e2977b	relance
9619	933	61	2026-10-08	15:00-16:00	\N	VO	RICHEPAIN  CLIO	\N	2026-10-07 16:12:13.799377+00	7	\N	\N	\N	\N	7223acc5-a9ac-4b01-a652-b3ec069cc549	relance
9626	933	61	2026-10-10	09:00-10:00	\N	VO	BUISSON MEGANE	\N	2026-10-07 16:13:04.228771+00	7	\N	\N	\N	\N	9acde6db-0438-45bd-b5c6-73d21a89b29b	relance
9629	933	99	2026-10-10	11:00-12:00	1	VN	BADMULER	\N	2026-10-07 16:13:22.430444+00	1778	\N	\N	\N	\N	d934a7bd-1afd-4f74-89e9-989d8747c506	relance
9733	933	73	2026-10-09	17:00-18:00	1	VN	ALQUIE	\N	2026-10-09 15:28:50.492395+00	5501	2026-10-09 15:28:52.964062+00	5501	2026-10-09 15:28:52.864+00	5501	47760935-7183-4686-9218-2c9508ae64f3	relance
2404	2	57	2026-09-11	17:00-18:00	\N	VO	RAYNAUD	\N	2026-09-08 15:09:00.431404+00	7	\N	\N	\N	\N	\N	relance
2414	2	23	2026-09-12	10:00-11:00	\N	VO	CALVIRAC	\N	2026-09-08 15:10:10.893028+00	3	\N	\N	\N	\N	\N	relance
8722	933	60	2026-10-09	14:00-15:00	1	VN	BLAQUIERES	\N	2026-10-06 09:48:10.474898+00	9	\N	\N	\N	\N	4bf594e9-8c8e-4a26-9552-e89df5c3c7ef	relance
8909	933	48	2026-10-09	14:00-15:00	1	VN	M SAVAY	\N	2026-10-06 10:30:39.555059+00	1783	\N	\N	\N	\N	9f8eaa7d-2ae0-4806-ae9e-5aea719f61c2	relance
9082	933	70	2026-10-09	11:00-12:00	\N	VO	LEYRELOU TWINGO	\N	2026-10-06 13:41:12.234045+00	7	\N	\N	\N	\N	fae20e98-b41a-4b6f-9a44-e8a2d7745e3f	relance
9189	933	69	2026-10-08	15:00-16:00	\N	VO	MORS	\N	2026-10-06 14:57:27.284264+00	8	\N	\N	\N	\N	3753ddf6-302e-4a5d-8076-f73ce2733d96	relance
9193	933	10	2026-10-12	09:00-10:00	1	VN	chereau  r5  le 17/10	\N	2026-10-06 14:58:17.642774+00	4	\N	\N	\N	\N	7f507150-71ae-4865-a5c1-75bf66766ede	relance
9403	933	4204	2026-10-11	11:00-12:00	2	VN	LANGELET SANDERO	\N	2026-10-06 16:22:20.55972+00	1782	\N	\N	\N	\N	9ccea4e2-8e46-4cbc-8b6d-0b7083b2083c	relance
9474	933	79	2026-10-10	11:00-12:00	1	VN	HERANT	\N	2026-10-07 07:09:12.535948+00	1776	\N	\N	\N	\N	7a782283-c890-4976-a0e1-469807bae44b	relance
9544	933	5770	2026-10-12	09:00-10:00	3	VN	FROMENTY	\N	2026-10-07 09:24:23.455483+00	5502	\N	\N	\N	\N	97084545-e219-406a-96e4-af88ff0609b7	relance
9623	933	99	2026-10-08	14:00-15:00	1	VN	DUBUIS	\N	2026-10-07 16:12:45.014929+00	1778	\N	\N	\N	\N	9d4c6aae-2222-47d8-9ff6-b2467cb4d30f	relance
9630	933	61	2026-10-11	10:00-11:00	\N	VO	SOLEILLAC SANDERO	\N	2026-10-07 16:13:22.74215+00	7	\N	\N	\N	\N	e56f4155-df48-4c69-9c1c-77103a7df73f	relance
9633	933	99	2026-10-12	10:00-11:00	2	VN	RAPELE	\N	2026-10-07 16:13:48.734037+00	1778	\N	\N	\N	\N	ad3676fd-e248-48f6-9bed-ab0cbe8eaf6d	relance
9635	933	99	2026-10-12	15:00-16:00	2	VN	LABOUREAU	\N	2026-10-07 16:14:09.415269+00	1778	\N	\N	\N	\N	3314f8fb-95c3-4a53-bcb5-4ebfd0a43d04	relance
9620	933	61	2026-10-09	09:00-10:00	\N	VO	PRADERE CAPTURE	\N	2026-10-07 16:12:24.99874+00	7	2026-10-09 15:10:56.821177+00	7	2026-10-09 15:10:56.97+00	7	1c3384d6-52ba-411b-945a-2793a6af9e1b	relance
9735	933	73	2026-10-09	18:00-19:00	1	VN	BEDEL	\N	2026-10-09 15:29:13.618199+00	5501	\N	\N	\N	\N	ab1e66a4-8bc1-42ee-881e-778fdd84a179	relance
2406	2	72	2026-09-11	17:00-18:00	1	VN	JOUCLA	\N	2026-09-08 15:09:10.8225+00	1778	\N	\N	\N	\N	\N	relance
2409	2	80	2026-09-11	09:00-10:00	1	VN	CHERUE CLIO 6	\N	2026-09-08 15:09:34.977783+00	1776	2026-09-08 15:09:37.064007+00	1776	2026-09-08 15:09:37.387+00	1776	\N	relance
2412	2	80	2026-09-11	09:00-10:00	1	VN	CHERUE	\N	2026-09-08 15:09:58.916036+00	1776	\N	\N	\N	\N	\N	relance
8910	933	56	2026-10-09	10:00-11:00	1	VN	POSTIC AUSTRAL	\N	2026-10-06 10:30:43.418012+00	7	\N	\N	\N	\N	f4cff82a-9617-4d62-9190-e7afd8adb412	relance
9083	933	65	2026-10-08	09:00-10:00	1	VN	grousset/ kangoo elec	\N	2026-10-06 13:41:44.148316+00	8	\N	\N	\N	\N	6142f7d7-8647-4eb5-a15d-12bcd460004d	relance
9191	933	60	2026-10-08	11:00-12:00	2	VN	DE NYS BIGSTER	\N	2026-10-06 14:57:59.073944+00	7	\N	\N	\N	\N	edacb00a-ba6f-4d1b-9d7b-47f05942042a	relance
9195	933	26	2026-10-08	09:00-10:00	1	VN	PAPON (TWINGO)	\N	2026-10-06 14:58:31.567973+00	2	\N	\N	\N	\N	6da56b80-6532-455b-a172-11014ed091b6	relance
9404	933	34	2026-10-09	10:00-11:00	1	VN	ROCHE	\N	2026-10-06 16:23:37.731939+00	97	\N	\N	\N	\N	eb0f7a7a-d27d-4e14-b3d3-b119cebb5a31	relance
9475	933	96	2026-10-12	10:00-11:00	1	VN	ROUALDES	\N	2026-10-07 07:12:23.670563+00	1775	\N	\N	\N	\N	62d92c3a-0d72-4e0c-90fd-e5f29e6cd80f	relance
9545	933	97	2026-10-11	10:00-11:00	1	VN	lartigaud	\N	2026-10-07 09:42:03.701268+00	1775	\N	\N	\N	\N	47e93a6d-26e5-419d-9903-ba4ad3c46eee	relance
9621	933	99	2026-10-08	11:00-12:00	1	VN	TORCHIA	\N	2026-10-07 16:12:35.057427+00	1778	\N	\N	\N	\N	54ce4c50-61ee-43b3-9236-9b256b0b1a2f	relance
9624	933	99	2026-10-08	17:00-18:00	1	VN	ICHEM	\N	2026-10-07 16:12:49.894415+00	1778	\N	\N	\N	\N	b5b43143-49e0-4a68-b149-deb31da04adf	relance
9628	933	99	2026-10-09	18:00-19:00	1	VN	ROBERT	\N	2026-10-07 16:13:11.366704+00	1778	\N	\N	\N	\N	8c65e831-27b5-4c98-ae6e-b4f1b92a7789	relance
9634	933	99	2026-10-12	12:00-13:00	2	VN	DUPUIS	\N	2026-10-07 16:13:54.90285+00	1778	2026-10-07 16:14:02.051965+00	1778	\N	\N	763750f4-1fee-441e-86e4-cef57dd1550f	relance
9736	933	5768	2026-10-09	18:00-19:00	\N	VO	DE NOUELLE	\N	2026-10-09 15:47:07.918272+00	5501	\N	\N	\N	\N	8068a321-5157-4c3f-b474-3f5c1c6ac03a	relance
8724	933	60	2026-10-11	10:00-11:00	1	VN	TRINQUE	\N	2026-10-06 09:48:23.155262+00	9	2026-10-11 08:03:48.017662+00	7	2026-10-11 08:03:48.755+00	7	3414ff1e-1754-421a-ad10-64bbdcb6a278	relance
2408	2	72	2026-09-11	11:00-12:00	2	VN	MEHAYE	\N	2026-09-08 15:09:25.445096+00	1778	\N	\N	\N	\N	\N	relance
2416	2	80	2026-09-12	09:00-10:00	1	VN	BLAZY TW3	\N	2026-09-08 15:10:37.049507+00	1776	\N	\N	\N	\N	\N	relance
8726	933	19	2026-10-08	11:00-12:00	1	VN	GRENIER (SCENIC)	\N	2026-10-06 09:48:43.933732+00	2	\N	\N	\N	\N	c89d2a6d-029f-4816-be78-27341d1b2bd3	relance
8913	933	6	2026-10-09	17:00-18:00	2	VN	GOFFIER	\N	2026-10-06 10:30:52.756181+00	2	\N	\N	\N	\N	ff4cbc65-cbde-4608-8721-652692438fc0	relance
8928	933	14	2026-10-11	09:00-10:00	2	VN	BONNEMOY ( SPRING)	\N	2026-10-06 10:34:24.314636+00	2	\N	\N	\N	\N	e9c3b037-0f30-4484-8bda-afb950cdcb34	relance
8929	933	12	2026-10-09	09:00-10:00	2	VN	KELLER ( DUSTER)	\N	2026-10-06 10:34:51.627792+00	2	\N	\N	\N	\N	e9a3f13a-6fed-423e-921a-0d642780b8ea	relance
8933	933	12	2026-10-09	15:00-16:00	2	VN	CHARNIER ( DUSTER)	\N	2026-10-06 10:35:59.775094+00	2	\N	\N	\N	\N	9441187e-5a87-443d-ac66-5029fa304be5	relance
8932	933	12	2026-10-09	14:00-15:00	2	VN	FOURTIN ( DUSTER)	\N	2026-10-06 10:35:45.170492+00	2	2026-10-06 10:36:24.760884+00	2	\N	\N	86ef5bce-4b83-44c8-a47a-cfbfd183fbdc	relance
9084	933	65	2026-10-11	09:00-10:00	1	VN	ALEXANE / TWINGO	\N	2026-10-06 13:42:13.482151+00	8	\N	\N	\N	\N	d2d35eed-d7ee-4aac-89bb-657b799f5940	relance
9192	933	69	2026-10-08	14:00-15:00	\N	VO	DI NATALI	\N	2026-10-06 14:58:15.293091+00	8	\N	\N	\N	\N	58896dda-6b29-41f4-837d-ef7dcef8ca34	relance
9197	933	69	2026-10-10	15:00-16:00	\N	VO	CHAMBAZIA	\N	2026-10-06 14:58:45.5433+00	8	\N	\N	\N	\N	d53351ba-14bf-4bd5-89a5-2e32e3f45675	relance
9199	933	69	2026-10-11	16:00-17:00	\N	VO	FORET	\N	2026-10-06 14:58:59.773445+00	8	\N	\N	\N	\N	e56962a9-c550-4847-802a-fa097e2ca965	relance
9405	933	34	2026-10-09	15:00-16:00	1	VN	VALLET	\N	2026-10-06 16:23:45.606458+00	97	\N	\N	\N	\N	f3bc727d-7e15-43cd-9a12-d150f94cca4c	relance
9476	933	1889	2026-10-10	10:00-11:00	\N	VO	SCHIAVVIONE	\N	2026-10-07 07:13:01.460287+00	1775	\N	\N	\N	\N	ad0f4e77-77df-49ea-8719-d95a6c7a0101	relance
9546	933	1890	2026-10-08	09:00-10:00	\N	VO	LATOUR (VO Captur)	\N	2026-10-07 09:44:20.088011+00	1777	\N	\N	\N	\N	817deebb-8af7-4989-99d8-b208c05e4e8d	relance
9622	933	61	2026-10-09	15:00-16:00	\N	VO	MORENO CLIO	\N	2026-10-07 16:12:41.08138+00	7	\N	\N	\N	\N	7c99129a-31f6-4127-97c5-61e6b7d22371	relance
9625	933	99	2026-10-09	14:00-15:00	1	VN	VERDIER	\N	2026-10-07 16:13:00.26514+00	1778	\N	\N	\N	\N	806d00ec-f277-41f5-9359-c8cc28880248	relance
9632	933	99	2026-10-10	16:00-17:00	2	VN	SOYEZ	\N	2026-10-07 16:13:38.485068+00	1778	\N	\N	\N	\N	f78bcdea-639a-4fd5-aca9-eb50cbddfb7c	relance
9737	933	5768	2026-10-09	15:00-16:00	\N	VO	CASTET	\N	2026-10-09 15:47:32.138017+00	5501	\N	\N	\N	\N	d1266b5d-7b8b-4d4b-a940-93e1b0978f5c	relance
2413	2	41	2026-09-13	10:00-11:00	\N	VO	youssef	\N	2026-09-08 15:10:10.711395+00	97	\N	\N	\N	\N	\N	relance
2418	2	54	2026-09-10	09:00-10:00	2	VN	PIGNOL /	\N	2026-09-08 15:11:46.746762+00	8	\N	\N	\N	\N	\N	relance
2419	2	84	2026-09-11	11:00-12:00	\N	VO	LALO CAPTUR	\N	2026-09-08 15:11:56.415886+00	1776	\N	\N	\N	\N	\N	relance
2420	2	84	2026-09-12	11:00-12:00	\N	VO	LACAN KADJAR	\N	2026-09-08 15:12:10.556281+00	1776	\N	\N	\N	\N	\N	relance
2421	2	85	2026-09-11	14:00-15:00	\N	VO	VEZY TWINGO	\N	2026-09-08 15:13:08.362022+00	1776	\N	\N	\N	\N	\N	relance
2243	2	215	2026-09-12	09:00-10:00	\N	VO	N GOUA	\N	2026-09-08 14:24:35.900236+00	3	2026-09-08 15:13:18.969076+00	3	\N	\N	\N	relance
2422	2	215	2026-09-12	10:00-11:00	\N	VO	SAVATIER	\N	2026-09-08 15:13:28.889393+00	3	\N	\N	\N	\N	\N	relance
2423	2	87	2026-09-14	11:00-12:00	2	VN	PIERRON - R5	\N	2026-09-08 15:13:47.312912+00	1777	\N	\N	\N	\N	\N	relance
2424	2	10	2026-09-10	14:00-15:00	1	VN	PRAX	\N	2026-09-08 15:14:04.76672+00	3	\N	\N	\N	\N	\N	relance
2425	2	92	2026-09-10	09:00-10:00	1	VN	NOUVEL	\N	2026-09-08 15:14:08.343894+00	1780	\N	\N	\N	\N	\N	relance
2426	2	92	2026-09-10	10:00-11:00	2	VN	MIRKA	\N	2026-09-08 15:14:21.512203+00	1780	\N	\N	\N	\N	\N	relance
2427	2	92	2026-09-10	11:00-12:00	1	VN	SCLAFERT	\N	2026-09-08 15:14:26.026809+00	1780	\N	\N	\N	\N	\N	relance
2428	2	92	2026-09-10	14:00-15:00	1	VN	BLANCHET	\N	2026-09-08 15:14:31.173127+00	1780	\N	\N	\N	\N	\N	relance
2429	2	92	2026-09-10	15:00-16:00	1	VN	VILLEMIN	\N	2026-09-08 15:14:37.297645+00	1780	\N	\N	\N	\N	\N	relance
2430	2	92	2026-09-10	16:00-17:00	2	VN	PIGNOT	\N	2026-09-08 15:14:43.483558+00	1780	\N	\N	\N	\N	\N	relance
2431	2	92	2026-09-10	17:00-18:00	2	VN	RIEHL	\N	2026-09-08 15:14:53.513738+00	1780	\N	\N	\N	\N	\N	relance
2433	2	33	2026-09-12	10:00-11:00	1	VN	prevot	\N	2026-09-08 15:15:03.278608+00	97	\N	\N	\N	\N	\N	relance
2434	2	33	2026-09-12	09:00-10:00	1	VN	bach	\N	2026-09-08 15:15:13.124208+00	97	\N	\N	\N	\N	\N	relance
2435	2	33	2026-09-12	11:00-12:00	1	VN	vallin	\N	2026-09-08 15:15:21.998269+00	97	\N	\N	\N	\N	\N	relance
2436	2	55	2026-09-10	10:00-11:00	1	VN	LAURENT	\N	2026-09-08 15:15:28.09585+00	9	\N	\N	\N	\N	\N	relance
2437	2	33	2026-09-12	13:00-14:00	1	VN	deshaies	\N	2026-09-08 15:15:34.072046+00	97	\N	\N	\N	\N	\N	relance
2439	2	33	2026-09-12	14:00-15:00	1	VN	touly	\N	2026-09-08 15:15:40.650299+00	97	\N	\N	\N	\N	\N	relance
2441	2	33	2026-09-12	15:00-16:00	1	VN	bouillerand	\N	2026-09-08 15:15:54.056169+00	97	\N	\N	\N	\N	\N	relance
2442	2	55	2026-09-10	14:00-15:00	1	VN	QUITTERIE COGNON	\N	2026-09-08 15:15:55.958704+00	9	\N	\N	\N	\N	\N	relance
2438	2	95	2026-09-11	15:00-16:00	1	VN	SOUQUIERES	\N	2026-09-08 15:15:40.084802+00	1780	2026-09-08 15:15:58.296705+00	1780	2026-09-08 15:15:57.783+00	1780	\N	relance
2440	2	95	2026-09-11	16:00-17:00	1	VN	LEVERT	\N	2026-09-08 15:15:45.48628+00	1780	2026-09-08 15:16:02.542408+00	1780	2026-09-08 15:16:01.71+00	1780	\N	relance
2443	2	55	2026-09-11	14:00-15:00	1	VN	SERRE	\N	2026-09-08 15:16:03.506282+00	9	\N	\N	\N	\N	\N	relance
2444	2	33	2026-09-12	16:00-17:00	1	VN	dumet	\N	2026-09-08 15:16:08.682434+00	97	\N	\N	\N	\N	\N	relance
2446	2	92	2026-09-11	15:00-16:00	1	VN	SOUQUIERES	\N	2026-09-08 15:16:18.685311+00	1780	\N	\N	\N	\N	\N	relance
2447	2	92	2026-09-11	16:00-17:00	1	VN	LEVERT	\N	2026-09-08 15:16:24.671861+00	1780	\N	\N	\N	\N	\N	relance
2448	2	92	2026-09-11	17:00-18:00	2	VN	TERNAT	\N	2026-09-08 15:16:29.101385+00	1780	\N	\N	\N	\N	\N	relance
2449	2	33	2026-09-12	17:00-18:00	1	VN	bigot	\N	2026-09-08 15:16:32.682386+00	97	\N	\N	\N	\N	\N	relance
9196	933	69	2026-10-09	11:00-12:00	\N	VO	GUYOLLOT	\N	2026-10-06 14:58:34.884088+00	8	\N	\N	\N	\N	b21809d5-d4fb-45df-b2e0-2746c10ba8b4	relance
2452	2	92	2026-09-12	11:00-12:00	1	VN	CARRIERE	\N	2026-09-08 15:16:43.618718+00	1780	\N	\N	\N	\N	\N	relance
2459	2	14	2026-09-13	09:00-10:00	1	VN	JIMENEZ DUSTER	\N	2026-09-08 15:17:29.863573+00	5	2026-09-09 16:23:20.592899+00	92	2026-09-09 16:23:20.224+00	92	\N	relance
2453	2	55	2026-09-14	14:00-15:00	1	VN	JOUFFRE	\N	2026-09-08 15:16:47.46278+00	9	\N	\N	\N	\N	\N	relance
2451	2	90	2026-09-12	10:00-11:00	2	VN	despeyroux	\N	2026-09-08 15:16:40.91539+00	1781	2026-09-08 15:16:50.400703+00	1781	\N	\N	\N	relance
2432	2	33	2026-09-12	09:00-10:00	1	VN	bach	\N	2026-09-08 15:14:56.306554+00	97	2026-09-08 15:16:56.265403+00	97	2026-09-08 15:16:55.925+00	97	\N	relance
2454	2	33	2026-09-13	10:00-11:00	1	VN	thouvenet	\N	2026-09-08 15:17:14.489169+00	97	\N	\N	\N	\N	\N	relance
2456	2	95	2026-09-12	09:00-10:00	2	VN	FRANC	\N	2026-09-08 15:17:18.603722+00	1780	\N	\N	\N	\N	\N	relance
2457	2	33	2026-09-13	11:00-12:00	1	VN	butey	\N	2026-09-08 15:17:23.379547+00	97	\N	\N	\N	\N	\N	relance
2458	2	95	2026-09-12	11:00-12:00	1	VN	DUCAYLAR	\N	2026-09-08 15:17:26.824905+00	1780	\N	\N	\N	\N	\N	relance
2460	2	95	2026-09-12	14:00-15:00	1	VN	BASTIDE	\N	2026-09-08 15:17:34.512117+00	1780	\N	\N	\N	\N	\N	relance
2461	2	10	2026-09-10	18:00-19:00	1	VN	FRAISSABGE	\N	2026-09-08 15:17:37.910287+00	3	\N	\N	\N	\N	\N	relance
2462	2	33	2026-09-13	14:00-15:00	1	VN	diccio	\N	2026-09-08 15:17:43.116894+00	97	\N	\N	\N	\N	\N	relance
2464	2	33	2026-09-13	15:00-16:00	1	VN	blanchet	\N	2026-09-08 15:17:54.472237+00	97	\N	\N	\N	\N	\N	relance
2465	2	74	2026-09-14	16:00-17:00	1	VN	BENETTI	\N	2026-09-08 15:18:07.009332+00	1778	\N	\N	\N	\N	\N	relance
2466	2	75	2026-09-11	09:00-10:00	2	VN	ROUQUET	\N	2026-09-08 15:18:31.124247+00	1778	\N	\N	\N	\N	\N	relance
2468	2	93	2026-09-10	09:00-10:00	2	VN	GILLES	\N	2026-09-08 15:18:58.018401+00	1780	\N	\N	\N	\N	\N	relance
2470	2	93	2026-09-10	10:00-11:00	1	VN	BAU	\N	2026-09-08 15:19:05.054963+00	1780	\N	\N	\N	\N	\N	relance
2471	2	93	2026-09-10	11:00-12:00	1	VN	MOLTENI	\N	2026-09-08 15:19:13.418887+00	1780	\N	\N	\N	\N	\N	relance
2472	2	68	2026-09-10	18:00-19:00	\N	VO	DESENCLOS	\N	2026-09-08 15:19:18.095523+00	9	\N	\N	\N	\N	\N	relance
2474	2	93	2026-09-10	15:00-16:00	2	VN	CHARREIRE	\N	2026-09-08 15:19:30.834965+00	1780	\N	\N	\N	\N	\N	relance
2475	2	90	2026-09-12	16:00-17:00	1	VN	senelier meg	\N	2026-09-08 15:19:39.464405+00	1781	\N	\N	\N	\N	\N	relance
2476	2	93	2026-09-11	15:00-16:00	1	VN	SEINCE	\N	2026-09-08 15:19:51.045165+00	1780	\N	\N	\N	\N	\N	relance
2477	2	93	2026-09-11	16:00-17:00	2	VN	COULON	\N	2026-09-08 15:20:04.179034+00	1780	\N	\N	\N	\N	\N	relance
2478	2	93	2026-09-12	14:00-15:00	2	VN	LAMOTTE	\N	2026-09-08 15:20:19.40165+00	1780	\N	\N	\N	\N	\N	relance
2479	2	32	2026-09-12	09:00-10:00	2	VN	guigen	\N	2026-09-08 15:20:21.021714+00	97	\N	\N	\N	\N	\N	relance
2481	2	32	2026-09-13	09:00-10:00	2	VN	duchassin	\N	2026-09-08 15:20:30.717053+00	97	\N	\N	\N	\N	\N	relance
2247	2	32	2026-09-12	09:00-10:00	1	VN	guigum	\N	2026-09-08 14:29:22.826539+00	97	2026-09-08 15:20:37.324715+00	97	2026-09-08 15:20:36.151+00	97	\N	relance
2483	2	93	2026-09-12	11:00-12:00	1	VN	MILLE	\N	2026-09-08 15:20:46.199322+00	1780	\N	\N	\N	\N	\N	relance
2485	2	17	2026-09-12	09:00-10:00	1	VN	ROLLEY R4	\N	2026-09-08 15:21:01.4455+00	5	\N	\N	\N	\N	\N	relance
2469	2	14	2026-09-14	09:00-10:00	1	VN	GAMBIER SANDERO	\N	2026-09-08 15:19:03.595305+00	5	2026-09-09 16:23:23.700593+00	92	2026-09-09 16:23:23.345+00	92	\N	relance
2463	2	14	2026-09-13	10:00-11:00	1	VN	GUILLO SANDERO	\N	2026-09-08 15:17:51.123309+00	5	2026-09-09 16:23:34.5208+00	92	2026-09-09 16:23:34.196+00	92	\N	relance
2445	2	14	2026-09-11	17:00-18:00	1	VN	DELPRAT JOGGER	\N	2026-09-08 15:16:16.734408+00	5	2026-09-09 16:24:00.386934+00	92	2026-09-09 16:24:00.044+00	92	\N	relance
2467	2	14	2026-09-13	17:00-18:00	1	VN	DUCHE DUSTER	\N	2026-09-08 15:18:52.977068+00	5	2026-09-09 16:24:03.736832+00	92	2026-09-09 16:24:03.402+00	92	\N	relance
2473	2	14	2026-09-14	17:00-18:00	1	VN	CHANTENAIS SANDERO	\N	2026-09-08 15:19:20.007523+00	5	2026-09-09 16:24:06.500251+00	92	2026-09-09 16:24:06.121+00	92	\N	relance
2480	2	17	2026-09-11	15:00-16:00	1	VN	PINO TWINGO	\N	2026-09-08 15:20:29.785408+00	5	2026-09-08 15:20:38.874774+00	5	\N	\N	\N	relance
8727	933	19	2026-10-08	14:00-15:00	1	VN	FONTAN ( AUSTRAL)	\N	2026-10-06 09:49:12.854813+00	2	\N	\N	\N	\N	20475df4-a443-4cc5-857d-50af4d48234b	relance
8921	933	60	2026-10-10	14:00-15:00	1	VN	BRESSIEUX	\N	2026-10-06 10:32:53.258536+00	9	\N	\N	\N	\N	298c94f0-0fb4-4299-8836-e13b707ca374	relance
8924	933	60	2026-10-12	10:00-11:00	2	VN	AMOUROUX	\N	2026-10-06 10:33:18.361014+00	9	\N	\N	\N	\N	3e70e7da-59e2-4b1e-aa16-1fd6f22fc4b3	relance
9085	933	55	2026-10-11	10:00-11:00	2	VN	PILLET / DUSTER	\N	2026-10-06 13:43:05.822012+00	8	\N	\N	\N	\N	007b3eec-7134-4462-946a-6759628c71e1	relance
9200	933	68	2026-10-08	14:00-15:00	\N	VO	BESSE DUSTER	\N	2026-10-06 14:59:43.243093+00	7	\N	\N	\N	\N	d6d3ddaf-e4d2-43b7-89f4-e132c65810ae	relance
9406	933	34	2026-10-10	09:00-10:00	1	VN	DULIN	\N	2026-10-06 16:23:53.564602+00	97	\N	\N	\N	\N	dc3240e0-ca11-4160-a1b0-58c821b1d03e	relance
9477	933	1889	2026-10-11	11:00-12:00	\N	VO	POUGET	\N	2026-10-07 07:13:07.83494+00	1775	\N	\N	\N	\N	600da1db-0daa-4dd1-9b44-918892f35f88	relance
9547	933	1890	2026-10-08	10:00-11:00	\N	VO	BRUSQUE (VN Duster)	\N	2026-10-07 09:44:45.789978+00	1777	\N	\N	\N	\N	69bd600b-9359-4e9c-ab4b-69a68829e229	relance
9627	933	99	2026-10-09	17:00-18:00	1	VN	JAN	\N	2026-10-07 16:13:06.457894+00	1778	\N	\N	\N	\N	2cde532d-5b6b-488c-8e31-7af59dbc2555	relance
9631	933	99	2026-10-10	15:00-16:00	2	VN	OFFROY	\N	2026-10-07 16:13:33.244236+00	1778	\N	\N	\N	\N	8e01cdc3-9d77-44c2-a95b-70246a5e5e21	relance
9738	933	5767	2026-10-09	16:00-17:00	\N	VO	CIONCO	\N	2026-10-09 15:47:54.370389+00	5501	\N	\N	\N	\N	eb26fb8e-2ee9-4329-814b-9a0088bdd40c	relance
2482	2	17	2026-09-11	16:00-17:00	1	VN	PINEAU TWINGO	\N	2026-09-08 15:20:35.537569+00	5	2026-09-08 15:20:52.24895+00	5	\N	\N	\N	relance
8728	933	10	2026-10-11	14:00-15:00	1	VN	saunier twingo	\N	2026-10-06 09:50:34.506146+00	4	\N	\N	\N	\N	fcc1b44a-beff-40fc-88b7-52a3813c5f72	relance
8927	933	59	2026-10-10	10:00-11:00	2	VN	GRANIER SANDERO	\N	2026-10-06 10:34:08.939066+00	7	\N	\N	\N	\N	cf483c33-8393-4d11-a842-e91135cbb7c1	relance
9201	933	70	2026-10-08	14:00-15:00	\N	VO	CADE KADJAR  4X4	\N	2026-10-06 15:00:12.864115+00	7	\N	\N	\N	\N	c682ba9a-777b-42b7-896b-f2c2c539ee47	relance
9407	933	34	2026-10-11	11:00-12:00	1	VN	SERRE	\N	2026-10-06 16:23:59.260549+00	97	\N	\N	\N	\N	e27c6a68-4501-477b-8489-156fe994fcc9	relance
9478	933	1889	2026-10-09	11:00-12:00	\N	VO	ANDRIEU	\N	2026-10-07 07:13:12.294403+00	1775	\N	\N	\N	\N	6d1bad66-ea2a-4a06-815e-a58d3a734cc4	relance
9548	933	1890	2026-10-08	14:00-15:00	\N	VO	TESSIER ( Clio VO)	\N	2026-10-07 09:45:00.308594+00	1777	\N	\N	\N	\N	5afa03d0-6960-403e-a5d2-414237727032	relance
9636	933	74	2026-10-10	16:00-17:00	2	VN	PONS	\N	2026-10-08 07:18:09.874803+00	5501	2026-10-09 06:46:57.299232+00	5501	2026-10-09 06:46:57.389+00	5501	17b02bbe-028f-4793-8dd6-b968745e1aab	relance
9086	933	60	2026-10-08	10:00-11:00	1	VN	VILLARET	\N	2026-10-06 13:46:19.698217+00	9	2026-10-09 14:11:22.843575+00	7	2026-10-09 14:11:22.901+00	7	30dee97d-9a51-4cad-b836-0a610655ff6a	relance
9739	933	71	2026-10-09	10:00-11:00	1	VN	HILD	\N	2026-10-09 15:50:15.670115+00	5501	2026-10-09 15:50:19.433503+00	5501	2026-10-09 15:50:19.274+00	5501	5c0eb744-1d29-4249-b655-2a944acb9807	relance
2484	2	3	2026-09-11	14:00-15:00	1	VN	MORIN  R5	\N	2026-09-08 15:20:52.456292+00	4	\N	\N	\N	\N	\N	relance
2486	2	93	2026-09-12	15:00-16:00	2	VN	RAJEWICZ	\N	2026-09-08 15:21:03.375396+00	1780	\N	\N	\N	\N	\N	relance
8729	933	70	2026-10-09	10:00-11:00	\N	VO	LOUIS FIAT SCUDO	\N	2026-10-06 09:50:59.258712+00	7	2026-10-06 09:51:05.426301+00	7	\N	\N	ce73ff95-5c1b-488b-9ea4-9b940e69f722	relance
8931	933	12	2026-10-09	11:00-12:00	2	VN	ROSSI (SANDERO°	\N	2026-10-06 10:35:24.432214+00	2	\N	\N	\N	\N	6c8313e9-cb66-449f-81aa-959a3ff86aba	relance
9087	933	60	2026-10-12	14:00-15:00	1	VN	LAZARDEUX	\N	2026-10-06 13:46:34.623496+00	9	\N	\N	\N	\N	4e0957e4-e64e-42b2-8229-8855788b02fb	relance
9202	933	41	2026-10-10	17:00-18:00	\N	VO	DENNE	\N	2026-10-06 15:02:16.305732+00	97	\N	\N	\N	\N	4faa1dfc-c138-49bf-a367-9498ffb44a8c	relance
9217	933	59	2026-10-10	15:00-16:00	1	VN	CHASSARIC TWINGO	\N	2026-10-06 15:04:41.749812+00	7	\N	\N	\N	\N	fce57079-ada5-4129-8942-9dda52d16b44	relance
9408	933	34	2026-10-11	17:00-18:00	1	VN	SENAT	\N	2026-10-06 16:24:07.541332+00	97	\N	\N	\N	\N	15ee77d6-11fa-4b9c-be3b-c87b0bca50b1	relance
9479	933	90	2026-10-08	10:00-11:00	1	VN	boursier austral	\N	2026-10-07 07:14:33.716615+00	1781	2026-10-07 07:14:40.073897+00	1781	\N	\N	805d45a2-7ce3-4d0b-b74c-37da07769dae	relance
9480	933	90	2026-10-08	17:00-18:00	2	VN	haut duster	\N	2026-10-07 07:15:00.822366+00	1781	\N	\N	\N	\N	c4bde919-f519-49a4-9591-3c1150ce6693	relance
9549	933	1890	2026-10-08	13:00-14:00	\N	VO	i	\N	2026-10-07 09:45:27.98911+00	1777	2026-10-07 09:51:21.28627+00	1777	2026-10-07 09:51:21.067+00	1777	85ced50f-7137-4307-9f56-f67584d91f11	relance
9637	933	60	2026-10-08	12:00-13:00	1	VN	FOUILLERON	\N	2026-10-08 12:25:05.199969+00	7	2026-10-08 12:25:18.143155+00	7	2026-10-08 12:25:18.089+00	7	b03841a8-6134-407e-b0b4-954dc8d923be	relance
9740	933	71	2026-10-09	10:00-11:00	2	VN	HILD	\N	2026-10-09 15:50:21.876361+00	5501	\N	\N	\N	\N	cede5749-d0ee-4718-88b7-a9bab97e80bb	relance
2487	2	3	2026-09-11	15:00-16:00	1	VN	MORIN  CAPTUR	\N	2026-09-08 15:21:05.855225+00	4	\N	\N	\N	\N	\N	relance
8730	933	70	2026-10-10	09:00-10:00	\N	VO	LEROY ARKANA OU CAPTUR	\N	2026-10-06 09:51:23.151377+00	7	\N	\N	\N	\N	eed8535b-236d-448a-964c-dd12aed844d4	relance
8935	933	19	2026-10-08	17:00-18:00	1	VN	GEROME ( TWINGO)	\N	2026-10-06 10:37:00.615923+00	2	\N	\N	\N	\N	9c2e98bb-17f7-4880-9d95-6a6e5b68a301	relance
8940	933	19	2026-10-09	15:00-16:00	1	VN	VIGITELLO (TWINGO)	\N	2026-10-06 10:37:54.653126+00	2	\N	\N	\N	\N	b9909c9f-bb8a-4c83-b09b-320f52b1f1a9	relance
8937	933	54	2026-10-09	11:00-12:00	1	VN	RANQUE ALPINE	\N	2026-10-06 10:37:29.869558+00	7	2026-10-06 10:38:11.388285+00	7	\N	\N	683f1ebd-1b74-44e4-ab14-75516045ba34	relance
8944	933	53	2026-10-08	17:00-18:00	1	VN	MURE	\N	2026-10-06 10:39:10.173798+00	9	\N	\N	\N	\N	294d969c-ceab-4d64-b3d1-79069c5644ec	relance
8950	933	53	2026-10-12	11:00-12:00	1	VN	CHAZEL	\N	2026-10-06 10:40:14.818313+00	9	\N	\N	\N	\N	a0a83d27-a087-4efd-bfbb-22ef6d4f10c6	relance
8952	933	53	2026-10-08	11:00-12:00	2	VN	BAYLE	\N	2026-10-06 10:40:37.859387+00	9	\N	\N	\N	\N	10d4e1b3-fef5-4ad2-a94e-6522d501ef1b	relance
9088	933	54	2026-10-08	15:00-16:00	2	VN	PEZON ALPINE	\N	2026-10-06 13:49:48.584626+00	7	\N	\N	\N	\N	eab1b101-8c41-42d6-8fce-64017baf53ae	relance
9203	933	41	2026-10-11	15:00-16:00	\N	VO	CHAMBONNIERE	\N	2026-10-06 15:02:28.219647+00	97	\N	\N	\N	\N	6bcc3eda-d3f3-4757-ba34-f5e09880b842	relance
9208	933	35	2026-10-12	11:00-12:00	1	VN	RIBOULET	\N	2026-10-06 15:03:16.174851+00	97	\N	\N	\N	\N	18dd3abb-f3d2-4d5d-a349-99301caaaffe	relance
9220	933	65	2026-10-09	14:00-15:00	1	VN	KOSARZKI / CLIO	\N	2026-10-06 15:07:14.330816+00	8	\N	\N	\N	\N	4273cd82-0ebc-4da3-9bec-d160d6359fcd	relance
9223	933	32	2026-10-10	16:00-17:00	1	VN	CANCRE	\N	2026-10-06 15:08:53.393612+00	97	\N	\N	\N	\N	c8a74faa-5c4c-443c-9356-722374e86951	relance
9409	933	42	2026-10-09	10:00-11:00	2	VN	LUNOAU	\N	2026-10-06 16:27:42.362678+00	1782	\N	\N	\N	\N	ee165f21-a7f9-40a6-96ef-4fe5ca00b0dd	relance
9481	933	90	2026-10-10	10:00-11:00	2	VN	st marc scenic	\N	2026-10-07 07:21:26.42308+00	1781	2026-10-07 07:22:38.030565+00	1781	2026-10-07 07:22:37.946+00	1781	5591906c-7e85-491b-9b4d-96f212546ad7	relance
9550	933	87	2026-10-08	09:00-10:00	2	VN	SALLES (Sandero CVT VO)	\N	2026-10-07 09:45:48.459721+00	1777	\N	\N	\N	\N	7c67123e-6fbc-4821-b0cb-941c06975ac1	relance
9638	933	60	2026-10-08	12:00-13:00	2	VN	FOUILLERON	\N	2026-10-08 12:25:25.262975+00	7	\N	\N	\N	\N	aa188b4c-3f7e-40d3-95ba-c9cd19b71fc1	relance
9741	933	60	2026-10-08	17:00-18:00	2	VN	RUAT	\N	2026-10-09 16:16:19.999383+00	7	\N	\N	\N	\N	89af5196-0765-4903-8420-c1e1d21c9684	showroom
2489	2	32	2026-09-10	11:00-12:00	2	VN	ribes	\N	2026-09-08 15:21:15.539468+00	97	\N	\N	\N	\N	\N	relance
2490	2	32	2026-09-13	11:00-12:00	2	VN	renard	\N	2026-09-08 15:21:18.996994+00	97	\N	\N	\N	\N	\N	relance
2491	2	17	2026-09-12	10:00-11:00	1	VN	GROSSENS SCENIC	\N	2026-09-08 15:21:21.663644+00	5	\N	\N	\N	\N	\N	relance
2492	2	3	2026-09-12	10:00-11:00	1	VN	MALLET SANDERO	\N	2026-09-08 15:21:26.747388+00	4	\N	\N	\N	\N	\N	relance
2493	2	93	2026-09-12	17:00-18:00	1	VN	MULLER	\N	2026-09-08 15:21:32.102163+00	1780	\N	\N	\N	\N	\N	relance
2488	2	32	2026-09-10	10:00-11:00	2	VN	gomard	\N	2026-09-08 15:21:11.505807+00	97	2026-09-08 15:21:37.674282+00	97	2026-09-08 15:21:37.489+00	97	\N	relance
2495	2	17	2026-09-12	13:00-14:00	1	VN	VENERAI R5	\N	2026-09-08 15:21:42.942442+00	5	\N	\N	\N	\N	\N	relance
2496	2	78	2026-09-13	14:00-15:00	1	VN	JOLY	\N	2026-09-08 15:21:49.856401+00	1778	\N	\N	\N	\N	\N	relance
2497	2	17	2026-09-12	14:00-15:00	1	VN	TARDIEU CLIO	\N	2026-09-08 15:21:57.467226+00	5	\N	\N	\N	\N	\N	relance
2526	2	32	2026-09-10	16:00-17:00	2	VN	descriaux	\N	2026-09-08 15:29:15.937972+00	97	\N	\N	\N	\N	\N	relance
2494	2	17	2026-09-12	13:00-14:00	1	VN	VERNERAI	\N	2026-09-08 15:21:32.417746+00	5	2026-09-08 15:22:09.916506+00	5	2026-09-08 15:22:02.721+00	5	\N	relance
2499	2	32	2026-09-10	10:00-11:00	2	VN	gomard	\N	2026-09-08 15:22:20.991388+00	97	\N	\N	\N	\N	\N	relance
2498	2	17	2026-09-12	16:00-17:00	1	VN	PICHARD CLIO	\N	2026-09-08 15:22:20.904014+00	5	2026-09-08 15:22:30.332757+00	5	\N	\N	\N	relance
2500	2	71	2026-09-11	17:00-18:00	1	VN	DOYE	\N	2026-09-08 15:22:39.307403+00	1778	\N	\N	\N	\N	\N	relance
2501	2	71	2026-09-11	17:00-18:00	1	VN	DOYE	\N	2026-09-08 15:22:45.614835+00	1778	\N	\N	\N	\N	\N	relance
2504	2	32	2026-09-11	14:00-15:00	2	VN	kramer	\N	2026-09-08 15:22:51.413395+00	97	\N	\N	\N	\N	\N	relance
2505	2	17	2026-09-13	10:00-11:00	1	VN	GOVERI SCENIC	\N	2026-09-08 15:22:52.125324+00	5	\N	\N	\N	\N	\N	relance
1801	2	32	2026-09-11	14:00-15:00	1	VN	kramer	\N	2026-09-08 09:49:37.371014+00	97	2026-09-08 15:22:58.786601+00	97	2026-09-08 15:22:58.821+00	97	\N	relance
2502	2	4	2026-09-10	17:00-18:00	1	VN	DUMAS  CLIO	\N	2026-09-08 15:22:46.529843+00	4	2026-09-08 15:23:04.195468+00	4	2026-09-08 15:23:01.463+00	4	\N	relance
2503	2	17	2026-09-13	10:00-11:00	1	VN	GOVERI SCENIC	\N	2026-09-08 15:22:50.072946+00	5	2026-09-08 15:23:05.403436+00	5	2026-09-08 15:23:01.704+00	5	\N	relance
2507	2	32	2026-09-12	14:00-15:00	2	VN	julien	\N	2026-09-08 15:23:13.561636+00	97	\N	\N	\N	\N	\N	relance
2508	2	19	2026-09-12	12:00-13:00	1	VN	ROUSSEL R4	\N	2026-09-08 15:23:15.722217+00	2	\N	\N	\N	\N	\N	relance
2506	2	4	2026-09-10	17:00-18:00	1	VN	DUMAS CLIO	\N	2026-09-08 15:22:53.808144+00	4	2026-09-08 15:23:25.516313+00	4	2026-09-08 15:23:23.434+00	4	\N	relance
2509	2	17	2026-09-13	15:00-16:00	1	VN	VUSINIC R5	\N	2026-09-08 15:23:26.351694+00	5	\N	\N	\N	\N	\N	relance
2511	2	32	2026-09-13	14:00-15:00	2	VN	louzat	\N	2026-09-08 15:23:43.34743+00	97	\N	\N	\N	\N	\N	relance
2510	2	19	2026-09-12	14:00-15:00	1	VN	DESGEOGES MEGANE	\N	2026-09-08 15:23:36.046962+00	2	2026-09-08 15:23:52.191623+00	2	\N	\N	\N	relance
2512	2	87	2026-09-12	14:00-15:00	2	VN	FEVRE - CLIO VI VN	\N	2026-09-08 15:23:43.385377+00	1777	2026-09-08 15:23:52.226307+00	1777	\N	\N	\N	relance
2255	2	32	2026-09-13	14:00-15:00	1	VN	louzat	\N	2026-09-08 14:29:59.792059+00	97	2026-09-08 15:23:53.548438+00	97	2026-09-08 15:23:53.688+00	97	\N	relance
2516	2	211	2026-09-11	10:00-11:00	\N	VO	CORNET CLIO5	\N	2026-09-08 15:24:24.539045+00	2	\N	\N	\N	\N	\N	relance
2517	2	32	2026-09-14	14:00-15:00	2	VN	fieschi	\N	2026-09-08 15:24:25.336369+00	97	\N	\N	\N	\N	\N	relance
2519	2	17	2026-09-11	18:00-19:00	1	VN	RAYMON DUSTER	\N	2026-09-08 15:24:38.628808+00	5	\N	\N	\N	\N	\N	relance
2513	2	17	2026-09-14	16:00-17:00	1	VN	GAUTHIER TWINGO	\N	2026-09-08 15:23:54.86481+00	5	2026-09-08 15:24:48.301594+00	5	2026-09-08 15:24:42.571+00	5	\N	relance
2518	2	17	2026-09-14	15:00-16:00	1	VN	GAUTHIER TWINGO	\N	2026-09-08 15:24:35.537018+00	5	2026-09-08 15:24:54.7891+00	5	2026-09-08 15:24:54.846+00	5	\N	relance
2542	2	61	2026-09-11	17:00-18:00	\N	VO	PASSEBOIS	\N	2026-09-08 15:41:04.290796+00	9	\N	\N	\N	\N	\N	relance
2514	2	17	2026-09-14	16:00-17:00	1	VN	GAUTHIER TWINGO	\N	2026-09-08 15:24:01.062987+00	5	2026-09-08 15:25:23.087931+00	5	2026-09-08 15:25:08.988+00	5	\N	relance
2522	2	211	2026-09-11	14:00-15:00	\N	VO	GUILLOU KANGOO VU	\N	2026-09-08 15:25:32.660888+00	2	\N	\N	\N	\N	\N	relance
2523	2	32	2026-09-12	15:00-16:00	2	VN	despalles	\N	2026-09-08 15:25:36.448092+00	97	\N	\N	\N	\N	\N	relance
2524	2	32	2026-09-10	15:00-16:00	2	VN	falchetto	\N	2026-09-08 15:25:38.886802+00	97	\N	\N	\N	\N	\N	relance
2520	2	211	2026-09-11	14:00-15:00	\N	VO	GUILLOU KANGOO VU	\N	2026-09-08 15:25:02.166514+00	2	2026-09-08 15:29:44.804321+00	2	2026-09-08 15:29:08.805+00	2	\N	relance
2515	2	211	2026-09-11	10:00-11:00	\N	VO	CORNET CLIO5	\N	2026-09-08 15:24:21.879419+00	2	2026-09-08 15:25:48.707071+00	2	2026-09-08 15:25:27.025+00	2	\N	relance
2525	2	32	2026-09-14	17:00-18:00	2	VN	chanat	\N	2026-09-08 15:27:03.698061+00	97	\N	\N	\N	\N	\N	relance
2538	2	213	2026-09-11	11:00-12:00	\N	VO	floment	\N	2026-09-08 15:39:01.679671+00	6	2026-09-08 15:39:45.264919+00	6	2026-09-08 15:39:44.892+00	6	\N	relance
2540	2	31	2026-09-13	11:00-12:00	2	VN	lambert	\N	2026-09-08 15:40:38.90103+00	97	\N	\N	\N	\N	\N	relance
2528	2	32	2026-09-11	16:00-17:00	2	VN	viguie	\N	2026-09-08 15:30:44.033523+00	97	\N	\N	\N	\N	\N	relance
2529	2	1885	2026-09-11	17:00-18:00	1	VN	DEJEAN - VN R	\N	2026-09-08 15:33:53.078713+00	1777	\N	\N	\N	\N	\N	relance
2530	2	1885	2026-09-11	11:00-12:00	1	VN	ROUSSEAU - VN	\N	2026-09-08 15:33:54.76228+00	1777	\N	\N	\N	\N	\N	relance
8731	933	54	2026-10-08	16:00-17:00	1	VN	PINEL SCENIC	\N	2026-10-06 09:52:10.758585+00	7	\N	\N	\N	\N	fb9bd164-6db7-48d4-bf56-05967382218d	relance
2533	2	24	2026-09-12	15:00-16:00	\N	VO	VALERO	\N	2026-09-08 15:34:56.470379+00	4	\N	\N	\N	\N	\N	relance
2535	2	69	2026-09-12	14:00-15:00	\N	VO	chabriere	\N	2026-09-08 15:35:02.500844+00	7	\N	\N	\N	\N	\N	relance
2536	2	4	2026-09-10	17:00-18:00	1	VN	DUMAS CLIO	\N	2026-09-08 15:35:19.799795+00	4	\N	\N	\N	\N	\N	relance
2527	2	4	2026-09-10	17:00-18:00	1	VN	DUMAS CLIO	\N	2026-09-08 15:30:43.374205+00	4	2026-09-08 15:38:55.122076+00	4	2026-09-08 15:38:55.051+00	4	\N	relance
2539	2	213	2026-09-11	11:00-12:00	\N	VO	flament	\N	2026-09-08 15:39:13.912395+00	6	\N	\N	\N	\N	\N	relance
2224	2	31	2026-09-13	11:00-12:00	1	VN	lambert	\N	2026-09-08 14:18:54.664299+00	97	2026-09-08 15:40:53.591036+00	97	2026-09-08 15:40:50.835+00	97	\N	relance
2541	2	74	2026-09-12	15:00-16:00	1	VN	BRELHIAT	\N	2026-09-08 15:40:54.317933+00	1778	2026-09-08 15:41:07.781213+00	1778	\N	\N	\N	relance
2543	2	31	2026-09-11	14:00-15:00	2	VN	lorderon	\N	2026-09-08 15:41:13.401653+00	97	\N	\N	\N	\N	\N	relance
2218	2	31	2026-09-11	14:00-15:00	1	VN	lorderon	\N	2026-09-08 14:18:17.594584+00	97	2026-09-08 15:41:17.705499+00	97	2026-09-08 15:41:14.95+00	97	\N	relance
2544	2	61	2026-09-12	16:00-17:00	\N	VO	BRUN	\N	2026-09-08 15:41:20.408404+00	9	\N	\N	\N	\N	\N	relance
2546	2	74	2026-09-12	16:00-17:00	1	VN	JORDY	\N	2026-09-08 15:41:22.327975+00	1778	\N	\N	\N	\N	\N	relance
2547	2	31	2026-09-12	15:00-16:00	2	VN	brun	\N	2026-09-08 15:43:09.627666+00	97	\N	\N	\N	\N	\N	relance
2537	2	67	2026-09-10	18:00-19:00	1	VN	BAILLON	\N	2026-09-08 15:35:54.435911+00	8	2026-09-08 15:53:59.982324+00	8	2026-09-08 15:53:58.943+00	8	\N	relance
2556	2	10	2026-09-12	10:00-11:00	1	VN	SAINT JOANNIS	\N	2026-09-08 15:49:04.509045+00	3	2026-09-08 16:00:10.420216+00	3	2026-09-08 16:00:10.276+00	3	\N	relance
2521	2	211	2026-09-11	14:00-15:00	\N	VO	GUILLOU KANGOO VU	\N	2026-09-08 15:25:14.900408+00	2	2026-09-08 16:02:39.6707+00	2	2026-09-08 16:02:40.43+00	2	\N	relance
2531	2	69	2026-09-12	14:00-15:00	\N	VO	chabriere	\N	2026-09-08 15:34:32.783885+00	7	2026-09-08 16:14:52.246492+00	7	2026-09-08 16:14:52.405+00	7	\N	relance
2532	2	67	2026-09-10	18:00-19:00	1	VN	BAILLON / R	\N	2026-09-08 15:34:55.697018+00	8	2026-09-08 15:46:11.045899+00	8	2026-09-08 15:45:43.046+00	8	\N	relance
8732	933	62	2026-10-08	09:00-10:00	1	VN	HUTIN	\N	2026-10-06 09:52:21.51038+00	9	\N	\N	\N	\N	dc5fa349-5182-4cee-a8b0-df734874e533	relance
8936	933	19	2026-10-09	08:00-09:00	1	VN	BERTHELOT ( TWINGO)	\N	2026-10-06 10:37:16.409859+00	2	2026-10-06 10:38:05.472037+00	2	\N	\N	dea3f0ac-0805-42e6-8595-0611a5d57bc1	relance
8949	933	53	2026-10-11	11:00-12:00	1	VN	OCA	\N	2026-10-06 10:40:08.637101+00	9	\N	\N	\N	\N	23c08ae9-f028-4458-a3d4-f629182c8471	relance
8954	933	53	2026-10-10	15:00-16:00	2	VN	PROTO	\N	2026-10-06 10:40:54.333919+00	9	\N	\N	\N	\N	1c4198dd-dd79-4b37-81e3-b893edfcc6d1	relance
8955	933	53	2026-10-11	10:00-11:00	2	VN	GILBERT	\N	2026-10-06 10:41:01.122149+00	9	\N	\N	\N	\N	d4fc94ea-43e7-46f5-a53a-6042af109dda	relance
8960	933	4205	2026-10-10	14:00-15:00	\N	VO	FORT SCENIC E TECH	\N	2026-10-06 10:42:15.288894+00	1782	\N	\N	\N	\N	548788cf-6218-4263-b57c-8d5f4e6d2839	relance
8962	933	70	2026-10-09	16:00-17:00	\N	VO	FONTES CAPTUR	\N	2026-10-06 10:42:27.315016+00	7	\N	\N	\N	\N	20a76bc3-4431-4935-b352-d12c7596dd85	relance
9089	933	68	2026-10-08	10:00-11:00	\N	VO	DELBOS TWINGO	\N	2026-10-06 13:50:11.588538+00	7	\N	\N	\N	\N	c7dcee6e-c24d-4c0a-b2c6-087415cf42f2	relance
9204	933	41	2026-10-12	16:00-17:00	\N	VO	GAY	\N	2026-10-06 15:02:36.78467+00	97	\N	\N	\N	\N	09d37115-8f67-4420-a604-da687d2fa150	relance
9209	933	51	2026-10-08	17:00-18:00	\N	VO	M PLASSE	\N	2026-10-06 15:03:29.07482+00	1783	\N	\N	\N	\N	0e687c49-7f9f-4c78-8606-5a2727bd43de	relance
9410	933	51	2026-10-11	14:00-15:00	\N	VO	M CHATELET	\N	2026-10-06 16:29:23.173754+00	1783	\N	\N	\N	\N	b9263db7-30c6-4c3e-a925-09c581c21357	relance
9482	933	90	2026-10-10	10:00-11:00	1	VN	st marc scenic	\N	2026-10-07 07:22:49.367905+00	1781	\N	\N	\N	\N	bd8962c2-b764-4efd-9024-da6f74dbac2e	relance
9551	933	87	2026-10-08	10:00-11:00	2	VN	BERNARD (R5 ou R4 VN)	\N	2026-10-07 09:46:17.152298+00	1777	\N	\N	\N	\N	848d2474-6950-49fa-8a24-c0f1fb5eae36	relance
9742	933	67	2026-10-08	08:00-09:00	1	VN	GAUTHIER	\N	2026-10-10 07:04:06.410823+00	9	\N	\N	\N	\N	23aac4a3-5785-4cd1-ab4d-b7d794db91d0	showroom
9743	933	67	2026-10-08	08:00-09:00	1	VN	ROCHE	\N	2026-10-10 07:04:31.19715+00	9	\N	\N	\N	\N	9587da3b-5a9c-4a86-bf64-544249f2844c	showroom
2545	2	74	2026-09-12	16:00-17:00	1	VN	JORDY	\N	2026-09-08 15:41:20.222403+00	1778	2026-09-08 15:43:12.440225+00	1778	2026-09-08 15:42:12.171+00	1778	\N	relance
2548	2	33	2026-09-14	11:00-12:00	1	VN	thillet	\N	2026-09-08 15:43:15.433244+00	97	\N	\N	\N	\N	\N	relance
2551	2	75	2026-09-13	11:00-12:00	2	VN	LAPARRA	\N	2026-09-08 15:45:43.454315+00	1778	\N	\N	\N	\N	\N	relance
2555	2	55	2026-09-12	16:00-17:00	1	VN	MOREL	\N	2026-09-08 15:48:14.423664+00	9	\N	\N	\N	\N	\N	relance
2560	2	31	2026-09-11	17:00-18:00	2	VN	buchard	\N	2026-09-08 15:50:55.624388+00	97	\N	\N	\N	\N	\N	relance
2561	2	31	2026-09-11	16:00-17:00	2	VN	brenet	\N	2026-09-08 15:50:53.639205+00	97	\N	\N	\N	\N	\N	relance
2564	2	33	2026-09-14	16:00-17:00	1	VN	pincon parents	\N	2026-09-08 15:51:46.440179+00	97	\N	\N	\N	\N	\N	relance
2534	2	67	2026-09-10	18:00-19:00	1	VN	BAILLON / R5	\N	2026-09-08 15:35:00.625005+00	8	2026-09-08 15:52:26.374539+00	8	2026-09-08 15:52:24.909+00	8	\N	relance
8733	933	62	2026-10-08	14:00-15:00	1	VN	BONNARDET	\N	2026-10-06 09:52:38.418581+00	9	\N	\N	\N	\N	1738ac55-6803-487e-bd47-697134588527	relance
2566	2	53	2026-09-11	14:00-15:00	2	VN	.	\N	2026-09-08 15:52:02.488625+00	9	2026-09-08 15:54:00.111925+00	9	2026-09-08 15:53:28.556+00	9	\N	relance
8938	933	19	2026-10-09	09:00-10:00	1	VN	THUEL ( SCENIC)	\N	2026-10-06 10:37:31.254351+00	2	\N	\N	\N	\N	24c7a40c-1338-4c2e-9644-4af3e4663d4c	relance
8942	933	53	2026-10-08	16:00-17:00	1	VN	CASSEZ	\N	2026-10-06 10:39:04.345162+00	9	\N	\N	\N	\N	c12263a1-d0c7-460a-bc99-b75c00362a8e	relance
2558	2	10	2026-09-12	11:00-12:00	1	VN	SAINT JOANNIS	\N	2026-09-08 15:49:04.539672+00	3	2026-09-08 15:55:00.624149+00	3	2026-09-08 15:54:59.004+00	3	\N	relance
2549	2	75	2026-09-13	10:00-11:00	2	VN	LAPARRA	\N	2026-09-08 15:45:06.18621+00	1778	2026-09-08 16:14:54.105008+00	1778	2026-09-08 16:14:52.783+00	1778	\N	relance
2550	2	75	2026-09-13	10:00-11:00	2	VN	LAPARRA	\N	2026-09-08 15:45:42.890054+00	1778	2026-09-08 16:15:37.828699+00	1778	2026-09-08 16:15:36.538+00	1778	\N	relance
2552	2	75	2026-09-13	10:00-11:00	2	VN	LAPPARA	\N	2026-09-08 15:46:10.361866+00	1778	2026-09-08 16:15:42.935987+00	1778	2026-09-08 16:15:41.24+00	1778	\N	relance
2553	2	75	2026-09-13	10:00-11:00	2	VN	LAPPARA	\N	2026-09-08 15:46:10.398136+00	1778	2026-09-08 16:15:48.090489+00	1778	2026-09-08 16:15:46.764+00	1778	\N	relance
2554	2	75	2026-09-13	10:00-11:00	2	VN	LAPARRA	\N	2026-09-08 15:46:23.171546+00	1778	2026-09-08 16:15:51.089578+00	1778	2026-09-08 16:15:49.748+00	1778	\N	relance
8946	933	53	2026-10-09	10:00-11:00	1	VN	GAY	\N	2026-10-06 10:39:29.476869+00	9	\N	\N	\N	\N	da76a694-64bd-4959-825c-208df4310a65	relance
8953	933	53	2026-10-09	09:00-10:00	2	VN	DOLLE	\N	2026-10-06 10:40:47.879047+00	9	\N	\N	\N	\N	c1205d80-49ac-4181-b644-467540bd3b46	relance
8961	933	53	2026-10-09	17:00-18:00	2	VN	PEYRON	\N	2026-10-06 10:42:18.657002+00	9	\N	\N	\N	\N	10299eb4-27da-4c9c-a264-269e9de8a801	relance
9205	933	35	2026-10-09	16:00-17:00	1	VN	GOUT	\N	2026-10-06 15:03:01.411412+00	97	\N	\N	\N	\N	f67c726d-2160-4cf1-9ced-8257067a74e5	relance
9210	933	1886	2026-10-10	14:00-15:00	2	VN	KILLING SANDERO	\N	2026-10-06 15:03:34.187114+00	1776	\N	\N	\N	\N	7fbe6eb7-9d6b-410e-8856-dbcef11c75f8	relance
9218	933	40	2026-10-11	16:00-17:00	\N	VO	TRUPTIL	\N	2026-10-06 15:04:54.999995+00	97	\N	\N	\N	\N	e17d70fe-4dfb-4fa4-add5-60bd451c2e00	relance
9219	933	65	2026-10-09	18:00-19:00	1	VN	BIZOUARN / R5	\N	2026-10-06 15:06:32.22893+00	8	2026-10-06 15:06:39.947277+00	8	\N	\N	33516ba8-8264-41f7-9fcf-c7d74e8e7b30	relance
9411	933	51	2026-10-08	18:00-19:00	\N	VO	M GRUDE	\N	2026-10-06 16:29:28.34367+00	1783	\N	\N	\N	\N	21a14bd9-911f-46e0-b952-d5b0746a60c2	relance
9413	933	18	2026-10-09	14:00-15:00	1	VN	mroczek  r5	\N	2026-10-06 16:31:08.759095+00	4	\N	\N	\N	\N	7d5f548c-cdbc-419f-a2a7-23c315358bcc	relance
9483	933	71	2026-10-08	11:00-12:00	1	VN	CAUQUIL	\N	2026-10-07 07:49:48.237776+00	5501	2026-10-07 07:50:20.02208+00	5501	\N	\N	4797f49f-203d-4ef1-afa0-1adecf0d8bd1	relance
9552	933	87	2026-10-08	11:00-12:00	2	VN	CHIGNAC (Scenic etech VN)	\N	2026-10-07 09:46:47.716932+00	1777	\N	\N	\N	\N	512be42a-c8dd-4c87-9927-8c11bc96d41c	relance
9681	933	76	2026-10-10	16:00-17:00	1	VN	LOPEZ	\N	2026-10-08 13:05:02.596702+00	1778	\N	\N	\N	\N	642db077-60d2-4352-98c5-e5bef3c2d542	relance
9682	933	76	2026-10-10	17:00-18:00	1	VN	GRINOVIES	\N	2026-10-08 13:05:19.486903+00	1778	\N	\N	\N	\N	86b429ac-577d-439d-854e-021dc04768dc	relance
9744	933	67	2026-10-08	08:00-09:00	1	VN	CERET	\N	2026-10-10 07:05:04.439965+00	9	\N	\N	\N	\N	d4f5919d-763a-4686-b6a7-bfe871dac14f	showroom
9090	933	60	2026-10-10	16:00-17:00	1	VN	DOMEZEL	\N	2026-10-06 13:52:10.394014+00	7	2026-10-10 09:28:19.867451+00	7	2026-10-10 09:28:20.324+00	7	a45c6c9d-5b97-4d1e-820e-112ee7b45729	relance
2559	2	10	2026-09-12	10:00-11:00	1	VN	SAINT JOANNIS	\N	2026-09-08 15:49:04.506941+00	3	\N	\N	\N	\N	\N	relance
2562	2	53	2026-09-12	14:00-15:00	2	VN	FERRAPIE	\N	2026-09-08 15:51:21.192821+00	9	\N	\N	\N	\N	\N	relance
2563	2	33	2026-09-10	16:00-17:00	1	VN	pincon	\N	2026-09-08 15:51:22.488723+00	97	\N	\N	\N	\N	\N	relance
2568	2	43	2026-09-10	14:00-15:00	1	VN	GUILLOU CAPTUR	\N	2026-09-08 15:53:47.784907+00	1782	\N	\N	\N	\N	\N	relance
2569	2	41	2026-09-10	10:00-11:00	\N	VO	warot	\N	2026-09-08 15:53:51.964911+00	97	\N	\N	\N	\N	\N	relance
2570	2	43	2026-09-13	14:00-15:00	1	VN	CLAVEL R5 TWINGO	\N	2026-09-08 15:53:56.214373+00	1782	\N	\N	\N	\N	\N	relance
2571	2	35	2026-09-14	17:00-18:00	1	VN	vergne	\N	2026-09-08 15:53:59.50261+00	97	\N	\N	\N	\N	\N	relance
2572	2	43	2026-09-10	09:00-10:00	1	VN	LEVIEUX MEGANE E TECH	\N	2026-09-08 15:54:00.214644+00	1782	\N	\N	\N	\N	\N	relance
8734	933	62	2026-10-08	17:00-18:00	1	VN	LAETITIA	\N	2026-10-06 09:53:02.514925+00	9	\N	\N	\N	\N	9cd3720f-c3a2-44fd-a65f-624b612b97f2	relance
2576	2	43	2026-09-14	10:00-11:00	1	VN	DEGUELLE MEGANE TECH	\N	2026-09-08 15:54:16.041604+00	1782	\N	\N	\N	\N	\N	relance
2565	2	60	2026-09-11	12:00-13:00	1	VN	nnn	\N	2026-09-08 15:52:02.304829+00	7	2026-09-08 15:54:19.865425+00	7	2026-09-08 15:54:19.612+00	7	\N	relance
2577	2	65	2026-09-11	11:00-12:00	2	VN	RUISE	\N	2026-09-08 15:54:20.475609+00	9	\N	\N	\N	\N	\N	relance
2573	2	67	2026-09-10	09:00-10:00	1	VN	LARAT / R5	\N	2026-09-08 15:54:03.278747+00	8	2026-09-08 15:54:27.729049+00	8	2026-09-08 15:54:27.747+00	8	\N	relance
2575	2	67	2026-09-10	09:00-10:00	1	VN	LARAT / R5	\N	2026-09-08 15:54:15.857473+00	8	2026-09-08 15:54:48.816405+00	8	2026-09-08 15:54:43.792+00	8	\N	relance
2578	2	47	2026-09-10	09:00-10:00	\N	VO	ROSETTE	\N	2026-09-08 15:55:10.505658+00	1782	\N	\N	\N	\N	\N	relance
2579	2	47	2026-09-13	16:00-17:00	\N	VO	MME NICOLAS	\N	2026-09-08 15:55:14.716468+00	1782	\N	\N	\N	\N	\N	relance
2580	2	80	2026-09-10	12:00-13:00	1	VN	DELTOR TW3	\N	2026-09-08 15:55:18.112077+00	1776	2026-09-08 15:55:44.352972+00	1776	\N	\N	\N	relance
2581	2	69	2026-09-12	10:00-11:00	\N	VO	FOLTIER	\N	2026-09-08 15:56:04.354519+00	7	\N	\N	\N	\N	\N	relance
2582	2	1886	2026-09-12	11:00-12:00	2	VN	MUNERATTO SANDERO	\N	2026-09-08 15:56:13.134355+00	1776	2026-09-08 15:56:18.864403+00	1776	2026-09-08 15:56:19.277+00	1776	\N	relance
2583	2	68	2026-09-11	11:00-12:00	\N	VO	SANNIER	\N	2026-09-08 15:56:21.415318+00	9	\N	\N	\N	\N	\N	relance
2584	2	1886	2026-09-12	14:00-15:00	2	VN	GUALANO BIGSTER	\N	2026-09-08 15:56:37.157677+00	1776	2026-09-08 15:56:46.783714+00	1776	2026-09-08 15:56:46.991+00	1776	\N	relance
2586	2	1886	2026-09-12	16:00-17:00	2	VN	GARRIGUES SPRING	\N	2026-09-08 15:56:48.803905+00	1776	\N	\N	\N	\N	\N	relance
2587	2	61	2026-09-14	09:00-10:00	\N	VO	POUGET	\N	2026-09-08 15:56:52.205709+00	9	\N	\N	\N	\N	\N	relance
2589	2	1886	2026-09-12	14:00-15:00	2	VN	GUALANO BIGSTER	\N	2026-09-08 15:57:29.066295+00	1776	2026-09-08 15:57:35.822482+00	1776	2026-09-08 15:57:36.019+00	1776	\N	relance
2588	2	1887	2026-09-10	08:00-09:00	\N	VO	test	\N	2026-09-08 15:57:16.575322+00	92	2026-09-08 15:57:48.971452+00	92	2026-09-08 15:57:48.343+00	92	\N	relance
2590	2	1886	2026-09-12	15:00-16:00	2	VN	GUALANO BIGSTER	\N	2026-09-08 15:58:15.376876+00	1776	\N	\N	\N	\N	\N	relance
2591	2	3	2026-09-10	09:00-10:00	1	VN	TEST	\N	2026-09-08 15:58:27.060015+00	4	2026-09-08 15:58:35.768301+00	4	2026-09-08 15:58:35.834+00	4	\N	relance
2592	2	1886	2026-09-12	11:00-12:00	2	VN	MUNERATO SANDERO	\N	2026-09-08 15:58:43.555328+00	1776	\N	\N	\N	\N	\N	relance
2593	2	82	2026-09-11	09:00-10:00	1	VN	VANOUCHY TW3	\N	2026-09-08 15:59:21.62647+00	1776	2026-09-08 15:59:24.564132+00	1776	2026-09-08 15:59:24.977+00	1776	\N	relance
2594	2	82	2026-09-11	09:00-10:00	1	VN	VANOUCHY	\N	2026-09-08 15:59:45.431642+00	1776	\N	\N	\N	\N	\N	relance
2595	2	82	2026-09-11	16:00-17:00	2	VN	CAMI SANDERO	\N	2026-09-08 16:00:13.369962+00	1776	\N	\N	\N	\N	\N	relance
2557	2	10	2026-09-12	10:00-11:00	1	VN	SAINT JOANNIS	\N	2026-09-08 15:49:04.494758+00	3	2026-09-08 16:00:15.768408+00	3	2026-09-08 16:00:15.688+00	3	\N	relance
2596	2	70	2026-09-13	15:00-16:00	\N	VO	RAMOINEAU / TWINGO	\N	2026-09-08 16:00:27.392087+00	8	\N	\N	\N	\N	\N	relance
2598	2	82	2026-09-12	14:00-15:00	2	VN	BOKKER SPRING	\N	2026-09-08 16:00:38.536407+00	1776	\N	\N	\N	\N	\N	relance
2599	2	70	2026-09-11	14:00-15:00	\N	VO	BOUAOULI / CLIO	\N	2026-09-08 16:00:52.710672+00	8	\N	\N	\N	\N	\N	relance
2600	2	23	2026-09-12	11:00-12:00	\N	VO	ANDRE	\N	2026-09-08 16:00:55.266267+00	3	\N	\N	\N	\N	\N	relance
2601	2	23	2026-09-13	15:00-16:00	\N	VO	DONNAT	\N	2026-09-08 16:01:39.283482+00	3	\N	\N	\N	\N	\N	relance
2602	2	67	2026-09-10	09:00-10:00	1	VN	LARA / R5	\N	2026-09-08 16:01:39.102537+00	8	\N	\N	\N	\N	\N	relance
2606	2	213	2026-09-11	09:00-10:00	\N	VO	lioret	\N	2026-09-08 16:01:56.306405+00	6	\N	\N	\N	\N	\N	relance
2603	2	213	2026-09-11	09:00-10:00	\N	VO	4	\N	2026-09-08 16:01:39.609206+00	6	2026-09-08 16:02:00.645761+00	6	2026-09-08 16:02:00.46+00	6	\N	relance
2604	2	213	2026-09-11	09:00-10:00	\N	VO	lioret	\N	2026-09-08 16:01:44.202733+00	6	2026-09-08 16:02:08.27005+00	6	2026-09-08 16:02:06.756+00	6	\N	relance
2607	1	53	2026-06-11	13:00-14:00	1	VN	GAGNAIRE	\N	2026-09-08 16:02:13.273281+00	9	\N	\N	\N	\N	\N	relance
2605	2	213	2026-09-11	09:00-10:00	\N	VO	lioret	\N	2026-09-08 16:01:54.137697+00	6	2026-09-08 16:02:18.373242+00	6	2026-09-08 16:02:16.729+00	6	\N	relance
2608	2	67	2026-09-10	18:00-19:00	1	VN	BAILLON / R5	\N	2026-09-08 16:02:18.580712+00	8	\N	\N	\N	\N	\N	relance
2609	2	9	2026-09-11	10:00-11:00	\N	VO	vedrine	\N	2026-09-08 16:02:49.296902+00	6	\N	\N	\N	\N	\N	relance
2610	2	67	2026-09-12	10:00-11:00	1	VN	GRIMA / CLIO	\N	2026-09-08 16:02:51.013762+00	8	\N	\N	\N	\N	\N	relance
2611	2	11	2026-09-11	13:00-14:00	1	VN	BULAND  ELECTRIQUE	\N	2026-09-08 16:03:04.315159+00	2	\N	\N	\N	\N	\N	relance
2612	2	67	2026-09-13	10:00-11:00	1	VN	ESTOC / TWINGO	\N	2026-09-08 16:03:27.288932+00	8	\N	\N	\N	\N	\N	relance
2613	2	18	2026-09-11	15:00-16:00	1	VN	BONNET JOGGER	\N	2026-09-08 16:03:28.318911+00	4	\N	\N	\N	\N	\N	relance
2614	2	11	2026-09-14	14:00-15:00	1	VN	BALLET	\N	2026-09-08 16:03:31.355634+00	2	\N	\N	\N	\N	\N	relance
2616	2	67	2026-09-13	11:00-12:00	1	VN	DUMAS / TWINGO	\N	2026-09-08 16:03:41.344163+00	8	\N	\N	\N	\N	\N	relance
2617	2	18	2026-09-12	11:00-12:00	1	VN	TEYSSIER CLIO	\N	2026-09-08 16:04:02.51077+00	4	\N	\N	\N	\N	\N	relance
2618	2	66	2026-09-13	13:00-14:00	1	VN	DESVAUX / TWINGO	\N	2026-09-08 16:04:07.337783+00	8	\N	\N	\N	\N	\N	relance
2619	2	2	2026-09-10	14:00-15:00	1	VN	BOURDUGE	\N	2026-09-08 16:04:09.919879+00	3	\N	\N	\N	\N	\N	relance
2620	2	66	2026-09-14	14:00-15:00	1	VN	ROUVEAU / R5	\N	2026-09-08 16:04:24.429125+00	8	\N	\N	\N	\N	\N	relance
2621	2	18	2026-09-12	15:00-16:00	1	VN	CLAVEROL  CAPTUR	\N	2026-09-08 16:04:25.449844+00	4	\N	\N	\N	\N	\N	relance
2622	2	66	2026-09-14	16:00-17:00	1	VN	VEISSEYRE / TWINGO	\N	2026-09-08 16:04:50.170991+00	8	\N	\N	\N	\N	\N	relance
2623	2	19	2026-09-12	16:00-17:00	1	VN	GAREIL R5	\N	2026-09-08 16:05:08.78938+00	2	\N	\N	\N	\N	\N	relance
2624	2	66	2026-09-13	10:00-11:00	1	VN	ROBERTS / R5	\N	2026-09-08 16:05:12.056382+00	8	\N	\N	\N	\N	\N	relance
2625	2	19	2026-09-12	17:00-18:00	1	VN	BASPERAS CLIO6	\N	2026-09-08 16:05:25.202208+00	2	\N	\N	\N	\N	\N	relance
2626	2	66	2026-09-12	14:00-15:00	2	VN	BRINON / DUSTER	\N	2026-09-08 16:05:26.880933+00	8	\N	\N	\N	\N	\N	relance
2628	1	65	2026-06-11	18:00-19:00	1	VN	CN CHAUFFAGE	\N	2026-09-08 16:05:39.996923+00	9	\N	\N	\N	\N	\N	relance
2585	2	44	2026-09-11	17:00-18:00	1	VN	JOLDAIN VO	\N	2026-09-08 15:56:47.21141+00	1782	2026-09-08 16:57:07.514513+00	1782	2026-09-08 16:57:06.988+00	1782	\N	relance
2615	2	2	2026-09-12	10:00-11:00	1	VN	MABRUT	\N	2026-09-08 16:03:41.254942+00	3	2026-09-08 16:58:24.193283+00	3	2026-09-08 16:58:23.915+00	3	\N	relance
2627	2	2	2026-09-13	08:00-09:00	1	VN	VILLENEUVE	\N	2026-09-08 16:05:27.089619+00	3	2026-09-08 16:05:34.389495+00	3	2026-09-08 16:05:34.241+00	3	\N	relance
2629	2	10	2026-09-13	08:00-09:00	1	VN	VILLENEUVE	\N	2026-09-08 16:05:51.259139+00	3	\N	\N	\N	\N	\N	relance
2630	2	66	2026-09-14	15:00-16:00	1	VN	LE CLEUYOUR / CLIO	\N	2026-09-08 16:05:54.584904+00	8	\N	\N	\N	\N	\N	relance
2631	2	19	2026-09-13	08:00-09:00	1	VN	MIGLIAWACCA SCENIC	\N	2026-09-08 16:05:58.871039+00	2	\N	\N	\N	\N	\N	relance
2632	2	10	2026-09-13	11:00-12:00	1	VN	VEGAS	\N	2026-09-08 16:06:04.138096+00	3	\N	\N	\N	\N	\N	relance
2636	2	19	2026-09-13	10:00-11:00	1	VN	BRUNEL R5	\N	2026-09-08 16:06:21.579866+00	2	\N	\N	\N	\N	\N	relance
2650	2	10	2026-09-13	15:00-16:00	1	VN	MEUNIER	\N	2026-09-08 16:06:34.013473+00	3	\N	\N	\N	\N	\N	relance
2651	2	59	2026-09-14	18:00-19:00	1	VN	ROUQUETTE / R5	\N	2026-09-08 16:06:36.074411+00	8	\N	\N	\N	\N	\N	relance
2656	2	211	2026-09-14	14:00-15:00	\N	VO	MASSEBOEUF KUGA	\N	2026-09-08 16:06:58.927517+00	2	\N	\N	\N	\N	\N	relance
2657	2	36	2026-09-10	11:00-12:00	1	VN	jouve	\N	2026-09-08 16:07:00.475098+00	97	\N	\N	\N	\N	\N	relance
2658	2	59	2026-09-12	15:00-16:00	1	VN	TUNA / SYMBIOZ	\N	2026-09-08 16:07:05.150563+00	8	\N	\N	\N	\N	\N	relance
2675	2	94	2026-09-14	16:00-17:00	1	VN	CRANTELLE	\N	2026-09-08 16:07:22.704801+00	1780	\N	\N	\N	\N	\N	relance
2678	2	36	2026-09-11	17:00-18:00	1	VN	jardino	\N	2026-09-08 16:07:40.05874+00	97	\N	\N	\N	\N	\N	relance
2680	2	92	2026-09-11	14:00-15:00	1	VN	ANESA	\N	2026-09-08 16:08:01.181056+00	1780	\N	\N	\N	\N	\N	relance
2690	2	49	2026-09-13	10:00-11:00	1	VN	M LAHMRY	\N	2026-09-08 16:09:46.282609+00	1783	\N	\N	\N	\N	\N	relance
2691	2	49	2026-09-14	09:00-10:00	1	VN	M MARC	\N	2026-09-08 16:09:53.785026+00	1783	\N	\N	\N	\N	\N	relance
2694	2	49	2026-09-10	16:00-17:00	1	VN	M PUISSANT	\N	2026-09-08 16:10:32.023526+00	1783	\N	\N	\N	\N	\N	relance
8735	933	62	2026-10-09	11:00-12:00	1	VN	ROCHE	\N	2026-10-06 09:53:16.501626+00	9	\N	\N	\N	\N	2c56d600-af6d-499a-b6ce-374988431276	relance
8939	933	19	2026-10-09	14:00-15:00	1	VN	BRUNEL ( AUSTRAL)	\N	2026-10-06 10:37:42.456374+00	2	\N	\N	\N	\N	faa8d3d7-e939-4d66-8c0a-b6328b454a03	relance
8958	933	53	2026-10-12	18:00-19:00	2	VN	COMBUEIL	\N	2026-10-06 10:41:18.825297+00	9	\N	\N	\N	\N	14eda256-4b3f-4409-867a-a659c5dd0007	relance
8959	933	4205	2026-10-10	10:00-11:00	\N	VO	BELLELLE CLIO E TECH	\N	2026-10-06 10:42:02.195155+00	1782	\N	\N	\N	\N	01a6d031-b153-4c9c-a996-b425381ffd07	relance
9091	933	70	2026-10-11	10:00-11:00	\N	VO	CHABANNE SANDERO	\N	2026-10-06 13:54:34.456143+00	7	\N	\N	\N	\N	e311aecf-f6d8-40e7-b910-6d395f6180e0	relance
9206	933	49	2026-10-11	16:00-17:00	1	VN	M CULPO	\N	2026-10-06 15:03:06.1807+00	1783	\N	\N	\N	\N	f91023e3-4387-41a1-965b-e2b3ecffd4cf	relance
9213	933	1886	2026-10-09	16:00-17:00	2	VN	SANSON DUSTER	\N	2026-10-06 15:03:43.545813+00	1776	\N	\N	\N	\N	684595c5-f1a3-4e65-9e7a-1ba86a28b025	relance
9215	933	40	2026-10-09	11:00-12:00	\N	VO	JULIEN	\N	2026-10-06 15:04:26.847686+00	97	\N	\N	\N	\N	3f3acbe1-9bb9-4e27-b9c9-984285ea1543	relance
9221	933	67	2026-10-09	09:00-10:00	1	VN	LARA / R5	\N	2026-10-06 15:08:08.838589+00	8	\N	\N	\N	\N	b4215fe4-b707-4893-8a5b-bf7855348f59	relance
9412	933	18	2026-10-09	17:00-18:00	1	VN	magalaes  twingo	\N	2026-10-06 16:30:44.360367+00	4	\N	\N	\N	\N	3c1ed7ae-18da-40bf-93a9-67fe91efcf16	relance
9553	933	87	2026-10-08	14:00-15:00	2	VN	CHU St AFFRIQUE (Trafic VN)	\N	2026-10-07 09:47:23.2169+00	1777	\N	\N	\N	\N	8385a3d7-acb6-4ca9-b58e-32cf0995a530	relance
9683	933	15	2026-10-08	10:00-11:00	1	VN	texetra	\N	2026-10-08 15:25:39.894588+00	5	\N	\N	\N	\N	a5d4a426-364e-41eb-b47f-9cec158696e5	relance
9484	933	71	2026-10-08	14:00-15:00	1	VN	HILD	\N	2026-10-07 07:49:56.254726+00	5501	2026-10-09 15:50:12.911652+00	5501	2026-10-09 15:50:12.817+00	5501	471b252c-7f5c-41c5-8fce-061e5c94e425	relance
9745	933	68	2026-10-08	08:00-09:00	\N	VO	PASSERIEUX	\N	2026-10-10 07:07:47.702734+00	9	\N	\N	\N	\N	b5816ee7-1ffa-4462-bfa3-e50d6053709b	showroom
2633	2	59	2026-09-13	11:00-12:00	1	VN	AMAT / CLIO	\N	2026-09-08 16:06:18.475911+00	8	\N	\N	\N	\N	\N	relance
8736	933	26	2026-10-08	10:00-11:00	1	VN	ROBERT ( R4)	\N	2026-10-06 09:53:24.845243+00	2	\N	\N	\N	\N	6d9be5e8-5118-407e-854a-7426b179ac61	relance
8941	933	53	2026-10-08	10:00-11:00	1	VN	GOUNON	\N	2026-10-06 10:38:59.361308+00	9	\N	\N	\N	\N	471eb2b0-5c42-4347-acdb-cec1e1f9531c	relance
8943	933	56	2026-10-12	17:00-18:00	1	VN	LACOMBE SPRING	\N	2026-10-06 10:39:06.596509+00	7	\N	\N	\N	\N	f1cd9843-4e5b-4282-8b5d-2fc7792448fb	relance
8947	933	53	2026-10-09	11:00-12:00	1	VN	SAUVANT	\N	2026-10-06 10:39:37.556676+00	9	2026-10-06 10:39:59.137418+00	9	\N	\N	61dfee05-8abe-493a-ac48-bbb251b60b15	relance
8957	933	40	2026-10-10	15:00-16:00	\N	VO	JAILLET	\N	2026-10-06 10:41:16.406631+00	97	\N	\N	\N	\N	8d44ee72-a93b-49b5-98b7-cf6d42553a5b	relance
9092	933	70	2026-10-10	11:00-12:00	\N	VO	CHADUC DUSTER	\N	2026-10-06 14:00:02.766099+00	7	2026-10-06 14:44:27.098739+00	7	2026-10-06 14:44:27.083+00	7	ea93c252-a6ef-4c68-b79d-fe5551684dcb	relance
9207	933	1886	2026-10-09	14:00-15:00	2	VN	KORZEMIKI	\N	2026-10-06 15:03:10.770159+00	1776	2026-10-06 15:03:23.320933+00	1776	\N	\N	9a49543b-0bc9-485d-85c9-0aab53a06532	relance
9211	933	51	2026-10-10	10:00-11:00	\N	VO	M MANDONNET	\N	2026-10-06 15:03:35.795013+00	1783	\N	\N	\N	\N	da93527a-17d5-4bde-b0b8-816500f302b1	relance
9212	933	51	2026-10-10	11:00-12:00	\N	VO	M SOUCHU	\N	2026-10-06 15:03:39.829701+00	1783	\N	\N	\N	\N	8731ceae-d93e-4182-b003-71ae4e0eb0a2	relance
9214	933	40	2026-10-08	09:00-10:00	\N	VO	MASSARD	\N	2026-10-06 15:04:14.389141+00	97	\N	\N	\N	\N	a35bb9ba-0feb-499b-ab36-7e6faff509f3	relance
2659	2	2	2026-09-10	16:00-17:00	1	VN	SOULARD	\N	2026-09-08 16:07:06.541296+00	3	\N	\N	\N	\N	\N	relance
2660	2	36	2026-09-10	14:00-15:00	1	VN	escudero	\N	2026-09-08 16:07:10.412978+00	97	\N	\N	\N	\N	\N	relance
9216	933	40	2026-10-09	16:00-17:00	\N	VO	DARCOUX	\N	2026-10-06 15:04:36.759573+00	97	\N	\N	\N	\N	cf891294-f790-46b3-9602-8f15a165810f	relance
9414	933	4206	2026-10-12	17:00-18:00	\N	VO	CHEVALIER CAPTUR	\N	2026-10-06 16:31:13.184574+00	1782	\N	\N	\N	\N	2bf39c9f-33cb-4f77-bfe0-55c0f96f42de	relance
9485	933	71	2026-10-08	16:00-17:00	1	VN	LE NORMAND	\N	2026-10-07 07:50:06.558898+00	5501	\N	\N	\N	\N	743f651e-39ee-4680-8543-e55def372528	relance
9486	933	71	2026-10-10	11:00-12:00	1	VN	TURGIS	\N	2026-10-07 07:50:32.582421+00	5501	\N	\N	\N	\N	17e37dd0-e15a-4380-b005-56205d8079a8	relance
2671	2	94	2026-09-14	10:00-11:00	1	VN	COUDERC	\N	2026-09-08 16:07:19.089332+00	1780	\N	\N	\N	\N	\N	relance
9554	933	87	2026-10-09	10:00-11:00	2	VN	PORTES (Twingo ou Spring VN)	\N	2026-10-07 09:47:42.250678+00	1777	\N	\N	\N	\N	9a71fe81-32be-4067-8a9b-6a9b90f0b44e	relance
9684	933	17	2026-10-08	18:00-19:00	1	VN	CARIOL TWINGO	\N	2026-10-08 15:42:58.988967+00	5	\N	\N	\N	\N	90d38151-0e2b-4c06-b064-0aa3f3a027e3	relance
9746	933	68	2026-10-08	08:00-09:00	\N	VO	FAYE	\N	2026-10-10 07:09:27.314416+00	9	\N	\N	\N	\N	69e546c9-1ff1-4a24-b424-0aaa265b6b78	showroom
2677	2	59	2026-09-10	17:00-18:00	1	VN	NURIT / R5	\N	2026-09-08 16:07:30.06259+00	8	\N	\N	\N	\N	\N	relance
2679	2	92	2026-09-12	15:00-16:00	2	VN	BENECH	\N	2026-09-08 16:07:54.38646+00	1780	\N	\N	\N	\N	\N	relance
2681	2	36	2026-09-12	10:00-11:00	1	VN	mariller	\N	2026-09-08 16:08:02.687819+00	97	\N	\N	\N	\N	\N	relance
2683	2	36	2026-09-13	11:00-12:00	1	VN	franchesco alu	\N	2026-09-08 16:08:28.053587+00	97	\N	\N	\N	\N	\N	relance
2376	2	882	2026-09-13	11:00-12:00	\N	VO	DARDELET / SCENIC VO	\N	2026-09-08 14:58:01.817019+00	8	2026-09-08 16:08:35.062315+00	8	2026-09-08 16:08:35.159+00	8	\N	relance
2685	2	50	2026-09-12	17:00-18:00	1	VN	M MARSON	\N	2026-09-08 16:08:48.779076+00	1783	\N	\N	\N	\N	\N	relance
2692	2	48	2026-09-12	10:00-11:00	1	VN	M MANRESA	\N	2026-09-08 16:10:19.557017+00	1783	\N	\N	\N	\N	\N	relance
2693	2	81	2026-09-14	16:00-17:00	1	VN	SIGNOVIA TW3	\N	2026-09-08 16:10:29.620519+00	1776	\N	\N	\N	\N	\N	relance
2695	2	50	2026-09-11	10:00-11:00	1	VN	M BRUNET	\N	2026-09-08 16:11:29.49365+00	1783	\N	\N	\N	\N	\N	relance
2696	2	50	2026-09-13	16:00-17:00	1	VN	M VORILHON	\N	2026-09-08 16:11:58.56974+00	1783	\N	\N	\N	\N	\N	relance
2697	2	50	2026-09-14	10:00-11:00	1	VN	M ARTHAUD	\N	2026-09-08 16:12:12.826236+00	1783	\N	\N	\N	\N	\N	relance
2682	2	36	2026-09-12	11:00-12:00	1	VN	bosse	\N	2026-09-08 16:08:07.20824+00	97	\N	\N	\N	\N	\N	relance
2686	2	882	2026-09-12	14:00-15:00	\N	VO	CHAPUIS / ZOE	\N	2026-09-08 16:08:52.824134+00	8	\N	\N	\N	\N	\N	relance
2687	2	50	2026-09-13	15:00-16:00	1	VN	M POUGHEON	\N	2026-09-08 16:09:03.649805+00	1783	\N	\N	\N	\N	\N	relance
2688	2	49	2026-09-13	09:00-10:00	1	VN	M IMBERT	\N	2026-09-08 16:09:13.145932+00	1783	\N	\N	\N	\N	\N	relance
8737	933	62	2026-10-10	14:00-15:00	1	VN	GROS	\N	2026-10-06 09:53:28.160444+00	9	\N	\N	\N	\N	0d7ff2c8-0068-45b5-aaf2-12586b140064	relance
8945	933	53	2026-10-08	18:00-19:00	1	VN	ENJOLRAS	\N	2026-10-06 10:39:17.327561+00	9	\N	\N	\N	\N	6fa94f74-7d52-4915-867e-d4808c5d0f72	relance
9093	933	49	2026-10-09	10:00-11:00	1	VN	M CAYRE (VP RODDIER)	\N	2026-10-06 14:04:05.174122+00	1783	\N	\N	\N	\N	12e7483b-2048-4475-afea-e8f717602e9c	relance
9222	933	59	2026-10-08	15:00-16:00	1	VN	SOPENARD R5	\N	2026-10-06 15:08:39.05429+00	7	\N	\N	\N	\N	db1ab09b-a80b-47df-93e4-22e4d9386851	relance
9415	933	4206	2026-10-12	18:00-19:00	\N	VO	DANTIQUI R5 CLIO ESPRIT	\N	2026-10-06 16:31:33.107724+00	1782	\N	\N	\N	\N	f9f4d57f-f5d0-409f-885b-09ec9ee7e841	relance
9487	933	72	2026-10-08	10:00-11:00	1	VN	GENEBRE	\N	2026-10-07 07:52:08.436795+00	5501	\N	\N	\N	\N	a880b7b3-bb7f-431d-a96f-a11b271dc666	relance
9555	933	87	2026-10-10	09:00-10:00	2	VN	BLANC (Sandero LOA VN)	\N	2026-10-07 09:48:15.155913+00	1777	\N	\N	\N	\N	903482c9-92eb-4d93-a6cb-11f934bd0654	relance
9685	933	61	2026-10-08	16:00-17:00	\N	VO	BLANC	\N	2026-10-08 15:46:24.150733+00	7	2026-10-08 16:42:16.385139+00	7	\N	\N	8228118e-999e-4ba2-8fb0-5e54a9b18d2f	relance
9747	933	68	2026-10-08	14:00-15:00	\N	VO	ALBOURIE	\N	2026-10-10 07:09:48.37606+00	9	\N	\N	\N	\N	7d35974e-aeec-430a-86b4-1b200d5cf4d3	showroom
2684	2	92	2026-09-13	10:00-11:00	1	VN	RAYNAL	\N	2026-09-08 16:08:28.077179+00	1780	\N	\N	\N	\N	\N	relance
2689	2	1887	2026-09-11	16:00-17:00	\N	VO	M PELLISON	\N	2026-09-08 16:09:32.503679+00	1783	\N	\N	\N	\N	\N	relance
2698	2	1887	2026-09-11	15:00-16:00	\N	VO	M BRUN	\N	2026-09-08 16:12:25.118485+00	1783	\N	\N	\N	\N	\N	relance
2699	2	33	2026-09-11	11:00-12:00	1	VN	morance	\N	2026-09-08 16:12:28.324973+00	97	\N	\N	\N	\N	\N	relance
8738	933	26	2026-10-08	15:00-16:00	2	VN	RUNNER ( SANDERO)	\N	2026-10-06 09:53:41.588619+00	2	\N	\N	\N	\N	902e4417-3481-4991-8f46-bd2584f6412e	relance
2701	2	96	2026-09-10	10:00-11:00	2	VN	MANIC SPRING	\N	2026-09-08 16:12:47.391872+00	1775	\N	\N	\N	\N	\N	relance
2703	2	96	2026-09-10	14:00-15:00	1	VN	ALCOUFFE	\N	2026-09-08 16:13:06.566169+00	1775	\N	\N	\N	\N	\N	relance
2705	2	54	2026-09-13	10:00-11:00	1	VN	AGRAIN / RAFALE	\N	2026-09-08 16:13:14.777679+00	8	\N	\N	\N	\N	\N	relance
2706	2	96	2026-09-10	15:00-16:00	1	VN	MORIN	\N	2026-09-08 16:13:17.2816+00	1775	\N	\N	\N	\N	\N	relance
2709	1	68	2026-06-12	17:00-18:00	\N	VO	QUBELKO	\N	2026-09-08 16:13:35.275717+00	9	\N	\N	\N	\N	\N	relance
2710	2	96	2026-09-11	14:00-15:00	1	VN	BRICARD	\N	2026-09-08 16:13:37.875555+00	1775	\N	\N	\N	\N	\N	relance
2712	2	96	2026-09-12	09:00-10:00	1	VN	COPO CLIO	\N	2026-09-08 16:13:55.500623+00	1775	2026-09-08 16:13:58.50124+00	1775	2026-09-08 16:13:58.935+00	1775	\N	relance
2713	2	12	2026-09-13	14:00-15:00	1	VN	GORAND SANDERO	\N	2026-09-08 16:14:12.372391+00	4	2026-09-09 16:22:13.456452+00	92	2026-09-09 16:22:13.09+00	92	\N	relance
2702	2	12	2026-09-12	17:00-18:00	1	VN	DUFAURE  SANDERO	\N	2026-09-08 16:12:50.688215+00	4	2026-09-09 16:22:43.062296+00	92	2026-09-09 16:22:42.731+00	92	\N	relance
2714	2	23	2026-09-11	18:00-19:00	\N	VO	LOPES	\N	2026-09-08 16:14:32.365778+00	3	\N	\N	\N	\N	\N	relance
2718	2	97	2026-09-14	15:00-16:00	1	VN	BEN ABI	\N	2026-09-08 16:15:29.550754+00	1775	\N	\N	\N	\N	\N	relance
2719	2	97	2026-09-10	16:00-17:00	1	VN	COLONGES	\N	2026-09-08 16:15:51.128414+00	1775	\N	\N	\N	\N	\N	relance
2720	2	78	2026-09-11	11:00-12:00	1	VN	ASSIE	\N	2026-09-08 16:16:25.590171+00	1778	\N	\N	\N	\N	\N	relance
2721	2	84	2026-09-14	09:00-10:00	\N	VO	DERIEN CLIO	\N	2026-09-08 16:16:38.593538+00	1776	\N	\N	\N	\N	\N	relance
2722	2	1890	2026-09-10	17:00-18:00	\N	VO	BELMOKTAR - VO LOA	\N	2026-09-08 16:17:16.168749+00	1777	\N	\N	\N	\N	\N	relance
2723	2	1890	2026-09-11	10:00-11:00	\N	VO	VERGUES - SCENIC VN	\N	2026-09-08 16:17:26.679071+00	1777	\N	\N	\N	\N	\N	relance
2724	2	84	2026-09-12	12:00-13:00	\N	VO	GUIGNO CLIO	\N	2026-09-08 16:17:26.754107+00	1776	\N	\N	\N	\N	\N	relance
2725	2	84	2026-09-12	14:00-15:00	\N	VO	CANTAGREL	\N	2026-09-08 16:17:46.918532+00	1776	\N	\N	\N	\N	\N	relance
2726	2	84	2026-09-11	15:00-16:00	\N	VO	HANESS CAPTUR	\N	2026-09-08 16:18:04.931325+00	1776	\N	\N	\N	\N	\N	relance
2727	2	15	2026-09-13	10:00-11:00	1	VN	GUILLOT R5	\N	2026-09-08 16:18:12.016246+00	2	\N	\N	\N	\N	\N	relance
2728	2	69	2026-09-14	09:00-10:00	\N	VO	VERICENE	\N	2026-09-08 16:18:35.652645+00	7	\N	\N	\N	\N	\N	relance
2729	2	23	2026-09-13	10:00-11:00	\N	VO	BARD	\N	2026-09-08 16:20:05.35418+00	3	\N	\N	\N	\N	\N	relance
2730	2	99	2026-09-10	10:00-11:00	2	VN	BONNAFOUS	\N	2026-09-08 16:20:07.802817+00	1778	\N	\N	\N	\N	\N	relance
2731	2	99	2026-09-14	13:00-14:00	1	VN	FABRICE	\N	2026-09-08 16:20:18.873202+00	1778	\N	\N	\N	\N	\N	relance
2732	2	71	2026-09-12	16:00-17:00	1	VN	VIGUIE	\N	2026-09-08 16:20:47.455843+00	1778	\N	\N	\N	\N	\N	relance
2733	2	74	2026-09-12	17:00-18:00	2	VN	FESTA	\N	2026-09-08 16:21:05.287465+00	1778	\N	\N	\N	\N	\N	relance
2366	2	14	2026-09-10	11:00-12:00	1	VN	CHOLLER SANDERO	\N	2026-09-08 14:55:25.096519+00	5	2026-09-08 16:21:30.558875+00	5	2026-09-08 16:21:30.655+00	5	\N	relance
2735	2	27	2026-09-13	15:00-16:00	1	VN	SANDONA AUSTRAL	\N	2026-09-08 16:22:40.899925+00	5	\N	\N	\N	\N	\N	relance
2736	2	27	2026-09-10	18:00-19:00	1	VN	GUILLER DUSTER	\N	2026-09-08 16:22:59.315857+00	5	\N	\N	\N	\N	\N	relance
2737	2	34	2026-09-14	17:00-18:00	1	VN	meyrial lagrange	\N	2026-09-08 16:23:49.425773+00	97	\N	\N	\N	\N	\N	relance
2738	2	34	2026-09-12	17:00-18:00	1	VN	bletery	\N	2026-09-08 16:24:04.897176+00	97	\N	\N	\N	\N	\N	relance
2739	2	34	2026-09-12	15:00-16:00	1	VN	fradin	\N	2026-09-08 16:24:11.373373+00	97	\N	\N	\N	\N	\N	relance
2740	2	34	2026-09-11	11:00-12:00	1	VN	devillard	\N	2026-09-08 16:24:26.406531+00	97	\N	\N	\N	\N	\N	relance
2741	2	87	2026-09-12	16:00-17:00	2	VN	BOYER - KEX VU	\N	2026-09-08 16:25:01.154306+00	1777	\N	\N	\N	\N	\N	relance
2742	2	43	2026-09-13	15:00-16:00	1	VN	ROBERT TWINGO	\N	2026-09-08 16:25:29.117921+00	1782	\N	\N	\N	\N	\N	relance
2743	2	43	2026-09-10	10:00-11:00	1	VN	AUCLAIR KANGOO	\N	2026-09-08 16:26:10.125015+00	1782	\N	\N	\N	\N	\N	relance
2744	2	79	2026-09-12	14:00-15:00	1	VN	MIHALOCHI	\N	2026-09-08 16:26:27.664545+00	1776	\N	\N	\N	\N	\N	relance
2745	2	5	2026-09-12	09:00-10:00	1	VN	CARTIER SANDERO	\N	2026-09-08 16:26:58.424889+00	5	\N	\N	\N	\N	\N	relance
2746	2	5	2026-09-12	11:00-12:00	1	VN	MOSSANG DUSTER	\N	2026-09-08 16:27:11.607754+00	5	\N	\N	\N	\N	\N	relance
2747	2	5	2026-09-11	17:00-18:00	1	VN	TAILLANDIER TRAFFIC	\N	2026-09-08 16:27:29.479029+00	5	\N	\N	\N	\N	\N	relance
2748	2	62	2026-09-11	15:00-16:00	1	VN	BAYLOT	\N	2026-09-08 16:28:17.085816+00	7	\N	\N	\N	\N	\N	relance
2749	2	53	2026-09-10	13:00-14:00	1	VN	GAGNAIRE	\N	2026-09-08 16:28:22.089406+00	9	\N	\N	\N	\N	\N	relance
2750	2	16	2026-09-12	16:00-17:00	1	VN	LACOTE	\N	2026-09-08 16:28:39.53964+00	3	\N	\N	\N	\N	\N	relance
2751	2	53	2026-09-10	14:00-15:00	1	VN	LABROSSE	\N	2026-09-08 16:28:47.363423+00	9	\N	\N	\N	\N	\N	relance
2574	2	53	2026-09-11	14:00-15:00	2	VN	.	\N	2026-09-08 15:54:03.847471+00	9	2026-09-08 16:28:52.291906+00	9	2026-09-08 16:28:51.905+00	9	\N	relance
2752	2	16	2026-09-11	16:00-17:00	1	VN	SCHULTZ	\N	2026-09-08 16:28:54.296507+00	3	\N	\N	\N	\N	\N	relance
2753	2	16	2026-09-14	10:00-11:00	1	VN	BLE	\N	2026-09-08 16:29:07.190104+00	3	\N	\N	\N	\N	\N	relance
2754	2	60	2026-09-14	16:00-17:00	2	VN	NACIVERA	\N	2026-09-08 16:29:16.372599+00	7	\N	\N	\N	\N	\N	relance
2755	2	55	2026-09-10	16:00-17:00	1	VN	BARBIERI	\N	2026-09-08 16:30:07.869077+00	9	\N	\N	\N	\N	\N	relance
2756	2	48	2026-09-12	15:00-16:00	1	VN	M BOURRE	\N	2026-09-08 16:30:35.186084+00	1783	\N	\N	\N	\N	\N	relance
2757	2	65	2026-09-10	18:00-19:00	1	VN	CN CHAUFFAGE	\N	2026-09-08 16:30:50.597478+00	9	\N	\N	\N	\N	\N	relance
2758	2	65	2026-09-12	09:00-10:00	1	VN	BERTRAND	\N	2026-09-08 16:31:11.58706+00	9	\N	\N	\N	\N	\N	relance
2759	2	18	2026-09-10	15:00-16:00	1	VN	COURAEL  R5	\N	2026-09-08 16:31:11.636194+00	4	\N	\N	\N	\N	\N	relance
2760	2	66	2026-09-10	15:00-16:00	2	VN	THIEBAULD / SANDERO	\N	2026-09-08 16:31:32.569301+00	8	\N	\N	\N	\N	\N	relance
2761	2	54	2026-09-13	14:00-15:00	1	VN	MARSOLAT /	\N	2026-09-08 16:32:19.5321+00	8	\N	\N	\N	\N	\N	relance
2704	2	12	2026-09-13	09:00-10:00	1	VN	MOUGIN SANDERO	\N	2026-09-08 16:13:12.935555+00	4	2026-09-09 16:21:09.402951+00	92	2026-09-09 16:21:09.045+00	92	\N	relance
2707	2	12	2026-09-13	10:00-11:00	1	VN	ROUX  DUSTER	\N	2026-09-08 16:13:19.640703+00	4	2026-09-09 16:21:25.275772+00	92	2026-09-09 16:21:24.934+00	92	\N	relance
2716	2	12	2026-09-14	10:00-11:00	1	VN	BEYNEIX  SPRING	\N	2026-09-08 16:14:57.736035+00	4	2026-09-09 16:21:28.164214+00	92	2026-09-09 16:21:27.779+00	92	\N	relance
2708	2	12	2026-09-13	11:00-12:00	1	VN	REVENU SANDERO	\N	2026-09-08 16:13:27.744461+00	4	2026-09-09 16:21:41.805544+00	92	2026-09-09 16:21:41.454+00	92	\N	relance
2717	2	12	2026-09-14	11:00-12:00	1	VN	TRONCHE  DUSTER	\N	2026-09-08 16:15:09.276671+00	4	2026-09-09 16:21:44.597012+00	92	2026-09-09 16:21:44.254+00	92	\N	relance
2734	2	14	2026-09-14	14:00-15:00	1	VN	GIRONDE SANDERO	\N	2026-09-08 16:21:49.46526+00	5	2026-09-09 16:23:51.955219+00	92	2026-09-09 16:23:51.613+00	92	\N	relance
2762	2	31	2026-09-12	10:00-11:00	2	VN	lebars	\N	2026-09-08 16:32:44.263008+00	97	\N	\N	\N	\N	\N	relance
2765	2	70	2026-09-10	15:00-16:00	\N	VO	MARVILLON / KADJAR	\N	2026-09-08 16:34:02.226842+00	8	\N	\N	\N	\N	\N	relance
8739	933	62	2026-10-10	15:00-16:00	1	VN	VANDENBROUCKE	\N	2026-10-06 09:53:49.935595+00	9	\N	\N	\N	\N	dd43c670-9ced-4de2-b3d0-839cf9a2a107	relance
8948	933	53	2026-10-09	14:00-15:00	1	VN	PELLERTIER	\N	2026-10-06 10:39:43.882851+00	9	\N	\N	\N	\N	356ab63c-c493-4020-9dd9-2094ec0cf6cf	relance
8951	933	53	2026-10-12	14:00-15:00	1	VN	BESTE	\N	2026-10-06 10:40:19.070271+00	9	\N	\N	\N	\N	b30806af-745f-4a07-987d-c3a8651e9be2	relance
9094	933	49	2026-10-09	14:00-15:00	1	VN	M PACHET(VP RODDIER)	\N	2026-10-06 14:04:32.937386+00	1783	2026-10-06 14:06:16.72963+00	1783	\N	\N	11793e18-fbec-441f-8748-2cf54945b287	relance
9224	933	56	2026-10-08	15:00-16:00	1	VN	VO NAKAARS CLIO V	\N	2026-10-06 15:11:03.244513+00	7	\N	\N	\N	\N	6c0a38c7-a59d-4138-94cd-93c7b86499f9	relance
9232	933	6	2026-10-10	08:00-09:00	1	VN	VALETTE ( R5)	\N	2026-10-06 15:14:04.81031+00	2	\N	\N	\N	\N	e356827a-d1be-443d-8df0-b6c163df8a73	relance
9246	933	50	2026-10-09	16:00-17:00	1	VN	M GRENIER	\N	2026-10-06 15:15:37.218746+00	1783	\N	\N	\N	\N	a0fd9468-5b21-4767-b33d-79a368223175	relance
9260	933	50	2026-10-12	16:00-17:00	1	VN	M SCHLESSER	\N	2026-10-06 15:16:58.810375+00	1783	\N	\N	\N	\N	0e5dd3e3-a43b-4f17-9dd7-276afccbe02b	relance
9261	933	89	2026-10-10	16:00-17:00	1	VN	noailles captur	\N	2026-10-06 15:17:27.96474+00	1781	\N	\N	\N	\N	bef6c604-dcba-40b1-9910-1377ee8f5e8a	relance
9240	933	6	2026-10-10	12:00-13:00	1	VN	CAREO ( R5)	\N	2026-10-06 15:15:07.935803+00	2	2026-10-06 15:58:32.897623+00	2	2026-10-06 15:58:33.73+00	2	cb491304-eab6-43f4-b45f-e7edbf065713	relance
9416	933	44	2026-10-08	14:00-15:00	1	VN	MONIER RAFALE	\N	2026-10-06 16:32:20.81273+00	1782	\N	\N	\N	\N	ad21da10-5f56-43b0-9239-7267e2afa377	relance
9488	933	72	2026-10-08	14:00-15:00	1	VN	ATO	\N	2026-10-07 07:52:09.46745+00	5501	\N	\N	\N	\N	7518b3dc-ebcf-41e2-8a4a-e025db9fd245	relance
9556	933	5770	2026-10-08	11:00-12:00	3	VN	TREILHOU	\N	2026-10-07 09:57:07.694596+00	5502	\N	\N	\N	\N	fa0b7857-c2d1-4d11-be22-7c1f444bb827	relance
9686	933	10	2026-10-08	16:00-17:00	1	VN	GOUT TWINGO	\N	2026-10-08 15:53:18.562037+00	5	\N	\N	\N	\N	5069752c-10f3-4e06-8b50-950fbf836024	relance
9748	933	74	2026-10-12	11:00-12:00	1	VN	FRANKOKIEWICZ	\N	2026-10-10 07:28:40.919586+00	5501	\N	\N	\N	\N	64bd93f2-ccce-4a8d-bc80-6aea57eca86a	relance
2763	2	31	2026-09-10	15:00-16:00	2	VN	laurent	\N	2026-09-08 16:32:59.07676+00	97	\N	\N	\N	\N	\N	relance
2764	2	68	2026-09-11	17:00-18:00	\N	VO	KUBELKO	\N	2026-09-08 16:33:10.662634+00	9	\N	\N	\N	\N	\N	relance
2767	2	66	2026-09-12	16:00-17:00	1	VN	PIRSCH / RAFALE	\N	2026-09-08 16:35:41.834023+00	8	\N	\N	\N	\N	\N	relance
2769	2	47	2026-09-10	14:00-15:00	\N	VO	MORGADOT SPRING MP	\N	2026-09-08 16:36:23.300575+00	1782	\N	\N	\N	\N	\N	relance
2766	2	44	2026-09-10	13:00-14:00	1	VN	MORGADOT SPRING VO	\N	2026-09-08 16:35:40.443379+00	1782	2026-09-08 16:36:34.619028+00	1782	2026-09-08 16:36:34.088+00	1782	\N	relance
2770	2	96	2026-09-14	16:00-17:00	1	VN	MOULY AUSTRAL	\N	2026-09-08 16:36:41.287504+00	1775	\N	\N	\N	\N	\N	relance
2768	2	44	2026-09-10	17:00-18:00	2	VN	ABSELAM SANDERO VO	\N	2026-09-08 16:36:04.559711+00	1782	2026-09-08 16:36:50.217918+00	1782	2026-09-08 16:36:49.722+00	1782	\N	relance
2772	2	27	2026-09-12	15:00-16:00	1	VN	PLANE DUSTER	\N	2026-09-08 16:37:09.907875+00	5	\N	\N	\N	\N	\N	relance
2773	2	35	2026-09-11	11:00-12:00	1	VN	dayriat	\N	2026-09-08 16:37:15.219753+00	97	\N	\N	\N	\N	\N	relance
2771	2	47	2026-09-10	17:00-18:00	\N	VO	ABSELAM SANDERO VO MP	\N	2026-09-08 16:37:08.580607+00	1782	2026-09-08 16:37:16.890111+00	1782	\N	\N	\N	relance
2774	2	53	2026-09-13	10:00-11:00	2	VN	DUMONT	\N	2026-09-08 16:38:04.338727+00	9	\N	\N	\N	\N	\N	relance
2777	2	15	2026-09-10	14:00-15:00	2	VN	PIGOT SANDERO	\N	2026-09-08 16:43:13.139935+00	2	\N	\N	\N	\N	\N	relance
2776	2	15	2026-09-10	14:00-15:00	1	VN	PIGOT	\N	2026-09-08 16:43:06.036817+00	2	2026-09-08 16:43:17.094892+00	2	2026-09-08 16:43:17.91+00	2	\N	relance
2778	2	57	2026-09-13	09:00-10:00	\N	VO	SOEIRO	\N	2026-09-08 16:43:58.005138+00	7	\N	\N	\N	\N	\N	relance
2779	2	75	2026-09-10	18:00-19:00	2	VN	CABRADJOUZ	\N	2026-09-08 16:44:53.736324+00	1778	\N	\N	\N	\N	\N	relance
2780	2	42	2026-09-11	17:00-18:00	2	VN	MANSARD SANDERO	\N	2026-09-08 16:45:08.887979+00	1782	2026-09-08 16:45:18.989389+00	1782	\N	\N	\N	relance
2781	2	73	2026-09-10	17:00-18:00	1	VN	PELISSIER	\N	2026-09-08 16:47:58.489375+00	1778	\N	\N	\N	\N	\N	relance
2782	2	40	2026-09-10	15:00-16:00	\N	VO	dedey	\N	2026-09-08 16:48:38.34605+00	97	\N	\N	\N	\N	\N	relance
2783	2	40	2026-09-11	11:00-12:00	\N	VO	kibaki	\N	2026-09-08 16:48:58.563561+00	97	\N	\N	\N	\N	\N	relance
2784	2	32	2026-09-13	16:00-17:00	2	VN	fournier	\N	2026-09-08 16:49:18.493018+00	97	\N	\N	\N	\N	\N	relance
2785	2	67	2026-09-11	10:00-11:00	1	VN	TOURNEVIS / R5	\N	2026-09-08 16:49:59.078946+00	8	\N	\N	\N	\N	\N	relance
2786	2	41	2026-09-13	15:00-16:00	\N	VO	brigand	\N	2026-09-08 16:51:58.630172+00	97	\N	\N	\N	\N	\N	relance
2787	2	62	2026-09-11	14:00-15:00	1	VN	BUDINEK	\N	2026-09-08 16:52:12.023798+00	7	\N	\N	\N	\N	\N	relance
2788	2	62	2026-09-14	16:00-17:00	2	VN	CROCOMBETTE	\N	2026-09-08 16:53:32.346943+00	7	\N	\N	\N	\N	\N	relance
2789	2	65	2026-09-11	18:00-19:00	1	VN	LAFITE	\N	2026-09-08 16:54:06.674375+00	9	\N	\N	\N	\N	\N	relance
2775	2	65	2026-09-14	16:00-17:00	1	VN	LAFITE	\N	2026-09-08 16:41:26.689619+00	9	2026-09-08 16:54:09.636734+00	9	2026-09-08 16:54:09.178+00	9	\N	relance
2790	2	69	2026-09-13	11:00-12:00	\N	VO	PARISSEAUX	\N	2026-09-08 16:54:16.06864+00	7	\N	\N	\N	\N	\N	relance
2792	2	23	2026-09-13	11:00-12:00	\N	VO	TIVEYRAT	\N	2026-09-08 16:55:03.174126+00	3	\N	\N	\N	\N	\N	relance
2793	2	44	2026-09-10	11:00-12:00	1	VN	FISCHER RENAULTMER	\N	2026-09-08 16:56:09.429361+00	1782	2026-09-08 16:56:23.659903+00	1782	\N	\N	\N	relance
2794	2	44	2026-09-10	17:00-18:00	1	VN	DUPERET R5 CHAUVIN	\N	2026-09-08 16:56:48.148529+00	1782	\N	\N	\N	\N	\N	relance
2795	2	47	2026-09-11	17:00-18:00	\N	VO	JOLDAIN MP	\N	2026-09-08 16:57:19.375849+00	1782	\N	\N	\N	\N	\N	relance
2796	2	215	2026-09-14	11:00-12:00	\N	VO	GRANIER	\N	2026-09-08 16:57:46.230382+00	3	\N	\N	\N	\N	\N	relance
2797	2	2	2026-09-11	15:00-16:00	1	VN	CLAUSS	\N	2026-09-08 16:58:07.761731+00	3	\N	\N	\N	\N	\N	relance
2798	2	2	2026-09-12	09:00-10:00	1	VN	DUGAT	\N	2026-09-08 16:58:18.554771+00	3	\N	\N	\N	\N	\N	relance
2799	2	2	2026-09-13	10:00-11:00	1	VN	MABRUT	\N	2026-09-08 16:58:38.467855+00	3	\N	\N	\N	\N	\N	relance
2800	2	2	2026-09-12	11:00-12:00	1	VN	ARNAUD	\N	2026-09-08 16:58:46.047841+00	3	\N	\N	\N	\N	\N	relance
2801	2	2	2026-09-12	15:00-16:00	1	VN	SERRE	\N	2026-09-08 16:59:01.493903+00	3	\N	\N	\N	\N	\N	relance
2802	2	2	2026-09-13	15:00-16:00	1	VN	MESURE	\N	2026-09-08 16:59:05.887043+00	3	\N	\N	\N	\N	\N	relance
2803	2	17	2026-09-13	16:00-17:00	1	VN	BONGEAN CLIO	\N	2026-09-08 17:00:09.878058+00	5	\N	\N	\N	\N	\N	relance
2804	2	17	2026-09-14	09:00-10:00	1	VN	RIGOULET R5	\N	2026-09-08 17:00:38.75501+00	5	\N	\N	\N	\N	\N	relance
2805	2	17	2026-09-14	14:00-15:00	1	VN	VAYSSAD R5	\N	2026-09-08 17:01:00.778591+00	5	\N	\N	\N	\N	\N	relance
2806	2	17	2026-09-14	15:00-16:00	1	VN	GAUTHIER TWINGO	\N	2026-09-08 17:01:19.957837+00	5	\N	\N	\N	\N	\N	relance
2807	2	65	2026-09-11	12:00-13:00	1	VN	MUTZENBERG	\N	2026-09-08 17:01:28.188519+00	9	\N	\N	\N	\N	\N	relance
2808	2	49	2026-09-12	14:00-15:00	1	VN	M PACHE	\N	2026-09-08 17:01:54.20169+00	1783	\N	\N	\N	\N	\N	relance
2809	2	68	2026-09-13	16:00-17:00	\N	VO	GIROUX	\N	2026-09-08 17:02:20.233985+00	9	\N	\N	\N	\N	\N	relance
2810	2	67	2026-09-12	15:00-16:00	1	VN	DUCHET / R5	\N	2026-09-08 17:03:03.817497+00	8	\N	\N	\N	\N	\N	relance
2791	2	69	2026-09-10	11:00-12:00	\N	VO	²	\N	2026-09-08 16:54:32.435874+00	7	2026-09-08 17:04:40.950755+00	7	\N	\N	\N	relance
2811	2	57	2026-09-13	14:00-15:00	\N	VO	POUZOL	\N	2026-09-08 17:04:54.044046+00	7	\N	\N	\N	\N	\N	relance
2812	2	213	2026-09-12	08:00-09:00	\N	VO	Dalet	\N	2026-09-08 17:05:06.734654+00	6	\N	\N	\N	\N	\N	relance
2813	2	43	2026-09-11	11:00-12:00	1	VN	BECQUE AUSTRAL	\N	2026-09-08 17:05:17.267473+00	1782	\N	\N	\N	\N	\N	relance
2814	2	213	2026-09-11	16:00-17:00	\N	VO	Chanony	\N	2026-09-08 17:05:18.07161+00	6	\N	\N	\N	\N	\N	relance
2815	2	213	2026-09-12	10:00-11:00	\N	VO	Guiot	\N	2026-09-08 17:05:24.700377+00	6	\N	\N	\N	\N	\N	relance
2816	2	23	2026-09-13	17:00-18:00	\N	VO	SANTINI	\N	2026-09-08 17:05:49.119174+00	3	\N	\N	\N	\N	\N	relance
2817	2	69	2026-09-10	15:00-16:00	\N	VO	DOME	\N	2026-09-08 17:06:01.91514+00	7	\N	\N	\N	\N	\N	relance
2818	2	23	2026-09-13	18:00-19:00	\N	VO	GUILLY	\N	2026-09-08 17:06:02.728499+00	3	\N	\N	\N	\N	\N	relance
2819	2	62	2026-09-14	18:00-19:00	1	VN	CROUZET	\N	2026-09-08 17:06:26.737573+00	7	\N	\N	\N	\N	\N	relance
2820	2	60	2026-09-13	15:00-16:00	1	VN	CHAUDESAIGUES	\N	2026-09-08 17:07:24.909532+00	7	\N	\N	\N	\N	\N	relance
2821	2	16	2026-09-11	15:00-16:00	1	VN	FOURNERON	\N	2026-09-08 17:07:38.612562+00	3	\N	\N	\N	\N	\N	relance
2822	2	10	2026-09-13	09:00-10:00	1	VN	PERNET	\N	2026-09-08 17:07:50.236811+00	3	\N	\N	\N	\N	\N	relance
2823	2	34	2026-09-11	10:00-11:00	1	VN	chatelier	\N	2026-09-08 17:08:02.755154+00	97	\N	\N	\N	\N	\N	relance
2824	2	19	2026-09-13	16:00-17:00	1	VN	BARRIER CAPTUR	\N	2026-09-08 17:09:20.141277+00	2	\N	\N	\N	\N	\N	relance
2825	2	19	2026-09-14	09:00-10:00	1	VN	AIMOT SYMBIOZ	\N	2026-09-08 17:09:47.069507+00	2	\N	\N	\N	\N	\N	relance
2826	2	882	2026-09-12	10:00-11:00	\N	VO	VALENTIN	\N	2026-09-08 17:10:30.271799+00	8	\N	\N	\N	\N	\N	relance
2827	2	60	2026-09-13	09:00-10:00	1	VN	DE-JESUS ANDRAD ECT	\N	2026-09-08 17:12:53.290435+00	7	\N	\N	\N	\N	\N	relance
2828	2	9	2026-09-10	09:00-10:00	\N	VO	sagne	\N	2026-09-08 17:14:11.809207+00	6	\N	\N	\N	\N	\N	relance
2829	2	26	2026-09-11	17:00-18:00	1	VN	FOURCHON	\N	2026-09-08 17:14:43.62713+00	3	\N	\N	\N	\N	\N	relance
2830	2	26	2026-09-12	18:00-19:00	1	VN	SONET	\N	2026-09-08 17:14:57.428081+00	3	\N	\N	\N	\N	\N	relance
2836	2	19	2026-09-14	15:00-16:00	1	VN	BESQUENT TWINGO	\N	2026-09-08 17:17:23.695187+00	2	\N	\N	\N	\N	\N	relance
2831	2	26	2026-09-13	17:00-18:00	1	VN	COUDERC	\N	2026-09-08 17:15:09.635398+00	3	2026-09-08 17:15:25.96289+00	3	\N	\N	\N	relance
2832	2	66	2026-09-11	15:00-16:00	1	VN	BAYGUES / R5	\N	2026-09-08 17:15:32.924565+00	8	\N	\N	\N	\N	\N	relance
2833	2	66	2026-09-12	15:00-16:00	1	VN	VIZCAILO / TWINGO	\N	2026-09-08 17:15:50.213468+00	8	\N	\N	\N	\N	\N	relance
2834	2	67	2026-09-11	11:00-12:00	2	VN	LAUNAY / SANDERO	\N	2026-09-08 17:16:16.074216+00	8	\N	\N	\N	\N	\N	relance
2835	2	65	2026-09-10	17:00-18:00	1	VN	LAURENT	\N	2026-09-08 17:17:21.94802+00	9	\N	\N	\N	\N	\N	relance
2837	2	59	2026-09-12	17:00-18:00	1	VN	JOULIE / KANGOO ELEC	\N	2026-09-08 17:18:37.79584+00	8	\N	\N	\N	\N	\N	relance
2838	2	67	2026-09-10	15:00-16:00	1	VN	COUDOUEL / CAPTUR	\N	2026-09-08 17:19:16.402183+00	8	\N	\N	\N	\N	\N	relance
2839	2	882	2026-09-12	17:00-18:00	\N	VO	PICHELLE / ELEC	\N	2026-09-08 17:21:22.981996+00	8	\N	\N	\N	\N	\N	relance
2840	2	54	2026-09-13	11:00-12:00	1	VN	AURELLE / R4 INFO VE	\N	2026-09-08 17:27:05.16565+00	8	\N	\N	\N	\N	\N	relance
2841	2	55	2026-09-11	16:00-17:00	1	VN	SOUIGNON	\N	2026-09-08 17:31:25.269865+00	9	\N	\N	\N	\N	\N	relance
2597	2	10	2026-09-10	09:00-10:00	1	VN	PLANTELIGNE	\N	2026-09-08 16:00:29.351311+00	3	2026-09-09 06:38:59.918382+00	5	2026-09-09 06:39:00.622+00	5	\N	relance
2842	2	99	2026-09-14	17:00-18:00	1	VN	BUREL	\N	2026-09-09 08:16:18.21286+00	1778	\N	\N	\N	\N	\N	relance
2843	2	96	2026-09-12	10:00-11:00	1	VN	LARGE R5	\N	2026-09-09 08:41:47.368407+00	1775	\N	\N	\N	\N	\N	relance
2844	2	96	2026-09-12	14:00-15:00	1	VN	FAIVRE	\N	2026-09-09 08:41:59.405192+00	1775	\N	\N	\N	\N	\N	relance
2845	2	96	2026-09-10	10:00-11:00	1	VN	BENOIST R5	\N	2026-09-09 08:42:17.575836+00	1775	\N	\N	\N	\N	\N	relance
2846	2	75	2026-09-11	15:00-16:00	2	VN	FERNANDEZ	\N	2026-09-09 08:52:34.431499+00	1778	\N	\N	\N	\N	\N	relance
2847	2	75	2026-09-12	09:00-10:00	1	VN	LAJOIE	\N	2026-09-09 08:54:55.605013+00	1778	\N	\N	\N	\N	\N	relance
2848	2	50	2026-09-11	11:00-12:00	1	VN	MME BARGEON	\N	2026-09-09 12:53:10.564561+00	1783	\N	\N	\N	\N	\N	relance
2700	2	12	2026-09-12	08:00-09:00	1	VN	VESCO  SANDERO	\N	2026-09-08 16:12:29.689546+00	4	2026-09-09 16:20:57.629279+00	92	2026-09-09 16:20:57.213+00	92	\N	relance
2849	2	12	2026-09-12	08:00-09:00	2	VN	VESCO  SANDERO	\N	2026-09-09 16:20:59.294028+00	92	\N	\N	\N	\N	\N	relance
1756	2	12	2026-09-10	09:00-10:00	1	VN	BOUTINON  DUSTER	\N	2026-09-08 09:36:53.420101+00	4	2026-09-09 16:21:01.873194+00	92	2026-09-09 16:21:01.525+00	92	\N	relance
2850	2	12	2026-09-10	09:00-10:00	2	VN	BOUTINON  DUSTER	\N	2026-09-09 16:21:02.768573+00	92	\N	\N	\N	\N	\N	relance
2851	2	12	2026-09-11	09:00-10:00	2	VN	MIOCHE SPRING	\N	2026-09-09 16:21:05.370757+00	92	\N	\N	\N	\N	\N	relance
2245	2	12	2026-09-12	09:00-10:00	1	VN	BOULANGER DUSTER	\N	2026-09-08 14:28:10.490571+00	4	2026-09-09 16:21:06.926657+00	92	2026-09-09 16:21:06.498+00	92	\N	relance
2852	2	12	2026-09-12	09:00-10:00	2	VN	BOULANGER DUSTER	\N	2026-09-09 16:21:07.869236+00	92	\N	\N	\N	\N	\N	relance
2853	2	12	2026-09-13	09:00-10:00	2	VN	MOUGIN SANDERO	\N	2026-09-09 16:21:10.373178+00	92	\N	\N	\N	\N	\N	relance
2715	2	12	2026-09-14	09:00-10:00	1	VN	BARDOTTI JOGGER	\N	2026-09-08 16:14:42.12816+00	4	2026-09-09 16:21:12.349574+00	92	2026-09-09 16:21:11.979+00	92	\N	relance
2854	2	12	2026-09-14	09:00-10:00	2	VN	BARDOTTI JOGGER	\N	2026-09-09 16:21:13.282609+00	92	\N	\N	\N	\N	\N	relance
2855	2	12	2026-09-10	10:00-11:00	2	VN	CHEVALLET DUSTER	\N	2026-09-09 16:21:17.737664+00	92	\N	\N	\N	\N	\N	relance
2856	2	12	2026-09-11	10:00-11:00	2	VN	DA SILVA SPRING	\N	2026-09-09 16:21:20.328143+00	92	\N	\N	\N	\N	\N	relance
2133	2	12	2026-09-12	10:00-11:00	1	VN	GONINET SANDERO	\N	2026-09-08 10:40:30.277514+00	4	2026-09-09 16:21:21.888182+00	92	2026-09-09 16:21:21.517+00	92	\N	relance
2857	2	12	2026-09-12	10:00-11:00	2	VN	GONINET SANDERO	\N	2026-09-09 16:21:22.897798+00	92	\N	\N	\N	\N	\N	relance
2858	2	12	2026-09-13	10:00-11:00	2	VN	ROUX  DUSTER	\N	2026-09-09 16:21:26.427173+00	92	\N	\N	\N	\N	\N	relance
2859	2	12	2026-09-14	10:00-11:00	2	VN	BEYNEIX  SPRING	\N	2026-09-09 16:21:29.653115+00	92	\N	\N	\N	\N	\N	relance
2860	2	12	2026-09-10	11:00-12:00	2	VN	ALEDO DUSTER	\N	2026-09-09 16:21:32.426926+00	92	\N	\N	\N	\N	\N	relance
2861	2	12	2026-09-11	11:00-12:00	2	VN	GAILLARD SANDERO	\N	2026-09-09 16:21:37.101245+00	92	\N	\N	\N	\N	\N	relance
2862	2	12	2026-09-12	11:00-12:00	2	VN	BOGTOB BIGSTER	\N	2026-09-09 16:21:40.071412+00	92	\N	\N	\N	\N	\N	relance
2863	2	12	2026-09-13	11:00-12:00	2	VN	REVENU SANDERO	\N	2026-09-09 16:21:42.7431+00	92	\N	\N	\N	\N	\N	relance
2864	2	12	2026-09-14	11:00-12:00	2	VN	TRONCHE  DUSTER	\N	2026-09-09 16:21:46.258116+00	92	\N	\N	\N	\N	\N	relance
2865	2	12	2026-09-10	13:00-14:00	2	VN	JORDA DUSTER	\N	2026-09-09 16:21:53.412385+00	92	\N	\N	\N	\N	\N	relance
2866	2	12	2026-09-12	13:00-14:00	2	VN	NAULT SANDERO	\N	2026-09-09 16:21:57.132111+00	92	\N	\N	\N	\N	\N	relance
2711	2	12	2026-09-13	13:00-14:00	1	VN	DAMAS SPRING	\N	2026-09-08 16:13:47.110165+00	4	2026-09-09 16:21:58.718084+00	92	2026-09-09 16:21:58.376+00	92	\N	relance
2867	2	12	2026-09-13	13:00-14:00	2	VN	DAMAS SPRING	\N	2026-09-09 16:22:00.820714+00	92	\N	\N	\N	\N	\N	relance
2868	2	12	2026-09-10	14:00-15:00	2	VN	TRONCHERE JOGGER	\N	2026-09-09 16:22:03.437757+00	92	\N	\N	\N	\N	\N	relance
2869	2	12	2026-09-11	14:00-15:00	2	VN	FLORY CLIO	\N	2026-09-09 16:22:09.999375+00	92	\N	\N	\N	\N	\N	relance
2870	2	12	2026-09-13	14:00-15:00	2	VN	GORAND SANDERO	\N	2026-09-09 16:22:15.497563+00	92	\N	\N	\N	\N	\N	relance
2871	2	12	2026-09-11	15:00-16:00	2	VN	ROBERT SANDERO	\N	2026-09-09 16:22:20.725785+00	92	\N	\N	\N	\N	\N	relance
2109	2	12	2026-09-10	16:00-17:00	1	VN	ENJARY SANDERO	\N	2026-09-08 10:36:21.779102+00	4	2026-09-09 16:22:23.207107+00	92	2026-09-09 16:22:22.852+00	92	\N	relance
2872	2	12	2026-09-10	16:00-17:00	2	VN	ENJARY SANDERO	\N	2026-09-09 16:22:30.145197+00	92	\N	\N	\N	\N	\N	relance
2873	2	12	2026-09-10	17:00-18:00	2	VN	CAILLE SANDERO	\N	2026-09-09 16:22:34.093757+00	92	\N	\N	\N	\N	\N	relance
2874	2	12	2026-09-10	18:00-19:00	2	VN	AUBERT SANDERO	\N	2026-09-09 16:22:37.759906+00	92	\N	\N	\N	\N	\N	relance
2875	2	12	2026-09-11	17:00-18:00	2	VN	LAFEUILLE SANDERO	\N	2026-09-09 16:22:41.221937+00	92	\N	\N	\N	\N	\N	relance
2876	2	12	2026-09-12	17:00-18:00	2	VN	DUFAURE  SANDERO	\N	2026-09-09 16:22:44.540781+00	92	\N	\N	\N	\N	\N	relance
2877	2	12	2026-09-12	16:00-17:00	2	VN	FERNANDES SANDERO	\N	2026-09-09 16:22:47.511251+00	92	\N	\N	\N	\N	\N	relance
2878	2	14	2026-09-10	09:00-10:00	2	VN	SCATOLIN DUSTER	\N	2026-09-09 16:23:15.535508+00	92	\N	\N	\N	\N	\N	relance
2450	2	14	2026-09-12	09:00-10:00	1	VN	GURRIER CLIO	\N	2026-09-08 15:16:38.691982+00	5	2026-09-09 16:23:18.062939+00	92	2026-09-09 16:23:17.711+00	92	\N	relance
2879	2	14	2026-09-12	09:00-10:00	2	VN	GURRIER CLIO	\N	2026-09-09 16:23:18.954593+00	92	\N	\N	\N	\N	\N	relance
2880	2	14	2026-09-13	09:00-10:00	2	VN	JIMENEZ DUSTER	\N	2026-09-09 16:23:21.939106+00	92	\N	\N	\N	\N	\N	relance
2881	2	14	2026-09-14	09:00-10:00	2	VN	GAMBIER SANDERO	\N	2026-09-09 16:23:25.447777+00	92	\N	\N	\N	\N	\N	relance
2455	2	14	2026-09-12	10:00-11:00	1	VN	PAILLOU SANDERO	\N	2026-09-08 15:17:15.703954+00	5	2026-09-09 16:23:31.195828+00	92	2026-09-09 16:23:30.86+00	92	\N	relance
2882	2	14	2026-09-12	10:00-11:00	2	VN	PAILLOU SANDERO	\N	2026-09-09 16:23:32.311072+00	92	\N	\N	\N	\N	\N	relance
2883	2	14	2026-09-13	10:00-11:00	2	VN	GUILLO SANDERO	\N	2026-09-09 16:23:36.273446+00	92	\N	\N	\N	\N	\N	relance
2884	2	14	2026-09-11	11:00-12:00	2	VN	MARTIN SANDERO	\N	2026-09-09 16:23:41.699776+00	92	\N	\N	\N	\N	\N	relance
2885	2	14	2026-09-10	14:00-15:00	2	VN	DIOUGAN DUSTER	\N	2026-09-09 16:23:47.381989+00	92	\N	\N	\N	\N	\N	relance
2886	2	14	2026-09-11	14:00-15:00	2	VN	SAURIN DUSTER	\N	2026-09-09 16:23:50.309961+00	92	\N	\N	\N	\N	\N	relance
2894	2	6	2026-09-10	10:00-11:00	2	VN	MR SAGNE SANDERO	\N	2026-09-09 16:25:09.792088+00	92	\N	\N	\N	\N	\N	relance
8740	933	62	2026-10-10	16:00-17:00	1	VN	VANDENBROUCKE	\N	2026-10-06 09:54:12.415047+00	9	\N	\N	\N	\N	d5eb762a-f90d-4b6e-b2a7-3698ef945779	relance
8956	933	53	2026-10-11	15:00-16:00	2	VN	GIORDANINO	\N	2026-10-06 10:41:13.54479+00	9	\N	\N	\N	\N	7db9dec2-5817-4a69-8696-b46bcc9116f8	relance
8963	933	4205	2026-10-11	08:00-09:00	\N	VO	DUFOUR CLIO E TECH	\N	2026-10-06 10:42:34.18243+00	1782	\N	\N	\N	\N	00606926-90a4-4cfd-9966-2c4ee8db3420	relance
9095	933	53	2026-10-10	10:00-11:00	1	VN	COTIER MAURICE	\N	2026-10-06 14:05:07.178315+00	9	\N	\N	\N	\N	35fe107c-4e4a-4bfe-ad36-e6fb6d3a5a38	relance
9225	933	14	2026-10-10	09:00-10:00	2	VN	LASSOT	\N	2026-10-06 15:12:04.370866+00	2	\N	\N	\N	\N	f5535eac-5d27-453b-9dd5-8e0bb937dbc9	relance
9226	933	14	2026-10-10	12:00-13:00	2	VN	NOUSSAMY (SANDERO)	\N	2026-10-06 15:12:26.066741+00	2	\N	\N	\N	\N	58cfa32e-dd8a-40d6-a1e8-3f541fc12f7e	relance
9229	933	6	2026-10-08	17:00-18:00	1	VN	PANETIER (TWINGO)	\N	2026-10-06 15:13:39.408942+00	2	\N	\N	\N	\N	40e2b830-ea23-4cac-97e4-af4a721df362	relance
9234	933	10	2026-10-12	14:00-15:00	1	VN	verdier  clio	\N	2026-10-06 15:14:31.38727+00	4	\N	\N	\N	\N	ea50a578-cae3-4062-a21a-e471e47234a5	relance
9243	933	82	2026-10-09	14:00-15:00	2	VN	SERRE SPRING	\N	2026-10-06 15:15:23.82863+00	1776	\N	\N	\N	\N	d977121e-bb0f-4251-8f55-b90e92a20e36	relance
9259	933	6	2026-10-10	17:00-18:00	1	VN	DEBRILLON ( SCENIC)	\N	2026-10-06 15:16:52.002441+00	2	\N	\N	\N	\N	33b6c671-1f3a-46db-8587-8ad1a35cc6f8	relance
9417	933	10	2026-10-10	17:00-18:00	1	VN	ledieu  r5	\N	2026-10-06 16:34:11.328682+00	4	\N	\N	\N	\N	45b1cbea-dbd9-4edf-bbf9-428ef3e3433f	relance
9418	933	36	2026-10-11	14:00-15:00	1	VN	LOPEZ	\N	2026-10-06 16:35:26.570545+00	97	\N	\N	\N	\N	d9c7cd33-1cd1-4041-a995-7e306890aa4b	relance
9489	933	72	2026-10-08	15:00-16:00	1	VN	AUGE TWINGO	\N	2026-10-07 07:52:13.433422+00	5501	2026-10-07 07:52:23.240839+00	5501	\N	\N	cca36621-3864-478c-bfbb-c69922e4137b	relance
9557	933	5770	2026-10-09	14:00-15:00	3	VN	AUX DELICES DE NEBOUZAT	\N	2026-10-07 09:57:38.824237+00	5502	\N	\N	\N	\N	1e86a645-dd8b-4171-832d-7837f6f408bc	relance
9687	933	10	2026-10-08	13:00-14:00	1	VN	TESSEIDRE SANDERO	\N	2026-10-08 15:53:28.970856+00	5	\N	\N	\N	\N	6f0944b4-422f-4aea-8758-9e6a439c4834	relance
9749	933	60	2026-10-10	11:00-12:00	1	VN	GUIGON AUSTRAL	\N	2026-10-10 09:27:53.108365+00	7	\N	\N	\N	\N	1de0132f-be06-466f-95f1-4dee0ff41f01	relance
2887	2	14	2026-09-14	14:00-15:00	2	VN	GIRONDE SANDERO	\N	2026-09-09 16:23:53.379051+00	92	\N	\N	\N	\N	\N	relance
8741	933	62	2026-10-11	14:00-15:00	1	VN	BOUDON	\N	2026-10-06 09:55:22.182539+00	9	\N	\N	\N	\N	b2dc509c-756a-4df2-b5f2-84dd1e2bca8a	relance
8964	933	41	2026-10-08	10:00-11:00	\N	VO	POTHIER	\N	2026-10-06 10:43:44.820636+00	97	\N	\N	\N	\N	ba417bf3-571a-4a14-a7c8-0dca1efee226	relance
8966	933	41	2026-10-08	18:00-19:00	\N	VO	REVERET	\N	2026-10-06 10:44:00.102228+00	97	\N	\N	\N	\N	0ea46114-88de-4813-904e-b46bf652c924	relance
8982	933	39	2026-10-09	18:00-19:00	\N	VO	VALLAS	\N	2026-10-06 10:46:03.41076+00	97	\N	\N	\N	\N	aaeda319-0a2e-4197-bf86-2cf9cf269eb7	relance
8991	933	4204	2026-10-10	15:00-16:00	1	VN	BARTHELEMY CLIO	\N	2026-10-06 10:47:12.401792+00	1782	\N	\N	\N	\N	dd5fdf3e-4890-4cb5-84c1-6d9b3f9c956b	relance
8994	933	49	2026-10-10	10:00-11:00	1	VN	M GROISNE	\N	2026-10-06 10:47:27.411522+00	1783	\N	\N	\N	\N	8118c981-c539-49be-b4ad-79f83f68c6f4	relance
9005	933	17	2026-10-08	17:00-18:00	1	VN	kovarichova Duster	\N	2026-10-06 10:48:56.155213+00	3	\N	\N	\N	\N	0135f0f0-70c9-4402-9f23-c63571c34562	relance
9007	933	4	2026-10-08	08:00-09:00	1	VN	FLATO MEGANE	\N	2026-10-06 10:49:11.239533+00	5	\N	\N	\N	\N	f318c7e8-f275-4920-aa87-c16bc1400118	relance
9011	933	5	2026-10-10	14:00-15:00	1	VN	DELCHER R5	\N	2026-10-06 10:49:27.763407+00	5	\N	\N	\N	\N	6593d261-ab63-41e5-b98a-147d1e539431	relance
9096	933	53	2026-10-10	11:00-12:00	1	VN	COTTIER MELINA	\N	2026-10-06 14:05:14.027441+00	9	\N	\N	\N	\N	670499f9-3d08-4b84-a9e9-160e4ec17a23	relance
9227	933	14	2026-10-11	14:00-15:00	2	VN	GELINO	\N	2026-10-06 15:12:38.622612+00	2	\N	\N	\N	\N	d29c29b9-84f5-4f4f-b06c-3f4d4af3fc3b	relance
9235	933	82	2026-10-08	14:00-15:00	2	VN	ALET SPRING	\N	2026-10-06 15:14:32.730763+00	1776	\N	\N	\N	\N	7feb14da-918c-410e-b59b-df9a198dd7e4	relance
9242	933	50	2026-10-08	09:00-10:00	1	VN	M RONGER	\N	2026-10-06 15:15:15.389234+00	1783	\N	\N	\N	\N	4be9543d-127a-4e18-829f-e90eaaa1daf0	relance
9252	933	50	2026-10-11	15:00-16:00	1	VN	MME DEZOLME	\N	2026-10-06 15:16:15.26048+00	1783	\N	\N	\N	\N	0ef8f9f9-6174-4a69-b739-3fc5bac967a2	relance
9255	933	6	2026-10-10	14:00-15:00	1	VN	ROBILLON ( R5)	\N	2026-10-06 15:16:28.805396+00	2	\N	\N	\N	\N	93b20753-7935-41ab-b33e-9779fb497156	relance
9419	933	41	2026-10-11	10:00-11:00	\N	VO	GARLOT	\N	2026-10-06 16:35:47.1876+00	97	\N	\N	\N	\N	110b67b4-1978-4061-b704-d911a3ed6303	relance
9490	933	72	2026-10-08	16:00-17:00	1	VN	AUGE SCENIC	\N	2026-10-07 07:52:14.733567+00	5501	2026-10-07 07:52:35.80845+00	5501	\N	\N	ed0abca5-2902-4f91-8289-a391a4711827	relance
9491	933	72	2026-10-12	14:00-15:00	1	VN	PONELLE	\N	2026-10-07 07:52:39.867591+00	5501	\N	\N	\N	\N	fe7b7c0b-5ba2-4450-8ee2-4c846c148b17	relance
9558	933	5770	2026-10-10	15:00-16:00	3	VN	JALLET	\N	2026-10-07 09:58:50.529265+00	5502	\N	\N	\N	\N	cfa3cb90-a5ac-4440-9c19-0c086889071b	relance
9688	933	59	2026-10-08	13:00-14:00	1	VN	VO MME PIGERE	\N	2026-10-08 16:20:50.61107+00	7	2026-10-08 16:21:40.767958+00	7	2026-10-08 16:21:40.84+00	7	f80d1ab0-ba2c-4540-946c-72af532da019	relance
9750	933	60	2026-10-10	16:00-17:00	2	VN	DOMEZEL	\N	2026-10-10 09:28:25.987384+00	7	\N	\N	\N	\N	e315ac47-7b2c-4492-8416-70762b33cee3	relance
2888	2	14	2026-09-10	16:00-17:00	2	VN	BESSERVE TWINGO	\N	2026-09-09 16:23:56.206627+00	92	\N	\N	\N	\N	\N	relance
2890	2	14	2026-09-11	17:00-18:00	2	VN	DELPRAT JOGGER	\N	2026-09-09 16:24:01.320254+00	92	\N	\N	\N	\N	\N	relance
2892	2	14	2026-09-14	17:00-18:00	2	VN	CHANTENAIS SANDERO	\N	2026-09-09 16:24:07.137094+00	92	\N	\N	\N	\N	\N	relance
2895	2	6	2026-09-11	10:00-11:00	2	VN	CHOMILLER DUSTER	\N	2026-09-09 16:25:13.64093+00	92	\N	\N	\N	\N	\N	relance
8965	933	41	2026-10-08	16:00-17:00	\N	VO	SAUVAN	\N	2026-10-06 10:43:53.702522+00	97	\N	\N	\N	\N	5b7c6a12-ab7a-425c-a7ce-aa08d67e26b2	relance
8970	933	882	2026-10-09	14:00-15:00	\N	VO	HERITIER	\N	2026-10-06 10:44:23.309776+00	9	\N	\N	\N	\N	2bd3c9dd-7e41-433a-acb4-a958431fb062	relance
8980	933	39	2026-10-09	09:00-10:00	\N	VO	DEBOUT	\N	2026-10-06 10:45:51.922999+00	97	\N	\N	\N	\N	7b2e11d3-d39c-4c11-9172-b35ddffb1df8	relance
8985	933	39	2026-10-12	17:00-18:00	\N	VO	MARTIN-FROUILLOU	\N	2026-10-06 10:46:27.263009+00	97	\N	\N	\N	\N	569931cd-f189-42d1-bab2-8b8d430f3243	relance
8993	933	4204	2026-10-11	14:00-15:00	1	VN	DELPUECH BIGSTER	\N	2026-10-06 10:47:25.333548+00	1782	2026-10-06 10:47:39.399408+00	1782	2026-10-06 10:47:45.836+00	1782	3a5663a9-2a10-4d29-b14b-e547a85d6429	relance
9002	933	43	2026-10-08	09:00-10:00	1	VN	BELLIEN CLIO	\N	2026-10-06 10:48:37.167717+00	1782	\N	\N	\N	\N	0e549ea9-f202-434f-9975-010ccdef3054	relance
9020	933	17	2026-10-10	16:00-17:00	1	VN	Blorinos R5	\N	2026-10-06 10:50:52.655801+00	3	\N	\N	\N	\N	8217a433-728c-4f67-8bc0-5756ae37d218	relance
8990	933	49	2026-10-09	09:00-10:00	1	VN	M GENDREAU (VP RODDIER)	\N	2026-10-06 10:47:03.953057+00	1783	2026-10-06 14:04:20.253313+00	1783	\N	\N	68ef38ba-7f22-40c6-98af-44d4f99f90a6	relance
9097	933	49	2026-10-09	15:00-16:00	1	VN	OJKIP	\N	2026-10-06 14:05:47.57803+00	1783	2026-10-06 14:05:51.752656+00	1783	2026-10-06 14:05:54.327+00	1783	d205f201-1cb9-4d00-80ef-04b6235e9b2a	relance
9098	933	49	2026-10-09	13:00-14:00	1	VN	MME PACHE (VP RODDIER)	\N	2026-10-06 14:06:12.199317+00	1783	\N	\N	\N	\N	81bc05b0-afd9-435d-bd48-707de0298f50	relance
8742	933	3215	2026-10-12	14:00-15:00	1	VN	septier clio le 13/10	\N	2026-10-06 09:57:45.228019+00	4	2026-10-06 14:57:14.380238+00	4	\N	\N	956bbbcd-bb45-4a6d-9fbf-32979a9a046e	relance
9228	933	6	2026-10-08	17:00-18:00	2	VN	PANETIER ( TWINGO)	\N	2026-10-06 15:13:15.13555+00	2	2026-10-06 15:13:28.173936+00	2	2026-10-06 15:13:29.043+00	2	48f58684-f17c-4f37-ad69-97120b80f025	relance
9238	933	6	2026-10-10	10:00-11:00	1	VN	BASSET ( R4)	\N	2026-10-06 15:14:54.16123+00	2	\N	\N	\N	\N	e61c8d6e-dc47-4b3f-9a16-642d2bf9ae9f	relance
9245	933	82	2026-10-09	17:00-18:00	2	VN	LESTRADE JOGGER	\N	2026-10-06 15:15:37.059793+00	1776	2026-10-06 15:15:54.389062+00	1776	\N	\N	6adb7ff6-77d2-4356-a4b5-b410d182e339	relance
9249	933	50	2026-10-10	16:00-17:00	1	VN	M BAUD	\N	2026-10-06 15:15:58.590149+00	1783	\N	\N	\N	\N	7b5d8f5b-9394-4c36-a9a4-2c8070ce2351	relance
9256	933	50	2026-10-12	15:00-16:00	1	VN	MME GIRAUDET	\N	2026-10-06 15:16:30.062868+00	1783	\N	\N	\N	\N	11ecbb9d-9212-442d-a13e-2832fc4cd3e5	relance
9258	933	82	2026-10-10	14:00-15:00	1	VN	LEMAIRE R5	\N	2026-10-06 15:16:42.961889+00	1776	\N	\N	\N	\N	f2454d96-f926-4d32-8356-6806ae5839f0	relance
9420	933	41	2026-10-11	09:00-10:00	\N	VO	MAY	\N	2026-10-06 16:35:50.89988+00	97	\N	\N	\N	\N	f8483198-a6ad-4ce8-8708-993f25fe226d	relance
9492	933	74	2026-10-08	10:00-11:00	1	VN	ROGER	\N	2026-10-07 07:53:07.255713+00	5501	\N	\N	\N	\N	983041ec-dd55-45f8-b9da-d867e26207e1	relance
9559	933	5770	2026-10-11	11:00-12:00	3	VN	DALLOIS	\N	2026-10-07 09:59:03.047045+00	5502	\N	\N	\N	\N	f27b7257-a9f6-4480-b7cb-a8490fa9592c	relance
9689	933	59	2026-10-08	13:00-14:00	2	VN	VO MME PIGERE	\N	2026-10-08 16:21:53.568426+00	7	\N	\N	\N	\N	6cd1de74-1a56-499f-b17d-06df935d51e0	relance
9751	933	60	2026-10-08	08:00-09:00	1	VN	FORESTIER	\N	2026-10-10 09:29:28.4124+00	7	2026-10-10 09:29:47.753313+00	7	2026-10-10 09:29:48.225+00	7	4279794c-57bd-4fe4-bbdb-e103edf61d63	showroom
2889	2	14	2026-09-10	17:00-18:00	2	VN	MEGRESIF BIGSTER	\N	2026-09-09 16:23:58.630413+00	92	\N	\N	\N	\N	\N	relance
2891	2	14	2026-09-13	17:00-18:00	2	VN	DUCHE DUSTER	\N	2026-09-09 16:24:04.773073+00	92	\N	\N	\N	\N	\N	relance
8743	933	79	2026-10-08	10:00-11:00	1	VN	VANDERSSEN DACIA	\N	2026-10-06 09:58:09.178524+00	1776	\N	\N	\N	\N	8843e120-9295-488a-913d-8e4cb0491cc4	relance
8967	933	54	2026-10-09	14:00-15:00	1	VN	FRACHISSE  MEGANE	\N	2026-10-06 10:44:08.954956+00	7	\N	\N	\N	\N	74a9410f-2724-445b-8638-bb7b4ed48948	relance
8969	933	41	2026-10-09	15:00-16:00	\N	VO	FRACHISSE	\N	2026-10-06 10:44:18.500371+00	97	\N	\N	\N	\N	03328104-3d4a-4610-8e50-f5f3b3b6dd61	relance
8971	933	41	2026-10-10	10:00-11:00	\N	VO	THOMAS	\N	2026-10-06 10:44:29.200133+00	97	\N	\N	\N	\N	d5b26b6b-e29a-406b-8682-68a16c4fcd5b	relance
8972	933	41	2026-10-10	11:00-12:00	\N	VO	BELLOT	\N	2026-10-06 10:44:33.025289+00	97	\N	\N	\N	\N	ba027120-9385-40bb-a45f-74b2d8bfd18b	relance
8977	933	4204	2026-10-08	10:00-11:00	2	VN	COUDROT DUSTER	\N	2026-10-06 10:45:06.717795+00	1782	\N	\N	\N	\N	fc597d8f-c29b-4545-9409-a6ecfa21a714	relance
8983	933	4204	2026-10-08	17:00-18:00	2	VN	BONNETIN JOGGER	\N	2026-10-06 10:46:14.844627+00	1782	\N	\N	\N	\N	5b553f4f-1309-4a47-9376-df7f9e52df01	relance
8996	933	49	2026-10-10	16:00-17:00	1	VN	M PECHEUR	\N	2026-10-06 10:47:41.889128+00	1783	\N	\N	\N	\N	2dcde6c1-c102-4185-8981-42a20d152d64	relance
9016	933	43	2026-10-10	10:00-11:00	1	VN	BERGER TWINGO	\N	2026-10-06 10:49:50.890569+00	1782	\N	\N	\N	\N	e54f3443-a76c-46df-919a-06a4ffddf77f	relance
9017	933	17	2026-10-10	11:00-12:00	1	VN	Hutin R5	\N	2026-10-06 10:50:13.151579+00	3	\N	\N	\N	\N	731d3058-919c-4b14-939f-ad023b36b0cb	relance
9099	933	49	2026-10-09	15:00-16:00	1	VN	M GUILLAUME (VP RODDIER)	\N	2026-10-06 14:06:28.124046+00	1783	\N	\N	\N	\N	a9a985ce-9a02-45ea-921d-c9d135fe3d74	relance
9230	933	82	2026-10-08	09:00-10:00	1	VN	PELAMOURGUE TW3	\N	2026-10-06 15:13:48.896425+00	1776	\N	\N	\N	\N	654562df-a627-404c-a19f-d881bc1c40bc	relance
9236	933	6	2026-10-10	09:00-10:00	2	VN	BAUDRY ( sandero stepway)	\N	2026-10-06 15:14:39.809654+00	2	\N	\N	\N	\N	b1f36074-73d8-47d7-803d-0a57d6280f60	relance
9241	933	82	2026-10-09	09:00-10:00	1	VN	PUECH CAPTUR	\N	2026-10-06 15:15:11.247255+00	1776	\N	\N	\N	\N	69ae12de-0988-44e0-b886-91ddd289de53	relance
9244	933	50	2026-10-09	10:00-11:00	1	VN	SOCIETE 2 EVENEMENTS	\N	2026-10-06 15:15:25.689633+00	1783	\N	\N	\N	\N	8ad46253-0bc9-48f7-afaf-56a1ef9821e5	relance
9247	933	50	2026-10-10	10:00-11:00	1	VN	MME PORTIER	\N	2026-10-06 15:15:45.355884+00	1783	\N	\N	\N	\N	4f9e447e-40b8-4671-80f1-1147d796e624	relance
9250	933	50	2026-10-11	10:00-11:00	1	VN	M MAURIN	\N	2026-10-06 15:16:07.501723+00	1783	\N	\N	\N	\N	54a7abbb-d256-4425-951a-7d550288fc46	relance
9253	933	50	2026-10-12	10:00-11:00	1	VN	M CHOMETTE	\N	2026-10-06 15:16:22.376895+00	1783	\N	\N	\N	\N	94ed33dc-ca75-4e9e-99f2-2edabc345ce2	relance
9422	933	14	2026-10-12	10:00-11:00	2	VN	MARCHIS ( SANDERO)	\N	2026-10-06 16:38:03.960037+00	2	\N	\N	\N	\N	fb9cd5e5-99d5-49ee-bfff-306ce3a58faa	relance
9493	933	74	2026-10-08	17:00-18:00	1	VN	NAVARRO	\N	2026-10-07 07:53:18.626297+00	5501	\N	\N	\N	\N	346ce73c-03f3-41f4-ad02-108fc7d5d2d6	relance
9560	933	87	2026-10-12	11:00-12:00	2	VN	GAUCHI-IMBERT (Espace VN)	\N	2026-10-07 10:19:21.187964+00	1777	\N	\N	\N	\N	85916a8b-0398-4679-849f-df1fe2447206	relance
9421	933	3217	2026-10-08	08:00-09:00	1	VN	AAAA	\N	2026-10-06 16:37:03.613169+00	92	2026-10-08 12:37:21.492095+00	92	2026-10-08 12:37:20.039+00	92	d3e13281-a1cb-4dd8-a0e3-15e2069edb53	showroom
9690	933	2	2026-10-08	10:00-11:00	2	VN	DUBOIS	\N	2026-10-08 16:25:18.943224+00	2	\N	\N	\N	\N	cc508cb0-859e-4bc3-a78f-948712ba2a00	showroom
9752	933	60	2026-10-10	10:00-11:00	1	VN	FORESTIER	\N	2026-10-10 09:30:15.350741+00	7	\N	\N	\N	\N	133338e5-274b-4415-89e6-52f730c77a48	showroom
2893	2	6	2026-09-10	08:00-09:00	2	VN	MR FOLLEAS SANDERO	\N	2026-09-09 16:25:05.660207+00	92	\N	\N	\N	\N	\N	relance
8744	933	79	2026-10-08	15:00-16:00	1	VN	DELAGNES DACIA	\N	2026-10-06 09:58:21.605853+00	1776	\N	\N	\N	\N	bc12f452-07d3-437e-85e9-82fdcc3efce8	relance
8968	933	41	2026-10-09	11:00-12:00	\N	VO	ROSSIGNOL	\N	2026-10-06 10:44:12.951517+00	97	\N	\N	\N	\N	e34d2471-d060-406e-867b-2ad513fe2914	relance
8974	933	41	2026-10-10	14:00-15:00	\N	VO	BIAZIZO	\N	2026-10-06 10:44:41.266556+00	97	\N	\N	\N	\N	f6a019fc-af7e-4d14-ba66-09a02777f066	relance
8987	933	4204	2026-10-10	11:00-12:00	1	VN	BARATHIER ESPACE	\N	2026-10-06 10:46:44.637134+00	1782	\N	\N	\N	\N	21e52aaf-e75d-44a3-9de7-938063efca37	relance
8988	933	49	2026-10-08	15:00-16:00	1	VN	M BIDET	\N	2026-10-06 10:46:58.395842+00	1783	\N	\N	\N	\N	499e5caf-9cfc-41ff-8970-e01cffeaf614	relance
8998	933	49	2026-10-11	10:00-11:00	1	VN	M MARTIN	\N	2026-10-06 10:47:49.994722+00	1783	\N	\N	\N	\N	341e5bed-04de-4f1f-afbc-a3a1edafdc88	relance
8999	933	49	2026-10-11	14:00-15:00	1	VN	M MELKIOR	\N	2026-10-06 10:47:58.851801+00	1783	\N	\N	\N	\N	49f67be5-ce6f-464f-ae0e-3bc907aa75b2	relance
9013	933	17	2026-10-10	09:00-10:00	1	VN	Ribeiro R5	\N	2026-10-06 10:49:33.2285+00	3	\N	\N	\N	\N	cc2922d2-05ca-4815-ac7d-25d51b05345c	relance
9015	933	17	2026-10-10	10:00-11:00	1	VN	Chereau R5	\N	2026-10-06 10:49:48.80766+00	3	\N	\N	\N	\N	2718664a-6053-4c14-bc10-90aae93ccf88	relance
9023	933	18	2026-10-08	10:00-11:00	1	VN	romeuf  r4	\N	2026-10-06 10:51:40.915113+00	4	\N	\N	\N	\N	2978e7f4-420e-41ad-88c2-61cbf044547a	relance
9100	933	49	2026-10-09	16:00-17:00	1	VN	M PITELET (VP RODDIER)	\N	2026-10-06 14:06:44.862363+00	1783	\N	\N	\N	\N	cae44770-e434-4cf2-8944-32d8ca588413	relance
9231	933	82	2026-10-08	10:00-11:00	1	VN	GARCIA	\N	2026-10-06 15:14:01.091039+00	1776	\N	\N	\N	\N	6a94841f-48bc-4407-8ac5-f550845477c9	relance
9233	933	82	2026-10-08	11:00-12:00	1	VN	GUENIER ARKANA	\N	2026-10-06 15:14:09.884254+00	1776	\N	\N	\N	\N	cb3494de-ad68-4bd2-a00d-51619b9e648a	relance
9237	933	82	2026-10-08	17:00-18:00	1	VN	VALAT A290	\N	2026-10-06 15:14:47.094989+00	1776	\N	\N	\N	\N	4277f333-d27f-4734-ac50-1e1a493c1951	relance
9239	933	82	2026-10-08	18:00-19:00	1	VN	CAMBOULIVES MEGANE ELC	\N	2026-10-06 15:15:03.245954+00	1776	\N	\N	\N	\N	b2e65ddc-720c-4c45-b64a-cbeaad45c236	relance
9248	933	50	2026-10-10	15:00-16:00	1	VN	MME JEAN	\N	2026-10-06 15:15:52.132694+00	1783	\N	\N	\N	\N	486e313a-f0c7-4432-b74a-82b830feea33	relance
9251	933	43	2026-10-09	14:00-15:00	1	VN	CHALMIN RAFALE	\N	2026-10-06 15:16:10.531401+00	1782	\N	\N	\N	\N	e0e756f2-3779-40a4-bdc2-032c43386433	relance
9254	933	44	2026-10-08	09:00-10:00	1	VN	PETITJEAN R5	\N	2026-10-06 15:16:28.17541+00	1782	\N	\N	\N	\N	dbbc902d-1587-458f-9293-58e2d7cb0438	relance
9257	933	82	2026-10-10	09:00-10:00	1	VN	SINGLARD R5	\N	2026-10-06 15:16:33.65172+00	1776	\N	\N	\N	\N	f4def0c1-e685-476b-83fa-cec5ebe49460	relance
9262	933	43	2026-10-08	18:00-19:00	1	VN	THEVENET R5	\N	2026-10-06 15:18:15.786147+00	1782	\N	\N	\N	\N	43f169ef-55fa-40d3-b122-5ac0bd4b7996	relance
9423	933	14	2026-10-12	14:00-15:00	2	VN	VENET (SANDERO)	\N	2026-10-06 16:38:41.849501+00	2	\N	\N	\N	\N	726bcead-9e68-420d-a636-4be969e7622e	relance
9561	933	93	2026-10-09	10:00-11:00	2	VN	SAUTO	\N	2026-10-07 12:05:29.913301+00	1780	\N	\N	\N	\N	21e4a3da-d687-4e8c-8053-16b3f94ee478	relance
9691	933	2	2026-10-08	14:00-15:00	1	VN	HENNEBERG	\N	2026-10-08 16:26:54.230623+00	2	\N	\N	\N	\N	4048cec1-a765-48fc-9b31-4cbb1853da26	showroom
9494	933	74	2026-10-09	09:00-10:00	1	VN	PUECH	\N	2026-10-07 07:53:20.241358+00	5501	2026-10-09 06:46:15.814844+00	5501	2026-10-09 06:46:15.925+00	5501	78db82ac-bde4-4e54-8942-42fe649a62c9	relance
9753	933	60	2026-10-10	13:00-14:00	2	VN	PARE	\N	2026-10-10 09:31:35.664088+00	7	\N	\N	\N	\N	de7c7079-0de6-462f-ac14-b8112f4ef8ad	relance
1784	2	6	2026-09-10	10:00-11:00	1	VN	MR SAGNE SANDERO	\N	2026-09-08 09:43:16.656852+00	5	2026-09-09 16:25:08.339087+00	92	2026-09-09 16:25:07.979+00	92	\N	relance
2896	2	6	2026-09-10	15:00-16:00	2	VN	DUTUEL SANDERO	\N	2026-09-09 16:25:28.459936+00	92	\N	\N	\N	\N	\N	relance
2897	2	6	2026-09-10	17:00-18:00	2	VN	KALINSKI DUSTER	\N	2026-09-09 16:25:33.839863+00	92	\N	\N	\N	\N	\N	relance
2340	2	6	2026-09-11	18:00-19:00	1	VN	CAMPOS JOGGER	\N	2026-09-08 14:51:45.919978+00	5	2026-09-09 16:28:46.963762+00	92	2026-09-09 16:28:46.629+00	92	\N	relance
2898	2	6	2026-09-11	18:00-19:00	2	VN	CAMPOS JOGGER	\N	2026-09-09 16:28:51.544247+00	92	\N	\N	\N	\N	\N	relance
2899	2	6	2026-09-12	10:00-11:00	2	VN	FOURNER SPRING	\N	2026-09-09 16:28:55.794369+00	92	\N	\N	\N	\N	\N	relance
2900	2	6	2026-09-13	10:00-11:00	2	VN	JEANJEAN SANDERO	\N	2026-09-09 16:29:02.335379+00	92	\N	\N	\N	\N	\N	relance
2901	2	6	2026-09-14	09:00-10:00	2	VN	BONABRI SPRING	\N	2026-09-09 16:29:07.826536+00	92	\N	\N	\N	\N	\N	relance
2360	2	6	2026-09-14	14:00-15:00	1	VN	ROYER SANDERO	\N	2026-09-08 14:54:14.608313+00	5	2026-09-09 16:29:13.404883+00	92	2026-09-09 16:29:12.999+00	92	\N	relance
2902	2	6	2026-09-14	14:00-15:00	2	VN	ROYER SANDERO	\N	2026-09-09 16:29:18.179494+00	92	\N	\N	\N	\N	\N	relance
2903	2	6	2026-09-14	15:00-16:00	2	VN	EVENO SANDERO	\N	2026-09-09 16:29:21.106521+00	92	\N	\N	\N	\N	\N	relance
2904	2	6	2026-09-14	16:00-17:00	2	VN	ASTAIX AUSTRAL	\N	2026-09-09 16:29:24.306761+00	92	\N	\N	\N	\N	\N	relance
2905	2	49	2026-09-14	10:00-11:00	1	VN	M MAROLLE	\N	2026-09-10 06:46:15.401472+00	1783	\N	\N	\N	\N	\N	relance
2906	2	49	2026-09-10	18:00-19:00	1	VN	M BARGEON	\N	2026-09-10 06:46:40.350185+00	1783	\N	\N	\N	\N	\N	relance
2150	2	17	2026-09-11	11:00-12:00	1	VN	TOURNADRE TWINGO	\N	2026-09-08 10:47:37.136126+00	5	2026-09-10 15:11:29.731671+00	92	2026-09-10 15:11:29.095+00	92	\N	relance
2907	2	17	2026-09-10	09:00-10:00	1	VN	MR COURET R5	\N	2026-09-10 15:24:43.15346+00	5	\N	\N	\N	\N	\N	relance
2908	2	17	2026-09-10	11:00-12:00	1	VN	TOURNADRE TWINGO	\N	2026-09-10 15:25:02.617462+00	5	\N	\N	\N	\N	\N	relance
2909	2	17	2026-09-11	14:00-15:00	1	VN	MR PLAGNE DUSTER	\N	2026-09-10 15:25:44.255867+00	5	\N	\N	\N	\N	\N	relance
8745	933	882	2026-10-11	11:00-12:00	\N	VO	ALFEREZ	\N	2026-10-06 09:58:31.611254+00	9	\N	\N	\N	\N	9de5e791-cc41-4b76-b6d0-24d051c7a5f4	relance
8973	933	882	2026-10-08	10:00-11:00	\N	VO	CLIO VI	\N	2026-10-06 10:44:33.309214+00	9	\N	\N	\N	\N	7a1a7c15-65cb-4936-8abf-65d93dfd9ef5	relance
8992	933	49	2026-10-10	09:00-10:00	1	VN	M GAULOCHE	\N	2026-10-06 10:47:15.143959+00	1783	\N	\N	\N	\N	d63d4c0f-6b67-4fd1-b6e2-dbde22ed7cf1	relance
8997	933	4204	2026-10-11	14:00-15:00	2	VN	DELPUECH DUSTER	\N	2026-10-06 10:47:48.732385+00	1782	\N	\N	\N	\N	208b2748-0ff4-461c-a32d-6cc7635bc854	relance
9004	933	43	2026-10-08	14:00-15:00	1	VN	ARRAUT CAPTUR	\N	2026-10-06 10:48:54.487975+00	1782	\N	\N	\N	\N	1e92757d-975e-40a1-ad12-89619ddd7ecb	relance
9010	933	43	2026-10-09	10:00-11:00	1	VN	GUYOT CAPTUR	\N	2026-10-06 10:49:23.156477+00	1782	\N	\N	\N	\N	a638c84d-571d-4416-9f66-b205fca271d9	relance
9014	933	43	2026-10-09	17:00-18:00	1	VN	GARCON TWINGO	\N	2026-10-06 10:49:39.782632+00	1782	\N	\N	\N	\N	96c348a6-be1c-42eb-bd40-55027261acfc	relance
9021	933	54	2026-10-10	09:00-10:00	1	VN	OSTIN S	\N	2026-10-06 10:51:07.315104+00	7	2026-10-06 10:51:18.450925+00	7	2026-10-06 10:51:18.394+00	7	a3bba99f-2e28-4289-b638-499b9a70e1c2	relance
9022	933	54	2026-10-10	09:00-10:00	2	VN	OSTIN SANDERO	\N	2026-10-06 10:51:35.233576+00	7	\N	\N	\N	\N	120e864e-c5d0-4828-a9f2-50550910ffeb	relance
9101	933	49	2026-10-09	17:00-18:00	1	VN	M BERODY (VP RODDIER)	\N	2026-10-06 14:07:03.383606+00	1783	\N	\N	\N	\N	dfd18296-05ff-41a3-98a2-fe4283de9570	relance
9263	933	54	2026-10-09	09:00-10:00	1	VN	INDERCHIED	\N	2026-10-06 15:19:33.139653+00	7	\N	\N	\N	\N	379b97c6-8c92-43d1-8ee1-a0ac29be08d2	relance
9264	933	32	2026-10-11	09:00-10:00	1	VN	BARRE	\N	2026-10-06 15:20:00.992784+00	97	\N	\N	\N	\N	425dbe52-ff21-4a44-b48b-36ea554a374f	relance
9267	933	49	2026-10-12	15:00-16:00	1	VN	M BATILLAT	\N	2026-10-06 15:20:50.910759+00	1783	\N	\N	\N	\N	8dcec2d2-e9ea-49e5-b71c-91e3e7bd2cee	relance
9424	933	14	2026-10-12	17:00-18:00	2	VN	HONORE	\N	2026-10-06 16:38:56.979325+00	2	\N	\N	\N	\N	052b3c1e-b022-4dff-a321-3c2b0073838f	relance
9426	933	19	2026-10-11	14:00-15:00	1	VN	BATISSE ( CLIO)	\N	2026-10-06 16:40:33.170775+00	2	\N	\N	\N	\N	2e65ac2f-7239-4b5b-9af8-ce8e428e9415	relance
9495	933	74	2026-10-09	14:00-15:00	1	VN	BRYHAT	\N	2026-10-07 07:53:33.995442+00	5501	\N	\N	\N	\N	656054ef-9767-4e1b-b0cf-b99e33beff17	relance
9562	933	83	2026-10-08	09:00-10:00	\N	VO	LACAZE	\N	2026-10-07 12:11:09.029124+00	1776	\N	\N	\N	\N	1b5e3144-00e4-4433-861b-c073348246f2	relance
9692	933	90	2026-10-08	16:00-17:00	1	VN	cloarec twingo	\N	2026-10-08 16:40:53.599312+00	1781	\N	\N	\N	\N	06c8d4f6-c2d9-4cd1-84ef-3608a8deb285	relance
9754	933	60	2026-10-10	15:00-16:00	1	VN	CHABAL	\N	2026-10-10 09:31:58.958624+00	7	\N	\N	\N	\N	82c6711e-95b1-411a-adb6-98bb85e669fb	relance
\.


--
-- Data for Name: rdv_suivi; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.rdv_suivi (rdv_id, issue, diac, stock, cs, modele, commentaire, cree_le, cree_par, modifie_le, modifie_par, vd) FROM stdin;
8547	commande	f	f	f	SCENIC	\N	2026-10-05 08:23:53.097259+00	95	2026-10-05 12:00:32.726429+00	92	f
9544	\N	f	f	f	A390	\N	2026-10-07 09:24:28.814558+00	5502	\N	\N	f
8682	\N	f	f	f	\N	\N	2026-10-06 09:11:17.864663+00	2	2026-10-06 09:11:28.688704+00	2	f
8548	no_show	f	f	f	\N	\N	2026-10-05 08:25:39.200171+00	95	2026-10-05 12:50:23.615093+00	787	f
8848	commande	t	f	f	\N	\N	2026-10-08 15:42:07.856521+00	5	2026-10-08 15:42:09.025318+00	5	f
9533	no_show	f	f	f	A290	\N	2026-10-07 08:49:59.608212+00	5502	2026-10-09 09:52:33.33945+00	5502	f
9315	clos_sans_suite	f	f	f	\N	\N	2026-10-08 15:19:47.545963+00	5	2026-10-08 15:19:58.080734+00	5	f
8838	clos_sans_suite	f	f	f	\N	\N	2026-10-08 15:20:06.999722+00	5	\N	\N	f
8684	commande	f	f	f	\N	\N	2026-10-06 09:15:01.445987+00	787	2026-10-06 09:15:22.114273+00	787	f
8626	commande	f	f	f	\N	\N	2026-10-05 12:32:31.914424+00	92	2026-10-05 13:17:49.110256+00	92	f
9023	offre_en_cours	f	f	f	\N	\N	2026-10-08 15:20:23.684755+00	5	\N	\N	f
8841	commande	f	f	f	\N	\N	2026-10-08 15:20:31.768222+00	5	\N	\N	f
9316	no_show	f	f	f	\N	\N	2026-10-08 15:20:57.482151+00	5	2026-10-08 15:20:58.97683+00	5	f
9393	offre_en_cours	f	f	f	\N	\N	2026-10-08 15:21:12.449136+00	5	\N	\N	f
8822	no_show	f	f	f	\N	\N	2026-10-08 15:24:45.284428+00	5	\N	\N	f
9146	\N	f	f	f	\N	\N	2026-10-06 16:25:44.716162+00	92	2026-10-06 16:25:53.470804+00	1785	f
9177	no_show	f	f	f	\N	\N	2026-10-08 15:25:00.328375+00	5	\N	\N	f
9421	\N	f	f	f	\N	\N	2026-10-06 16:37:03.806014+00	92	2026-10-07 12:02:05.632111+00	5503	f
8545	\N	f	f	f	Bigster	\N	2026-10-03 15:41:10.430531+00	92	2026-10-03 15:41:43.089954+00	92	f
8668	commande	t	f	t	\N	\N	2026-10-05 14:41:57.106721+00	95	2026-10-05 14:42:26.426657+00	95	f
8669	offre_en_cours	f	f	f	\N	\N	2026-10-05 14:42:29.258544+00	95	\N	\N	f
8670	annule	f	f	f	\N	\N	2026-10-05 14:42:31.877958+00	95	\N	\N	f
9178	no_show	f	f	f	\N	\N	2026-10-08 15:25:08.971558+00	5	\N	\N	f
8671	no_show	f	f	f	\N	\N	2026-10-05 14:42:33.010228+00	95	\N	\N	f
8672	commande	f	t	f	\N	\N	2026-10-05 14:42:34.028842+00	95	2026-10-05 14:42:35.780852+00	95	f
8549	commande	t	t	f	\N	\N	2026-10-05 08:31:33.829774+00	95	2026-10-05 08:31:43.337854+00	95	f
8677	commande	t	f	f	\N	\N	2026-10-05 14:42:37.182574+00	95	2026-10-05 14:42:39.070064+00	95	f
8675	offre_en_cours	f	f	f	\N	\N	2026-10-05 14:42:41.371169+00	95	\N	\N	f
8674	annule	f	f	f	\N	\N	2026-10-05 14:42:42.572857+00	95	\N	\N	f
8676	no_show	f	f	f	\N	\N	2026-10-05 14:42:43.996493+00	95	\N	\N	f
8678	commande	t	f	f	JOGGER	\N	2026-10-05 14:45:05.379258+00	95	2026-10-05 14:45:20.535585+00	95	f
8679	commande	f	t	f	\N	\N	2026-10-06 07:34:45.366115+00	4	2026-10-06 07:34:51.820722+00	4	f
9005	commande	f	t	f	\N	\N	2026-10-08 15:42:19.229187+00	5	2026-10-08 15:42:24.998602+00	5	f
8777	commande	t	t	t	R5	\N	2026-10-08 07:09:18.286902+00	7	2026-10-08 07:11:42.007864+00	7	f
8844	commande	t	t	f	\N	\N	2026-10-08 15:28:41.213126+00	5	2026-10-08 15:28:44.624056+00	5	f
8849	no_show	f	f	f	\N	\N	2026-10-08 15:29:06.737055+00	5	\N	\N	f
8680	\N	f	f	f	\N	\N	2026-10-06 08:09:15.491702+00	5	2026-10-06 08:09:36.079997+00	5	f
8833	commande	t	t	f	Rafale	\N	2026-10-08 10:17:58.23387+00	7	2026-10-08 10:18:08.291147+00	7	f
8783	no_show	f	f	f	\N	\N	2026-10-08 10:18:39.262677+00	7	\N	\N	f
8706	offre_en_cours	f	f	f	\N	\N	2026-10-08 15:48:16.366649+00	5	\N	\N	f
9191	commande	t	f	t	BIGSTER 4x4 extreme	\N	2026-10-08 12:23:37.615503+00	7	2026-10-08 12:24:06.657517+00	7	f
9541	commande	t	f	t	A290	\N	2026-10-07 09:23:23.389464+00	5502	2026-10-08 15:55:16.481754+00	5502	f
9638	commande	f	f	f	SPRING	\N	2026-10-08 12:25:39.80721+00	7	2026-10-08 12:25:39.924312+00	7	f
8702	commande	f	t	t	\N	\N	2026-10-08 15:47:39.302121+00	5	2026-10-08 15:47:46.993686+00	5	f
8843	commande	t	t	f	\N	\N	2026-10-08 15:41:20.988831+00	5	2026-10-08 15:41:24.8873+00	5	f
9462	no_show	f	f	f	\N	\N	2026-10-08 15:25:57.914112+00	5	2026-10-08 15:41:35.979004+00	5	f
9683	commande	t	t	f	\N	\N	2026-10-08 15:41:39.963867+00	5	2026-10-08 15:41:43.689416+00	5	f
9457	offre_en_cours	f	f	f	\N	\N	2026-10-08 15:41:55.134948+00	5	\N	\N	f
8846	no_show	f	f	f	\N	\N	2026-10-08 15:42:02.467318+00	5	\N	\N	f
9684	commande	f	f	t	\N	\N	2026-10-08 15:43:12.648819+00	5	2026-10-08 15:43:19.33473+00	5	f
9618	offre_en_cours	f	f	f	\N	\N	2026-10-08 15:45:25.303255+00	7	\N	\N	f
9619	no_show	f	f	f	\N	\N	2026-10-08 15:45:34.583914+00	7	\N	\N	f
8703	commande	f	t	f	\N	\N	2026-10-08 15:47:53.427893+00	5	2026-10-08 15:47:57.107786+00	5	f
9041	no_show	f	f	f	\N	\N	2026-10-08 15:09:52.987763+00	1780	2026-10-09 07:53:48.873116+00	1780	f
8704	commande	t	f	f	\N	\N	2026-10-08 15:48:02.582803+00	5	2026-10-08 15:48:03.742602+00	5	f
8705	offre_en_cours	f	f	f	\N	\N	2026-10-08 15:48:11.233163+00	5	\N	\N	f
8707	clos_sans_suite	f	f	f	\N	\N	2026-10-08 15:48:23.854041+00	5	\N	\N	f
8708	commande	f	f	t	\N	\N	2026-10-08 15:48:32.650212+00	5	2026-10-08 15:48:34.716673+00	5	f
8721	offre_en_cours	f	f	f	\N	\N	2026-10-08 15:50:58.933903+00	5	\N	\N	f
8723	offre_en_cours	f	f	f	\N	\N	2026-10-08 15:51:04.8741+00	5	\N	\N	f
8726	offre_en_cours	f	f	f	\N	\N	2026-10-08 15:51:10.193421+00	5	\N	\N	f
8727	commande	t	t	t	\N	\N	2026-10-08 15:51:14.068736+00	5	2026-10-08 15:51:16.926199+00	5	f
9051	commande	t	f	t	R4	\N	2026-10-08 15:51:16.223135+00	1780	2026-10-09 07:29:46.451218+00	1780	f
8935	offre_en_cours	f	f	f	\N	\N	2026-10-08 15:51:33.356247+00	5	\N	\N	f
9048	commande	t	f	t	DUSTER	\N	2026-10-08 15:09:40.459017+00	1780	2026-10-09 07:43:37.729992+00	1780	f
9052	commande	t	f	t	MEGANE	\N	2026-10-08 15:10:05.350439+00	1780	2026-10-09 07:47:15.997351+00	1780	f
8904	no_show	f	f	f	\N	\N	2026-10-08 15:52:22.492488+00	5	\N	\N	f
9047	commande	t	t	t	CLIO	\N	2026-10-08 15:09:39.192685+00	1780	2026-10-08 15:52:48.054666+00	1780	f
9525	offre_en_cours	f	f	f	A290	\N	2026-10-07 08:47:27.413644+00	5502	2026-10-08 15:55:06.352262+00	5502	f
9534	clos_sans_suite	f	f	f	A390	\N	2026-10-07 08:49:50.273481+00	5502	2026-10-08 15:56:09.449777+00	5502	f
9526	annule	f	f	f	A390	\N	2026-10-07 08:49:57.727756+00	5502	2026-10-08 15:56:11.076275+00	5502	f
9527	commande	t	f	t	A290	\N	2026-10-07 08:50:03.141213+00	5502	2026-10-09 09:52:42.75265+00	5502	f
9528	offre_en_cours	f	f	f	A390	\N	2026-10-07 08:50:06.497552+00	5502	2026-10-09 09:52:46.483185+00	5502	f
9086	no_show	f	f	f	SANDERO	\N	2026-10-08 12:23:14.73415+00	7	2026-10-09 14:09:58.458666+00	7	f
9542	no_show	f	f	f	A290	\N	2026-10-07 09:24:00.590609+00	5502	2026-10-09 16:02:55.912852+00	5502	f
9557	offre_en_cours	f	f	f	A390	\N	2026-10-07 09:57:44.74892+00	5502	2026-10-09 16:03:01.829452+00	5502	f
9530	offre_en_cours	f	f	f	A290	\N	2026-10-07 08:50:15.227711+00	5502	2026-10-09 16:03:11.174988+00	5502	f
9543	commande	t	f	t	A390	\N	2026-10-07 09:24:10.949364+00	5502	2026-10-10 08:49:22.286476+00	5502	f
9558	offre_en_cours	f	f	f	A110	\N	2026-10-07 09:58:56.517149+00	5502	2026-10-11 09:40:59.258634+00	5502	f
9559	offre_en_cours	f	f	f	A290	\N	2026-10-07 09:59:07.266806+00	5502	2026-10-11 09:41:08.648984+00	5502	f
9500	\N	f	f	f	\N	\N	2026-10-09 06:45:28.90685+00	5501	2026-10-09 06:45:36.004258+00	5501	f
9694	commande	f	f	f	\N	\N	2026-10-09 06:45:55.198953+00	5501	\N	\N	f
8685	commande	t	t	t	\N	\N	2026-10-08 15:52:26.994281+00	5	2026-10-08 15:52:37.771481+00	5	f
8686	no_show	f	f	f	\N	\N	2026-10-08 15:52:44.543711+00	5	\N	\N	f
8687	commande	f	t	f	\N	\N	2026-10-08 15:52:50.926766+00	5	2026-10-08 15:52:56.512944+00	5	f
9509	commande	f	f	f	\N	\N	2026-10-09 06:49:06.782994+00	5501	\N	\N	f
9489	clos_sans_suite	f	f	f	\N	\N	2026-10-09 06:50:10.200829+00	5501	\N	\N	f
9485	commande	f	f	f	\N	\N	2026-10-09 06:50:13.720155+00	5501	\N	\N	f
9490	clos_sans_suite	f	f	f	\N	\N	2026-10-09 06:50:19.578547+00	5501	\N	\N	f
9493	offre_en_cours	f	f	f	\N	\N	2026-10-09 06:50:27.138207+00	5501	\N	\N	f
9686	commande	f	t	f	\N	\N	2026-10-08 15:53:40.367398+00	5	2026-10-08 15:54:11.564824+00	5	f
9687	commande	t	f	t	\N	\N	2026-10-08 15:53:53.964034+00	5	2026-10-08 15:54:13.107871+00	5	f
9556	offre_en_cours	f	f	f	A390	\N	2026-10-07 09:57:13.340765+00	5502	2026-10-08 15:55:09.688117+00	5502	f
9501	offre_en_cours	f	f	f	\N	\N	2026-10-09 06:55:41.84981+00	5501	2026-10-09 06:55:43.74113+00	5501	f
9222	commande	f	t	f	R5	\N	2026-10-08 16:18:43.256606+00	7	2026-10-08 16:19:22.354016+00	7	f
9512	commande	f	t	f	\N	\N	2026-10-09 06:57:17.61179+00	5501	2026-10-09 06:57:20.452253+00	5501	f
8794	commande	t	f	t	MEGANE ETECH	\N	2026-10-08 16:19:33.342232+00	7	2026-10-08 16:19:41.261013+00	7	f
8797	offre_en_cours	f	f	f	\N	\N	2026-10-08 16:19:49.665262+00	7	\N	\N	f
9689	commande	f	f	f	SANDERO VO	\N	2026-10-08 16:22:08.693175+00	7	2026-10-08 16:22:08.832376+00	7	f
8877	commande	f	f	f	symbioz	\N	2026-10-08 16:24:25.525124+00	2	2026-10-08 16:24:32.962025+00	2	f
8882	annule	f	f	f	\N	\N	2026-10-08 16:24:36.503489+00	2	\N	\N	f
9511	offre_en_cours	f	f	f	\N	\N	2026-10-09 06:57:25.462871+00	5501	\N	\N	f
8875	offre_en_cours	f	f	f	R5	\N	2026-10-08 16:24:23.467992+00	2	2026-10-08 16:25:40.464547+00	2	f
9690	commande	f	t	f	JOGGER	\N	2026-10-08 16:25:19.109376+00	2	2026-10-08 16:26:00.579024+00	2	f
9691	offre_en_cours	f	f	f	TWINGO	\N	2026-10-08 16:26:54.357623+00	2	2026-10-08 16:26:57.176385+00	2	f
8734	commande	f	f	f	MEGANE	\N	2026-10-09 07:11:19.509889+00	9	2026-10-09 07:11:19.65745+00	9	f
9201	commande	f	f	f	KADJAR	\N	2026-10-09 07:11:48.221294+00	9	2026-10-09 07:11:48.293408+00	9	f
9578	commande	t	t	f	\N	\N	2026-10-08 16:39:12.448961+00	1781	2026-10-08 16:39:51.760248+00	1781	f
9480	commande	t	t	f	\N	\N	2026-10-08 16:38:58.928579+00	1781	2026-10-08 16:40:10.868448+00	1781	f
9692	commande	f	t	f	\N	\N	2026-10-08 16:41:03.935111+00	1781	2026-10-08 16:41:10.643378+00	1781	f
9702	commande	t	t	t	CAPTUR	\N	2026-10-09 06:58:29.339354+00	5501	2026-10-09 06:58:44.586417+00	5501	f
9685	commande	t	t	f	SANDERO VO	\N	2026-10-08 15:46:31.133626+00	7	2026-10-08 16:41:47.992435+00	7	f
9479	commande	t	t	t	\N	\N	2026-10-08 16:41:43.914536+00	1781	2026-10-08 16:41:54.186821+00	1781	f
9151	commande	t	t	f	\N	\N	2026-10-08 16:46:03.885683+00	1781	2026-10-08 16:46:07.468895+00	1781	f
9703	commande	f	t	f	TWINGO	\N	2026-10-09 06:58:48.553147+00	5501	2026-10-09 06:58:51.295546+00	5501	f
9693	commande	t	t	f	\N	\N	2026-10-08 16:46:54.202183+00	1781	2026-10-08 16:46:56.818225+00	1781	f
9587	commande	f	f	f	\N	\N	2026-10-09 05:48:54.089413+00	1778	\N	\N	f
9607	commande	f	f	f	\N	\N	2026-10-09 05:48:56.745575+00	1778	\N	\N	f
9492	commande	t	t	f	\N	\N	2026-10-09 06:44:01.682313+00	5501	2026-10-09 06:44:17.648359+00	5501	f
9704	commande	f	f	f	TWINGO	\N	2026-10-09 06:59:02.182822+00	5501	2026-10-09 06:59:02.248369+00	5501	f
9487	commande	t	t	t	\N	\N	2026-10-09 06:44:08.695632+00	5501	2026-10-09 06:44:22.656172+00	5501	f
9483	commande	t	f	f	\N	\N	2026-10-09 06:44:30.102788+00	5501	2026-10-09 06:44:32.750082+00	5501	f
9537	commande	f	t	t	\N	\N	2026-10-09 06:45:12.78261+00	5501	2026-10-09 06:45:17.738016+00	5501	f
9488	no_show	f	f	f	\N	\N	2026-10-09 06:45:24.395603+00	5501	\N	\N	f
9268	clos_sans_suite	f	f	f	\N	\N	2026-10-09 07:13:40.214835+00	9	2026-10-09 07:13:49.22915+00	9	f
9126	commande	f	f	f	DURIEUX SPRING	\N	2026-10-09 07:14:16.737163+00	9	2026-10-09 07:14:16.857242+00	9	f
9705	commande	t	t	f	R5	\N	2026-10-09 06:59:15.757258+00	5501	2026-10-09 06:59:18.681939+00	5501	f
8884	commande	f	f	f	MEGANE	\N	2026-10-09 07:14:27.545205+00	9	2026-10-09 07:14:27.638692+00	9	f
9707	commande	f	t	f	JOGGER	\N	2026-10-09 06:59:25.471282+00	5501	2026-10-09 06:59:27.948444+00	5501	f
9323	commande	f	f	f	SANDERO	\N	2026-10-09 07:07:39.419788+00	9	2026-10-09 07:07:39.473683+00	9	f
9188	commande	f	f	f	CAPTUR	\N	2026-10-09 07:08:01.15348+00	9	2026-10-09 07:08:01.242127+00	9	f
9192	offre_en_cours	f	f	f	\N	\N	2026-10-09 07:08:45.32128+00	9	\N	\N	f
9189	clos_sans_suite	f	f	f	\N	\N	2026-10-09 07:09:16.486976+00	9	\N	\N	f
8732	commande	f	f	f	CLIO	\N	2026-10-09 07:10:49.291459+00	9	2026-10-09 07:10:49.392024+00	9	f
8733	commande	f	f	f	CAPTUR	\N	2026-10-09 07:11:03.596977+00	9	2026-10-09 07:11:03.651287+00	9	f
9027	commande	f	f	f	R5	\N	2026-10-09 07:14:53.351986+00	9	2026-10-09 07:14:53.413921+00	9	f
9709	\N	f	f	f	R5	\N	2026-10-09 07:15:20.195105+00	9	\N	\N	f
8835	no_show	f	f	f	\N	\N	2026-10-09 07:53:47.096246+00	9	\N	\N	f
9053	commande	t	f	t	TWINGO	\N	2026-10-09 07:22:14.381974+00	1780	2026-10-09 07:22:38.0896+00	1780	f
9710	commande	f	t	f	TWINGO	\N	2026-10-09 07:41:58.343349+00	5501	2026-10-09 07:42:05.11745+00	5501	f
9518	commande	f	t	f	JOGGER	\N	2026-10-09 07:34:44.898856+00	5501	2026-10-09 07:34:50.522141+00	5501	f
9515	clos_sans_suite	f	f	f	\N	\N	2026-10-09 07:35:03.415+00	5501	\N	\N	f
9484	offre_en_cours	f	f	f	\N	\N	2026-10-09 07:35:07.693328+00	5501	\N	\N	f
9056	commande	f	f	f	SANDERO	\N	2026-10-09 07:45:39.995388+00	1780	2026-10-09 07:45:40.549815+00	1780	f
9062	commande	f	f	f	CAPTUR	\N	2026-10-09 07:46:18.175014+00	1780	2026-10-09 07:46:18.254407+00	1780	f
9089	no_show	f	f	f	\N	\N	2026-10-09 07:53:02.328452+00	9	\N	\N	f
9200	offre_en_cours	f	f	f	\N	\N	2026-10-09 07:53:15.650239+00	9	\N	\N	f
9712	commande	f	t	f	CAPTUR	\N	2026-10-09 07:52:45.627716+00	1780	2026-10-09 07:53:25.053685+00	1780	f
8709	commande	f	f	f	ZOE	\N	2026-10-09 07:53:38.188372+00	9	2026-10-09 07:53:38.312557+00	9	f
9713	commande	t	f	t	TWINGO	\N	2026-10-09 07:55:43.399041+00	1780	2026-10-09 07:55:46.794868+00	1780	f
9714	commande	f	f	f	R5	\N	2026-10-09 07:56:29.82188+00	1780	2026-10-09 07:56:39.016757+00	1780	f
9715	commande	f	f	f	SANDERO	\N	2026-10-09 07:59:55.887643+00	1780	2026-10-09 07:59:55.971605+00	1780	f
9083	offre_en_cours	f	f	f	\N	\N	2026-10-09 08:41:01.808529+00	9	\N	\N	f
9035	offre_en_cours	f	f	f	R4	\N	2026-10-09 08:41:25.133993+00	9	2026-10-09 08:41:25.237942+00	9	f
8757	offre_en_cours	f	f	f	TWINGO R4	\N	2026-10-09 08:41:45.886675+00	9	2026-10-09 08:41:46.039974+00	9	f
9028	commande	f	f	f	MEGANE	\N	2026-10-09 08:42:06.688264+00	9	2026-10-09 08:42:06.857485+00	9	f
9708	commande	f	f	f	SPRING	\N	2026-10-09 07:12:32.323757+00	9	2026-10-10 07:05:22.720937+00	9	f
9395	offre_en_cours	f	f	f	DUSTER	\N	2026-10-08 16:25:45.86401+00	2	2026-10-10 15:53:54.125627+00	2	f
9717	\N	f	f	f	SANDERO	\N	2026-10-09 08:43:40.485478+00	9	\N	\N	f
8894	offre_en_cours	f	f	f	SANDERO	\N	2026-10-09 08:44:41.291829+00	9	2026-10-09 08:44:41.356644+00	9	f
8845	clos_sans_suite	f	f	f	SANDERO	\N	2026-10-09 12:10:28.241051+00	1782	2026-10-09 14:06:09.879355+00	1782	f
9254	offre_en_cours	f	f	f	R5	\N	2026-10-09 12:36:53.263874+00	1782	2026-10-09 14:06:18.599892+00	1782	f
8722	offre_en_cours	f	f	f	\N	\N	2026-10-09 14:07:52.130626+00	7	\N	\N	f
9570	commande	f	f	f	BIGSTER	\N	2026-10-09 14:57:23.701874+00	1780	2026-10-09 14:57:23.74451+00	1780	f
9727	commande	f	f	f	BIGSTER	\N	2026-10-09 14:58:23.632236+00	1780	2026-10-09 14:58:23.702422+00	1780	f
8930	commande	t	f	t	\N	\N	2026-10-09 15:13:14.260422+00	5	2026-10-09 15:13:16.546457+00	5	f
9409	no_show	f	f	f	\N	\N	2026-10-09 12:12:50.508164+00	1782	\N	\N	f
9721	commande	t	f	t	TWINGO	\N	2026-10-09 14:08:48.632382+00	7	2026-10-09 14:09:04.140112+00	7	f
8781	offre_en_cours	f	f	f	R5	\N	2026-10-08 10:18:27.534951+00	7	2026-10-09 14:09:46.519709+00	7	f
9043	commande	t	f	t	TWINGO	\N	2026-10-09 14:58:46.087383+00	1780	2026-10-09 14:58:49.282957+00	1780	f
8810	commande	t	t	t	TWINGO E TECH	\N	2026-10-09 12:08:48.520502+00	1782	2026-10-09 12:15:52.089529+00	1782	t
8977	commande	t	t	t	DUSTER	\N	2026-10-09 12:14:35.060799+00	1782	2026-10-09 12:15:57.826894+00	1782	f
9003	commande	t	t	t	CAPTUR	\N	2026-10-09 12:11:00.854224+00	1782	2026-10-09 12:16:30.588613+00	1782	f
9416	commande	t	f	t	RAFALE	\N	2026-10-09 12:09:13.989447+00	1782	2026-10-09 12:17:03.44972+00	1782	f
9723	commande	t	f	t	TWINGO	\N	2026-10-09 14:12:00.614849+00	7	2026-10-09 14:13:17.383858+00	7	f
9620	\N	f	f	f	CAPTURE	\N	2026-10-09 14:13:24.144414+00	7	\N	\N	f
9004	commande	t	t	t	CAPTUR	\N	2026-10-09 12:11:14.864491+00	1782	2026-10-09 12:17:23.564545+00	1782	f
8853	offre_en_cours	f	f	f	\N	\N	2026-10-09 14:31:55.893471+00	5	\N	\N	f
9262	commande	t	t	t	R5 E TECH	\N	2026-10-09 12:11:29.487066+00	1782	2026-10-09 12:17:34.812594+00	1782	f
8719	commande	t	f	f	\N	\N	2026-10-09 15:23:36.531901+00	5	2026-10-09 15:23:44.177902+00	5	f
9010	commande	t	t	t	CAPTUR	\N	2026-10-09 12:11:39.642452+00	1782	2026-10-09 12:17:51.514894+00	1782	f
8857	commande	t	t	t	\N	\N	2026-10-09 14:32:05.620642+00	5	2026-10-09 14:32:17.647863+00	5	f
8862	no_show	f	f	f	\N	\N	2026-10-09 14:32:26.708624+00	5	\N	\N	f
8821	commande	t	t	t	SCENIC E TECH	\N	2026-10-09 12:10:15.094991+00	1782	2026-10-09 12:18:03.318395+00	1782	f
9725	commande	f	f	t	\N	\N	2026-10-09 14:38:40.033644+00	5	2026-10-09 14:38:44.33547+00	5	f
9495	commande	t	f	t	SCENIC	\N	2026-10-09 13:58:56.227113+00	5501	2026-10-09 13:59:01.512145+00	5501	f
9251	commande	f	t	f	RAFALE	\N	2026-10-09 15:05:50.609521+00	1782	2026-10-09 15:05:53.192394+00	1782	f
9695	commande	t	f	t	MEGANE	\N	2026-10-09 13:59:12.704468+00	5501	2026-10-09 13:59:17.995994+00	5501	f
8922	offre_en_cours	f	f	f	\N	\N	2026-10-09 14:00:04.855634+00	7	\N	\N	f
8798	clos_sans_suite	f	f	f	\N	\N	2026-10-09 14:00:12.284616+00	7	\N	\N	f
9513	offre_en_cours	f	f	f	\N	\N	2026-10-09 14:00:19.19908+00	5501	\N	\N	f
9724	commande	f	t	t	\N	\N	2026-10-09 14:38:51.980537+00	5	2026-10-09 14:38:55.774376+00	5	f
8688	no_show	f	f	f	\N	\N	2026-10-09 14:54:10.787533+00	5	\N	\N	f
8807	offre_en_cours	f	f	f	\N	\N	2026-10-09 14:00:59.460408+00	7	\N	\N	f
8804	clos_sans_suite	f	f	f	\N	\N	2026-10-09 14:03:05.507555+00	7	\N	\N	f
8819	offre_en_cours	f	f	f	KANGOO VAN	\N	2026-10-09 14:05:17.439488+00	1782	2026-10-09 14:05:48.031369+00	1782	f
9269	offre_en_cours	f	f	f	SANDERO	\N	2026-10-09 12:10:47.898435+00	1782	2026-10-09 14:05:57.11711+00	1782	f
8847	clos_sans_suite	f	f	f	SPRING	\N	2026-10-09 12:10:46.403609+00	1782	2026-10-09 14:06:00.139162+00	1782	f
8697	clos_sans_suite	f	f	f	\N	\N	2026-10-09 14:54:22.799874+00	5	\N	\N	f
9181	clos_sans_suite	f	f	f	\N	\N	2026-10-09 14:54:32.445718+00	5	\N	\N	f
8827	clos_sans_suite	f	f	f	\N	\N	2026-10-09 14:54:42.254911+00	5	\N	\N	f
8866	no_show	f	f	f	\N	\N	2026-10-09 15:07:34.765885+00	5	\N	\N	f
9362	offre_en_cours	f	f	f	\N	\N	2026-10-09 15:07:55.855214+00	5	2026-10-09 15:07:57.211674+00	5	f
8691	commande	t	f	t	\N	\N	2026-10-09 14:54:48.746203+00	5	2026-10-09 14:54:53.075279+00	5	f
9726	commande	t	f	t	\N	\N	2026-10-09 14:55:44.018639+00	5	2026-10-09 14:55:54.293209+00	5	f
8931	commande	t	f	t	\N	\N	2026-10-09 15:13:26.108152+00	5	2026-10-09 15:13:29.303062+00	5	f
8720	commande	t	f	t	\N	\N	2026-10-09 14:56:14.566678+00	5	2026-10-09 14:56:19.209267+00	5	f
8938	offre_en_cours	f	f	f	\N	\N	2026-10-09 14:56:29.872894+00	5	\N	\N	f
8939	clos_sans_suite	f	f	f	\N	\N	2026-10-09 14:56:44.945591+00	5	\N	\N	f
8940	offre_en_cours	f	f	f	\N	\N	2026-10-09 14:56:55.526946+00	5	2026-10-09 14:56:58.171952+00	5	f
8867	commande	t	t	f	\N	\N	2026-10-09 15:08:12.835238+00	5	2026-10-09 15:08:24.231762+00	5	f
9363	no_show	f	f	f	\N	\N	2026-10-09 15:08:31.49242+00	5	\N	\N	f
9728	offre_en_cours	f	f	f	\N	\N	2026-10-09 15:09:15.347126+00	5	\N	\N	f
9622	offre_en_cours	f	f	f	CLIO	\N	2026-10-09 14:13:06.715751+00	7	2026-10-09 15:11:56.3617+00	7	f
8932	offre_en_cours	f	f	f	\N	\N	2026-10-09 15:13:35.835496+00	5	\N	\N	f
8929	commande	t	f	t	\N	\N	2026-10-09 15:13:04.242748+00	5	2026-10-09 15:13:08.920217+00	5	f
8933	offre_en_cours	f	f	f	\N	\N	2026-10-09 15:13:40.584311+00	5	\N	\N	f
8934	offre_en_cours	f	f	f	\N	\N	2026-10-09 15:13:48.473965+00	5	\N	\N	f
9696	offre_en_cours	f	f	f	\N	\N	2026-10-09 15:21:39.811127+00	5501	\N	\N	f
8718	commande	t	f	f	\N	\N	2026-10-09 15:23:26.231492+00	5	2026-10-09 15:23:28.652087+00	5	f
9502	commande	t	t	t	SANDERO	\N	2026-10-09 15:25:20.401528+00	5501	2026-10-09 15:25:37.297756+00	5501	f
9506	no_show	f	f	f	\N	\N	2026-10-09 15:27:24.687233+00	5501	\N	\N	f
9392	clos_sans_suite	f	f	f	\N	\N	2026-10-09 15:24:00.659519+00	5	2026-10-09 15:24:03.536863+00	5	f
9510	clos_sans_suite	f	f	f	\N	\N	2026-10-09 15:25:17.67354+00	5501	\N	\N	f
9507	no_show	f	f	f	\N	\N	2026-10-09 15:27:32.671402+00	5501	\N	\N	f
9503	offre_en_cours	f	f	f	\N	\N	2026-10-09 15:27:00.708728+00	5501	\N	\N	f
9697	commande	t	t	t	AUSTRAL	\N	2026-10-09 15:28:02.934536+00	5501	2026-10-09 15:28:12.257821+00	5501	t
9732	commande	f	t	f	AUSTRAL	\N	2026-10-09 15:29:24.89842+00	5501	2026-10-09 15:29:33.070924+00	5501	f
9734	offre_en_cours	f	f	f	\N	\N	2026-10-09 15:29:39.848283+00	5501	\N	\N	f
9514	offre_en_cours	f	f	f	\N	\N	2026-10-09 15:46:29.87873+00	5501	\N	\N	f
9735	commande	t	t	t	R5	\N	2026-10-09 15:29:53.204868+00	5501	2026-10-09 15:29:58.99297+00	5501	f
9719	no_show	f	f	f	DUSTER	\N	2026-10-09 14:13:02.296796+00	7	2026-10-09 16:15:23.004194+00	7	f
8725	no_show	f	f	f	JOGGER	\N	2026-10-09 14:09:21.248749+00	7	2026-10-09 16:15:28.182274+00	7	f
9720	commande	f	f	f	DUSTER	\N	2026-10-09 14:12:57.562596+00	7	2026-10-09 16:15:32.180076+00	7	f
8801	commande	t	t	t	CLIO	\N	2026-10-09 14:00:39.024247+00	7	2026-10-09 16:18:02.657713+00	7	f
9736	commande	t	t	t	ZOE	\N	2026-10-09 15:47:15.882632+00	5501	2026-10-09 15:47:19.398977+00	5501	f
9737	commande	f	t	f	TWINGO	\N	2026-10-09 15:47:37.433756+00	5501	2026-10-09 15:47:38.618781+00	5501	f
8816	commande	f	f	f	TWINGO	\N	2026-10-10 14:04:23.31739+00	7	2026-10-10 16:38:59.520762+00	7	f
9014	commande	t	f	t	TWINGO	\N	2026-10-10 13:15:07.398127+00	1782	2026-10-10 13:15:26.623796+00	1782	f
9738	commande	t	t	t	CAPTUR	\N	2026-10-09 15:48:10.582521+00	5501	2026-10-09 15:48:12.857557+00	5501	f
9054	commande	t	t	t	JOGGER	\N	2026-10-10 08:14:32.359549+00	1780	2026-10-10 08:14:44.100397+00	1780	f
9740	commande	t	f	t	SPRING	\N	2026-10-09 15:50:29.384405+00	5501	2026-10-09 15:50:38.154363+00	5501	f
9055	offre_en_cours	f	f	f	\N	\N	2026-10-10 08:14:49.823802+00	1780	\N	\N	f
9529	commande	t	f	t	A290	\N	2026-10-07 08:50:12.293244+00	5502	2026-10-09 16:03:07.539521+00	5502	f
9731	offre_en_cours	f	f	f	SANDERO GPL	\N	2026-10-09 15:27:55.600056+00	7	2026-10-09 16:16:35.868795+00	7	f
9505	commande	t	t	t	clio	\N	2026-10-10 12:29:55.900327+00	5501	2026-10-10 12:30:02.596134+00	5501	t
8888	commande	f	f	f	captur	\N	2026-10-09 17:05:58.669065+00	2	2026-10-09 17:05:58.692369+00	2	f
8890	offre_en_cours	f	f	f	MEGANE	\N	2026-10-09 17:06:19.839112+00	2	2026-10-09 17:06:19.886402+00	2	f
9345	offre_en_cours	f	f	f	SYMBIOZ	\N	2026-10-09 16:28:20.700308+00	1782	2026-10-10 15:57:03.885638+00	1782	f
8820	offre_en_cours	f	f	f	DUSTER	\N	2026-10-09 17:07:07.558037+00	2	2026-10-09 17:07:07.62109+00	2	f
8893	offre_en_cours	f	f	f	R5	\N	2026-10-09 17:07:23.035587+00	2	2026-10-09 17:07:23.103986+00	2	f
9450	offre_en_cours	f	f	f	DUSTER	\N	2026-10-09 17:07:38.55699+00	2	2026-10-09 17:07:38.5957+00	2	f
9221	offre_en_cours	f	f	f	\N	\N	2026-10-10 07:01:51.812309+00	9	\N	\N	f
9321	offre_en_cours	f	f	f	\N	\N	2026-10-10 07:02:05.538195+00	9	\N	\N	f
8886	offre_en_cours	f	f	f	\N	\N	2026-10-10 07:02:20.35078+00	9	\N	\N	f
8887	offre_en_cours	f	f	f	\N	\N	2026-10-10 07:02:26.546079+00	9	\N	\N	f
9029	offre_en_cours	f	f	f	\N	\N	2026-10-10 07:02:41.82961+00	9	\N	\N	f
9220	commande	f	f	f	clio	\N	2026-10-10 07:02:58.237722+00	9	2026-10-10 07:02:58.265061+00	9	f
9155	commande	f	f	f	symbioz	\N	2026-10-10 07:03:08.996797+00	9	2026-10-10 07:03:09.16644+00	9	f
9219	offre_en_cours	f	f	f	\N	\N	2026-10-10 07:03:20.176113+00	9	\N	\N	f
9742	commande	f	f	f	MEGANE	\N	2026-10-10 07:04:06.935424+00	9	2026-10-10 07:04:12.267793+00	9	f
9743	offre_en_cours	f	f	f	TWINGO	\N	2026-10-10 07:04:31.305743+00	9	2026-10-10 07:04:34.116679+00	9	f
9744	offre_en_cours	f	f	f	CLIO	\N	2026-10-10 07:05:04.561149+00	9	2026-10-10 07:05:07.077607+00	9	f
9196	offre_en_cours	f	f	f	GOLF	\N	2026-10-10 07:06:20.959369+00	9	2026-10-10 07:06:21.132633+00	9	f
9198	annule	f	f	f	\N	\N	2026-10-10 07:06:40.162374+00	9	\N	\N	f
9745	clos_sans_suite	f	f	f	ZOE	\N	2026-10-10 07:07:47.786036+00	9	2026-10-10 07:07:56.692191+00	9	f
9746	\N	f	f	f	CAPTUR	\N	2026-10-10 07:09:27.454571+00	9	\N	\N	f
9747	\N	f	f	f	SPRING	\N	2026-10-10 07:09:48.460832+00	9	\N	\N	f
9496	clos_sans_suite	f	f	f	\N	\N	2026-10-10 07:27:26.761611+00	5501	\N	\N	f
9270	clos_sans_suite	f	f	f	STEPWAY	\N	2026-10-10 07:51:17.766885+00	1782	2026-10-10 07:51:33.067902+00	1782	f
9531	commande	t	f	t	A290	\N	2026-10-07 08:50:17.411102+00	5502	2026-10-10 08:05:51.49712+00	5502	f
9452	no_show	f	f	f	\N	\N	2026-10-10 08:14:55.886393+00	1780	\N	\N	f
9569	commande	t	t	t	\N	\N	2026-10-10 08:15:02.121434+00	1780	2026-10-10 08:15:10.198833+00	1780	f
9453	offre_en_cours	f	f	f	\N	\N	2026-10-10 08:15:18.704661+00	1780	\N	\N	f
8729	no_show	f	f	f	\N	\N	2026-10-10 08:37:28.894294+00	9	\N	\N	f
9042	commande	t	t	t	R5	\N	2026-10-10 08:12:34.010371+00	1780	2026-10-10 08:12:45.011586+00	1780	t
9082	offre_en_cours	f	f	f	\N	\N	2026-10-10 08:37:35.915609+00	9	\N	\N	f
9561	commande	f	t	f	DUSTER	\N	2026-10-10 08:13:10.545851+00	1780	2026-10-10 08:13:30.042765+00	1780	f
9049	offre_en_cours	f	f	f	\N	\N	2026-10-10 08:14:04.765459+00	1780	\N	\N	f
9050	clos_sans_suite	f	f	f	\N	\N	2026-10-10 08:14:10.201455+00	1780	\N	\N	f
8962	commande	f	f	f	\N	\N	2026-10-10 08:37:56.618262+00	9	\N	\N	f
9174	annule	f	f	f	\N	\N	2026-10-10 08:38:39.088834+00	9	\N	\N	f
9749	offre_en_cours	f	f	f	\N	\N	2026-10-10 09:28:52.970661+00	7	\N	\N	f
9751	\N	f	f	f	MEGANE	\N	2026-10-10 09:29:28.525972+00	7	\N	\N	f
9752	clos_sans_suite	f	f	f	MEGANE	\N	2026-10-10 09:30:15.467303+00	7	2026-10-10 09:30:21.606587+00	7	f
9016	clos_sans_suite	f	f	f	TWINGO	\N	2026-10-10 13:15:44.382746+00	1782	2026-10-10 13:15:57.697966+00	1782	f
9741	commande	f	t	f	BIGSTER	\N	2026-10-09 16:16:20.159887+00	7	2026-10-10 09:30:53.373918+00	7	f
9504	offre_en_cours	f	f	f	\N	\N	2026-10-10 09:42:06.842015+00	5501	\N	\N	f
9058	commande	t	f	t	R5	\N	2026-10-10 12:42:55.916245+00	1780	2026-10-10 12:43:00.111608+00	1780	f
9497	commande	t	f	t	\N	\N	2026-10-10 09:42:07.581992+00	5501	2026-10-10 09:42:10.113728+00	5501	f
9572	no_show	f	f	f	\N	\N	2026-10-10 12:43:33.474747+00	1780	\N	\N	f
9755	commande	t	t	f	SANDERO	\N	2026-10-10 09:42:14.06588+00	5501	2026-10-10 09:42:24.325743+00	5501	f
9516	offre_en_cours	f	f	f	\N	\N	2026-10-10 09:42:24.394557+00	5501	\N	\N	f
8823	offre_en_cours	f	f	f	\N	\N	2026-10-10 12:09:16.08388+00	1782	\N	\N	f
8959	commande	t	f	f	\N	\N	2026-10-10 12:09:19.774867+00	1782	2026-10-10 12:09:21.468356+00	1782	f
9002	clos_sans_suite	f	f	f	CLIO	\N	2026-10-10 13:14:00.782293+00	1782	2026-10-10 13:14:12.79494+00	1782	f
9006	clos_sans_suite	f	f	f	\N	\N	2026-10-10 13:14:22.862891+00	1782	\N	\N	f
9008	clos_sans_suite	f	f	f	\N	\N	2026-10-10 13:14:34.747813+00	1782	\N	\N	f
9012	offre_en_cours	f	f	f	\N	\N	2026-10-10 13:15:00.528751+00	1782	\N	\N	f
9318	commande	f	t	f	\N	\N	2026-10-10 14:04:09.116719+00	7	2026-10-10 14:04:14.864017+00	7	f
8851	commande	t	f	t	SANDERO	\N	2026-10-10 13:15:57.7392+00	1782	2026-10-10 13:16:15.602156+00	1782	f
8927	commande	f	t	f	Sandero	\N	2026-10-10 14:03:47.116064+00	7	2026-10-10 14:03:59.403947+00	7	f
9757	commande	f	f	f	CLIO VO	\N	2026-10-10 14:06:18.257397+00	7	2026-10-10 14:06:33.424487+00	7	f
9217	commande	t	f	t	\N	\N	2026-10-10 14:04:49.40578+00	7	2026-10-10 14:04:55.150149+00	7	f
9034	offre_en_cours	f	f	f	\N	\N	2026-10-10 14:12:13.987517+00	7	\N	\N	f
9626	commande	t	t	t	\N	\N	2026-10-10 14:10:06.630291+00	7	2026-10-10 14:10:26.1528+00	7	f
9032	offre_en_cours	f	f	f	\N	\N	2026-10-10 14:10:38.400215+00	7	\N	\N	f
9729	offre_en_cours	f	f	f	\N	\N	2026-10-10 14:12:23.688062+00	7	\N	\N	f
9758	commande	f	f	f	CLIO	\N	2026-10-10 14:13:11.749227+00	7	2026-10-10 14:13:49.238453+00	7	f
8871	offre_en_cours	f	f	f	DUSTER	\N	2026-10-09 17:06:55.521412+00	2	2026-10-10 15:53:51.420561+00	2	f
9398	commande	t	t	t	SANDERO	\N	2026-10-10 15:04:45.427942+00	1782	2026-10-10 15:05:09.771554+00	1782	f
8987	commande	t	f	f	ESPACE	\N	2026-10-10 13:16:15.696652+00	1782	2026-10-10 15:57:47.114152+00	1782	f
8739	\N	f	f	f	SOLDE	\N	2026-10-10 16:00:52.359083+00	9	2026-10-10 16:00:52.228487+00	9	f
8815	commande	t	t	t	SCENIC E TECH	\N	2026-10-09 12:37:00.635374+00	1782	2026-10-10 15:06:24.415938+00	1782	f
8740	clos_sans_suite	f	f	f	ARKANA JUIN SOLDE	\N	2026-10-10 16:01:10.26216+00	9	2026-10-10 16:01:10.366068+00	9	f
9759	commande	t	f	t	MEGANE E TECH	\N	2026-10-10 15:08:49.520456+00	1782	2026-10-10 15:08:59.264417+00	1782	f
9225	offre_en_cours	f	f	f	\N	\N	2026-10-10 15:16:35.904382+00	5	\N	\N	f
8926	commande	t	f	t	\N	\N	2026-10-10 15:16:43.511025+00	5	2026-10-10 15:16:46.707407+00	5	f
9226	commande	t	f	f	\N	\N	2026-10-10 15:17:13.774235+00	5	2026-10-10 15:17:15.571416+00	5	f
9440	commande	t	f	t	\N	\N	2026-10-10 16:03:46.639831+00	5	2026-10-10 16:03:50.99064+00	5	f
9760	commande	t	t	f	\N	\N	2026-10-10 15:17:42.207231+00	5	2026-10-10 15:17:46.488291+00	5	f
9429	offre_en_cours	f	f	f	\N	\N	2026-10-10 16:03:58.052918+00	5	\N	\N	f
9280	commande	t	f	t	\N	\N	2026-10-10 15:33:05.260207+00	5	2026-10-10 15:33:09.387572+00	5	f
9282	offre_en_cours	f	f	f	\N	\N	2026-10-10 15:33:15.798584+00	5	\N	\N	f
9341	commande	t	f	t	\N	\N	2026-10-10 15:33:56.878361+00	5	2026-10-10 15:34:00.97821+00	5	f
9283	clos_sans_suite	f	f	f	\N	\N	2026-10-10 15:34:04.210469+00	5	2026-10-10 15:34:06.525056+00	5	f
9378	clos_sans_suite	f	f	f	\N	\N	2026-10-11 07:02:47.686507+00	5	2026-10-11 07:02:53.12464+00	5	f
9761	commande	t	f	t	\N	\N	2026-10-10 15:34:56.820878+00	5	2026-10-10 15:35:00.694606+00	5	f
9379	clos_sans_suite	f	f	f	\N	\N	2026-10-11 07:02:57.285284+00	5	\N	\N	f
9430	commande	t	t	t	\N	\N	2026-10-10 16:04:02.29812+00	5	2026-10-10 16:04:08.221859+00	5	f
9762	commande	t	f	t	SPRING	\N	2026-10-10 15:35:33.887172+00	5	2026-10-10 15:35:44.534183+00	5	f
9018	clos_sans_suite	f	f	f	\N	\N	2026-10-10 16:04:17.379629+00	5	\N	\N	f
9380	commande	f	t	t	\N	\N	2026-10-10 15:49:28.834169+00	5	2026-10-10 15:49:33.030778+00	5	f
8692	commande	f	t	f	\N	\N	2026-10-10 15:49:36.297297+00	5	2026-10-10 15:49:37.27376+00	5	f
9015	no_show	f	f	f	\N	\N	2026-10-10 15:49:45.229184+00	5	\N	\N	f
9432	commande	f	f	t	\N	\N	2026-10-10 16:04:25.515988+00	5	2026-10-10 16:04:28.881295+00	5	f
9017	commande	f	t	f	\N	\N	2026-10-10 15:49:50.347774+00	5	2026-10-10 15:49:53.002422+00	5	f
9517	offre_en_cours	f	f	f	\N	\N	2026-10-10 16:07:45.682903+00	5501	\N	\N	f
9019	commande	t	f	t	\N	\N	2026-10-10 15:50:03.330851+00	5	2026-10-10 15:50:05.702961+00	5	f
9020	offre_en_cours	f	f	f	\N	\N	2026-10-10 15:50:27.223488+00	5	\N	\N	f
9451	clos_sans_suite	f	f	f	\N	\N	2026-10-11 07:07:45.407008+00	5	\N	\N	f
9763	commande	f	f	f	\N	\N	2026-10-10 15:51:26.13981+00	5	\N	\N	f
9756	offre_en_cours	f	f	f	\N	\N	2026-10-10 16:07:52.024747+00	5501	\N	\N	f
9765	commande	t	f	t	\N	\N	2026-10-10 15:51:37.964648+00	5	2026-10-10 15:51:39.840702+00	5	f
9334	offre_en_cours	f	f	f	MEGANE R5	\N	2026-10-10 15:53:33.431031+00	2	2026-10-10 15:53:33.438097+00	2	f
8818	no_show	f	f	f	\N	\N	2026-10-10 15:54:07.704934+00	2	\N	\N	f
9766	offre_en_cours	f	f	f	CLIO 6	\N	2026-10-10 15:54:46.574103+00	2	2026-10-10 15:54:52.890409+00	2	f
9767	commande	f	f	f	MEGANE	\N	2026-10-10 15:55:18.273256+00	2	2026-10-10 15:55:22.51044+00	2	f
8983	offre_en_cours	f	f	f	SYMBIOZ	\N	2026-10-10 15:56:40.352885+00	1782	2026-10-10 15:56:49.135941+00	1782	f
9401	offre_en_cours	f	f	f	CAPTUR	\N	2026-10-10 15:57:11.813937+00	1782	2026-10-10 15:57:11.907019+00	1782	f
8986	no_show	f	f	f	\N	\N	2026-10-10 15:57:23.116179+00	1782	2026-10-10 15:57:24.159675+00	1782	f
9347	clos_sans_suite	f	f	f	\N	\N	2026-10-10 15:58:28.111663+00	9	\N	\N	f
8735	commande	f	f	f	captur	\N	2026-10-10 15:58:43.476311+00	9	2026-10-10 15:58:43.617408+00	9	f
9768	commande	f	f	f	TWINGO	\N	2026-10-10 15:59:49.199266+00	9	2026-10-10 16:00:10.360134+00	9	f
9348	commande	f	f	f	MEGANE	\N	2026-10-10 16:00:23.248095+00	9	2026-10-10 16:00:23.376659+00	9	f
8737	commande	f	f	f	CLIO	\N	2026-10-10 16:00:32.539167+00	9	2026-10-10 16:00:32.690547+00	9	f
9333	offre_en_cours	f	f	f	\N	\N	2026-10-10 16:08:41.085928+00	2	\N	\N	f
9774	commande	t	t	f	R5	\N	2026-10-10 16:41:40.364036+00	7	2026-10-10 16:41:59.829418+00	7	f
8750	offre_en_cours	f	f	f	\N	\N	2026-10-11 06:54:06.665266+00	5	\N	\N	f
9455	no_show	f	f	f	\N	\N	2026-10-11 07:07:55.408773+00	5	\N	\N	f
9769	commande	t	t	t	MEGANE	\N	2026-10-10 16:08:48.860863+00	5501	2026-10-10 16:08:51.457471+00	5501	f
9775	commande	f	f	f	\N	\N	2026-10-11 07:09:27.578045+00	5	\N	\N	f
8830	offre_en_cours	f	f	f	\N	\N	2026-10-11 07:12:20.014492+00	5	\N	\N	f
9770	commande	t	t	t	AUSTRAL	\N	2026-10-10 16:08:56.431614+00	5501	2026-10-10 16:08:58.778873+00	5501	f
8855	offre_en_cours	f	f	f	\N	\N	2026-10-10 16:09:41.771792+00	5	\N	\N	f
9771	offre_en_cours	f	f	f	R4	\N	2026-10-10 16:09:42.297752+00	2	2026-10-10 16:09:45.90837+00	2	f
9773	offre_en_cours	f	f	f	TWINGO	\N	2026-10-10 16:10:25.582197+00	2	2026-10-10 16:10:29.616143+00	2	f
8694	commande	t	t	t	\N	\N	2026-10-10 15:50:21.67649+00	5	2026-10-11 06:54:18.81871+00	5	f
9772	commande	t	t	t	\N	\N	2026-10-10 16:10:32.1284+00	5	2026-10-10 16:10:38.213248+00	5	f
9754	offre_en_cours	f	f	f	\N	\N	2026-10-10 16:37:03.743179+00	7	\N	\N	f
9750	no_show	f	f	f	\N	\N	2026-10-10 16:37:12.594573+00	7	\N	\N	f
9753	clos_sans_suite	f	f	f	\N	\N	2026-10-10 16:37:22.476214+00	7	\N	\N	f
9776	commande	t	t	t	\N	\N	2026-10-11 07:09:37.254616+00	5	2026-10-11 07:09:39.77631+00	5	f
9417	commande	t	t	t	\N	\N	2026-10-11 06:54:22.492479+00	5	2026-10-11 06:54:25.674935+00	5	f
8842	commande	f	t	f	\N	\N	2026-10-11 07:01:18.453854+00	5	2026-10-11 07:01:20.735993+00	5	f
8850	no_show	f	f	f	\N	\N	2026-10-11 07:01:34.460241+00	5	\N	\N	f
9374	no_show	f	f	f	\N	\N	2026-10-11 07:10:47.433445+00	5	\N	\N	f
8852	commande	t	t	f	\N	\N	2026-10-11 07:01:38.85568+00	5	2026-10-11 07:01:47.548961+00	5	f
9439	commande	f	t	f	\N	\N	2026-10-11 07:11:17.80439+00	5	2026-10-11 07:11:26.751547+00	5	f
8824	no_show	f	f	f	\N	\N	2026-10-11 07:11:39.07209+00	5	\N	\N	f
9394	commande	t	t	t	\N	\N	2026-10-11 07:17:38.796514+00	5	2026-10-11 07:17:46.460395+00	5	f
9461	commande	t	f	t	\N	\N	2026-10-11 07:11:45.583673+00	5	2026-10-11 07:11:52.23719+00	5	f
8829	offre_en_cours	f	f	f	\N	\N	2026-10-11 07:12:04.639115+00	5	\N	\N	f
9436	commande	t	f	t	\N	\N	2026-10-11 07:12:42.690173+00	5	2026-10-11 07:12:49.675793+00	5	f
9778	commande	t	f	t	\N	\N	2026-10-11 07:13:56.139561+00	5	2026-10-11 07:14:03.073164+00	5	f
9412	commande	t	f	t	\N	\N	2026-10-11 07:16:54.787724+00	5	2026-10-11 07:17:00.565225+00	5	f
9463	commande	t	t	f	\N	\N	2026-10-11 07:17:05.843962+00	5	2026-10-11 07:17:12.708793+00	5	f
9413	no_show	f	f	f	\N	\N	2026-10-11 07:17:25.150088+00	5	2026-10-11 07:17:30.236951+00	5	f
8837	commande	t	t	t	\N	\N	2026-10-11 07:17:50.925093+00	5	2026-10-11 07:17:57.066375+00	5	f
8836	commande	t	t	t	\N	\N	2026-10-11 07:18:01.609802+00	5	2026-10-11 07:18:05.913066+00	5	f
8690	no_show	f	f	f	\N	\N	2026-10-11 07:18:24.488549+00	5	\N	\N	f
8872	offre_en_cours	f	f	f	\N	\N	2026-10-11 07:18:15.025955+00	5	\N	\N	f
9532	commande	f	f	f	A290	\N	2026-10-07 08:50:21.604261+00	5502	2026-10-11 09:40:51.906964+00	5502	f
9779	commande	t	f	t	\N	\N	2026-10-11 09:42:27.499424+00	5502	2026-10-11 09:42:29.386567+00	5502	f
9780	commande	f	f	f	\N	\N	2026-10-11 09:43:33.51264+00	5502	\N	\N	f
9781	commande	f	f	f	\N	\N	2026-10-11 09:44:58.061264+00	5502	\N	\N	f
9433	annule	f	f	f	\N	\N	2026-10-11 14:38:26.422516+00	5	\N	\N	f
9434	commande	f	f	t	\N	\N	2026-10-11 14:38:35.861047+00	5	2026-10-11 14:38:37.346162+00	5	f
9466	offre_en_cours	f	f	f	r4	\N	2026-10-12 06:00:24.658183+00	2	2026-10-12 06:00:24.660634+00	2	f
9435	commande	t	f	t	\N	\N	2026-10-11 14:38:56.770118+00	5	2026-10-11 14:38:59.22095+00	5	f
9331	offre_en_cours	f	f	f	megane	\N	2026-10-12 06:00:31.537808+00	2	2026-10-12 06:00:31.611837+00	2	f
9782	commande	t	t	t	\N	\N	2026-10-11 14:41:18.616613+00	5	2026-10-11 14:41:23.856737+00	5	f
9783	commande	t	f	t	\N	\N	2026-10-11 14:41:30.645601+00	5	2026-10-11 14:41:34.177458+00	5	f
9784	commande	f	f	f	\N	\N	2026-10-11 14:41:36.794474+00	5	\N	\N	f
9794	commande	f	f	t	austral VO	\N	2026-10-12 06:01:53.031014+00	2	2026-10-12 06:02:03.490423+00	2	f
9785	commande	t	t	t	\N	\N	2026-10-11 14:42:17.29312+00	5	2026-10-11 14:42:20.299394+00	5	f
8928	clos_sans_suite	f	f	f	\N	\N	2026-10-11 14:43:09.038527+00	5	2026-10-11 14:43:18.020618+00	5	f
8695	commande	t	f	f	\N	\N	2026-10-11 14:43:19.50423+00	5	2026-10-11 14:43:20.352143+00	5	f
9227	commande	t	f	t	\N	\N	2026-10-11 14:43:30.001634+00	5	2026-10-11 14:43:37.546264+00	5	f
9795	commande	t	f	t	R5	\N	2026-10-12 06:02:29.478363+00	2	2026-10-12 06:02:34.953639+00	2	f
9630	commande	t	t	f	Sandero	\N	2026-10-11 15:52:43.923297+00	7	2026-10-11 15:52:47.024089+00	7	f
9730	commande	f	t	f	Mercedes Class B	\N	2026-10-11 15:52:52.270171+00	7	2026-10-11 15:53:07.078049+00	7	f
9796	offre_en_cours	f	f	f	SANDERO	\N	2026-10-12 06:02:57.348382+00	2	2026-10-12 06:02:59.067143+00	2	f
8774	offre_en_cours	f	f	f	\N	\N	2026-10-12 07:12:55.139727+00	8	\N	\N	f
8778	commande	f	f	f	\N	\N	2026-10-12 07:13:02.556566+00	8	\N	\N	f
9786	commande	f	t	f	SANDERO	\N	2026-10-11 15:58:50.170262+00	7	2026-10-11 15:59:08.703419+00	7	f
8921	commande	t	f	t	R 5	\N	2026-10-10 09:28:55.474989+00	7	2026-10-11 16:28:14.083389+00	7	f
9287	offre_en_cours	f	f	f	\N	\N	2026-10-11 16:28:54.66976+00	7	\N	\N	f
9127	clos_sans_suite	f	f	f	\N	\N	2026-10-11 16:29:03.377285+00	7	\N	\N	f
8780	offre_en_cours	f	f	f	\N	\N	2026-10-12 07:13:29.813269+00	8	\N	\N	f
8782	offre_en_cours	f	f	f	\N	\N	2026-10-12 07:13:41.60571+00	8	\N	\N	f
8784	offre_en_cours	f	f	f	\N	\N	2026-10-12 07:13:47.786089+00	8	\N	\N	f
9789	commande	t	t	t	SANDERO	\N	2026-10-11 16:29:50.474122+00	7	2026-10-11 16:30:11.84995+00	7	f
8785	offre_en_cours	f	f	f	\N	\N	2026-10-12 07:13:59.005425+00	8	\N	\N	f
9790	commande	f	f	t	SYMBIOZ	\N	2026-10-11 16:31:07.001464+00	7	2026-10-11 16:31:27.820201+00	7	f
8825	commande	t	t	f	\N	\N	2026-10-11 16:40:53.96689+00	7	2026-10-11 16:40:57.811738+00	7	f
8826	clos_sans_suite	f	f	f	\N	\N	2026-10-11 16:41:29.941362+00	7	\N	\N	f
9329	no_show	f	f	f	\N	\N	2026-10-11 16:41:40.416667+00	7	\N	\N	f
9718	no_show	f	f	f	\N	\N	2026-10-11 16:41:54.319937+00	7	\N	\N	f
9183	no_show	f	f	f	\N	\N	2026-10-11 16:44:51.33017+00	7	\N	\N	f
8786	commande	t	f	f	\N	\N	2026-10-12 07:14:09.550404+00	8	2026-10-12 07:14:11.216136+00	8	f
9026	offre_en_cours	f	f	f	\N	\N	2026-10-12 07:14:26.045876+00	8	\N	\N	f
9085	offre_en_cours	f	f	f	\N	\N	2026-10-12 07:14:39.187559+00	8	\N	\N	f
9791	commande	t	t	t	MEGANE	\N	2026-10-11 16:44:53.803278+00	7	2026-10-11 16:45:06.901858+00	7	f
9125	commande	t	f	f	\N	\N	2026-10-12 07:14:44.446732+00	8	2026-10-12 07:14:45.653012+00	8	f
9793	commande	t	t	f	R5	\N	2026-10-11 16:45:14.823231+00	7	2026-10-11 16:45:17.494398+00	7	f
9792	commande	t	t	t	CLIO VI	\N	2026-10-11 16:44:37.184068+00	7	2026-10-11 16:45:44.893193+00	7	f
\.


--
-- Data for Name: role_campagne; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.role_campagne (id, campagne_id, utilisateur_id, role, plaque_id, site_id, cree_le, cree_par, archive_le) FROM stdin;
4	2	13	chef_plaque	1	\N	2026-08-31 20:53:19.106+00	\N	\N
5	2	14	chef_site	\N	3	2026-08-31 20:53:19.987+00	\N	\N
\.


--
-- Data for Name: role_global; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.role_global (utilisateur_id, role, cree_le, cree_par) FROM stdin;
10	admin	2026-08-31 20:53:15.78+00	\N
11	direction	2026-08-31 20:53:17.147+00	\N
2116	lecteur	2026-10-05 09:55:16.604019+00	92
5500	admin	2026-10-07 07:18:09.636205+00	\N
1784	admin	2026-09-07 14:40:27.730194+00	\N
787	admin	2026-09-01 16:43:20.447858+00	\N
92	admin	2026-09-01 12:45:20.746852+00	\N
93	admin	2026-09-01 12:58:40.915832+00	\N
94	direction	2026-09-01 12:59:44.615288+00	\N
95	direction	2026-09-01 13:01:37.569948+00	\N
96	direction	2026-09-01 13:01:52.884959+00	\N
98	admin	2026-09-01 15:11:18.605526+00	\N
1785	admin	2026-10-06 15:03:34.720146+00	92
5503	admin	2026-10-07 09:04:10.617222+00	\N
1779	direction	2026-09-04 09:48:52.997933+00	\N
1	direction	2026-09-08 07:44:07.655897+00	92
1786	admin	2026-09-08 13:22:16.105933+00	\N
\.


--
-- Data for Name: session_plaque; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.session_plaque (id, campagne_id, plaque_id, mode, effectif_cible_table, cree_le, cree_par, archive_le) FROM stdin;
1	1	1	par_table	6	2026-08-31 20:50:18.397+00	\N	\N
2	1	2	par_site	\N	2026-08-31 20:50:18.808+00	\N	\N
3	1	3	par_table	6	2026-08-31 20:50:19.045+00	\N	\N
4	1	4	par_site	\N	2026-08-31 20:50:19.279+00	\N	\N
5	2	1	par_table	6	2026-08-31 20:50:20.458+00	\N	\N
6	2	2	par_site	\N	2026-08-31 20:50:20.716+00	\N	\N
7	2	3	par_table	6	2026-08-31 20:50:21.29+00	\N	\N
8	2	4	par_site	\N	2026-08-31 20:50:21.539+00	\N	\N
494	933	3	par_table	5	2026-10-02 09:06:05.777418+00	92	\N
492	933	1	par_table	5	2026-10-02 09:06:05.777418+00	92	\N
493	933	2	par_site	\N	2026-10-02 09:06:05.777418+00	92	\N
495	933	4	par_site	\N	2026-10-02 09:06:05.777418+00	92	\N
\.


--
-- Data for Name: site; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.site (id, code, libelle, plaque_id, cree_le, cree_par, archive_le, tableau_ventes) FROM stdin;
1	MASS	Massagettes	1	2026-08-31 20:49:25.453+00	\N	\N	t
2	MOZ	Mozac	1	2026-08-31 20:49:25.569+00	\N	\N	t
3	CLF	Clermont-Ferrand	1	2026-08-31 20:49:25.61+00	\N	\N	t
4	USS	Ussel	1	2026-08-31 20:49:25.658+00	\N	\N	t
6	VI	Vichy	2	2026-08-31 20:49:25.745+00	\N	\N	t
7	MOU	Moulins	2	2026-08-31 20:49:25.793+00	\N	\N	t
8	TH	Thiers	2	2026-08-31 20:49:25.83+00	\N	\N	t
9	PUY	Le Puy	3	2026-08-31 20:49:25.871+00	\N	\N	t
10	MEN	Mende	3	2026-08-31 20:49:25.942+00	\N	\N	t
11	ISS	Issoire	3	2026-08-31 20:49:25.992+00	\N	\N	t
12	GAILL	Gaillac	4	2026-08-31 20:49:26.025+00	\N	\N	t
13	ALBI	Albi	4	2026-08-31 20:49:26.066+00	\N	\N	t
14	RDZ	Rodez	4	2026-08-31 20:49:26.11+00	\N	\N	t
15	MILL	Millau	4	2026-08-31 20:49:26.149+00	\N	\N	t
16	FIGEAC	Figeac	4	2026-08-31 20:49:26.19+00	\N	\N	t
17	AUR	Aurillac	4	2026-08-31 20:49:26.232+00	\N	\N	t
18	VDR	Villefranche	4	2026-08-31 20:49:26.28+00	\N	\N	t
19	CARM	Carmaux	4	2026-08-31 20:49:26.33+00	\N	\N	t
710	LAV	Lavaur	4	2026-09-04 13:11:11.762874+00	\N	\N	t
5	ALPINE	Alpine	1	2026-08-31 20:49:25.702+00	\N	\N	f
\.


--
-- Data for Name: table_phoning; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.table_phoning (id, session_plaque_id, libelle, chef_utilisateur_id, ordre, cree_le, cree_par, archive_le, marque_id) FROM stdin;
1	1	Table 1	2	1	2026-08-31 20:50:21.882+00	\N	\N	\N
2	1	Table 2	3	2	2026-08-31 20:50:22.039+00	\N	\N	\N
3	1	Table 3	4	3	2026-08-31 20:50:22.124+00	\N	\N	\N
4	1	Table 4	5	4	2026-08-31 20:50:22.226+00	\N	\N	\N
5	1	Table 5	6	5	2026-08-31 20:50:22.346+00	\N	\N	\N
6	3	Table 1	7	1	2026-08-31 20:50:22.461+00	\N	\N	\N
7	3	Table 2	8	2	2026-08-31 20:50:22.59+00	\N	\N	\N
8	3	Table 3	9	3	2026-08-31 20:50:22.709+00	\N	\N	\N
1082	494	Table 1 - Sud	8	1	2026-10-05 12:13:32.523784+00	787	\N	\N
1084	494	Table 3 - Sud	7	3	2026-10-05 12:13:50.558109+00	787	\N	\N
572	492	EAA - TABLE 1	2	1	2026-10-03 09:43:45.686115+00	92	\N	\N
575	492	EAA - TABLE 4	4	4	2026-10-03 09:44:07.08086+00	92	\N	\N
145	7	PLAQUE SUD - 2	8	2	2026-09-02 09:30:35.062701+00	787	\N	\N
9	5	TABLE 1 - EAA	5	1	2026-09-01 15:28:59.817474+00	92	\N	\N
10	5	TABLE 2 - EAA	6	2	2026-09-01 15:29:31.677519+00	92	\N	\N
11	5	TABLE 3 - EAA	4	3	2026-09-01 15:29:37.085727+00	92	\N	\N
12	5	TABLE 4 - EAA	2	4	2026-09-01 15:29:42.158952+00	92	\N	\N
13	5	TABLE 5 - EAA	3	5	2026-09-01 15:29:49.251706+00	92	\N	\N
573	492	EAA - TABLE 2	3	2	2026-10-03 09:43:55.687385+00	92	\N	\N
144	7	Plaque SUD -1	7	1	2026-09-01 16:46:55.487315+00	787	\N	\N
146	7	PLAQUE SUD - 3	9	3	2026-09-02 09:36:45.359915+00	787	\N	\N
574	492	EAA - TABLE 3	5	3	2026-10-03 09:44:01.238299+00	92	\N	\N
1083	494	Table 2 - Sud	9	2	2026-10-05 12:13:43.098828+00	787	\N	\N
\.


--
-- Data for Name: utilisateur; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.utilisateur (id, login_id, password_hash, nom, actif, cree_le, cree_par, archive_le, auth_uid, doit_changer_mdp) FROM stdin;
1779	dsarotti	(supabase-auth)	Didier SAROTTI	t	2026-09-04 09:48:52.932794+00	\N	\N	5a1145e6-a11b-43df-825f-ce23b5620782	f
1	admin	$2b$10$jf1LfAOZSMgiQLYsVflYL.q0dRv8ocSlzR9ZpBjoTQNojIXHN9CJa	Administrateur	t	2026-08-31 20:50:14.806+00	\N	\N	2e6f4109-a9ae-4975-9077-757592869249	f
13	chef.plaque.test	$2b$10$jf1LfAOZSMgiQLYsVflYL.q0dRv8ocSlzR9ZpBjoTQNojIXHN9CJa	CHEF DE PLAQUE — test	f	2026-08-31 20:53:18.693+00	\N	\N	\N	f
14	chef.site.test	$2b$10$jf1LfAOZSMgiQLYsVflYL.q0dRv8ocSlzR9ZpBjoTQNojIXHN9CJa	CHEF DE SITE — test	f	2026-08-31 20:53:19.683+00	\N	\N	\N	f
787	lroux	(supabase-auth)	LUDIVINE ROUX	t	2026-09-01 16:43:20.353208+00	\N	\N	303b0dd3-4ada-4f53-958b-29825fef98f3	f
4	lmarchetti	$2b$10$gYMOmKic9qsqxHud2dyZ0.RjSMQpPXWKzzZpZJj7CBvkSggU6bevK	LUCIEN MARCHETTI	t	2026-08-31 20:50:15.98+00	\N	\N	6d61ac3b-1cad-42ce-ae94-963421dd4fb1	f
3	tcoignac	$2b$10$gYMOmKic9qsqxHud2dyZ0.RjSMQpPXWKzzZpZJj7CBvkSggU6bevK	THIERRY COIGNAC	t	2026-08-31 20:50:15.729+00	\N	\N	c4f2a711-917f-4158-adab-74a71c34527e	f
5	jlarget	$2b$10$gYMOmKic9qsqxHud2dyZ0.RjSMQpPXWKzzZpZJj7CBvkSggU6bevK	JF LARGET	t	2026-08-31 20:50:16.198+00	\N	\N	5a637024-b12e-47b9-b3f1-25631c049fdd	f
6	mmasson	$2b$10$gYMOmKic9qsqxHud2dyZ0.RjSMQpPXWKzzZpZJj7CBvkSggU6bevK	MICKAEL MASSON	t	2026-08-31 20:50:16.394+00	\N	\N	bfc0adb8-889d-482e-a45c-17ca5ac56805	f
2	sbesson	$2b$10$jf1LfAOZSMgiQLYsVflYL.q0dRv8ocSlzR9ZpBjoTQNojIXHN9CJa	SÉVERINE BESSON	t	2026-08-31 20:50:15.467+00	\N	\N	323bc1ec-515e-4676-913a-50b39e43d18c	f
7	fnogues	$2b$10$gYMOmKic9qsqxHud2dyZ0.RjSMQpPXWKzzZpZJj7CBvkSggU6bevK	FRANCK NOGUES	t	2026-08-31 20:50:16.599+00	\N	\N	79958d14-63ab-4f93-bbc6-f57e3bb5082d	f
8	jhebert	$2b$10$gYMOmKic9qsqxHud2dyZ0.RjSMQpPXWKzzZpZJj7CBvkSggU6bevK	JÉRÔME HÉBERT	t	2026-08-31 20:50:16.808+00	\N	\N	c0eb4ed3-3b70-4af4-98f1-9fbb01f55f97	f
9	gparrain	$2b$10$gYMOmKic9qsqxHud2dyZ0.RjSMQpPXWKzzZpZJj7CBvkSggU6bevK	GILLES PARRAIN	t	2026-08-31 20:50:17.083+00	\N	\N	104bb84c-e5c5-4201-85aa-bf8cbdad1fb9	f
1778	rbouzat	(supabase-auth)	Renaud BOUZAT	t	2026-09-04 09:47:53.826403+00	\N	\N	734f38ca-fe79-417e-9e7b-9a287336436c	f
93	rfuziol	(supabase-auth)	RAPHAÊL FUZIOL	t	2026-09-01 12:58:40.811244+00	\N	\N	28e3e42b-0162-49f0-a62c-c0b827534777	f
94	ftixier	(supabase-auth)	FRANCK TIXIER	t	2026-09-01 12:59:44.528474+00	\N	\N	5c3f5664-b44a-44ef-8683-79041d50ac78	f
96	sgaudon	(supabase-auth)	STÉPHANE GAUDON	t	2026-09-01 13:01:52.818469+00	\N	\N	da923fe6-593f-4f5a-9423-36ff8b088d03	f
97	pduverger	(supabase-auth)	PIERRE DUVERGER	t	2026-09-01 13:02:41.790628+00	\N	\N	d6837ce3-decd-41a9-b616-77c9b16791e2	f
98	perard	(supabase-auth)	PIERRE-MICHEL ERARD	t	2026-09-01 15:11:18.506033+00	\N	\N	14b3b621-42d9-4463-9baa-57b036c50a27	f
1782	rfradetal	(supabase-auth)	ROMAIN FRADETAL	t	2026-09-07 13:53:28.180092+00	\N	\N	e81e5e4c-3fe6-43fa-aec2-8f7a9864f813	f
1783	rzennouche	(supabase-auth)	Romain Zennouche	t	2026-09-07 13:54:39.696631+00	\N	\N	499a5468-d3f8-497b-81c3-e92b1f857dc2	f
1784	aperz	(supabase-auth)	Alexis PERZ	t	2026-09-07 14:40:27.651382+00	\N	\N	8834688a-bb11-4b05-ae55-bcb73ec6c7a3	f
1786	crichard	(supabase-auth)	CLAIRE RICHARD	t	2026-09-08 13:22:16.020976+00	\N	\N	ce6dff67-d3ad-473f-9bc0-0e50634e08c4	f
95	bbourron	(supabase-auth)	BENJAMIN BOURRON	t	2026-09-01 13:01:37.432109+00	\N	\N	11da046f-dfd2-4216-890f-f97c3782fea8	f
2116	pyb	(supabase-auth)	PIERRE-YVES BEYRON	f	2026-09-09 09:47:45.998152+00	\N	\N	48cef650-a3d8-466c-b429-c01bff90f2a7	f
10	admin.test	$2b$10$jf1LfAOZSMgiQLYsVflYL.q0dRv8ocSlzR9ZpBjoTQNojIXHN9CJa	ADMIN — test	f	2026-08-31 20:53:15.597+00	\N	\N	37d1c8d1-6efb-41d9-84ad-1f5978acc0ce	f
11	direction.test	$2b$10$jf1LfAOZSMgiQLYsVflYL.q0dRv8ocSlzR9ZpBjoTQNojIXHN9CJa	DIRECTION — test	f	2026-08-31 20:53:16.85+00	\N	\N	986a6c38-99b3-4ad6-8d71-501a04ca0c23	f
12	encadrant.test	$2b$10$jf1LfAOZSMgiQLYsVflYL.q0dRv8ocSlzR9ZpBjoTQNojIXHN9CJa	ENCADRANT — test	f	2026-08-31 20:53:17.728+00	\N	\N	d39e1b71-0b03-4d78-902f-02d50d3fa1ab	f
92	tlabonne	(supabase-auth)	THEO LABONNE	t	2026-09-01 12:45:20.618531+00	\N	\N	9467b496-2b42-4663-9254-76454c9ae544	f
1776	smarty	(supabase-auth)	Stéphanie MARTY	t	2026-09-04 09:46:25.290645+00	\N	\N	0d437d07-4ce1-4368-8c7e-bb9dc0017c1a	f
1775	cfabre	(supabase-auth)	Caroline FABRE	t	2026-09-04 09:45:14.793567+00	\N	\N	7fcb205f-7f0d-4136-baec-a7a34f9d1b8e	f
1780	cdelpuech	(supabase-auth)	Cédric DELPUECH	t	2026-09-04 09:49:59.218837+00	\N	\N	e988aca4-d096-462e-ba0f-3f23fae0f037	f
1781	jcazes	(supabase-auth)	Jean-Philippe CAZES	t	2026-09-04 09:50:49.297013+00	\N	\N	2de97c97-7eda-4f79-8d07-ff68abaf4f21	f
1785	ccharlier	(supabase-auth)	CHRISTIAN CHARLIER	t	2026-09-08 10:31:23.485863+00	\N	\N	752f4494-9746-4075-a251-0a161f78e1ba	f
5500	bwalkowiak	(supabase-auth)	WALKOWIAK BRUNO	t	2026-10-07 07:18:09.562512+00	\N	\N	1a073281-c3d4-4b3f-bf48-1ef3e8e5807c	f
5501	jsebe	(supabase-auth)	Julien SEBE	t	2026-10-07 07:24:50.903825+00	\N	\N	3f3c7826-2427-4117-b0a8-7f9f40a67cb9	f
5502	smira	(supabase-auth)	SEBASTIEN MIRA	t	2026-10-07 08:43:58.752122+00	\N	\N	2d1c4da7-224d-4670-abe1-e9c2c02bff06	f
5503	bfuziol	(supabase-auth)	BASTIEN FUZIOL	t	2026-10-07 09:04:10.541206+00	\N	\N	93c10dba-21cf-4699-94d1-6a1726ccef7b	f
1777	lbressan	(supabase-auth)	Laurent BRESSAN	t	2026-09-04 09:46:42.435072+00	\N	\N	42985b02-8b3b-4dd6-9163-a7e443132448	f
\.


--
-- Data for Name: vendeur; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.vendeur (id, nom, site_id, utilisateur_id, date_entree, date_sortie, cree_le, cree_par, capacites_confirmees_le, capacites_confirmees_par, type_vehicule, archive_le, archive_par) FROM stdin;
2	VIRGINIE CUMINAL	1	\N	\N	\N	2026-08-31 20:49:27.54+00	\N	\N	\N	VN	\N	\N
4	JORDAN CALDEIRA	2	\N	\N	\N	2026-08-31 20:49:28.795+00	\N	\N	\N	VN	\N	\N
5	ROBIN RABOISSON	2	\N	\N	\N	2026-08-31 20:49:29.355+00	\N	\N	\N	VN	\N	\N
6	KEVIN DIJOUX	2	\N	\N	\N	2026-08-31 20:49:30.148+00	\N	\N	\N	VN	\N	\N
13	BLANDINE CLÉMENT	3	\N	\N	2026-07-31	2026-08-31 20:49:33.679+00	\N	2026-09-01 15:38:04.770842+00	92	VN	\N	\N
8	YANN DE OLIVEIRA	2	\N	\N	\N	2026-08-31 20:49:31.298+00	\N	\N	\N	VO	\N	\N
10	VALENTIN PARPINELLI	3	\N	\N	\N	2026-08-31 20:49:31.644+00	\N	\N	\N	VN	\N	\N
11	THIERRY DUBERNAT	3	\N	\N	\N	2026-08-31 20:49:32.17+00	\N	\N	\N	VN	\N	\N
12	OCEANE ESPINASSE	3	\N	\N	\N	2026-08-31 20:49:33.088+00	\N	\N	\N	VN	\N	\N
14	THOMAS SOULIER	3	\N	\N	\N	2026-08-31 20:49:34.277+00	\N	\N	\N	VN	\N	\N
15	CHRISTOPHE BROSSEAU	3	\N	\N	\N	2026-08-31 20:49:34.82+00	\N	\N	\N	VN	\N	\N
16	THÉO ROUSSET	3	\N	\N	\N	2026-08-31 20:49:35.392+00	\N	\N	\N	VN	\N	\N
17	QUENTIN BELLAIGUES	3	\N	\N	\N	2026-08-31 20:49:35.914+00	\N	\N	\N	VN	\N	\N
18	JEAN-PIERRE FERRIER	3	\N	\N	\N	2026-08-31 20:49:36.449+00	\N	\N	\N	VN	\N	\N
19	JULIEN BIASUTTI	3	\N	\N	\N	2026-08-31 20:49:37.08+00	\N	\N	\N	VN	\N	\N
31	ALEXANDRE CHAVIGNON	6	\N	\N	2026-10-05	2026-08-31 20:49:41.278+00	\N	2026-10-05 07:31:25.681635+00	1786	VN	\N	\N
21	ANTOINE BASTIEN	3	\N	\N	\N	2026-08-31 20:49:38.351+00	\N	\N	\N	VO	\N	\N
22	DYLAN GUERRET	3	\N	\N	\N	2026-08-31 20:49:38.482+00	\N	\N	\N	VO	\N	\N
23	JOAO TEIXEIRA	3	\N	\N	\N	2026-08-31 20:49:38.604+00	\N	\N	\N	VO	\N	\N
25	JEROME SABIN	3	\N	\N	\N	2026-08-31 20:49:38.909+00	\N	\N	\N	VO	\N	\N
26	ROBIN GUERY	4	\N	\N	\N	2026-08-31 20:49:39.039+00	\N	\N	\N	VN	\N	\N
27	JULIEN SPADAT	4	\N	\N	\N	2026-08-31 20:49:39.636+00	\N	\N	\N	VN	\N	\N
28	STÉPHANE VANDAMME	4	\N	\N	\N	2026-08-31 20:49:40.281+00	\N	\N	\N	VO	\N	\N
29	SÉBASTIEN MIRA	5	\N	\N	\N	2026-08-31 20:49:40.399+00	\N	\N	\N	VN	\N	\N
30	EMILIEN SOLEILHAVOUP	5	\N	\N	\N	2026-08-31 20:49:40.727+00	\N	\N	\N	VN	\N	\N
34	DYLAN MEYRIAL	6	\N	\N	\N	2026-08-31 20:49:43.05+00	\N	\N	\N	VN	\N	\N
35	YOANN TRIBOULET	6	\N	\N	\N	2026-08-31 20:49:43.564+00	\N	\N	\N	VN	\N	\N
36	MATTIS BONNAMOUR	6	\N	\N	\N	2026-08-31 20:49:44.169+00	\N	\N	\N	VN	\N	\N
4204	LAURENT CHANAT	7	\N	\N	\N	2026-10-05 07:32:37.051363+00	1786	2026-10-05 07:32:37.051363+00	1786	VN	\N	\N
39	CLÉMENT JACQUET	6	\N	\N	\N	2026-08-31 20:49:45.484+00	\N	\N	\N	VO	\N	\N
40	ROMARIC RAMBERT	6	\N	\N	\N	2026-08-31 20:49:45.643+00	\N	\N	\N	VO	\N	\N
41	CLÉMENT RAYA	6	\N	\N	\N	2026-08-31 20:49:45.839+00	\N	\N	\N	VO	\N	\N
48	LOUIS DUBOST	8	\N	\N	\N	2026-08-31 20:49:47.952+00	\N	\N	\N	VN	\N	\N
49	CYNTHIA VALLIN	8	\N	\N	\N	2026-08-31 20:49:48.57+00	\N	\N	\N	VN	\N	\N
50	AXEL DUMONT	8	\N	\N	\N	2026-08-31 20:49:49.219+00	\N	\N	\N	VN	\N	\N
51	DAMIEN DAGOSTINO	8	\N	\N	\N	2026-08-31 20:49:49.754+00	\N	\N	\N	VO	\N	\N
53	ARNAUD GALLAND	9	\N	\N	\N	2026-08-31 20:49:50.054+00	\N	\N	\N	VN	\N	\N
54	GUILLAUME SAVINEL	9	\N	\N	\N	2026-08-31 20:49:50.598+00	\N	\N	\N	VN	\N	\N
55	JEAN-PAUL RANVOISE	9	\N	\N	\N	2026-08-31 20:49:51.171+00	\N	\N	\N	VN	\N	\N
56	ARTHUR DURANTON	9	\N	\N	\N	2026-08-31 20:49:51.736+00	\N	\N	\N	VN	\N	\N
57	VALENTIN MOLINES	9	\N	\N	\N	2026-08-31 20:49:52.381+00	\N	\N	\N	VO	\N	\N
61	WILLIAM PASCAL	10	\N	\N	\N	2026-08-31 20:49:53.893+00	\N	\N	\N	VO	\N	\N
62	YOANN PICARD	11	\N	\N	\N	2026-08-31 20:49:54.046+00	\N	\N	\N	VN	\N	\N
5766	Alexandre PINOT	9	\N	2026-10-01	\N	2026-10-05 15:01:17.783871+00	787	2026-10-05 15:01:17.783871+00	787	VO	\N	\N
65	MAGALI MICHEL	11	\N	\N	\N	2026-08-31 20:49:55.883+00	\N	\N	\N	VN	\N	\N
58	RICHARD WEISSELDINGER	9	\N	\N	\N	2026-08-31 20:49:52.544+00	\N	\N	\N	VO	2026-10-06 15:47:16.11144+00	95
67	SÉBASTIEN DUMONT	11	\N	\N	\N	2026-08-31 20:49:57.277+00	\N	\N	\N	VN	\N	\N
68	REDWANE TOULOUSE	11	\N	\N	\N	2026-08-31 20:49:57.884+00	\N	\N	\N	VO	\N	\N
69	STÉPHANE DALLO-BELLESSA	11	\N	\N	\N	2026-08-31 20:49:58.037+00	\N	\N	\N	VO	\N	\N
47	ROMAIN DENIS	7	\N	\N	\N	2026-08-31 20:49:47.82+00	\N	\N	\N	VO	2026-10-05 07:32:51.812369+00	1786
24	THIERRY MARTINEZ	3	\N	\N	2026-09-30	2026-08-31 20:49:38.777+00	\N	2026-10-03 09:40:20.148098+00	92	VO	\N	\N
72	JULIEN SEBE	12	\N	\N	\N	2026-08-31 20:49:59.003+00	\N	\N	\N	VN	\N	\N
73	GUILLAUME SEGUI	12	\N	\N	\N	2026-08-31 20:49:59.657+00	\N	\N	\N	VN	\N	\N
74	FLAVIEN MILLON	12	\N	\N	\N	2026-08-31 20:50:00.271+00	\N	\N	\N	VN	\N	\N
75	DANIEL DIAS FERNANDES	13	\N	\N	\N	2026-08-31 20:50:00.978+00	\N	\N	\N	VN	\N	\N
76	AURÉLIE BOMPART	13	\N	\N	\N	2026-08-31 20:50:01.551+00	\N	\N	\N	VN	\N	\N
3	ANTHONY DONAS	2	\N	\N	2026-09-30	2026-08-31 20:49:28.084+00	\N	2026-10-03 09:41:40.720136+00	92	VN	\N	\N
78	FLORENT THOMASSIN	13	\N	\N	\N	2026-08-31 20:50:02.833+00	\N	\N	\N	VN	\N	\N
79	ROMAIN BOISSONNADE	14	\N	\N	\N	2026-08-31 20:50:03.448+00	\N	\N	\N	VN	\N	\N
81	ALEXIS COMPANS	14	\N	\N	\N	2026-08-31 20:50:04.58+00	\N	\N	\N	VN	\N	\N
82	RÉMI DEGAND	14	\N	\N	\N	2026-08-31 20:50:05.428+00	\N	\N	\N	VN	\N	\N
83	ARNAUD LOPEZ	14	\N	\N	\N	2026-08-31 20:50:05.981+00	\N	\N	\N	VO	\N	\N
84	DORIAN FRANCE	14	\N	\N	\N	2026-08-31 20:50:06.106+00	\N	\N	\N	VO	\N	\N
85	DAMIEN RULHE	14	\N	\N	\N	2026-08-31 20:50:06.263+00	\N	\N	\N	VO	\N	\N
89	DORIAN ALLEGRE	16	\N	\N	\N	2026-08-31 20:50:08.199+00	\N	\N	\N	VN	\N	\N
90	MATIS BRUNO	16	\N	\N	\N	2026-08-31 20:50:08.719+00	\N	\N	\N	VN	\N	\N
92	YOHAN BANYIK	17	\N	\N	\N	2026-08-31 20:50:09.915+00	\N	\N	\N	VN	\N	\N
93	ROMAIN COMBOURIEU	17	\N	\N	\N	2026-08-31 20:50:10.608+00	\N	\N	\N	VN	\N	\N
1	QUENTIN VANINI	1	\N	\N	2026-08-01	2026-08-31 20:49:26.552+00	\N	2026-09-01 16:15:23.629754+00	92	VN	\N	\N
64	JULIEN MONATTE	11	\N	\N	2026-07-01	2026-08-31 20:49:55.371+00	\N	2026-09-02 09:28:21.242777+00	787	VN	\N	\N
882	JULIEN RAYNAL	9	\N	2026-08-17	\N	2026-09-02 09:29:00.167354+00	787	2026-09-02 09:29:00.167354+00	787	VO	\N	\N
88	ELSA AGRINIER	15	\N	\N	2026-09-01	2026-08-31 20:50:07.65+00	\N	2026-09-04 09:40:02.976243+00	1	VN	\N	\N
86	NICOLAS CAYRON	15	\N	\N	2026-09-01	2026-08-31 20:50:06.406+00	\N	2026-09-04 09:40:10.368376+00	1	VN	\N	\N
87	MATHIS FRANCOIS	15	\N	\N	\N	2026-08-31 20:50:06.987+00	\N	2026-09-04 09:40:53.277466+00	1	VN	\N	\N
46	JULIEN LE QUELLEC	7	\N	\N	2026-08-31	2026-08-31 20:49:47.699+00	\N	2026-09-07 16:51:38.951157+00	92	VO	\N	\N
45	PAULINE COIGNET	7	\N	\N	2026-08-31	2026-08-31 20:49:47.57+00	\N	2026-09-07 16:53:14.731361+00	92	VO	\N	\N
52	ALEXANDRE PINOT	8	\N	\N	2026-08-31	2026-08-31 20:49:49.924+00	\N	2026-09-08 09:44:12.07912+00	92	VO	\N	\N
37	VIKTORIIA BONDARENKO	6	\N	\N	2026-08-31	2026-08-31 20:49:44.723+00	\N	2026-09-07 16:54:36.73063+00	92	VN	\N	\N
71	CHRISTIAN CAUQUIL	12	\N	\N	\N	2026-08-31 20:49:58.351+00	\N	2026-09-08 14:14:01.710692+00	1784	VN	\N	\N
59	JÉRÉMY DA COSTA	10	\N	\N	\N	2026-08-31 20:49:52.699+00	\N	2026-10-05 07:41:32.262445+00	1786	VN	\N	\N
32	MICHEL GUILLERM	6	\N	\N	\N	2026-08-31 20:49:41.815+00	\N	2026-10-05 07:41:05.794626+00	1786	VN	\N	\N
42	SYLVETTE ROGUE	7	\N	\N	\N	2026-08-31 20:49:45.97+00	\N	2026-10-05 07:40:55.695144+00	1786	VN	\N	\N
43	SEBASTIEN DUBOST	7	\N	\N	\N	2026-08-31 20:49:46.529+00	\N	2026-10-05 07:40:51.504831+00	1786	VN	\N	\N
60	DYLAN NOGUEIRA	10	\N	\N	\N	2026-08-31 20:49:53.289+00	\N	2026-10-05 07:41:28.239913+00	1786	VN	\N	\N
44	MARC PALUMBO	7	\N	\N	\N	2026-08-31 20:49:47.037+00	\N	2026-10-05 07:40:46.949698+00	1786	VN	\N	\N
94	STÉPHANE SUC	17	\N	\N	\N	2026-08-31 20:50:11.145+00	\N	\N	\N	VN	\N	\N
95	ANTONIN LUC	17	\N	\N	\N	2026-08-31 20:50:11.84+00	\N	\N	\N	VN	\N	\N
96	MAGALI BRUGIER	18	\N	\N	\N	2026-08-31 20:50:12.458+00	\N	\N	\N	VN	\N	\N
97	THOMAS BERT	18	\N	\N	\N	2026-08-31 20:50:13.438+00	\N	\N	\N	VN	\N	\N
9	MATTHIAS VALLE	2	\N	\N	2026-10-01	2026-08-31 20:49:31.515+00	\N	2026-10-03 09:42:07.684826+00	92	VO	\N	\N
7	UGO FERVEL	2	\N	\N	2026-08-31	2026-08-31 20:49:30.651+00	\N	2026-09-01 15:39:00.971629+00	92	VN	\N	\N
70	LENAIC FRANCOIS	11	\N	\N	\N	2026-08-31 20:49:58.198+00	\N	2026-09-02 09:32:30.62226+00	787	VO	\N	\N
1886	Florian HELOIRE	14	\N	2026-09-01	\N	2026-09-04 09:41:48.853076+00	1	2026-09-04 09:41:48.853076+00	1	VN	\N	\N
80	MARINE FLAUJAGUET	14	\N	\N	\N	2026-08-31 20:50:03.969+00	\N	2026-09-04 09:41:57.153009+00	1	VN	\N	\N
98	AZIZ CHOUAY	18	\N	\N	\N	2026-08-31 20:50:14.021+00	\N	\N	\N	VO	2026-09-04 09:42:32.67308+00	1
38	NICOLAS BOUCHET	6	\N	\N	2026-08-31	2026-08-31 20:49:45.35+00	\N	2026-09-07 16:54:25.327233+00	92	VO	\N	\N
211	PASCAL TABOULOT	3	\N	\N	\N	2026-09-01 16:12:42.508485+00	92	2026-09-01 16:12:42.508485+00	92	VO	\N	\N
212	DAMIEN TERRASSE	3	\N	\N	\N	2026-09-01 16:13:00.762443+00	92	2026-09-01 16:13:00.762443+00	92	VO	\N	\N
213	PIERRE PASSARELLI	3	\N	\N	\N	2026-09-01 16:13:19.46982+00	92	2026-09-01 16:13:19.46982+00	92	VO	\N	\N
214	QUENTIN OLIVO	3	\N	\N	\N	2026-09-01 16:13:43.970975+00	92	2026-09-01 16:13:43.970975+00	92	VO	\N	\N
215	FABIEN DELPUECH	3	\N	\N	\N	2026-09-01 16:14:02.900871+00	92	2026-09-01 16:14:02.900871+00	92	VO	\N	\N
4205	PAULINE COIGNET	7	\N	\N	\N	2026-10-05 07:33:08.523953+00	1786	2026-10-05 07:33:08.523953+00	1786	VO	\N	\N
1888	Aziz CHOUAY	710	\N	2026-09-08	\N	2026-09-08 10:06:53.168488+00	1784	2026-09-08 10:06:53.168488+00	1784	VO	2026-09-08 10:07:02.351077+00	1784
1889	Aziz CHOUAY	18	\N	2026-09-08	\N	2026-09-08 10:07:18.641531+00	1784	2026-09-08 10:07:18.641531+00	1784	VO	\N	\N
99	GEOFFREY SALGUES	13	\N	\N	\N	2026-08-31 20:50:14.173+00	\N	2026-09-08 14:13:31.024597+00	1784	VN	\N	\N
1890	Lolita ENGUIX	15	\N	\N	\N	2026-09-08 14:32:03.736085+00	1784	2026-09-08 14:32:03.736085+00	1784	VO	\N	\N
1887	ALEXANDRE  PINOT	8	\N	\N	\N	2026-09-08 09:44:52.268276+00	92	2026-09-08 09:44:52.268276+00	92	VO	2026-10-05 07:33:48.595025+00	1786
66	AMÉLIE HERVÉ	11	\N	\N	2026-10-05	2026-08-31 20:49:56.498+00	\N	2026-10-05 07:34:50.847462+00	1786	VN	\N	\N
33	ALEXANDRE DIOT	6	\N	\N	\N	2026-08-31 20:49:42.493+00	\N	2026-10-05 07:40:11.056772+00	1786	VN	\N	\N
159	EMMA GUENGEN	13	\N	\N	2026-09-01	2026-09-01 08:36:23.102009+00	10	2026-09-04 09:30:54.305402+00	1	VN	\N	\N
5767	DAN HEDIN	12	\N	2026-10-07	\N	2026-10-07 07:49:40.744978+00	1784	2026-10-07 07:49:51.235178+00	1784	VO	\N	\N
881	ADRIEN BRISSARD	11	\N	2026-11-01	\N	2026-09-02 09:28:07.716215+00	787	2026-09-08 15:21:24.695076+00	787	VN	2026-09-08 15:41:15.60847+00	787
5769	Malik ABDESSELAM	12	\N	2026-10-07	\N	2026-10-07 07:50:36.535466+00	1784	2026-10-07 07:50:36.535466+00	1784	VO	\N	\N
91	CLÉMENT MALGOUZOU	16	\N	\N	2026-09-01	2026-08-31 20:50:09.313+00	\N	2026-09-04 09:34:40.704556+00	1	VN	\N	\N
77	EMMA GUEGUEN	13	\N	\N	\N	2026-08-31 20:50:02.201+00	\N	\N	\N	VN	2026-09-01 08:35:38.146573+00	10
20	PIERRE-EDOUARD LAROCHE	3	\N	\N	2026-07-31	2026-08-31 20:49:37.667+00	\N	2026-09-01 15:33:51.776264+00	92	VN	\N	\N
160	BAPTISTE DUBOIS	2	\N	2026-09-01	\N	2026-09-01 15:35:17.590064+00	92	2026-10-03 09:41:53.406278+00	92	VN	\N	\N
1885	Clément CALVI	15	\N	2026-09-01	\N	2026-09-04 09:40:42.733882+00	1	2026-09-04 09:40:42.733882+00	1	VN	\N	\N
3217	ARTHUR MALLET	4	\N	2026-10-01	\N	2026-10-03 09:42:59.552745+00	92	2026-10-03 09:42:59.552745+00	92	VN	\N	\N
4206	THEO PARNIERE	7	\N	\N	\N	2026-10-05 07:33:25.581698+00	1786	2026-10-05 07:33:25.581698+00	1786	VO	\N	\N
63	STANISLAS RODAMEL	11	\N	\N	2026-10-05	2026-08-31 20:49:54.607+00	\N	2026-10-05 07:35:56.302632+00	1786	VN	\N	\N
5768	RAYANNE TERKI	12	\N	2026-10-07	\N	2026-10-07 07:50:09.870254+00	1784	2026-10-07 07:50:09.870254+00	1784	VO	\N	\N
5770	LAURENT NORE	5	\N	2026-09-30	\N	2026-10-07 08:46:50.021755+00	92	2026-10-07 08:46:50.021755+00	92	VN	\N	\N
3215	FABRICE MILLET	3	\N	2026-09-21	\N	2026-10-03 09:38:26.379372+00	92	2026-10-03 09:40:07.260042+00	92	VN	\N	\N
3216	GAËTAN THOMASSIN	1	\N	2026-10-01	\N	2026-10-03 09:41:15.959822+00	92	2026-10-03 09:41:15.959822+00	92	VO	\N	\N
\.


--
-- Data for Name: vendeur_marque; Type: TABLE DATA; Schema: relance; Owner: -
--

COPY relance.vendeur_marque (vendeur_id, marque_id, cree_le, cree_par) FROM stdin;
2	1	2026-08-31 20:49:27.576+00	\N
2	2	2026-08-31 20:49:27.817+00	\N
4	1	2026-08-31 20:49:28.848+00	\N
4	2	2026-08-31 20:49:29.057+00	\N
5	1	2026-08-31 20:49:29.425+00	\N
5	2	2026-08-31 20:49:29.849+00	\N
6	1	2026-08-31 20:49:30.181+00	\N
6	2	2026-08-31 20:49:30.406+00	\N
3	1	2026-10-03 09:41:40.720136+00	92
3	2	2026-10-03 09:41:40.720136+00	92
10	1	2026-08-31 20:49:31.686+00	\N
10	2	2026-08-31 20:49:31.899+00	\N
11	1	2026-08-31 20:49:32.21+00	\N
11	2	2026-08-31 20:49:32.555+00	\N
12	1	2026-08-31 20:49:33.14+00	\N
12	2	2026-08-31 20:49:33.353+00	\N
3217	1	2026-10-03 09:42:59.552745+00	92
3217	2	2026-10-03 09:42:59.552745+00	92
14	1	2026-08-31 20:49:34.32+00	\N
14	2	2026-08-31 20:49:34.514+00	\N
15	1	2026-08-31 20:49:34.897+00	\N
15	2	2026-08-31 20:49:35.147+00	\N
16	1	2026-08-31 20:49:35.436+00	\N
16	2	2026-08-31 20:49:35.67+00	\N
17	1	2026-08-31 20:49:35.95+00	\N
17	2	2026-08-31 20:49:36.162+00	\N
18	1	2026-08-31 20:49:36.514+00	\N
18	2	2026-08-31 20:49:36.777+00	\N
19	1	2026-08-31 20:49:37.136+00	\N
19	2	2026-08-31 20:49:37.39+00	\N
4204	1	2026-10-05 07:32:37.051363+00	1786
4204	2	2026-10-05 07:32:37.051363+00	1786
26	1	2026-08-31 20:49:39.08+00	\N
26	2	2026-08-31 20:49:39.323+00	\N
27	1	2026-08-31 20:49:39.68+00	\N
27	2	2026-08-31 20:49:39.91+00	\N
29	3	2026-08-31 20:49:40.443+00	\N
30	3	2026-08-31 20:49:40.765+00	\N
34	1	2026-08-31 20:49:43.091+00	\N
34	2	2026-08-31 20:49:43.328+00	\N
35	1	2026-08-31 20:49:43.609+00	\N
35	2	2026-08-31 20:49:43.877+00	\N
36	1	2026-08-31 20:49:44.219+00	\N
36	2	2026-08-31 20:49:44.449+00	\N
63	1	2026-10-05 07:35:56.302632+00	1786
63	2	2026-10-05 07:35:56.302632+00	1786
48	1	2026-08-31 20:49:47.996+00	\N
48	2	2026-08-31 20:49:48.275+00	\N
49	1	2026-08-31 20:49:48.614+00	\N
49	2	2026-08-31 20:49:48.847+00	\N
50	1	2026-08-31 20:49:49.267+00	\N
50	2	2026-08-31 20:49:49.475+00	\N
53	1	2026-08-31 20:49:50.105+00	\N
53	2	2026-08-31 20:49:50.328+00	\N
54	1	2026-08-31 20:49:50.641+00	\N
54	2	2026-08-31 20:49:50.868+00	\N
55	1	2026-08-31 20:49:51.205+00	\N
55	2	2026-08-31 20:49:51.425+00	\N
56	1	2026-08-31 20:49:51.796+00	\N
56	2	2026-08-31 20:49:52.039+00	\N
62	1	2026-08-31 20:49:54.098+00	\N
62	2	2026-08-31 20:49:54.313+00	\N
65	1	2026-08-31 20:49:55.931+00	\N
65	2	2026-08-31 20:49:56.154+00	\N
67	1	2026-08-31 20:49:57.336+00	\N
67	2	2026-08-31 20:49:57.574+00	\N
33	1	2026-10-05 07:40:11.056772+00	1786
72	1	2026-08-31 20:49:59.067+00	\N
72	2	2026-08-31 20:49:59.385+00	\N
73	1	2026-08-31 20:49:59.724+00	\N
73	2	2026-08-31 20:49:59.974+00	\N
74	1	2026-08-31 20:50:00.315+00	\N
74	2	2026-08-31 20:50:00.598+00	\N
75	1	2026-08-31 20:50:01.028+00	\N
75	2	2026-08-31 20:50:01.244+00	\N
76	1	2026-08-31 20:50:01.606+00	\N
76	2	2026-08-31 20:50:01.846+00	\N
77	1	2026-08-31 20:50:02.246+00	\N
77	2	2026-08-31 20:50:02.52+00	\N
78	1	2026-08-31 20:50:02.879+00	\N
78	2	2026-08-31 20:50:03.174+00	\N
79	1	2026-08-31 20:50:03.49+00	\N
79	2	2026-08-31 20:50:03.714+00	\N
33	2	2026-10-05 07:40:11.056772+00	1786
44	1	2026-10-05 07:40:46.949698+00	1786
81	1	2026-08-31 20:50:04.644+00	\N
81	2	2026-08-31 20:50:05.177+00	\N
82	1	2026-08-31 20:50:05.473+00	\N
82	2	2026-08-31 20:50:05.709+00	\N
44	2	2026-10-05 07:40:46.949698+00	1786
43	1	2026-10-05 07:40:51.504831+00	1786
43	2	2026-10-05 07:40:51.504831+00	1786
42	2	2026-10-05 07:40:55.695144+00	1786
42	1	2026-10-05 07:40:55.695144+00	1786
32	2	2026-10-05 07:41:05.794626+00	1786
89	1	2026-08-31 20:50:08.248+00	\N
89	2	2026-08-31 20:50:08.454+00	\N
90	1	2026-08-31 20:50:08.761+00	\N
90	2	2026-08-31 20:50:08.973+00	\N
32	1	2026-10-05 07:41:05.794626+00	1786
5770	3	2026-10-07 08:46:50.021755+00	92
92	1	2026-08-31 20:50:09.99+00	\N
92	2	2026-08-31 20:50:10.24+00	\N
93	1	2026-08-31 20:50:10.656+00	\N
93	2	2026-08-31 20:50:10.896+00	\N
94	1	2026-08-31 20:50:11.207+00	\N
94	2	2026-08-31 20:50:11.464+00	\N
95	1	2026-08-31 20:50:11.899+00	\N
95	2	2026-08-31 20:50:12.155+00	\N
96	1	2026-08-31 20:50:12.494+00	\N
96	2	2026-08-31 20:50:12.721+00	\N
97	1	2026-08-31 20:50:13.51+00	\N
97	2	2026-08-31 20:50:13.721+00	\N
20	1	2026-09-01 15:33:51.776264+00	92
20	2	2026-09-01 15:33:51.776264+00	92
13	1	2026-09-01 15:38:04.770842+00	92
13	2	2026-09-01 15:38:04.770842+00	92
7	1	2026-09-01 15:39:00.971629+00	92
7	2	2026-09-01 15:39:00.971629+00	92
1	1	2026-09-01 16:15:23.629754+00	92
1	2	2026-09-01 16:15:23.629754+00	92
64	1	2026-09-02 09:28:21.242777+00	787
64	2	2026-09-02 09:28:21.242777+00	787
159	1	2026-09-04 09:30:54.305402+00	1
159	2	2026-09-04 09:30:54.305402+00	1
91	1	2026-09-04 09:34:40.704556+00	1
91	2	2026-09-04 09:34:40.704556+00	1
88	1	2026-09-04 09:40:02.976243+00	1
88	2	2026-09-04 09:40:02.976243+00	1
86	1	2026-09-04 09:40:10.368376+00	1
86	2	2026-09-04 09:40:10.368376+00	1
1885	1	2026-09-04 09:40:42.733882+00	1
87	2	2026-09-04 09:40:53.277466+00	1
1886	2	2026-09-04 09:41:48.853076+00	1
80	1	2026-09-04 09:41:57.153009+00	1
37	1	2026-09-07 16:54:36.73063+00	92
37	2	2026-09-07 16:54:36.73063+00	92
99	1	2026-09-08 14:13:31.024597+00	1784
99	2	2026-09-08 14:13:31.024597+00	1784
71	1	2026-09-08 14:14:01.710692+00	1784
71	2	2026-09-08 14:14:01.710692+00	1784
881	1	2026-09-08 15:21:24.695076+00	787
881	2	2026-09-08 15:21:24.695076+00	787
3215	1	2026-10-03 09:40:07.260042+00	92
3215	2	2026-10-03 09:40:07.260042+00	92
160	1	2026-10-03 09:41:53.406278+00	92
160	2	2026-10-03 09:41:53.406278+00	92
31	1	2026-10-05 07:31:25.681635+00	1786
31	2	2026-10-05 07:31:25.681635+00	1786
66	1	2026-10-05 07:34:50.847462+00	1786
66	2	2026-10-05 07:34:50.847462+00	1786
60	2	2026-10-05 07:41:28.239913+00	1786
60	1	2026-10-05 07:41:28.239913+00	1786
59	1	2026-10-05 07:41:32.262445+00	1786
59	2	2026-10-05 07:41:32.262445+00	1786
\.


--
-- Name: affectation_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.affectation_id_seq', 3436, true);


--
-- Name: campagne_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.campagne_id_seq', 2377, true);


--
-- Name: encadrement_site_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.encadrement_site_id_seq', 1469, true);


--
-- Name: journal_compte_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.journal_compte_id_seq', 101, true);


--
-- Name: marque_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.marque_id_seq', 78, true);


--
-- Name: mobilisation_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.mobilisation_id_seq', 22, true);


--
-- Name: objectif_vente_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.objectif_vente_id_seq', 9, true);


--
-- Name: plaque_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.plaque_id_seq', 1175, true);


--
-- Name: rdv_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.rdv_id_seq', 9796, true);


--
-- Name: role_campagne_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.role_campagne_id_seq', 25, true);


--
-- Name: session_plaque_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.session_plaque_id_seq', 1343, true);


--
-- Name: site_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.site_id_seq', 2442, true);


--
-- Name: table_phoning_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.table_phoning_id_seq', 1194, true);


--
-- Name: utilisateur_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.utilisateur_id_seq', 6057, true);


--
-- Name: vendeur_id_seq; Type: SEQUENCE SET; Schema: relance; Owner: -
--

SELECT pg_catalog.setval('relance.vendeur_id_seq', 6323, true);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: affectation affectation_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.affectation
    ADD CONSTRAINT affectation_pkey PRIMARY KEY (id);


--
-- Name: campagne_creneau campagne_creneau_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.campagne_creneau
    ADD CONSTRAINT campagne_creneau_pkey PRIMARY KEY (campagne_id, code);


--
-- Name: campagne_jour campagne_jour_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.campagne_jour
    ADD CONSTRAINT campagne_jour_pkey PRIMARY KEY (campagne_id, jour);


--
-- Name: campagne campagne_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.campagne
    ADD CONSTRAINT campagne_pkey PRIMARY KEY (id);


--
-- Name: encadrement_site encadrement_site_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.encadrement_site
    ADD CONSTRAINT encadrement_site_pkey PRIMARY KEY (id);


--
-- Name: journal_compte journal_compte_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.journal_compte
    ADD CONSTRAINT journal_compte_pkey PRIMARY KEY (id);


--
-- Name: marque marque_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.marque
    ADD CONSTRAINT marque_pkey PRIMARY KEY (id);


--
-- Name: mobilisation mobilisation_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.mobilisation
    ADD CONSTRAINT mobilisation_pkey PRIMARY KEY (id);


--
-- Name: objectif_vente objectif_vente_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.objectif_vente
    ADD CONSTRAINT objectif_vente_pkey PRIMARY KEY (id);


--
-- Name: plaque plaque_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.plaque
    ADD CONSTRAINT plaque_pkey PRIMARY KEY (id);


--
-- Name: rdv rdv_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.rdv
    ADD CONSTRAINT rdv_pkey PRIMARY KEY (id);


--
-- Name: rdv_suivi rdv_suivi_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.rdv_suivi
    ADD CONSTRAINT rdv_suivi_pkey PRIMARY KEY (rdv_id);


--
-- Name: role_campagne role_campagne_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.role_campagne
    ADD CONSTRAINT role_campagne_pkey PRIMARY KEY (id);


--
-- Name: role_global role_global_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.role_global
    ADD CONSTRAINT role_global_pkey PRIMARY KEY (utilisateur_id, role);


--
-- Name: session_plaque session_plaque_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.session_plaque
    ADD CONSTRAINT session_plaque_pkey PRIMARY KEY (id);


--
-- Name: site site_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.site
    ADD CONSTRAINT site_pkey PRIMARY KEY (id);


--
-- Name: table_phoning table_phoning_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.table_phoning
    ADD CONSTRAINT table_phoning_pkey PRIMARY KEY (id);


--
-- Name: utilisateur utilisateur_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.utilisateur
    ADD CONSTRAINT utilisateur_pkey PRIMARY KEY (id);


--
-- Name: vendeur_marque vendeur_marque_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.vendeur_marque
    ADD CONSTRAINT vendeur_marque_pkey PRIMARY KEY (vendeur_id, marque_id);


--
-- Name: vendeur vendeur_pkey; Type: CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.vendeur
    ADD CONSTRAINT vendeur_pkey PRIMARY KEY (id);


--
-- Name: affectation_table_id_vendeur_id_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX affectation_table_id_vendeur_id_key ON relance.affectation USING btree (table_id, vendeur_id);


--
-- Name: affectation_vendeur_id_idx; Type: INDEX; Schema: relance; Owner: -
--

CREATE INDEX affectation_vendeur_id_idx ON relance.affectation USING btree (vendeur_id);


--
-- Name: campagne_libelle_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX campagne_libelle_key ON relance.campagne USING btree (libelle);


--
-- Name: encadrement_site_site_role_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX encadrement_site_site_role_key ON relance.encadrement_site USING btree (site_id, role);


--
-- Name: encadrement_site_utilisateur_id_idx; Type: INDEX; Schema: relance; Owner: -
--

CREATE INDEX encadrement_site_utilisateur_id_idx ON relance.encadrement_site USING btree (utilisateur_id);


--
-- Name: journal_compte_cible_id_idx; Type: INDEX; Schema: relance; Owner: -
--

CREATE INDEX journal_compte_cible_id_idx ON relance.journal_compte USING btree (cible_id);


--
-- Name: marque_code_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX marque_code_key ON relance.marque USING btree (code);


--
-- Name: mobilisation_campagne_id_vendeur_id_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX mobilisation_campagne_id_vendeur_id_key ON relance.mobilisation USING btree (campagne_id, vendeur_id);


--
-- Name: mobilisation_vendeur_id_idx; Type: INDEX; Schema: relance; Owner: -
--

CREATE INDEX mobilisation_vendeur_id_idx ON relance.mobilisation USING btree (vendeur_id);


--
-- Name: objectif_vente_campagne_id_site_id_marque_id_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX objectif_vente_campagne_id_site_id_marque_id_key ON relance.objectif_vente USING btree (campagne_id, site_id, marque_id);


--
-- Name: plaque_libelle_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX plaque_libelle_key ON relance.plaque USING btree (libelle);


--
-- Name: rdv_campagne_id_jour_creneau_code_idx; Type: INDEX; Schema: relance; Owner: -
--

CREATE INDEX rdv_campagne_id_jour_creneau_code_idx ON relance.rdv USING btree (campagne_id, jour, creneau_code);


--
-- Name: rdv_campagne_id_vendeur_id_idx; Type: INDEX; Schema: relance; Owner: -
--

CREATE INDEX rdv_campagne_id_vendeur_id_idx ON relance.rdv USING btree (campagne_id, vendeur_id);


--
-- Name: rdv_cle_client_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX rdv_cle_client_key ON relance.rdv USING btree (cle_client);


--
-- Name: role_campagne_campagne_id_utilisateur_id_idx; Type: INDEX; Schema: relance; Owner: -
--

CREATE INDEX role_campagne_campagne_id_utilisateur_id_idx ON relance.role_campagne USING btree (campagne_id, utilisateur_id);


--
-- Name: session_plaque_campagne_id_plaque_id_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX session_plaque_campagne_id_plaque_id_key ON relance.session_plaque USING btree (campagne_id, plaque_id);


--
-- Name: site_code_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX site_code_key ON relance.site USING btree (code);


--
-- Name: table_phoning_marque_id_idx; Type: INDEX; Schema: relance; Owner: -
--

CREATE INDEX table_phoning_marque_id_idx ON relance.table_phoning USING btree (marque_id);


--
-- Name: table_phoning_session_plaque_id_libelle_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX table_phoning_session_plaque_id_libelle_key ON relance.table_phoning USING btree (session_plaque_id, libelle);


--
-- Name: utilisateur_auth_uid_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX utilisateur_auth_uid_key ON relance.utilisateur USING btree (auth_uid);


--
-- Name: utilisateur_login_id_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX utilisateur_login_id_key ON relance.utilisateur USING btree (login_id);


--
-- Name: vendeur_site_id_idx; Type: INDEX; Schema: relance; Owner: -
--

CREATE INDEX vendeur_site_id_idx ON relance.vendeur USING btree (site_id);


--
-- Name: vendeur_utilisateur_id_key; Type: INDEX; Schema: relance; Owner: -
--

CREATE UNIQUE INDEX vendeur_utilisateur_id_key ON relance.vendeur USING btree (utilisateur_id);


--
-- Name: affectation affectation_diffusion_ajout; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER affectation_diffusion_ajout AFTER INSERT ON relance.affectation REFERENCING NEW TABLE AS nouveaux FOR EACH STATEMENT EXECUTE FUNCTION relance.diffuser_tables();


--
-- Name: affectation affectation_diffusion_modif; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER affectation_diffusion_modif AFTER UPDATE ON relance.affectation REFERENCING NEW TABLE AS nouveaux FOR EACH STATEMENT EXECUTE FUNCTION relance.diffuser_tables();


--
-- Name: affectation affectation_marque_table; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER affectation_marque_table BEFORE INSERT OR UPDATE ON relance.affectation FOR EACH ROW EXECUTE FUNCTION relance.verifier_affectation_marque_table();


--
-- Name: affectation affectation_meme_plaque; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER affectation_meme_plaque BEFORE INSERT OR UPDATE ON relance.affectation FOR EACH ROW EXECUTE FUNCTION relance.verifier_affectation_meme_plaque();


--
-- Name: affectation affectation_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER affectation_pas_de_delete BEFORE DELETE ON relance.affectation FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: affectation affectation_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER affectation_tracabilite BEFORE INSERT ON relance.affectation FOR EACH ROW EXECUTE FUNCTION relance.tracer_creation();


--
-- Name: affectation affectation_unique_par_campagne; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER affectation_unique_par_campagne BEFORE INSERT OR UPDATE ON relance.affectation FOR EACH ROW EXECUTE FUNCTION relance.verifier_affectation_unique();


--
-- Name: affectation affectation_vendeur_present; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER affectation_vendeur_present BEFORE INSERT OR UPDATE ON relance.affectation FOR EACH ROW EXECUTE FUNCTION relance.verifier_affectation_presence();


--
-- Name: campagne campagne_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER campagne_pas_de_delete BEFORE DELETE ON relance.campagne FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: campagne campagne_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER campagne_tracabilite BEFORE INSERT ON relance.campagne FOR EACH ROW EXECUTE FUNCTION relance.tracer_creation();


--
-- Name: encadrement_site encadrement_site_compte_actif; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER encadrement_site_compte_actif BEFORE INSERT OR UPDATE ON relance.encadrement_site FOR EACH ROW EXECUTE FUNCTION relance.verifier_encadrant_actif();


--
-- Name: encadrement_site encadrement_site_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER encadrement_site_pas_de_delete BEFORE DELETE ON relance.encadrement_site FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: encadrement_site encadrement_site_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER encadrement_site_tracabilite BEFORE INSERT ON relance.encadrement_site FOR EACH ROW EXECUTE FUNCTION relance.tracer_creation();


--
-- Name: journal_compte journal_compte_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER journal_compte_pas_de_delete BEFORE DELETE ON relance.journal_compte FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: marque marque_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER marque_pas_de_delete BEFORE DELETE ON relance.marque FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: mobilisation mobilisation_horodatage; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER mobilisation_horodatage BEFORE UPDATE ON relance.mobilisation FOR EACH ROW EXECUTE FUNCTION relance.horodater_mobilisation();


--
-- Name: mobilisation mobilisation_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER mobilisation_pas_de_delete BEFORE DELETE ON relance.mobilisation FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: mobilisation mobilisation_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER mobilisation_tracabilite BEFORE INSERT ON relance.mobilisation FOR EACH ROW EXECUTE FUNCTION relance.tracer_creation();


--
-- Name: objectif_vente objectif_vente_horodatage; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER objectif_vente_horodatage BEFORE UPDATE ON relance.objectif_vente FOR EACH ROW EXECUTE FUNCTION relance.horodater_mobilisation();


--
-- Name: objectif_vente objectif_vente_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER objectif_vente_pas_de_delete BEFORE DELETE ON relance.objectif_vente FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: objectif_vente objectif_vente_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER objectif_vente_tracabilite BEFORE INSERT ON relance.objectif_vente FOR EACH ROW EXECUTE FUNCTION relance.tracer_creation();


--
-- Name: plaque plaque_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER plaque_pas_de_delete BEFORE DELETE ON relance.plaque FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: rdv rdv_campagne_ouverte; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER rdv_campagne_ouverte BEFORE INSERT OR DELETE OR UPDATE ON relance.rdv FOR EACH ROW EXECUTE FUNCTION relance.verifier_campagne_ouverte();


--
-- Name: rdv rdv_diffusion; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER rdv_diffusion AFTER INSERT OR UPDATE ON relance.rdv FOR EACH ROW EXECUTE FUNCTION relance.diffuser_rdv();


--
-- Name: rdv rdv_marque_autorisee; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER rdv_marque_autorisee BEFORE INSERT OR UPDATE OF vendeur_id, marque_id ON relance.rdv FOR EACH ROW EXECUTE FUNCTION relance.verifier_marque_autorisee();


--
-- Name: rdv rdv_marque_selon_metier; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER rdv_marque_selon_metier BEFORE INSERT OR UPDATE OF vendeur_id, marque_id ON relance.rdv FOR EACH ROW EXECUTE FUNCTION relance.verifier_marque_selon_metier();


--
-- Name: rdv rdv_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER rdv_pas_de_delete BEFORE DELETE ON relance.rdv FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: rdv_suivi rdv_suivi_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER rdv_suivi_pas_de_delete BEFORE DELETE ON relance.rdv_suivi FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: rdv_suivi rdv_suivi_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER rdv_suivi_tracabilite BEFORE INSERT OR UPDATE ON relance.rdv_suivi FOR EACH ROW EXECUTE FUNCTION relance.tracer_suivi();


--
-- Name: rdv rdv_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER rdv_tracabilite BEFORE INSERT OR UPDATE ON relance.rdv FOR EACH ROW EXECUTE FUNCTION relance.tracer_modification_rdv();


--
-- Name: rdv rdv_type_coherent; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER rdv_type_coherent BEFORE INSERT OR UPDATE OF vendeur_id, type_vehicule ON relance.rdv FOR EACH ROW EXECUTE FUNCTION relance.verifier_type_coherent();


--
-- Name: role_campagne role_campagne_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER role_campagne_tracabilite BEFORE INSERT ON relance.role_campagne FOR EACH ROW EXECUTE FUNCTION relance.tracer_creation();


--
-- Name: role_global role_global_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER role_global_tracabilite BEFORE INSERT ON relance.role_global FOR EACH ROW EXECUTE FUNCTION relance.tracer_creation();


--
-- Name: session_plaque session_plaque_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER session_plaque_pas_de_delete BEFORE DELETE ON relance.session_plaque FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: session_plaque session_plaque_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER session_plaque_tracabilite BEFORE INSERT ON relance.session_plaque FOR EACH ROW EXECUTE FUNCTION relance.tracer_creation();


--
-- Name: site site_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER site_pas_de_delete BEFORE DELETE ON relance.site FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: table_phoning table_phoning_diffusion_ajout; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER table_phoning_diffusion_ajout AFTER INSERT ON relance.table_phoning REFERENCING NEW TABLE AS nouveaux FOR EACH STATEMENT EXECUTE FUNCTION relance.diffuser_tables();


--
-- Name: table_phoning table_phoning_diffusion_modif; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER table_phoning_diffusion_modif AFTER UPDATE ON relance.table_phoning REFERENCING NEW TABLE AS nouveaux FOR EACH STATEMENT EXECUTE FUNCTION relance.diffuser_tables();


--
-- Name: table_phoning table_phoning_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER table_phoning_pas_de_delete BEFORE DELETE ON relance.table_phoning FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: table_phoning table_phoning_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER table_phoning_tracabilite BEFORE INSERT ON relance.table_phoning FOR EACH ROW EXECUTE FUNCTION relance.tracer_creation();


--
-- Name: utilisateur utilisateur_journal_actif; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER utilisateur_journal_actif AFTER UPDATE OF actif ON relance.utilisateur FOR EACH ROW EXECUTE FUNCTION relance.journaliser_actif();


--
-- Name: utilisateur utilisateur_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER utilisateur_pas_de_delete BEFORE DELETE ON relance.utilisateur FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: vendeur vendeur_dates_contre_rdv; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER vendeur_dates_contre_rdv BEFORE INSERT OR UPDATE ON relance.vendeur FOR EACH ROW EXECUTE FUNCTION relance.verifier_vendeur_dates_contre_rdv();


--
-- Name: vendeur vendeur_pas_de_delete; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER vendeur_pas_de_delete BEFORE DELETE ON relance.vendeur FOR EACH STATEMENT EXECUTE FUNCTION relance.interdire_suppression();


--
-- Name: vendeur vendeur_tracabilite; Type: TRIGGER; Schema: relance; Owner: -
--

CREATE TRIGGER vendeur_tracabilite BEFORE INSERT ON relance.vendeur FOR EACH ROW EXECUTE FUNCTION relance.tracer_creation();


--
-- Name: affectation affectation_table_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.affectation
    ADD CONSTRAINT affectation_table_id_fkey FOREIGN KEY (table_id) REFERENCES relance.table_phoning(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: affectation affectation_vendeur_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.affectation
    ADD CONSTRAINT affectation_vendeur_id_fkey FOREIGN KEY (vendeur_id) REFERENCES relance.vendeur(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: campagne_creneau campagne_creneau_campagne_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.campagne_creneau
    ADD CONSTRAINT campagne_creneau_campagne_id_fkey FOREIGN KEY (campagne_id) REFERENCES relance.campagne(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: campagne_jour campagne_jour_campagne_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.campagne_jour
    ADD CONSTRAINT campagne_jour_campagne_id_fkey FOREIGN KEY (campagne_id) REFERENCES relance.campagne(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: encadrement_site encadrement_site_site_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.encadrement_site
    ADD CONSTRAINT encadrement_site_site_id_fkey FOREIGN KEY (site_id) REFERENCES relance.site(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: encadrement_site encadrement_site_utilisateur_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.encadrement_site
    ADD CONSTRAINT encadrement_site_utilisateur_id_fkey FOREIGN KEY (utilisateur_id) REFERENCES relance.utilisateur(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: journal_compte journal_compte_cible_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.journal_compte
    ADD CONSTRAINT journal_compte_cible_id_fkey FOREIGN KEY (cible_id) REFERENCES relance.utilisateur(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: mobilisation mobilisation_campagne_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.mobilisation
    ADD CONSTRAINT mobilisation_campagne_id_fkey FOREIGN KEY (campagne_id) REFERENCES relance.campagne(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: mobilisation mobilisation_vendeur_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.mobilisation
    ADD CONSTRAINT mobilisation_vendeur_id_fkey FOREIGN KEY (vendeur_id) REFERENCES relance.vendeur(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: objectif_vente objectif_vente_campagne_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.objectif_vente
    ADD CONSTRAINT objectif_vente_campagne_id_fkey FOREIGN KEY (campagne_id) REFERENCES relance.campagne(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: objectif_vente objectif_vente_marque_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.objectif_vente
    ADD CONSTRAINT objectif_vente_marque_id_fkey FOREIGN KEY (marque_id) REFERENCES relance.marque(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: objectif_vente objectif_vente_site_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.objectif_vente
    ADD CONSTRAINT objectif_vente_site_id_fkey FOREIGN KEY (site_id) REFERENCES relance.site(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: rdv rdv_campagne_id_creneau_code_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.rdv
    ADD CONSTRAINT rdv_campagne_id_creneau_code_fkey FOREIGN KEY (campagne_id, creneau_code) REFERENCES relance.campagne_creneau(campagne_id, code) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: rdv rdv_campagne_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.rdv
    ADD CONSTRAINT rdv_campagne_id_fkey FOREIGN KEY (campagne_id) REFERENCES relance.campagne(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: rdv rdv_campagne_id_jour_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.rdv
    ADD CONSTRAINT rdv_campagne_id_jour_fkey FOREIGN KEY (campagne_id, jour) REFERENCES relance.campagne_jour(campagne_id, jour) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: rdv rdv_marque_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.rdv
    ADD CONSTRAINT rdv_marque_id_fkey FOREIGN KEY (marque_id) REFERENCES relance.marque(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: rdv_suivi rdv_suivi_rdv_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.rdv_suivi
    ADD CONSTRAINT rdv_suivi_rdv_id_fkey FOREIGN KEY (rdv_id) REFERENCES relance.rdv(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: rdv rdv_vendeur_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.rdv
    ADD CONSTRAINT rdv_vendeur_id_fkey FOREIGN KEY (vendeur_id) REFERENCES relance.vendeur(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: role_campagne role_campagne_campagne_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.role_campagne
    ADD CONSTRAINT role_campagne_campagne_id_fkey FOREIGN KEY (campagne_id) REFERENCES relance.campagne(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: role_campagne role_campagne_plaque_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.role_campagne
    ADD CONSTRAINT role_campagne_plaque_id_fkey FOREIGN KEY (plaque_id) REFERENCES relance.plaque(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: role_campagne role_campagne_site_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.role_campagne
    ADD CONSTRAINT role_campagne_site_id_fkey FOREIGN KEY (site_id) REFERENCES relance.site(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: role_campagne role_campagne_utilisateur_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.role_campagne
    ADD CONSTRAINT role_campagne_utilisateur_id_fkey FOREIGN KEY (utilisateur_id) REFERENCES relance.utilisateur(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: role_global role_global_utilisateur_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.role_global
    ADD CONSTRAINT role_global_utilisateur_id_fkey FOREIGN KEY (utilisateur_id) REFERENCES relance.utilisateur(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: session_plaque session_plaque_campagne_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.session_plaque
    ADD CONSTRAINT session_plaque_campagne_id_fkey FOREIGN KEY (campagne_id) REFERENCES relance.campagne(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: session_plaque session_plaque_plaque_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.session_plaque
    ADD CONSTRAINT session_plaque_plaque_id_fkey FOREIGN KEY (plaque_id) REFERENCES relance.plaque(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: site site_plaque_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.site
    ADD CONSTRAINT site_plaque_id_fkey FOREIGN KEY (plaque_id) REFERENCES relance.plaque(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: table_phoning table_phoning_chef_utilisateur_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.table_phoning
    ADD CONSTRAINT table_phoning_chef_utilisateur_id_fkey FOREIGN KEY (chef_utilisateur_id) REFERENCES relance.utilisateur(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: table_phoning table_phoning_marque_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.table_phoning
    ADD CONSTRAINT table_phoning_marque_id_fkey FOREIGN KEY (marque_id) REFERENCES relance.marque(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: table_phoning table_phoning_session_plaque_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.table_phoning
    ADD CONSTRAINT table_phoning_session_plaque_id_fkey FOREIGN KEY (session_plaque_id) REFERENCES relance.session_plaque(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vendeur_marque vendeur_marque_marque_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.vendeur_marque
    ADD CONSTRAINT vendeur_marque_marque_id_fkey FOREIGN KEY (marque_id) REFERENCES relance.marque(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: vendeur_marque vendeur_marque_vendeur_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.vendeur_marque
    ADD CONSTRAINT vendeur_marque_vendeur_id_fkey FOREIGN KEY (vendeur_id) REFERENCES relance.vendeur(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: vendeur vendeur_site_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.vendeur
    ADD CONSTRAINT vendeur_site_id_fkey FOREIGN KEY (site_id) REFERENCES relance.site(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: vendeur vendeur_utilisateur_id_fkey; Type: FK CONSTRAINT; Schema: relance; Owner: -
--

ALTER TABLE ONLY relance.vendeur
    ADD CONSTRAINT vendeur_utilisateur_id_fkey FOREIGN KEY (utilisateur_id) REFERENCES relance.utilisateur(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: _prisma_migrations; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance._prisma_migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: affectation; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.affectation ENABLE ROW LEVEL SECURITY;

--
-- Name: affectation affectation_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY affectation_creation ON relance.affectation FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: affectation affectation_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY affectation_lecture ON relance.affectation FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: affectation affectation_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY affectation_modification ON relance.affectation FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: campagne; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.campagne ENABLE ROW LEVEL SECURITY;

--
-- Name: campagne campagne_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_creation ON relance.campagne FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: campagne_creneau; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.campagne_creneau ENABLE ROW LEVEL SECURITY;

--
-- Name: campagne_creneau campagne_creneau_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_creneau_creation ON relance.campagne_creneau FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: campagne_creneau campagne_creneau_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_creneau_lecture ON relance.campagne_creneau FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: campagne_creneau campagne_creneau_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_creneau_modification ON relance.campagne_creneau FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: campagne_jour; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.campagne_jour ENABLE ROW LEVEL SECURITY;

--
-- Name: campagne_jour campagne_jour_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_jour_creation ON relance.campagne_jour FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: campagne_jour campagne_jour_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_jour_lecture ON relance.campagne_jour FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: campagne_jour campagne_jour_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_jour_modification ON relance.campagne_jour FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: campagne campagne_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_lecture ON relance.campagne FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: campagne campagne_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY campagne_modification ON relance.campagne FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: encadrement_site; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.encadrement_site ENABLE ROW LEVEL SECURITY;

--
-- Name: encadrement_site encadrement_site_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY encadrement_site_creation ON relance.encadrement_site FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs));


--
-- Name: encadrement_site encadrement_site_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY encadrement_site_lecture ON relance.encadrement_site FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: encadrement_site encadrement_site_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY encadrement_site_modification ON relance.encadrement_site FOR UPDATE TO authenticated USING (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs)) WITH CHECK (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs));


--
-- Name: journal_compte; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.journal_compte ENABLE ROW LEVEL SECURITY;

--
-- Name: journal_compte journal_compte_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY journal_compte_lecture ON relance.journal_compte FOR SELECT TO authenticated USING (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs));


--
-- Name: marque; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.marque ENABLE ROW LEVEL SECURITY;

--
-- Name: marque marque_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY marque_creation ON relance.marque FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: marque marque_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY marque_lecture ON relance.marque FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: marque marque_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY marque_modification ON relance.marque FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: mobilisation; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.mobilisation ENABLE ROW LEVEL SECURITY;

--
-- Name: mobilisation mobilisation_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY mobilisation_creation ON relance.mobilisation FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: mobilisation mobilisation_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY mobilisation_lecture ON relance.mobilisation FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: mobilisation mobilisation_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY mobilisation_modification ON relance.mobilisation FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: objectif_vente; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.objectif_vente ENABLE ROW LEVEL SECURITY;

--
-- Name: objectif_vente objectif_vente_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY objectif_vente_creation ON relance.objectif_vente FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: objectif_vente objectif_vente_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY objectif_vente_lecture ON relance.objectif_vente FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: objectif_vente objectif_vente_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY objectif_vente_modification ON relance.objectif_vente FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: plaque; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.plaque ENABLE ROW LEVEL SECURITY;

--
-- Name: plaque plaque_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY plaque_creation ON relance.plaque FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: plaque plaque_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY plaque_lecture ON relance.plaque FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: plaque plaque_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY plaque_modification ON relance.plaque FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: rdv; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.rdv ENABLE ROW LEVEL SECURITY;

--
-- Name: rdv rdv_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY rdv_creation ON relance.rdv FOR INSERT TO authenticated WITH CHECK ((( SELECT relance.peut_saisir(rdv.vendeur_id, rdv.campagne_id) AS peut_saisir) AND ( SELECT relance.campagne_ouverte(rdv.campagne_id) AS campagne_ouverte)));


--
-- Name: rdv rdv_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY rdv_lecture ON relance.rdv FOR SELECT TO authenticated USING (((campagne_id, vendeur_id) IN ( SELECT ps.campagne_id,
    ps.vendeur_id
   FROM relance.perimetre_saisie ps)));


--
-- Name: rdv rdv_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY rdv_modification ON relance.rdv FOR UPDATE TO authenticated USING ((( SELECT relance.peut_saisir(rdv.vendeur_id, rdv.campagne_id) AS peut_saisir) AND ( SELECT relance.campagne_ouverte(rdv.campagne_id) AS campagne_ouverte))) WITH CHECK ((( SELECT relance.peut_saisir(rdv.vendeur_id, rdv.campagne_id) AS peut_saisir) AND ( SELECT relance.campagne_ouverte(rdv.campagne_id) AS campagne_ouverte)));


--
-- Name: rdv_suivi; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.rdv_suivi ENABLE ROW LEVEL SECURITY;

--
-- Name: rdv_suivi rdv_suivi_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY rdv_suivi_creation ON relance.rdv_suivi FOR INSERT TO authenticated WITH CHECK ((EXISTS ( SELECT 1
   FROM (relance.rdv r
     JOIN relance.perimetre_suivi ps ON (((ps.vendeur_id = r.vendeur_id) AND (ps.campagne_id = r.campagne_id))))
  WHERE ((r.id = rdv_suivi.rdv_id) AND relance.campagne_ouverte(r.campagne_id)))));


--
-- Name: rdv_suivi rdv_suivi_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY rdv_suivi_lecture ON relance.rdv_suivi FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM (relance.rdv r
     JOIN relance.perimetre_suivi ps ON (((ps.vendeur_id = r.vendeur_id) AND (ps.campagne_id = r.campagne_id))))
  WHERE (r.id = rdv_suivi.rdv_id))));


--
-- Name: rdv_suivi rdv_suivi_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY rdv_suivi_modification ON relance.rdv_suivi FOR UPDATE TO authenticated USING ((EXISTS ( SELECT 1
   FROM (relance.rdv r
     JOIN relance.perimetre_suivi ps ON (((ps.vendeur_id = r.vendeur_id) AND (ps.campagne_id = r.campagne_id))))
  WHERE ((r.id = rdv_suivi.rdv_id) AND relance.campagne_ouverte(r.campagne_id))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM (relance.rdv r
     JOIN relance.perimetre_suivi ps ON (((ps.vendeur_id = r.vendeur_id) AND (ps.campagne_id = r.campagne_id))))
  WHERE ((r.id = rdv_suivi.rdv_id) AND relance.campagne_ouverte(r.campagne_id)))));


--
-- Name: role_campagne; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.role_campagne ENABLE ROW LEVEL SECURITY;

--
-- Name: role_campagne role_campagne_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY role_campagne_creation ON relance.role_campagne FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs));


--
-- Name: role_campagne role_campagne_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY role_campagne_lecture ON relance.role_campagne FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: role_campagne role_campagne_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY role_campagne_modification ON relance.role_campagne FOR UPDATE TO authenticated USING (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs)) WITH CHECK (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs));


--
-- Name: role_global; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.role_global ENABLE ROW LEVEL SECURITY;

--
-- Name: role_global role_global_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY role_global_creation ON relance.role_global FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs));


--
-- Name: role_global role_global_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY role_global_lecture ON relance.role_global FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: role_global role_global_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY role_global_modification ON relance.role_global FOR UPDATE TO authenticated USING (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs)) WITH CHECK (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs));


--
-- Name: session_plaque; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.session_plaque ENABLE ROW LEVEL SECURITY;

--
-- Name: session_plaque session_plaque_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY session_plaque_creation ON relance.session_plaque FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: session_plaque session_plaque_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY session_plaque_lecture ON relance.session_plaque FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: session_plaque session_plaque_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY session_plaque_modification ON relance.session_plaque FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: site; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.site ENABLE ROW LEVEL SECURITY;

--
-- Name: site site_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY site_creation ON relance.site FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: site site_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY site_lecture ON relance.site FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: site site_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY site_modification ON relance.site FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: table_phoning; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.table_phoning ENABLE ROW LEVEL SECURITY;

--
-- Name: table_phoning table_phoning_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY table_phoning_creation ON relance.table_phoning FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: table_phoning table_phoning_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY table_phoning_lecture ON relance.table_phoning FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: table_phoning table_phoning_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY table_phoning_modification ON relance.table_phoning FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: utilisateur; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.utilisateur ENABLE ROW LEVEL SECURITY;

--
-- Name: utilisateur utilisateur_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY utilisateur_creation ON relance.utilisateur FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs));


--
-- Name: utilisateur utilisateur_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY utilisateur_lecture ON relance.utilisateur FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: utilisateur utilisateur_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY utilisateur_modification ON relance.utilisateur FOR UPDATE TO authenticated USING (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs)) WITH CHECK (( SELECT relance.peut_gerer_utilisateurs() AS peut_gerer_utilisateurs));


--
-- Name: vendeur; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.vendeur ENABLE ROW LEVEL SECURITY;

--
-- Name: vendeur vendeur_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY vendeur_creation ON relance.vendeur FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: vendeur vendeur_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY vendeur_lecture ON relance.vendeur FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: vendeur_marque; Type: ROW SECURITY; Schema: relance; Owner: -
--

ALTER TABLE relance.vendeur_marque ENABLE ROW LEVEL SECURITY;

--
-- Name: vendeur_marque vendeur_marque_creation; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY vendeur_marque_creation ON relance.vendeur_marque FOR INSERT TO authenticated WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: vendeur_marque vendeur_marque_lecture; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY vendeur_marque_lecture ON relance.vendeur_marque FOR SELECT TO authenticated USING ((( SELECT relance.utilisateur_courant() AS utilisateur_courant) IS NOT NULL));


--
-- Name: vendeur_marque vendeur_marque_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY vendeur_marque_modification ON relance.vendeur_marque FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- Name: vendeur vendeur_modification; Type: POLICY; Schema: relance; Owner: -
--

CREATE POLICY vendeur_modification ON relance.vendeur FOR UPDATE TO authenticated USING (( SELECT relance.peut_administrer() AS peut_administrer)) WITH CHECK (( SELECT relance.peut_administrer() AS peut_administrer));


--
-- PostgreSQL database dump complete
--

\unrestrict W6A2mJtYwqpnHLYDn1ol8fKXB80vKsCvULUdREaIWpfkBLshStbJ0ffl1SHaezm

